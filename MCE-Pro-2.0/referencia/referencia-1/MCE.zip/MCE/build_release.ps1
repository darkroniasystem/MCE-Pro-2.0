[CmdletBinding()]
param(
    [switch]$SkipInstall
)

$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path $PSScriptRoot).Path
$python = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw 'No existe .venv\Scripts\python.exe. Prepare primero el entorno de desarrollo.'
}
if (-not $SkipInstall) {
    & $python -m pip install -e "${projectRoot}[build]"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
& $python -m PyInstaller --clean --noconfirm (Join-Path $projectRoot 'MCE.spec')
exit $LASTEXITCODE
