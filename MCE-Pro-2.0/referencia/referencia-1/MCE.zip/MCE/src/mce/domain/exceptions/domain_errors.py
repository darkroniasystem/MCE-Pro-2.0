"""Errores específicos e independientes de presentación."""


class DomainValidationError(ValueError):
    """Un valor viola una invariante del dominio."""


class InvalidIdentifierError(DomainValidationError):
    """Un identificador no tiene un UUID admitido."""


class InvalidStateTransitionError(DomainValidationError):
    """Una transición no pertenece a la máquina de estados."""


class InvalidYearError(DomainValidationError):
    """Un año queda fuera del rango aceptado."""


class InvalidConfidenceError(DomainValidationError):
    """Una confianza queda fuera de 0 a 100."""


class InvalidScanScopeError(DomainValidationError):
    """El alcance de escaneo es internamente incoherente."""


class FieldLockedError(DomainValidationError):
    """Una actualización intenta sobrescribir un campo bloqueado."""


class InvalidAvailabilityTransitionError(InvalidStateTransitionError):
    """Una transición de disponibilidad no está permitida."""


class InvalidContentRelationshipError(DomainValidationError):
    """Una relación obra-versión-temporada-archivo no es válida."""
