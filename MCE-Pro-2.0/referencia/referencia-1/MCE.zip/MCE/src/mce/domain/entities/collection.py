"""Saga o agrupación editorial, nunca una carpeta."""

from dataclasses import dataclass

from mce.domain._validation import require_text
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import CollectionId, ContentId
from mce.domain.value_objects.states import CollectionType, LifecycleStatus


@dataclass(frozen=True, slots=True)
class Collection(Serializable):
    """Agrupación editorial de contenidos."""

    collection_id: CollectionId
    name: str
    collection_type: CollectionType = CollectionType.OTHER
    status: LifecycleStatus = LifecycleStatus.ACTIVE
    content_ids: tuple[ContentId, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "name", require_text(self.name, "name"))
        if len(set(self.content_ids)) != len(self.content_ids):
            raise ValueError("collection content identifiers must be unique")
