"""Archivo físico observado por MSL, independiente de la obra lógica."""

from dataclasses import dataclass

from mce.domain._validation import optional_text, require_instance, require_text
from mce.domain.exceptions import DomainValidationError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.fingerprints import FileFingerprint
from mce.domain.value_objects.identifiers import (
    ContentId,
    ContentVersionId,
    PhysicalFileId,
    ScanId,
    SourceId,
)
from mce.domain.value_objects.paths import NormalizedPath
from mce.domain.value_objects.states import PhysicalFileStatus


@dataclass(frozen=True, slots=True)
class PhysicalFile(Serializable):
    """Archivo observado, identificable sin convertirse en una obra."""

    file_id: PhysicalFileId
    scan_id: ScanId
    source_id: SourceId
    original_name: str
    relative_path: str
    normalized_path: NormalizedPath
    extension: str
    fingerprint: FileFingerprint
    status: PhysicalFileStatus = PhysicalFileStatus.UNVERIFIED
    content_id: ContentId | None = None
    content_version_id: ContentVersionId | None = None
    size_bytes: int | None = None
    cryptographic_hash: str | None = None
    duration_seconds: float | None = None

    def __post_init__(self) -> None:
        require_instance(self.file_id, PhysicalFileId, "file_id")
        require_instance(self.scan_id, ScanId, "scan_id")
        require_instance(self.source_id, SourceId, "source_id")
        require_instance(self.normalized_path, NormalizedPath, "normalized_path")
        require_instance(self.fingerprint, FileFingerprint, "fingerprint")
        object.__setattr__(self, "original_name", require_text(self.original_name, "original_name"))
        relative_path = require_text(self.relative_path, "relative_path")
        if relative_path.startswith(("/", "\\")) or ":" in relative_path:
            raise DomainValidationError("relative_path must be relative")
        object.__setattr__(self, "relative_path", relative_path)
        extension = require_text(self.extension, "extension").lower()
        if not extension.startswith("."):
            extension = f".{extension}"
        object.__setattr__(self, "extension", extension)
        object.__setattr__(
            self, "cryptographic_hash", optional_text(self.cryptographic_hash, "cryptographic_hash")
        )
        if self.content_version_id is not None and self.content_id is None:
            raise DomainValidationError("a version link requires a primary content link")
        if self.size_bytes is not None and self.size_bytes < 0:
            raise DomainValidationError("size_bytes must be non-negative")
        if self.duration_seconds is not None and self.duration_seconds < 0:
            raise DomainValidationError("duration_seconds must be non-negative")

    @property
    def identified(self) -> bool:
        """Indica si existe un único vínculo principal con una obra."""
        return self.content_id is not None
