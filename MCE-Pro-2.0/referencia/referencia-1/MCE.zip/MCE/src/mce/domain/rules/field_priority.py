"""Prioridad pura de procedencias para futuras actualizaciones."""

from dataclasses import dataclass

from mce.domain.exceptions import FieldLockedError
from mce.domain.value_objects.confidence import ConfidenceScore
from mce.domain.value_objects.states import FieldSourceType, LockType

_PRIORITY: dict[FieldSourceType, int] = {
    FieldSourceType.MANUAL: 800,
    FieldSourceType.BANK_RULE: 600,
    FieldSourceType.CONFIRMED_ALIAS: 500,
    FieldSourceType.PROVIDER: 400,
    FieldSourceType.IMPORTED: 300,
    FieldSourceType.SYSTEM: 250,
    FieldSourceType.INFERRED: 200,
    FieldSourceType.AI_GENERATED: 100,
}


@dataclass(frozen=True, slots=True)
class FieldUpdateDecision:
    """Resultado explicable de comparar un valor actual y uno candidato."""

    allowed: bool
    reason: str


def decide_field_update(
    current_source: FieldSourceType,
    candidate_source: FieldSourceType,
    *,
    current_confidence: ConfidenceScore | None = None,
    candidate_confidence: ConfidenceScore | None = None,
    lock_type: LockType | None = None,
    raise_on_manual_lock: bool = False,
) -> FieldUpdateDecision:
    """Decide reemplazo por bloqueo, prioridad y confianza, sin mutar valores."""
    if lock_type is LockType.MANUAL and candidate_source is not FieldSourceType.MANUAL:
        if raise_on_manual_lock:
            raise FieldLockedError("manually locked fields reject automatic updates")
        return FieldUpdateDecision(False, "manual_lock")
    current_priority = _PRIORITY[current_source]
    candidate_priority = _PRIORITY[candidate_source]
    if candidate_priority > current_priority:
        return FieldUpdateDecision(True, "higher_provenance_priority")
    if candidate_priority < current_priority:
        return FieldUpdateDecision(False, "lower_provenance_priority")
    if candidate_confidence is None:
        return FieldUpdateDecision(False, "equal_priority_without_higher_confidence")
    if current_confidence is None or candidate_confidence > current_confidence:
        return FieldUpdateDecision(True, "higher_confidence")
    return FieldUpdateDecision(False, "confidence_not_higher")
