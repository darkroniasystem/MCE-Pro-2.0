"""Origen físico o lógico escaneado por una instalación."""

from dataclasses import dataclass

from mce.domain._validation import require_instance, require_text
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import InstallationId, SourceId
from mce.domain.value_objects.paths import NormalizedPath
from mce.domain.value_objects.states import LifecycleStatus, SourceType


@dataclass(frozen=True, slots=True)
class Source(Serializable):
    """Volumen, directorio o ubicación de red de una instalación."""

    source_id: SourceId
    installation_id: InstallationId
    source_type: SourceType
    display_name: str
    root_path: NormalizedPath
    status: LifecycleStatus = LifecycleStatus.ACTIVE

    def __post_init__(self) -> None:
        require_instance(self.source_id, SourceId, "source_id")
        require_instance(self.installation_id, InstallationId, "installation_id")
        require_instance(self.root_path, NormalizedPath, "root_path")
        object.__setattr__(self, "display_name", require_text(self.display_name, "display_name"))
