"""Excepciones públicas del dominio."""

from mce.domain.exceptions.domain_errors import (
    DomainValidationError,
    FieldLockedError,
    InvalidAvailabilityTransitionError,
    InvalidConfidenceError,
    InvalidContentRelationshipError,
    InvalidIdentifierError,
    InvalidScanScopeError,
    InvalidStateTransitionError,
    InvalidYearError,
)

__all__ = [
    "DomainValidationError",
    "FieldLockedError",
    "InvalidAvailabilityTransitionError",
    "InvalidConfidenceError",
    "InvalidContentRelationshipError",
    "InvalidIdentifierError",
    "InvalidScanScopeError",
    "InvalidStateTransitionError",
    "InvalidYearError",
]
