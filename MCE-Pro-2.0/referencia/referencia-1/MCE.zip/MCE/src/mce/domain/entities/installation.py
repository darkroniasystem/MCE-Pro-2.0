"""Instalación de MSL perteneciente a un banco."""

from dataclasses import dataclass
from datetime import datetime

from mce.domain._validation import optional_text, require_instance, require_text, require_utc
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import BankId, InstallationId
from mce.domain.value_objects.states import LifecycleStatus


@dataclass(frozen=True, slots=True)
class Installation(Serializable):
    """Instalación de MSL asociada a un banco."""

    installation_id: InstallationId
    bank_id: BankId
    name: str
    created_at: datetime
    machine_identifier: str | None = None
    status: LifecycleStatus = LifecycleStatus.ACTIVE

    def __post_init__(self) -> None:
        require_instance(self.installation_id, InstallationId, "installation_id")
        require_instance(self.bank_id, BankId, "bank_id")
        object.__setattr__(self, "name", require_text(self.name, "name"))
        object.__setattr__(
            self, "machine_identifier", optional_text(self.machine_identifier, "machine_identifier")
        )
        require_utc(self.created_at, "created_at")
