"""Versión editorial o comercial de una obra."""

from dataclasses import dataclass

from mce.domain._validation import optional_text, require_instance, require_text
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import ContentId, ContentVersionId


@dataclass(frozen=True, slots=True)
class ContentVersion(Serializable):
    """Edición editorial o comercial perteneciente a una obra."""

    version_id: ContentVersionId
    content_id: ContentId
    name: str
    edition_type: str | None = None
    language_variant: str | None = None
    notes: str | None = None

    def __post_init__(self) -> None:
        require_instance(self.version_id, ContentVersionId, "version_id")
        require_instance(self.content_id, ContentId, "content_id")
        object.__setattr__(self, "name", require_text(self.name, "name"))
        object.__setattr__(self, "edition_type", optional_text(self.edition_type, "edition_type"))
        object.__setattr__(
            self, "language_variant", optional_text(self.language_variant, "language_variant")
        )
        object.__setattr__(self, "notes", optional_text(self.notes, "notes"))
