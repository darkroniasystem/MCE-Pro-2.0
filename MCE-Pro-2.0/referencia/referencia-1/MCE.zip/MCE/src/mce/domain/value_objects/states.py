"""Enumeraciones centrales; las entidades no repiten cadenas de estado."""

from enum import StrEnum


class LifecycleStatus(StrEnum):
    """Ciclo de vida simple de entidades administrativas."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"


class ContentStatus(StrEnum):
    """Estado de publicación lógica de una obra."""

    PENDING = "pending"
    ACTIVE = "active"
    EXCLUDED = "excluded"
    ARCHIVED = "archived"
    LOGICALLY_DELETED = "logically_deleted"


class CatalogStage(StrEnum):
    """Capa persistente; publicar requiere el flujo atómico de la Fase 17."""

    STAGING = "staging"
    APPROVED = "approved"
    PUBLISHED = "published"


class IdentificationStatus(StrEnum):
    """Resultado actual de identificación de una obra o archivo."""

    UNPROCESSED = "unprocessed"
    IDENTIFIED = "identified"
    PROBABLE = "probable"
    AMBIGUOUS = "ambiguous"
    MANUAL = "manual"
    UNKNOWN = "unknown"
    EXCLUDED = "excluded"


class ReviewStatus(StrEnum):
    """Estado general de revisión humana."""

    NOT_REQUIRED = "not_required"
    PENDING = "pending"
    APPROVED = "approved"
    ACCEPTED = "approved"
    REJECTED = "rejected"
    CORRECTED = "corrected"


class PhysicalFileStatus(StrEnum):
    """Estado observado de un archivo físico."""

    PRESENT = "present"
    MISSING = "missing"
    MOVED = "moved"
    UNVERIFIED = "unverified"
    EXCLUDED = "excluded"


class AvailabilityStatus(StrEnum):
    """Estado de presencia de una disponibilidad."""

    AVAILABLE = "available"
    NOT_AVAILABLE = "not_available"
    UNAVAILABLE = "not_available"
    UNKNOWN = "unknown"
    ARCHIVED = "archived"


class ImportStatus(StrEnum):
    """Etapa de recepción y procesamiento de un escaneo."""

    RECEIVED = "received"
    VALIDATING = "validating"
    VALID = "valid"
    INVALID = "invalid"
    INCOMPATIBLE = "incompatible"
    DUPLICATE = "duplicate"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REVERTED = "reverted"


class JobStatus(StrEnum):
    """Estado ejecutable de un trabajo de procesamiento."""

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WAITING_INTERNET = "waiting_internet"
    WAITING_REVIEW = "waiting_review"


class SourceType(StrEnum):
    """Clase de origen escaneado."""

    LOCAL_VOLUME = "local_volume"
    LOCAL_DIRECTORY = "local_directory"
    NETWORK_SHARE = "network_share"
    NETWORK_DIRECTORY = "network_directory"
    UNKNOWN = "unknown"


class ScanStatus(StrEnum):
    """Resultado del escaneo realizado por MSL."""

    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ScanScopeType(StrEnum):
    """Modalidad del alcance declarado por un escaneo."""

    FULL = "full"
    PARTIAL = "partial"
    SELECTED_SOURCES = "selected_sources"
    SELECTED_PATHS = "selected_paths"


class FieldSourceType(StrEnum):
    """Procedencia semántica de un valor de metadatos."""

    IMPORTED = "imported"
    INFERRED = "inferred"
    BANK_RULE = "bank_rule"
    CONFIRMED_ALIAS = "confirmed_alias"
    PROVIDER = "provider"
    MANUAL = "manual"
    AI_GENERATED = "ai_generated"
    SYSTEM = "system"


class LockType(StrEnum):
    """Origen del bloqueo aplicado a un campo."""

    MANUAL = "manual"
    SYSTEM = "system"


class ReviewDecisionType(StrEnum):
    """Acciones posibles durante revisión manual."""

    ACCEPT_CANDIDATE = "accept_candidate"
    REJECT_CANDIDATE = "reject_candidate"
    SELECT_ALTERNATIVE = "select_alternative"
    CREATE_MANUAL_CONTENT = "create_manual_content"
    EXCLUDE = "exclude"
    MERGE = "merge"
    SPLIT = "split"
    CHANGE_TYPE = "change_type"
    SAVE_ALIAS = "save_alias"


class ConfidenceCategory(StrEnum):
    """Categoría legible de una confianza porcentual."""

    SAFE = "safe"
    PROBABLE = "probable"
    UNCERTAIN = "uncertain"
    LOW = "low"


class ConflictSeverity(StrEnum):
    """Impacto de una contradicción de metadatos."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class CollectionType(StrEnum):
    """Clase editorial de una colección."""

    SAGA = "saga"
    UNIVERSE = "universe"
    EDITORIAL = "editorial"
    OTHER = "other"
