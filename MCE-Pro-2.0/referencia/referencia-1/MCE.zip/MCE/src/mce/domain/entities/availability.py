"""Presencia de un archivo u obra en un banco y ubicación concreta."""

from dataclasses import dataclass, replace
from datetime import datetime

from mce.domain._validation import require_instance, require_utc
from mce.domain.exceptions import DomainValidationError
from mce.domain.rules.state_transitions import transition_availability
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import (
    AvailabilityId,
    BankId,
    ContentId,
    InstallationId,
    PhysicalFileId,
    ScanId,
    SourceId,
)
from mce.domain.value_objects.states import AvailabilityStatus


@dataclass(frozen=True, slots=True)
class Availability(Serializable):
    """Localización y estado temporal de un archivo u obra en un banco."""

    availability_id: AvailabilityId
    bank_id: BankId
    installation_id: InstallationId | None
    source_id: SourceId | None
    physical_file_id: PhysicalFileId | None
    content_id: ContentId | None
    status: AvailabilityStatus
    first_seen_at: datetime
    last_seen_at: datetime
    last_scan_id: ScanId

    def __post_init__(self) -> None:
        require_instance(self.availability_id, AvailabilityId, "availability_id")
        require_instance(self.bank_id, BankId, "bank_id")
        require_instance(self.last_scan_id, ScanId, "last_scan_id")
        require_utc(self.first_seen_at, "first_seen_at")
        require_utc(self.last_seen_at, "last_seen_at")
        if self.last_seen_at < self.first_seen_at:
            raise DomainValidationError("last_seen_at cannot precede first_seen_at")
        if self.physical_file_id is None and self.content_id is None:
            raise DomainValidationError("availability requires a physical file or content")

    def transition_to(
        self,
        target: AvailabilityStatus,
        *,
        explicit_restore: bool = False,
    ) -> "Availability":
        """Devuelve una disponibilidad con transición validada."""
        return replace(
            self,
            status=transition_availability(self.status, target, explicit_restore=explicit_restore),
        )
