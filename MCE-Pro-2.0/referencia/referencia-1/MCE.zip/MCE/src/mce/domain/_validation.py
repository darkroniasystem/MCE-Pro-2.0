"""Validadores compartidos sin dependencias externas."""

from datetime import datetime

from mce.domain.exceptions import DomainValidationError


def require_text(value: str, field_name: str) -> str:
    """Devuelve texto recortado o rechaza un valor vacío."""
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} must not be empty")
    return normalized


def optional_text(value: str | None, field_name: str) -> str | None:
    """Normaliza texto opcional manteniendo ``None``."""
    return None if value is None else require_text(value, field_name)


def require_utc(value: datetime, field_name: str) -> datetime:
    """Exige una fecha consciente de zona horaria y expresada en UTC."""
    if not isinstance(value, datetime):
        raise TypeError(f"{field_name} must be a datetime")
    offset = value.utcoffset()
    if value.tzinfo is None or offset is None:
        raise ValueError(f"{field_name} must include UTC timezone information")
    if offset.total_seconds() != 0:
        raise ValueError(f"{field_name} must be in UTC")
    return value


def require_non_negative(value: int, field_name: str) -> int:
    """Exige un entero mayor o igual a cero, excluyendo booleanos."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{field_name} must be an integer")
    if value < 0:
        raise ValueError(f"{field_name} must be non-negative")
    return value


def require_positive(value: int, field_name: str) -> int:
    """Exige un entero estrictamente positivo."""
    if require_non_negative(value, field_name) == 0:
        raise ValueError(f"{field_name} must be positive")
    return value


def require_instance[ValueT](value: object, expected: type[ValueT], field_name: str) -> ValueT:
    """Exige el tipo nominal indicado para proteger IDs y objetos de valor."""
    if not isinstance(value, expected):
        raise DomainValidationError(f"{field_name} must be a {expected.__name__}")
    return value
