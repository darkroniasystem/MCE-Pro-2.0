"""Decisión de revisión, distinta de una corrección de campo."""

from dataclasses import dataclass
from datetime import datetime

from mce.domain._validation import optional_text, require_text, require_utc
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import ReviewDecisionId
from mce.domain.value_objects.states import ReviewDecisionType


@dataclass(frozen=True, slots=True)
class ReviewDecision(Serializable):
    """Elección humana durante revisión, distinta de una corrección."""

    decision_id: ReviewDecisionId
    target_type: str
    target_id: str
    decision_type: ReviewDecisionType
    created_at: datetime
    candidate_reference: str | None = None
    reason: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "target_type", require_text(self.target_type, "target_type"))
        object.__setattr__(self, "target_id", require_text(self.target_id, "target_id"))
        object.__setattr__(
            self,
            "candidate_reference",
            optional_text(self.candidate_reference, "candidate_reference"),
        )
        object.__setattr__(self, "reason", optional_text(self.reason, "reason"))
        require_utc(self.created_at, "created_at")
