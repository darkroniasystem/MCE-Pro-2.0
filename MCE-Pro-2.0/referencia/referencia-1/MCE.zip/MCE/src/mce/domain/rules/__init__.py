"""Reglas puras del dominio, organizadas por responsabilidad."""
