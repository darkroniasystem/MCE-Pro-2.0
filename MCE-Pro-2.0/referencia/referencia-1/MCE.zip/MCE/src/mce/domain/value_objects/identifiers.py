"""Identificadores opacos y estables del dominio."""

from dataclasses import dataclass
from typing import Self
from uuid import UUID, uuid4

from mce.domain.exceptions import InvalidIdentifierError


@dataclass(frozen=True, slots=True)
class DomainId:
    """UUID canónico con igualdad nominal por tipo de identificador."""

    value: str

    def __post_init__(self) -> None:
        if not isinstance(self.value, str):
            raise TypeError("identifier value must be a string")
        try:
            parsed = UUID(self.value)
        except (ValueError, AttributeError) as exc:
            raise InvalidIdentifierError("identifier must be a valid UUID") from exc
        if parsed.version not in {4, 5, 7}:
            raise InvalidIdentifierError("identifier must use UUID version 4, 5 or 7")
        object.__setattr__(self, "value", str(parsed))

    @classmethod
    def new(cls) -> Self:
        """Crea un identificador UUID4 del tipo concreto."""
        return cls(str(uuid4()))

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True, slots=True)
class BankId(DomainId):
    """Identificador de banco."""


@dataclass(frozen=True, slots=True)
class InstallationId(DomainId):
    """Identificador de instalación."""


@dataclass(frozen=True, slots=True)
class SourceId(DomainId):
    """Identificador de fuente escaneada."""


@dataclass(frozen=True, slots=True)
class ScanId(DomainId):
    """Identificador de escaneo."""


@dataclass(frozen=True, slots=True)
class PhysicalFileId(DomainId):
    """Identificador de archivo físico."""


# Alias compatible con el contrato inicial de Fase 1.
FileId = PhysicalFileId


@dataclass(frozen=True, slots=True)
class SubtitleId(DomainId):
    """Identificador de subtítulo."""


@dataclass(frozen=True, slots=True)
class ContentId(DomainId):
    """Identificador de contenido lógico."""


@dataclass(frozen=True, slots=True)
class SeasonId(DomainId):
    """Identificador de temporada."""


@dataclass(frozen=True, slots=True)
class EpisodeId(DomainId):
    """Identificador de episodio."""


@dataclass(frozen=True, slots=True)
class CollectionId(DomainId):
    """Identificador de colección."""


@dataclass(frozen=True, slots=True)
class AvailabilityId(DomainId):
    """Identificador de disponibilidad."""


@dataclass(frozen=True, slots=True)
class JobId(DomainId):
    """Identificador de trabajo."""


@dataclass(frozen=True, slots=True)
class CorrectionId(DomainId):
    """Identificador de corrección."""


@dataclass(frozen=True, slots=True)
class ImportId(DomainId):
    """Identificador de recepción de un escaneo."""


@dataclass(frozen=True, slots=True)
class ContentVersionId(DomainId):
    """Identificador de versión editorial."""


@dataclass(frozen=True, slots=True)
class FieldLockId(DomainId):
    """Identificador de bloqueo de campo."""


@dataclass(frozen=True, slots=True)
class ReviewDecisionId(DomainId):
    """Identificador de decisión de revisión."""


@dataclass(frozen=True, slots=True)
class ExternalId(DomainId):
    """Identificador interno de una referencia externa."""
