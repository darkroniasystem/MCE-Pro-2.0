"""Punto reservado para contratos; Fase 1 no define adaptadores reales."""
