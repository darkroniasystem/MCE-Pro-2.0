"""Protección de un campo contra sobrescritura automática."""

from dataclasses import dataclass
from datetime import datetime

from mce.domain._validation import optional_text, require_text, require_utc
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import FieldLockId
from mce.domain.value_objects.states import LockType


@dataclass(frozen=True, slots=True)
class FieldLock(Serializable):
    """Bloqueo manual o de sistema de un campo concreto."""

    lock_id: FieldLockId
    target_type: str
    target_id: str
    field_name: str
    lock_type: LockType
    created_at: datetime
    reason: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "target_type", require_text(self.target_type, "target_type"))
        object.__setattr__(self, "target_id", require_text(self.target_id, "target_id"))
        object.__setattr__(self, "field_name", require_text(self.field_name, "field_name"))
        object.__setattr__(self, "reason", optional_text(self.reason, "reason"))
        require_utc(self.created_at, "created_at")
