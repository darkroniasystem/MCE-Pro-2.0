"""Máquinas de estado compartidas por las entidades."""

from collections.abc import Mapping
from enum import StrEnum

from mce.domain.exceptions import (
    InvalidAvailabilityTransitionError,
    InvalidStateTransitionError,
)
from mce.domain.value_objects.states import AvailabilityStatus, ImportStatus, JobStatus

JOB_TRANSITIONS: Mapping[JobStatus, frozenset[JobStatus]] = {
    JobStatus.PENDING: frozenset({JobStatus.RUNNING, JobStatus.CANCELLED}),
    JobStatus.RUNNING: frozenset(
        {
            JobStatus.PAUSED,
            JobStatus.WAITING_INTERNET,
            JobStatus.WAITING_REVIEW,
            JobStatus.COMPLETED,
            JobStatus.FAILED,
        }
    ),
    JobStatus.PAUSED: frozenset({JobStatus.RUNNING, JobStatus.CANCELLED}),
    JobStatus.WAITING_INTERNET: frozenset({JobStatus.RUNNING, JobStatus.CANCELLED}),
    JobStatus.WAITING_REVIEW: frozenset({JobStatus.RUNNING, JobStatus.CANCELLED}),
    JobStatus.FAILED: frozenset(),
    JobStatus.COMPLETED: frozenset(),
    JobStatus.CANCELLED: frozenset(),
}

IMPORT_TRANSITIONS: Mapping[ImportStatus, frozenset[ImportStatus]] = {
    ImportStatus.RECEIVED: frozenset({ImportStatus.VALIDATING, ImportStatus.DUPLICATE}),
    ImportStatus.VALIDATING: frozenset(
        {ImportStatus.VALID, ImportStatus.INVALID, ImportStatus.INCOMPATIBLE}
    ),
    ImportStatus.VALID: frozenset({ImportStatus.PROCESSING}),
    ImportStatus.PROCESSING: frozenset({ImportStatus.COMPLETED, ImportStatus.FAILED}),
    ImportStatus.COMPLETED: frozenset({ImportStatus.REVERTED}),
    ImportStatus.INVALID: frozenset(),
    ImportStatus.INCOMPATIBLE: frozenset(),
    ImportStatus.DUPLICATE: frozenset(),
    ImportStatus.FAILED: frozenset(),
    ImportStatus.REVERTED: frozenset(),
}

AVAILABILITY_TRANSITIONS: Mapping[AvailabilityStatus, frozenset[AvailabilityStatus]] = {
    AvailabilityStatus.UNKNOWN: frozenset(
        {
            AvailabilityStatus.AVAILABLE,
            AvailabilityStatus.NOT_AVAILABLE,
            AvailabilityStatus.ARCHIVED,
        }
    ),
    AvailabilityStatus.AVAILABLE: frozenset(
        {AvailabilityStatus.NOT_AVAILABLE, AvailabilityStatus.ARCHIVED}
    ),
    AvailabilityStatus.NOT_AVAILABLE: frozenset(
        {AvailabilityStatus.AVAILABLE, AvailabilityStatus.ARCHIVED}
    ),
    AvailabilityStatus.ARCHIVED: frozenset(),
}


def _transition[StateT: StrEnum](
    current: StateT,
    target: StateT,
    transitions: Mapping[StateT, frozenset[StateT]],
    error_type: type[InvalidStateTransitionError] = InvalidStateTransitionError,
) -> StateT:
    if target not in transitions[current]:
        raise error_type(f"cannot transition from {current.value} to {target.value}")
    return target


def transition_job(current: JobStatus, target: JobStatus) -> JobStatus:
    """Valida una transición normal de trabajo."""
    return _transition(current, target, JOB_TRANSITIONS)


def prepare_job_retry(current: JobStatus) -> JobStatus:
    """Prepara explícitamente un trabajo fallido para un nuevo intento."""
    if current is not JobStatus.FAILED:
        raise InvalidStateTransitionError("only a failed job can be prepared for retry")
    return JobStatus.PENDING


def transition_import(current: ImportStatus, target: ImportStatus) -> ImportStatus:
    """Valida una transición de recepción de escaneo."""
    return _transition(current, target, IMPORT_TRANSITIONS)


def transition_availability(
    current: AvailabilityStatus,
    target: AvailabilityStatus,
    *,
    explicit_restore: bool = False,
) -> AvailabilityStatus:
    """Valida disponibilidad; restaurar un archivado exige acción explícita."""
    if current is AvailabilityStatus.ARCHIVED and target is AvailabilityStatus.AVAILABLE:
        if explicit_restore:
            return target
        raise InvalidAvailabilityTransitionError("archived availability requires explicit restore")
    return _transition(
        current, target, AVAILABILITY_TRANSITIONS, InvalidAvailabilityTransitionError
    )
