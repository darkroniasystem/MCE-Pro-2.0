"""Año de estreno validado."""

from dataclasses import dataclass

from mce.domain.exceptions import InvalidYearError


@dataclass(frozen=True, order=True, slots=True)
class ReleaseYear:
    """Año razonable desde el nacimiento del cine hasta un margen futuro."""

    value: int

    MINIMUM = 1878
    MAXIMUM = 2100

    def __post_init__(self) -> None:
        if isinstance(self.value, bool) or not isinstance(self.value, int):
            raise InvalidYearError("release year must be an integer")
        if not self.MINIMUM <= self.value <= self.MAXIMUM:
            raise InvalidYearError(
                f"release year must be between {self.MINIMUM} and {self.MAXIMUM}"
            )


Year = ReleaseYear
