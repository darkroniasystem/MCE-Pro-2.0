"""Huella lógica opcional de un archivo."""

from dataclasses import dataclass

from mce.domain._validation import optional_text, require_non_negative
from mce.domain.exceptions import DomainValidationError
from mce.domain.value_objects.identifiers import SourceId
from mce.domain.value_objects.paths import NormalizedPath


@dataclass(frozen=True, slots=True)
class FileFingerprint:
    """Evidencias disponibles para reconocer un archivo tras un movimiento."""

    source_id: SourceId | None = None
    normalized_relative_path: NormalizedPath | None = None
    size_bytes: int | None = None
    cryptographic_hash: str | None = None

    def __post_init__(self) -> None:
        if self.size_bytes is not None:
            require_non_negative(self.size_bytes, "size_bytes")
        digest = optional_text(self.cryptographic_hash, "cryptographic_hash")
        if digest is not None:
            digest = digest.lower()
            if len(digest) != 64 or any(
                character not in "0123456789abcdef" for character in digest
            ):
                raise DomainValidationError(
                    "cryptographic_hash must be a SHA-256 hexadecimal digest"
                )
        object.__setattr__(self, "cryptographic_hash", digest)
