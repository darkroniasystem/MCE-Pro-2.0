"""Tipos de contenido admitidos por el dominio."""

from enum import StrEnum


class ContentType(StrEnum):
    """Clasificación general de una obra multimedia."""

    MOVIE = "movie"
    SERIES = "series"
    NOVELA = "novela"
    ANIME = "anime"
    SOAP_OPERA = "novela"
    DORAMA = "dorama"
    DOCUMENTARY = "documentary"
    MINISERIES = "miniseries"
    TV_SHOW = "tv_show"
    WESTERN_ANIMATION = "western_animation"
    CONCERT = "concert"
    SPORTS = "sports"
    COURSE = "course"
    OTHER = "other"
    UNKNOWN = "unknown"

    @property
    def is_episodic(self) -> bool:
        """Indica si el tipo admite temporadas o episodios."""
        return self in {
            ContentType.SERIES,
            ContentType.NOVELA,
            ContentType.ANIME,
            ContentType.DORAMA,
            ContentType.MINISERIES,
            ContentType.TV_SHOW,
            ContentType.WESTERN_ANIMATION,
            ContentType.COURSE,
        }
