"""Cambio humano de un valor, separado de aceptar un candidato."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from mce.domain._validation import optional_text, require_text, require_utc
from mce.domain.exceptions import DomainValidationError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import CorrectionId


@dataclass(frozen=True, slots=True)
class Correction(Serializable):
    """Cambio manual auditable aplicado a un campo concreto."""

    correction_id: CorrectionId
    target_type: str
    target_id: str
    field_name: str
    old_value: Any
    new_value: Any
    created_at: datetime
    reason: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "target_type", require_text(self.target_type, "target_type"))
        object.__setattr__(self, "target_id", require_text(self.target_id, "target_id"))
        object.__setattr__(self, "field_name", require_text(self.field_name, "field_name"))
        object.__setattr__(self, "reason", optional_text(self.reason, "reason"))
        require_utc(self.created_at, "created_at")
        if self.old_value == self.new_value:
            raise DomainValidationError("a correction must change the value")
