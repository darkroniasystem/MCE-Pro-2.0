"""Escaneo producido por MSL, distinto de su recepción en MCE."""

from dataclasses import dataclass
from datetime import datetime

from mce.domain._validation import require_instance, require_text, require_utc
from mce.domain.exceptions import DomainValidationError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import InstallationId, ScanId
from mce.domain.value_objects.scan_scope import ScanScope
from mce.domain.value_objects.states import ScanStatus


@dataclass(frozen=True, slots=True)
class Scan(Serializable):
    """Escaneo realizado por MSL con alcance y fechas explícitos."""

    scan_id: ScanId
    installation_id: InstallationId
    started_at: datetime
    finished_at: datetime | None
    scope: ScanScope
    status: ScanStatus
    msl_version: str
    schema_version: str

    def __post_init__(self) -> None:
        require_instance(self.scan_id, ScanId, "scan_id")
        require_instance(self.installation_id, InstallationId, "installation_id")
        require_instance(self.scope, ScanScope, "scope")
        require_utc(self.started_at, "started_at")
        if self.finished_at is not None:
            require_utc(self.finished_at, "finished_at")
            if self.finished_at < self.started_at:
                raise DomainValidationError("finished_at cannot precede started_at")
        object.__setattr__(self, "msl_version", require_text(self.msl_version, "msl_version"))
        object.__setattr__(
            self, "schema_version", require_text(self.schema_version, "schema_version")
        )
