"""Modelo de dominio puro de MCE."""
