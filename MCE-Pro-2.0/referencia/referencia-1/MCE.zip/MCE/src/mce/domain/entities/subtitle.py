"""Archivo de subtítulo asociado opcionalmente a video, obra o episodio."""

from dataclasses import dataclass

from mce.domain._validation import optional_text
from mce.domain.exceptions import DomainValidationError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import ContentId, EpisodeId, PhysicalFileId, SubtitleId


@dataclass(frozen=True, slots=True)
class Subtitle(Serializable):
    """Subtítulo enlazable a archivo, obra o episodio."""

    subtitle_id: SubtitleId
    physical_file_id: PhysicalFileId | None = None
    content_id: ContentId | None = None
    episode_id: EpisodeId | None = None
    language: str | None = None
    format: str | None = None
    hearing_impaired: bool | None = None
    forced: bool | None = None

    def __post_init__(self) -> None:
        if self.physical_file_id is None and self.content_id is None and self.episode_id is None:
            raise DomainValidationError("subtitle requires at least one target")
        object.__setattr__(self, "language", optional_text(self.language, "language"))
        object.__setattr__(self, "format", optional_text(self.format, "format"))
