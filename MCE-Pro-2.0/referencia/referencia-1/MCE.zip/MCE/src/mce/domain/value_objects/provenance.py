"""Procedencia de valores de metadatos."""

from dataclasses import dataclass
from datetime import datetime

from mce.domain._validation import optional_text, require_utc
from mce.domain.value_objects.confidence import ConfidenceScore
from mce.domain.value_objects.states import FieldSourceType


@dataclass(frozen=True, slots=True)
class FieldProvenance:
    """Describe quién produjo un valor y con qué confianza."""

    source_type: FieldSourceType
    source_name: str | None
    external_reference: str | None
    obtained_at: datetime
    confidence: ConfidenceScore | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "source_name", optional_text(self.source_name, "source_name"))
        object.__setattr__(
            self,
            "external_reference",
            optional_text(self.external_reference, "external_reference"),
        )
        require_utc(self.obtained_at, "obtained_at")
