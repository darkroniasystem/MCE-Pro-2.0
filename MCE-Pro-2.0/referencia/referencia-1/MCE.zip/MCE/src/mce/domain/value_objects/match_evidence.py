"""Evidencia y conflictos para identificación futura."""

from dataclasses import dataclass
from typing import Any

from mce.domain._validation import require_text
from mce.domain.exceptions import DomainValidationError
from mce.domain.value_objects.provenance import FieldProvenance
from mce.domain.value_objects.states import ConflictSeverity


@dataclass(frozen=True, slots=True)
class MatchEvidence:
    """Razón ponderada a favor o en contra de una coincidencia."""

    evidence_type: str
    description: str
    weight: float
    source: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "evidence_type", require_text(self.evidence_type, "evidence_type"))
        object.__setattr__(self, "description", require_text(self.description, "description"))
        object.__setattr__(self, "source", require_text(self.source, "source"))
        if isinstance(self.weight, bool) or not isinstance(self.weight, (int, float)):
            raise DomainValidationError("weight must be numeric")
        if not -100 <= float(self.weight) <= 100:
            raise DomainValidationError("weight must be between -100 and 100")


@dataclass(frozen=True, slots=True)
class MetadataConflict:
    """Contradicción no resuelta entre dos procedencias."""

    field_name: str
    current_value: Any
    candidate_value: Any
    current_source: FieldProvenance
    candidate_source: FieldProvenance
    severity: ConflictSeverity
    description: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "field_name", require_text(self.field_name, "field_name"))
        object.__setattr__(self, "description", require_text(self.description, "description"))
