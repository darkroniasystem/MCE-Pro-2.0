"""Banco de copia o cliente administrado."""

from dataclasses import dataclass, replace
from datetime import datetime

from mce.domain._validation import optional_text, require_instance, require_text, require_utc
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import BankId
from mce.domain.value_objects.states import LifecycleStatus


@dataclass(frozen=True, slots=True)
class Bank(Serializable):
    """Banco de copia desactivable sin eliminación física."""

    bank_id: BankId
    name: str
    created_at: datetime
    status: LifecycleStatus = LifecycleStatus.ACTIVE
    code: str | None = None
    branch: str | None = None

    def __post_init__(self) -> None:
        require_instance(self.bank_id, BankId, "bank_id")
        object.__setattr__(self, "name", require_text(self.name, "name"))
        object.__setattr__(self, "code", optional_text(self.code, "code"))
        object.__setattr__(self, "branch", optional_text(self.branch, "branch"))
        require_utc(self.created_at, "created_at")

    def deactivate(self) -> "Bank":
        """Desactiva sin eliminar el banco."""
        return replace(self, status=LifecycleStatus.INACTIVE)
