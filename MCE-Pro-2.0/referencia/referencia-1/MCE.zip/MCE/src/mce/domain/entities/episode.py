"""Episodio normal, especial o con numeración absoluta."""

from dataclasses import dataclass

from mce.domain._validation import require_instance, require_non_negative
from mce.domain.exceptions import InvalidContentRelationshipError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.content_type import ContentType
from mce.domain.value_objects.identifiers import ContentId, EpisodeId, SeasonId
from mce.domain.value_objects.states import LifecycleStatus
from mce.domain.value_objects.title import Title


@dataclass(frozen=True, slots=True)
class Episode(Serializable):
    """Episodio perteneciente a contenido episódico."""

    episode_id: EpisodeId
    content_id: ContentId
    content_type: ContentType
    episode_number: int
    season_id: SeasonId | None = None
    absolute_number: int | None = None
    title: Title | None = None
    special: bool = False
    status: LifecycleStatus = LifecycleStatus.ACTIVE

    def __post_init__(self) -> None:
        require_instance(self.episode_id, EpisodeId, "episode_id")
        require_instance(self.content_id, ContentId, "content_id")
        require_non_negative(self.episode_number, "episode_number")
        if self.absolute_number is not None:
            require_non_negative(self.absolute_number, "absolute_number")
        if not self.content_type.is_episodic:
            raise InvalidContentRelationshipError("episode requires episodic content")
