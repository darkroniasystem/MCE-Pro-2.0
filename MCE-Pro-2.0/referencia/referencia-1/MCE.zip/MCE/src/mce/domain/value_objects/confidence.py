"""Confianza porcentual comparable."""

from dataclasses import dataclass

from mce.domain.exceptions import InvalidConfidenceError
from mce.domain.value_objects.states import ConfidenceCategory


@dataclass(frozen=True, order=True, slots=True)
class ConfidenceScore:
    """Puntuación inmutable entre 0 y 100."""

    value: float

    def __post_init__(self) -> None:
        if isinstance(self.value, bool) or not isinstance(self.value, (int, float)):
            raise InvalidConfidenceError("confidence must be numeric")
        numeric = float(self.value)
        if not 0.0 <= numeric <= 100.0:
            raise InvalidConfidenceError("confidence must be between 0 and 100")
        object.__setattr__(self, "value", numeric)

    @property
    def category(self) -> ConfidenceCategory:
        """Clasifica la puntuación sin depender de proveedores."""
        if self.value >= 90:
            return ConfidenceCategory.SAFE
        if self.value >= 75:
            return ConfidenceCategory.PROBABLE
        if self.value >= 50:
            return ConfidenceCategory.UNCERTAIN
        return ConfidenceCategory.LOW


Confidence = ConfidenceScore
