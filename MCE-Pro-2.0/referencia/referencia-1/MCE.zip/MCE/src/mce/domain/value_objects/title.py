"""Título no vacío de una obra."""

from dataclasses import dataclass

from mce.domain._validation import require_text


@dataclass(frozen=True, slots=True)
class Title:
    """Título Unicode que conserva el texto recibido y una vista recortada."""

    value: str
    original_value: str = ""

    def __post_init__(self) -> None:
        original = self.value
        object.__setattr__(self, "value", require_text(original, "title"))
        object.__setattr__(self, "original_value", original)

    def __str__(self) -> str:
        return self.value
