"""Obra multimedia lógica, nunca un archivo físico."""

from dataclasses import dataclass

from mce.domain._validation import require_instance
from mce.domain.exceptions import InvalidContentRelationshipError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.content_type import ContentType
from mce.domain.value_objects.identifiers import (
    ContentId,
    ContentVersionId,
    PhysicalFileId,
    SeasonId,
)
from mce.domain.value_objects.states import ContentStatus, IdentificationStatus, ReviewStatus
from mce.domain.value_objects.title import Title
from mce.domain.value_objects.year import ReleaseYear


@dataclass(frozen=True, slots=True)
class Content(Serializable):
    """Obra multimedia universal separada de versiones y archivos."""

    content_id: ContentId
    content_type: ContentType
    main_title: Title
    original_title: Title | None = None
    release_year: ReleaseYear | None = None
    status: ContentStatus = ContentStatus.PENDING
    identification_status: IdentificationStatus = IdentificationStatus.UNPROCESSED
    review_status: ReviewStatus = ReviewStatus.PENDING
    catalog_code: str | None = None
    version_ids: tuple[ContentVersionId, ...] = ()
    physical_file_ids: tuple[PhysicalFileId, ...] = ()
    season_ids: tuple[SeasonId, ...] = ()

    def __post_init__(self) -> None:
        require_instance(self.content_id, ContentId, "content_id")
        require_instance(self.main_title, Title, "main_title")
        for name, values in (
            ("version_ids", self.version_ids),
            ("physical_file_ids", self.physical_file_ids),
            ("season_ids", self.season_ids),
        ):
            if len(set(values)) != len(values):
                raise InvalidContentRelationshipError(f"{name} must contain unique identifiers")
        if self.season_ids and not self.content_type.is_episodic:
            raise InvalidContentRelationshipError("non-episodic content cannot contain seasons")
