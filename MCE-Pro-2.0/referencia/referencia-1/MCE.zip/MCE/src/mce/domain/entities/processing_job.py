"""Trabajo en memoria con progreso y transiciones controladas."""

from dataclasses import dataclass, replace
from datetime import datetime

from mce.domain._validation import optional_text, require_instance, require_utc
from mce.domain.exceptions import DomainValidationError, InvalidStateTransitionError
from mce.domain.rules.state_transitions import prepare_job_retry, transition_job
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import ImportId, JobId
from mce.domain.value_objects.states import JobStatus

InvalidJobTransition = InvalidStateTransitionError


@dataclass(frozen=True, slots=True)
class ProcessingJob(Serializable):
    """Unidad de procesamiento con estado, etapa y progreso validados."""

    job_id: JobId
    import_id: ImportId
    created_at: datetime
    status: JobStatus = JobStatus.PENDING
    current_stage: str | None = None
    progress: float = 0.0
    started_at: datetime | None = None
    completed_at: datetime | None = None
    failure_reason: str | None = None

    def __post_init__(self) -> None:
        require_instance(self.job_id, JobId, "job_id")
        require_instance(self.import_id, ImportId, "import_id")
        require_utc(self.created_at, "created_at")
        for field_name, value in (
            ("started_at", self.started_at),
            ("completed_at", self.completed_at),
        ):
            if value is not None:
                require_utc(value, field_name)
                if value < self.created_at:
                    raise DomainValidationError(f"{field_name} cannot precede created_at")
        if (
            self.started_at is not None
            and self.completed_at is not None
            and self.completed_at < self.started_at
        ):
            raise DomainValidationError("completed_at cannot precede started_at")
        if isinstance(self.progress, bool) or not isinstance(self.progress, (int, float)):
            raise DomainValidationError("progress must be numeric")
        if not 0 <= float(self.progress) <= 100:
            raise DomainValidationError("progress must be between 0 and 100")
        object.__setattr__(
            self, "current_stage", optional_text(self.current_stage, "current_stage")
        )
        object.__setattr__(
            self, "failure_reason", optional_text(self.failure_reason, "failure_reason")
        )
        if self.status is JobStatus.COMPLETED and self.completed_at is None:
            raise DomainValidationError("completed jobs require completed_at")
        if self.status is JobStatus.FAILED and self.failure_reason is None:
            raise DomainValidationError("failed jobs require failure_reason")

    def transition_to(
        self,
        target: JobStatus,
        *,
        at: datetime | None = None,
        failure_reason: str | None = None,
    ) -> "ProcessingJob":
        """Avanza el trabajo y exige datos explícitos para estados finales."""
        status = transition_job(self.status, target)
        started_at = self.started_at
        completed_at = self.completed_at
        reason = self.failure_reason
        progress = self.progress
        if target is JobStatus.RUNNING and started_at is None:
            if at is None:
                raise InvalidStateTransitionError(
                    "starting a job requires an explicit UTC timestamp"
                )
            require_utc(at, "started_at")
            started_at = at
        if target is JobStatus.COMPLETED:
            if at is None:
                raise InvalidStateTransitionError(
                    "completing a job requires an explicit UTC timestamp"
                )
            require_utc(at, "completed_at")
            completed_at = at
            progress = 100.0
        if target is JobStatus.FAILED:
            reason = optional_text(failure_reason, "failure_reason")
            if reason is None:
                raise InvalidStateTransitionError("failing a job requires a reason")
        return replace(
            self,
            status=status,
            started_at=started_at,
            completed_at=completed_at,
            failure_reason=reason,
            progress=progress,
        )

    def prepare_retry(self) -> "ProcessingJob":
        """Lleva explícitamente un trabajo fallido a pendiente."""
        return replace(
            self,
            status=prepare_job_retry(self.status),
            progress=0.0,
            current_stage=None,
            started_at=None,
            completed_at=None,
            failure_reason=None,
        )

    def with_progress(self, progress: float, stage: str) -> "ProcessingJob":
        """Actualiza progreso solo mientras el trabajo está ejecutándose."""
        if self.status is not JobStatus.RUNNING:
            raise InvalidStateTransitionError("progress can only change while a job is running")
        return replace(self, progress=progress, current_stage=stage)
