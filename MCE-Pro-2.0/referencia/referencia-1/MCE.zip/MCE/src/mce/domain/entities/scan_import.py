"""Recepción inmutable de un archivo JSON de MSL."""

from dataclasses import dataclass, replace
from datetime import datetime

from mce.domain._validation import require_instance, require_text, require_utc
from mce.domain.exceptions import DomainValidationError, InvalidStateTransitionError
from mce.domain.rules.state_transitions import transition_import
from mce.domain.serialization import Serializable
from mce.domain.value_objects.identifiers import BankId, ImportId, ScanId
from mce.domain.value_objects.states import ImportStatus


@dataclass(frozen=True, slots=True)
class ScanImport(Serializable):
    """Registro de recepción del JSON original dentro de MCE."""

    import_id: ImportId
    scan_id: ScanId
    bank_id: BankId
    original_filename: str
    file_hash: str
    received_at: datetime
    status: ImportStatus = ImportStatus.RECEIVED
    is_duplicate: bool = False
    reverted_at: datetime | None = None

    def __post_init__(self) -> None:
        require_instance(self.import_id, ImportId, "import_id")
        require_instance(self.scan_id, ScanId, "scan_id")
        require_instance(self.bank_id, BankId, "bank_id")
        object.__setattr__(
            self, "original_filename", require_text(self.original_filename, "original_filename")
        )
        digest = require_text(self.file_hash, "file_hash").lower()
        if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
            raise DomainValidationError("file_hash must be a SHA-256 hexadecimal digest")
        object.__setattr__(self, "file_hash", digest)
        require_utc(self.received_at, "received_at")
        if self.reverted_at is not None:
            require_utc(self.reverted_at, "reverted_at")
        if self.is_duplicate and self.status is not ImportStatus.DUPLICATE:
            raise DomainValidationError("duplicate imports must use duplicate status")
        if self.status is ImportStatus.REVERTED and self.reverted_at is None:
            raise DomainValidationError("reverted imports require reverted_at")

    def transition_to(self, target: ImportStatus, *, at: datetime | None = None) -> "ScanImport":
        """Avanza la importación según la máquina de estados central."""
        status = transition_import(self.status, target)
        reverted_at = self.reverted_at
        if target is ImportStatus.REVERTED:
            if at is None:
                raise InvalidStateTransitionError(
                    "reverting an import requires an explicit UTC timestamp"
                )
            require_utc(at, "reverted_at")
            reverted_at = at
        return replace(
            self,
            status=status,
            is_duplicate=target is ImportStatus.DUPLICATE,
            reverted_at=reverted_at,
        )
