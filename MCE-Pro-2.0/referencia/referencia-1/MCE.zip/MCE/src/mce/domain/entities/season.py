"""Temporada de una obra episódica."""

from dataclasses import dataclass

from mce.domain._validation import require_instance, require_non_negative
from mce.domain.exceptions import InvalidContentRelationshipError
from mce.domain.serialization import Serializable
from mce.domain.value_objects.content_type import ContentType
from mce.domain.value_objects.identifiers import ContentId, SeasonId
from mce.domain.value_objects.states import LifecycleStatus
from mce.domain.value_objects.title import Title


@dataclass(frozen=True, slots=True)
class Season(Serializable):
    """Temporada numerada de una obra episódica."""

    season_id: SeasonId
    content_id: ContentId
    content_type: ContentType
    season_number: int
    title: Title | None = None
    status: LifecycleStatus = LifecycleStatus.ACTIVE

    def __post_init__(self) -> None:
        require_instance(self.season_id, SeasonId, "season_id")
        require_instance(self.content_id, ContentId, "content_id")
        require_non_negative(self.season_number, "season_number")
        if not self.content_type.is_episodic:
            raise InvalidContentRelationshipError("season requires episodic content")
