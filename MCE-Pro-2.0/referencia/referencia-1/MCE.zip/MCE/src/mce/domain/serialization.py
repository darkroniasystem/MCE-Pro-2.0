"""Conversión estable de objetos de dominio a primitivas serializables."""

from dataclasses import fields, is_dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class Serializable:
    """Mixin para exponer una representación básica independiente de frameworks."""

    def to_dict(self) -> dict[str, Any]:
        """Convierte la instancia en un diccionario de primitivas JSON."""
        result = to_primitive(self)
        if not isinstance(result, dict):  # pragma: no cover - defensive invariant
            raise TypeError("serializable domain objects must produce a dictionary")
        return result


def to_primitive(value: Any) -> Any:
    """Convierte recursivamente valores del dominio a primitivas JSON."""
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, datetime):
        return value.isoformat().replace("+00:00", "Z")
    if hasattr(value, "value") and value.__class__.__module__.endswith("identifiers"):
        return value.value
    if is_dataclass(value):
        return {field.name: to_primitive(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, dict):
        return {str(key): to_primitive(item) for key, item in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [to_primitive(item) for item in value]
    return value
