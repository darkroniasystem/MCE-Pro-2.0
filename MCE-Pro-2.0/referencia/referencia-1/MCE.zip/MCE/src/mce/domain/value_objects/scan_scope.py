"""Alcance explícito de un escaneo."""

from dataclasses import dataclass

from mce.domain.exceptions import InvalidScanScopeError
from mce.domain.value_objects.identifiers import SourceId
from mce.domain.value_objects.paths import NormalizedPath
from mce.domain.value_objects.states import ScanScopeType


@dataclass(frozen=True, slots=True)
class ScanScope:
    """Describe qué fuentes o rutas están cubiertas por un escaneo."""

    scope_type: ScanScopeType
    source_ids: tuple[SourceId, ...] = ()
    included_paths: tuple[NormalizedPath, ...] = ()

    def __post_init__(self) -> None:
        if len(set(self.source_ids)) != len(self.source_ids):
            raise InvalidScanScopeError("scan scope source identifiers must be unique")
        if len(set(self.included_paths)) != len(self.included_paths):
            raise InvalidScanScopeError("scan scope paths must be unique")
        if self.scope_type is ScanScopeType.SELECTED_SOURCES and not self.source_ids:
            raise InvalidScanScopeError("selected_sources scope requires at least one source")
        if self.scope_type is ScanScopeType.SELECTED_PATHS and not self.included_paths:
            raise InvalidScanScopeError("selected_paths scope requires at least one path")
        if self.scope_type is ScanScopeType.FULL and self.included_paths:
            raise InvalidScanScopeError("full scope cannot be restricted to paths")

    @property
    def is_complete(self) -> bool:
        """Indica si cubre todo el alcance conocido de la instalación."""
        return self.scope_type is ScanScopeType.FULL

    def contains(self, source_id: SourceId, path: NormalizedPath | None = None) -> bool:
        """Decide si una fuente/ruta pertenece al alcance declarado."""
        if self.scope_type is ScanScopeType.FULL:
            return True
        if self.scope_type is ScanScopeType.PARTIAL:
            return source_id in self.source_ids
        if self.scope_type is ScanScopeType.SELECTED_SOURCES:
            return source_id in self.source_ids
        return path is not None and any(
            path.normalized == included.normalized
            or path.normalized.startswith(included.normalized.rstrip("\\") + "\\")
            for included in self.included_paths
        )
