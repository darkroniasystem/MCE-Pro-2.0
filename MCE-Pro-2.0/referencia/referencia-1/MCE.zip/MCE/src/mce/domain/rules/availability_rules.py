"""Decisiones puras sobre disponibilidad y alcance de escaneo."""

from dataclasses import replace
from datetime import datetime

from mce.domain.entities.availability import Availability
from mce.domain.entities.physical_file import PhysicalFile
from mce.domain.exceptions import InvalidAvailabilityTransitionError
from mce.domain.value_objects.identifiers import SourceId
from mce.domain.value_objects.paths import NormalizedPath
from mce.domain.value_objects.scan_scope import ScanScope
from mce.domain.value_objects.states import AvailabilityStatus, PhysicalFileStatus


def can_mark_not_available(
    scope: ScanScope,
    source_id: SourceId,
    path: NormalizedPath,
) -> bool:
    """Solo permite ausencia dentro del alcance confirmado del escaneo."""
    return scope.contains(source_id, path)


def can_publish_available(file: PhysicalFile) -> bool:
    """Un archivo excluido o ausente no puede anunciarse como disponible."""
    return file.status not in {PhysicalFileStatus.EXCLUDED, PhysicalFileStatus.MISSING}


def record_seen(availability: Availability, seen_at: datetime) -> Availability:
    """Conserva primera observación y avanza la última de forma inmutable."""
    if availability.status is AvailabilityStatus.ARCHIVED:
        raise InvalidAvailabilityTransitionError(
            "archived availability requires explicit restore before recording a sighting"
        )
    if seen_at < availability.first_seen_at:
        raise ValueError("last_seen_at cannot precede first_seen_at")
    return replace(
        availability,
        status=AvailabilityStatus.AVAILABLE,
        last_seen_at=seen_at,
    )
