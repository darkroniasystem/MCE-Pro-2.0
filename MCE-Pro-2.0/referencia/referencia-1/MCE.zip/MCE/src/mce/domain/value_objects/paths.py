"""Rutas de Windows comparables sin acceder al sistema de archivos."""

import ntpath
from dataclasses import dataclass

from mce.domain._validation import require_text


@dataclass(frozen=True, slots=True)
class NormalizedPath:
    """Conserva la ruta original y normaliza solo para comparación lógica."""

    original: str
    normalized: str = ""

    def __post_init__(self) -> None:
        original = require_text(self.original, "path")
        normalized = ntpath.normcase(ntpath.normpath(original)).replace("/", "\\")
        object.__setattr__(self, "original", original)
        object.__setattr__(self, "normalized", normalized)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, NormalizedPath) and self.normalized == other.normalized

    def __hash__(self) -> int:
        return hash(self.normalized)
