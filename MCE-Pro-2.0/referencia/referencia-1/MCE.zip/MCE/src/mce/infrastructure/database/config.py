"""Configuración segura de la conexión."""

import os

from sqlalchemy import Engine, create_engine


def database_url() -> str:
    """Lee la URL obligatoria sin incluir valores por defecto inseguros."""
    value = os.environ.get("MCE_DATABASE_URL")
    if not value:
        raise RuntimeError("MCE_DATABASE_URL is not configured")
    return value


def build_engine(url: str | None = None) -> Engine:
    """Crea el motor SQLAlchemy 2.x con comprobación de conexiones."""
    return create_engine(url or database_url(), pool_pre_ping=True)
