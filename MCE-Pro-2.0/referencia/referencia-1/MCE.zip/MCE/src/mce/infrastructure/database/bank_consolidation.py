"""Consolidación transaccional, conservadora y auditable de bancos históricos."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast
from uuid import NAMESPACE_URL, UUID, uuid4, uuid5

from sqlalchemy import CursorResult, func, select, update
from sqlalchemy.orm import Session, sessionmaker

from mce.infrastructure.database.models import (
    AuditEventModel,
    BankConsolidationModel,
    BankModel,
    ContentAliasModel,
    ContentModel,
    InstallationModel,
    ProcessingSessionModel,
    ScanImportModel,
)

DIRECT_MODELS: dict[str, Any] = {
    "installations": InstallationModel,
    "scan_imports": ScanImportModel,
    "processing_sessions": ProcessingSessionModel,
    "contents": ContentModel,
    "content_aliases": ContentAliasModel,
}


@dataclass(frozen=True, slots=True)
class ConsolidationPlan:
    external_bank_id: str
    canonical_bank_id: str
    merged_bank_ids: tuple[str, ...]
    references_by_table: dict[str, int]
    conflicts: tuple[dict[str, object], ...]
    movable_records: int

    @property
    def executable(self) -> bool:
        return not self.conflicts and bool(self.merged_bank_ids)


class BankConsolidationService:
    """Nunca fusiona silenciosamente: dry-run y backup son obligatorios."""

    def __init__(self, factory: sessionmaker[Session]) -> None:
        self._factory = factory

    def dry_run(self, external_bank_id: str, bank_ids: tuple[str, ...]) -> ConsolidationPlan:
        normalized = external_bank_id.strip()
        if not normalized or len(set(bank_ids)) < 2:
            raise ValueError("external_bank_id and at least two distinct banks are required")
        with self._factory() as database:
            banks = tuple(
                database.scalars(select(BankModel).where(BankModel.id.in_(set(bank_ids))))
            )
            if len(banks) != len(set(bank_ids)):
                raise ValueError("one or more banks do not exist")
            mismatched = [
                bank.id for bank in banks if bank.external_bank_id not in {None, normalized}
            ]
            if mismatched:
                raise ValueError(f"banks belong to another external identity: {mismatched}")
            try:
                UUID(normalized)
                stable_id = normalized
            except ValueError:
                stable_id = str(uuid5(NAMESPACE_URL, f"mce:msl-bank:{normalized}"))
            canonical = next(
                (bank for bank in banks if bank.id == stable_id),
                min(banks, key=lambda bank: (bank.created_at, bank.id)),
            )
            merged = tuple(sorted(bank.id for bank in banks if bank.id != canonical.id))
            counts = {
                table: int(
                    database.execute(
                        select(func.count()).select_from(model).where(model.bank_id.in_(merged))
                    ).scalar_one()
                )
                for table, model in DIRECT_MODELS.items()
            }
            conflicts = self._conflicts(database, canonical.id, merged)
            return ConsolidationPlan(
                normalized,
                canonical.id,
                merged,
                counts,
                tuple(conflicts),
                sum(counts.values()),
            )

    def consolidate(
        self,
        plan: ConsolidationPlan,
        *,
        rollback_reference: str,
        fail_after_table: str | None = None,
    ) -> str:
        if not rollback_reference.strip():
            raise ValueError("a verified backup or restore-point reference is required")
        if not plan.executable:
            raise ValueError("the dry-run plan contains conflicts or nothing to merge")
        consolidation_id = str(uuid4())
        now = datetime.now(UTC)
        with self._factory.begin() as database:
            locked = tuple(
                database.scalars(
                    select(BankModel)
                    .where(BankModel.id.in_((plan.canonical_bank_id, *plan.merged_bank_ids)))
                    .with_for_update()
                )
            )
            if len(locked) != len(plan.merged_bank_ids) + 1:
                raise RuntimeError("bank set changed after dry-run")
            if any(bank.external_bank_id not in {None, plan.external_bank_id} for bank in locked):
                raise RuntimeError("external identity changed after dry-run")
            fresh_conflicts = self._conflicts(
                database, plan.canonical_bank_id, plan.merged_bank_ids
            )
            if fresh_conflicts:
                raise RuntimeError(f"new consolidation conflicts: {fresh_conflicts}")
            moved = 0
            for table, model in DIRECT_MODELS.items():
                result = cast(
                    CursorResult[Any],
                    database.execute(
                        update(model)
                        .where(model.bank_id.in_(plan.merged_bank_ids))
                        .values(bank_id=plan.canonical_bank_id)
                    ),
                )
                count = int(result.rowcount or 0)
                moved += count
                if count:
                    database.add(
                        AuditEventModel(
                            id=str(uuid4()),
                            occurred_at=now,
                            actor="mce-bank-consolidation",
                            action="reassign_bank",
                            object_type=table,
                            object_id=plan.canonical_bank_id,
                            previous_value={"bank_ids": list(plan.merged_bank_ids)},
                            new_value={
                                "bank_id": plan.canonical_bank_id,
                                "records": count,
                            },
                            correlation_id=consolidation_id,
                            reversible=True,
                            reversed_by=None,
                        )
                    )
                if fail_after_table == table:
                    raise RuntimeError("injected consolidation failure")
            canonical = database.get(BankModel, plan.canonical_bank_id)
            assert canonical is not None
            for bank_id in plan.merged_bank_ids:
                duplicate = database.get(BankModel, bank_id)
                assert duplicate is not None
                duplicate.external_bank_id = None
                duplicate.status = "archived"
                duplicate.name = f"{duplicate.name} [fusionado en {canonical.id}]"
            database.flush()
            canonical.external_bank_id = plan.external_bank_id
            database.add(
                BankConsolidationModel(
                    id=consolidation_id,
                    external_bank_id=plan.external_bank_id,
                    canonical_bank_id=plan.canonical_bank_id,
                    merged_bank_ids=list(plan.merged_bank_ids),
                    affected_tables=plan.references_by_table,
                    moved_records=moved,
                    conflicts=[],
                    created_at=now,
                    result="completed",
                    rollback_reference=rollback_reference,
                )
            )
        return consolidation_id

    @staticmethod
    def _conflicts(
        database: Session, canonical: str, merged: tuple[str, ...]
    ) -> list[dict[str, object]]:
        conflicts: list[dict[str, object]] = []
        machines = tuple(
            value
            for value in database.scalars(
                select(InstallationModel.machine_identifier).where(
                    InstallationModel.bank_id == canonical,
                    InstallationModel.machine_identifier.is_not(None),
                )
            )
            if value
        )
        if machines:
            duplicates = tuple(
                database.scalars(
                    select(InstallationModel.machine_identifier).where(
                        InstallationModel.bank_id.in_(merged),
                        InstallationModel.machine_identifier.in_(machines),
                    )
                )
            )
            for value in duplicates:
                conflicts.append(
                    {
                        "table": "installations",
                        "constraint": "bank_id,machine_identifier",
                        "value": value,
                        "automatic": False,
                    }
                )
        return conflicts
