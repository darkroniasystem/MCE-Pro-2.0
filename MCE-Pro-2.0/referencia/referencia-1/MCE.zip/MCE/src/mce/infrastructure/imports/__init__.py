"""Adaptadores de infraestructura para evidencia de importación."""

from mce.infrastructure.imports.original_archive import ArchivedOriginal, OriginalJsonArchive

__all__ = ["ArchivedOriginal", "OriginalJsonArchive"]
