"""Adaptadores opcionales de modelos de lenguaje."""

from mce.infrastructure.language_models.errors import (
    InvalidLanguageModelResponseError,
    LanguageModelUnavailableError,
)

__all__ = [
    "InvalidLanguageModelResponseError",
    "LanguageModelUnavailableError",
]
