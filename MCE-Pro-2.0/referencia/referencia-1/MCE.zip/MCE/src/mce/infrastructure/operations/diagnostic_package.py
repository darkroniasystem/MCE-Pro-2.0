"""Paquete de diagnóstico portable con redacción estricta de secretos."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import zipfile
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

from mce.version import __version__

_URL_SECRET = re.compile(r"(?i)(postgresql(?:\+\w+)?://[^:\s/]+:)([^@\s]+)(@)")
_ASSIGNMENT_SECRET = re.compile(
    r"(?i)\b(api[_-]?key|password|passwd|secret|token)\b\s*[:=]\s*([^\s,;]+)"
)
_SENSITIVE_KEYS = ("api_key", "apikey", "password", "passwd", "secret", "token", "database_url")


@dataclass(frozen=True, slots=True)
class DiagnosticContext:
    active_stage: str = "unknown"
    session_id: str | None = None
    scan_id: str | None = None
    bank_id: str | None = None
    error: str | None = None
    traceback: str | None = None
    provider: str | None = None
    statistics: dict[str, Any] | None = None
    migration_version: str | None = None
    classifier_version: str = "local-evidence-v1"
    ruleset_version: str = "classification-rules-v1"


class DiagnosticPackageService:
    """Genera un ZIP autocontenido sin incluir configuraciones ni secretos."""

    def create(
        self,
        destination: Path,
        context: DiagnosticContext,
        *,
        logs_directory: Path,
        health_checks: tuple[dict[str, Any], ...] = (),
    ) -> Path:
        if destination.is_symlink():
            raise ValueError("diagnostic destination must not be a symbolic link")
        target = destination.resolve()
        if target.suffix.casefold() != ".zip":
            raise ValueError("diagnostic destination must end with .zip")
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(".zip.tmp")
        payload = self._payload(context, health_checks)
        try:
            with zipfile.ZipFile(
                temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
            ) as archive:
                archive.writestr(
                    "diagnostic.json",
                    json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n",
                )
                archive.writestr("logs/latest.log", self._recent_logs(logs_directory))
            temporary.replace(target)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return target

    def _payload(
        self,
        context: DiagnosticContext,
        health_checks: tuple[dict[str, Any], ...],
    ) -> dict[str, Any]:
        raw = asdict(context)
        raw["bank_id"] = self._anonymous_bank(context.bank_id)
        return cast(
            dict[str, Any],
            self._redact(
            {
                "contract_version": "mce.diagnostic.v1",
                "created_at": datetime.now(UTC).isoformat(),
                "mce_version": __version__,
                "windows_version": platform.platform(),
                "context": raw,
                "health_checks": health_checks,
            }
            ),
        )

    @classmethod
    def _recent_logs(cls, directory: Path, *, limit: int = 200_000) -> str:
        chunks: list[str] = []
        remaining = limit
        for path in sorted(directory.glob("mce-desktop.log*"), reverse=True):
            if path.is_symlink() or not path.is_file() or remaining <= 0:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")[-remaining:]
            except OSError:
                continue
            chunks.append(text)
            remaining -= len(text)
        return cls._redact_text("\n".join(reversed(chunks)))

    @classmethod
    def _redact(cls, value: Any) -> Any:
        if isinstance(value, dict):
            return {
                str(key): (
                    "***"
                    if any(fragment in str(key).casefold() for fragment in _SENSITIVE_KEYS)
                    else cls._redact(item)
                )
                for key, item in value.items()
            }
        if isinstance(value, (list, tuple)):
            return [cls._redact(item) for item in value]
        if isinstance(value, str):
            return cls._redact_text(value)
        return value

    @staticmethod
    def _redact_text(value: str) -> str:
        sanitized = _URL_SECRET.sub(r"\1***\3", value)
        sanitized = _ASSIGNMENT_SECRET.sub(r"\1=***", sanitized)
        for name, secret in os.environ.items():
            if any(fragment in name.casefold() for fragment in _SENSITIVE_KEYS) and secret:
                sanitized = sanitized.replace(secret, "***")
        return sanitized

    @staticmethod
    def _anonymous_bank(bank_id: str | None) -> str | None:
        if bank_id is None:
            return None
        return "bank-" + hashlib.sha256(bank_id.encode("utf-8")).hexdigest()[:12]
