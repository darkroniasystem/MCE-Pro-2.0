"""Adaptadores de proveedores de metadatos."""

from mce.infrastructure.metadata.browser_extractor import (
    BrowserDomLocator,
    BrowserDomPage,
    BrowserEvidenceExtractor,
    BrowserPageExtraction,
    ExtractedBrowserEvidence,
)
from mce.infrastructure.metadata.browser_partial import (
    BrowserPartialEnrichment,
    BrowserPartialEnrichmentMapper,
    BrowserQwenEvidenceAdapter,
)
from mce.infrastructure.metadata.browser_playwright import PlaywrightBrowserAutomationBackend
from mce.infrastructure.metadata.browser_search import (
    BrowserAutomationBackend,
    BrowserSearchHit,
    BrowserSearchProvider,
    BrowserSearchResponse,
    BrowserSearchSettings,
    BrowserSearchStatus,
    UnavailableBrowserAutomationBackend,
)
from mce.infrastructure.metadata.external_providers import (
    AniListMetadataProvider,
    FanartMetadataProvider,
    ProviderCapabilities,
    TvMazeMetadataProvider,
)
from mce.infrastructure.metadata.factory import (
    MetadataRuntime,
    ProviderUsage,
    build_metadata_runtime,
)
from mce.infrastructure.metadata.http_transport import UrllibJsonTransport
from mce.infrastructure.metadata.manager import MetadataProviderManager, ProviderRegistration
from mce.infrastructure.metadata.providers import (
    CachedMetadataProvider,
    ControlledMetadataProvider,
    InMemoryMetadataCache,
    MetadataProviderSettings,
    RateLimitedMetadataProvider,
    ResilientMetadataProvider,
    TmdbMetadataProvider,
    UnavailableMetadataProvider,
)
from mce.infrastructure.metadata.sqlite_cache import SqliteMetadataCache
from mce.infrastructure.metadata.web_search import (
    CachedWebSearchProvider,
    ExaWebSearchProvider,
    ResilientControlledWebSearchProvider,
    SequentialWebSearchProvider,
    SerperWebSearchProvider,
    TavilyWebSearchProvider,
    WebProviderRegistration,
)

__all__ = [
    "AniListMetadataProvider",
    "BrowserAutomationBackend",
    "BrowserDomLocator",
    "BrowserDomPage",
    "BrowserEvidenceExtractor",
    "BrowserPageExtraction",
    "BrowserPartialEnrichment",
    "BrowserPartialEnrichmentMapper",
    "BrowserQwenEvidenceAdapter",
    "BrowserSearchHit",
    "BrowserSearchProvider",
    "BrowserSearchResponse",
    "BrowserSearchSettings",
    "BrowserSearchStatus",
    "CachedMetadataProvider",
    "CachedWebSearchProvider",
    "ControlledMetadataProvider",
    "ExaWebSearchProvider",
    "ExtractedBrowserEvidence",
    "FanartMetadataProvider",
    "InMemoryMetadataCache",
    "MetadataProviderManager",
    "MetadataProviderSettings",
    "MetadataRuntime",
    "PlaywrightBrowserAutomationBackend",
    "ProviderCapabilities",
    "ProviderRegistration",
    "ProviderUsage",
    "RateLimitedMetadataProvider",
    "ResilientControlledWebSearchProvider",
    "ResilientMetadataProvider",
    "SequentialWebSearchProvider",
    "SerperWebSearchProvider",
    "SqliteMetadataCache",
    "TavilyWebSearchProvider",
    "TmdbMetadataProvider",
    "TvMazeMetadataProvider",
    "UnavailableBrowserAutomationBackend",
    "UnavailableMetadataProvider",
    "UrllibJsonTransport",
    "WebProviderRegistration",
    "build_metadata_runtime",
]
