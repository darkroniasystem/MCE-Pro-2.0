"""Extracción defensiva de evidencia visible desde una página de navegador."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Protocol

from mce.infrastructure.metadata.browser_search import (
    BrowserSearchSettings,
    BrowserSearchStatus,
)
from mce.infrastructure.metadata.web_search import _infer_type, _infer_year, _safe_url


class BrowserDomLocator(Protocol):
    def count(self) -> int: ...

    def nth(self, index: int) -> BrowserDomLocator: ...

    def locator(self, selector: str) -> BrowserDomLocator: ...

    def inner_text(self, *, timeout: float | None = None) -> str: ...

    def text_content(self, *, timeout: float | None = None) -> str | None: ...

    def get_attribute(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> str | None: ...


class BrowserDomPage(Protocol):
    @property
    def url(self) -> str: ...

    def locator(self, selector: str) -> BrowserDomLocator: ...


@dataclass(frozen=True, slots=True)
class ExtractedBrowserEvidence:
    title: str
    source_url: str = ""
    snippet: str = ""
    year: int | None = None
    media_type: str | None = None
    seasons: int | None = None
    genres: tuple[str, ...] = ()
    cast: tuple[str, ...] = ()
    rating: float | None = None
    platforms: tuple[str, ...] = ()
    alternate_titles: tuple[str, ...] = ()
    visible_text: str = ""
    origin: str = "organic"


@dataclass(frozen=True, slots=True)
class BrowserPageExtraction:
    status: BrowserSearchStatus
    evidence: tuple[ExtractedBrowserEvidence, ...] = ()
    page_text: str = ""
    message: str = ""


class BrowserEvidenceExtractor:
    """Extrae resultados sin depender de un único selector del buscador."""

    result_selectors = (
        "article[data-testid='result']",
        "li.b_algo",
        "div.g",
        "[data-result-index]",
        "main article",
    )
    knowledge_panel_selectors = (
        "[data-testid='knowledge-panel']",
        "[data-attrid='title']",
        "#rhs",
        "aside[role='complementary']",
    )
    title_selectors = ("h3", "h2", "[role='heading']", "a[href]")
    link_selectors = ("h3 a[href]", "h2 a[href]", "a[href]")
    snippet_selectors = (
        "[data-snippet]",
        ".snippet",
        ".b_caption p",
        "[data-content-feature='1']",
        "p",
    )

    _captcha_markers = (
        "captcha",
        "recaptcha",
        "unusual traffic",
        "tráfico inusual",
        "verify you are human",
        "verifica que eres humano",
    )
    _rate_limit_markers = ("too many requests", "rate limit", "429")
    _blocked_markers = (
        "access denied",
        "forbidden",
        "service is not available in your location",
        "acceso denegado",
        "before you continue",
        "antes de continuar",
    )

    def extract(
        self,
        page: BrowserDomPage,
        *,
        settings: BrowserSearchSettings,
        limit: int,
    ) -> BrowserPageExtraction:
        effective_limit = min(max(1, limit), settings.max_results)
        page_text = self._limited_text(
            self._page_text(page),
            settings.max_page_text_chars,
        )
        blocked_status = self._blocking_status(page_text)
        if blocked_status is not None:
            return BrowserPageExtraction(
                blocked_status,
                page_text=page_text,
                message=f"Browser: {blocked_status.value} detectado",
            )

        rows: list[ExtractedBrowserEvidence] = []
        rows.extend(self._organic_results(page, settings, effective_limit))
        if len(rows) < effective_limit:
            rows.extend(self._knowledge_panels(page, settings, effective_limit - len(rows)))
        evidence = self._deduplicate(rows)[:effective_limit]
        if not evidence:
            return BrowserPageExtraction(
                BrowserSearchStatus.NO_EVIDENCE,
                page_text=page_text,
                message="Browser: la página no contiene evidencia utilizable",
            )
        status = (
            BrowserSearchStatus.PARTIAL
            if any(self._is_partial(item) for item in evidence)
            else BrowserSearchStatus.SUCCESS
        )
        return BrowserPageExtraction(status, evidence, page_text)

    def _organic_results(
        self,
        page: BrowserDomPage,
        settings: BrowserSearchSettings,
        limit: int,
    ) -> list[ExtractedBrowserEvidence]:
        rows: list[ExtractedBrowserEvidence] = []
        for selector in self.result_selectors:
            for container in self._locators(page.locator(selector), limit * 2):
                title = self._first_text(container, self.title_selectors)
                source_url = self._first_attribute(container, self.link_selectors, "href")
                if not title or not _safe_url(source_url):
                    continue
                visible = self._limited_text(
                    self._safe_text(container),
                    settings.max_page_text_chars,
                )
                snippet = self._first_text(container, self.snippet_selectors)
                if not snippet:
                    snippet = visible.removeprefix(title).strip()
                rows.append(
                    self._evidence(
                        title,
                        source_url,
                        snippet,
                        visible,
                        origin="organic",
                    )
                )
        return rows

    def _knowledge_panels(
        self,
        page: BrowserDomPage,
        settings: BrowserSearchSettings,
        limit: int,
    ) -> list[ExtractedBrowserEvidence]:
        rows: list[ExtractedBrowserEvidence] = []
        for selector in self.knowledge_panel_selectors:
            for container in self._locators(page.locator(selector), limit):
                visible = self._limited_text(
                    self._safe_text(container),
                    settings.max_page_text_chars,
                )
                title = self._first_text(container, self.title_selectors)
                if not title:
                    title = next(
                        (line.strip() for line in visible.splitlines() if line.strip()),
                        "",
                    )
                if not title:
                    continue
                source_url = self._first_attribute(container, self.link_selectors, "href")
                if not _safe_url(source_url):
                    source_url = ""
                rows.append(
                    self._evidence(
                        title,
                        source_url,
                        visible.removeprefix(title).strip(),
                        visible,
                        origin="knowledge_panel",
                    )
                )
        return rows

    def _evidence(
        self,
        title: str,
        source_url: str,
        snippet: str,
        visible: str,
        *,
        origin: str,
    ) -> ExtractedBrowserEvidence:
        context = " ".join((title, snippet, visible))
        return ExtractedBrowserEvidence(
            title=self._clean(title),
            source_url=source_url.strip(),
            snippet=self._clean(snippet),
            year=_infer_year(context),
            media_type=self._media_type(context),
            seasons=self._integer_label(context, ("temporadas", "temporada", "seasons", "season")),
            genres=self._values_label(visible, ("géneros", "género", "genres", "genre")),
            cast=self._values_label(visible, ("reparto", "elenco", "cast", "starring")),
            rating=self._rating(context),
            platforms=self._values_label(
                visible,
                ("plataformas", "plataforma", "streaming", "watch on", "disponible en"),
            ),
            alternate_titles=self._values_label(
                visible,
                ("títulos alternativos", "título alternativo", "also known as", "aka"),
            ),
            visible_text=visible,
            origin=origin,
        )

    @classmethod
    def _page_text(cls, page: BrowserDomPage) -> str:
        return cls._safe_text(page.locator("body"))

    @classmethod
    def _blocking_status(cls, text: str) -> BrowserSearchStatus | None:
        folded = text.casefold()
        if any(marker in folded for marker in cls._captcha_markers):
            return BrowserSearchStatus.CAPTCHA
        if any(marker in folded for marker in cls._rate_limit_markers):
            return BrowserSearchStatus.RATE_LIMITED
        if any(marker in folded for marker in cls._blocked_markers):
            return BrowserSearchStatus.BLOCKED
        return None

    @staticmethod
    def _locators(locator: BrowserDomLocator, limit: int) -> tuple[BrowserDomLocator, ...]:
        try:
            count = min(locator.count(), max(0, limit))
            return tuple(locator.nth(index) for index in range(count))
        except Exception:
            return ()

    @classmethod
    def _first_text(cls, container: BrowserDomLocator, selectors: tuple[str, ...]) -> str:
        for selector in selectors:
            candidates = cls._locators(container.locator(selector), 1)
            if candidates:
                value = cls._safe_text(candidates[0])
                if value:
                    return cls._clean(value)
        return ""

    @classmethod
    def _first_attribute(
        cls,
        container: BrowserDomLocator,
        selectors: tuple[str, ...],
        name: str,
    ) -> str:
        for selector in selectors:
            candidates = cls._locators(container.locator(selector), 1)
            if not candidates:
                continue
            try:
                value = candidates[0].get_attribute(name, timeout=1_000)
            except Exception:
                continue
            if value:
                return value.strip()
        return ""

    @staticmethod
    def _safe_text(locator: BrowserDomLocator) -> str:
        try:
            visible_text = locator.inner_text(timeout=1_000).strip()
        except Exception:
            visible_text = ""
        if visible_text:
            return visible_text
        try:
            text_content = locator.text_content(timeout=1_000)
        except Exception:
            return ""
        return (text_content or "").strip()

    @staticmethod
    def _clean(value: str) -> str:
        return " ".join(value.split())

    @staticmethod
    def _limited_text(value: str, limit: int) -> str:
        return value[:limit].strip()

    @staticmethod
    def _integer_label(text: str, labels: tuple[str, ...]) -> int | None:
        joined = "|".join(re.escape(label) for label in labels)
        match = re.search(rf"(?:{joined})\s*[:\-]?\s*(\d{{1,3}})", text, re.IGNORECASE)
        if not match:
            match = re.search(rf"(\d{{1,3}})\s*(?:{joined})", text, re.IGNORECASE)
        return int(match.group(1)) if match else None

    @staticmethod
    def _rating(text: str) -> float | None:
        match = re.search(
            r"(?:rating|valoraci[oó]n|puntuaci[oó]n)\s*[:\-]?\s*(\d{1,3}(?:[.,]\d+)?)",
            text,
            re.IGNORECASE,
        )
        if not match:
            return None
        value = float(match.group(1).replace(",", "."))
        return value if 0 <= value <= 100 else None

    @staticmethod
    def _media_type(text: str) -> str | None:
        folded = text.casefold()
        if any(marker in folded for marker in ("dorama", "k-drama", "kdrama", "serie coreana")):
            return "dorama"
        if any(marker in folded for marker in ("telenovela", "novela turca")):
            return "novela"
        return _infer_type(text)

    @classmethod
    def _values_label(cls, text: str, labels: tuple[str, ...]) -> tuple[str, ...]:
        label_set = tuple(label.casefold() for label in labels)
        for raw_line in text.splitlines():
            line = raw_line.strip()
            folded = line.casefold()
            for label in label_set:
                if not folded.startswith(label):
                    continue
                tail = line[len(label) :].lstrip(" :-")
                values = tuple(
                    cls._clean(value)
                    for value in re.split(r"[,;|·]", tail)
                    if cls._clean(value)
                )
                return values
        return ()

    @staticmethod
    def _deduplicate(
        rows: list[ExtractedBrowserEvidence],
    ) -> tuple[ExtractedBrowserEvidence, ...]:
        unique: list[ExtractedBrowserEvidence] = []
        seen: set[tuple[str, str]] = set()
        for row in rows:
            key = (row.title.casefold(), row.source_url.casefold())
            if key in seen:
                continue
            seen.add(key)
            unique.append(row)
        return tuple(unique)

    @staticmethod
    def _is_partial(item: ExtractedBrowserEvidence) -> bool:
        return not item.source_url or item.year is None or item.media_type is None


__all__ = [
    "BrowserDomLocator",
    "BrowserDomPage",
    "BrowserEvidenceExtractor",
    "BrowserPageExtraction",
    "ExtractedBrowserEvidence",
]
