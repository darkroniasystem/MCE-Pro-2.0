"""Adaptador de búsqueda Wikidata compatible con MetadataProvider."""

from __future__ import annotations

from mce.application.identification.models import IdentificationQuery, ProviderCandidate
from mce.application.identification.service import ProviderNotFoundError

from .client import WikidataClient
from .config import WikidataProviderConfig
from .mapper import WikidataEntityMapper
from .scoring import WikidataCandidateScorer


class WikidataSearchProvider:
    name = "wikidata"

    def __init__(
        self,
        client: WikidataClient,
        config: WikidataProviderConfig,
        mapper: WikidataEntityMapper | None = None,
        scorer: WikidataCandidateScorer | None = None,
    ) -> None:
        self.client = client
        self.config = config
        self.mapper = mapper or WikidataEntityMapper(config)
        self.scorer = scorer or WikidataCandidateScorer()

    def _search(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        variants = tuple(
            dict.fromkeys(
                value.strip()
                for value in (query.title, query.original_title, *query.aliases)
                if value and value.strip()
            )
        )[: self.config.max_search_variants]
        qids: list[str] = []
        for variant in variants:
            for qid in self.client.search(variant, self.config.language):
                if qid not in qids:
                    qids.append(qid)
            if len(qids) >= self.config.max_candidates:
                break
        entities = self.client.get_entities(tuple(qids))
        candidates = tuple(
            candidate
            for entity in entities
            if (candidate := self.mapper.map(entity, query.kind)) is not None
        )
        return tuple(
            sorted(
                candidates,
                key=lambda row: self.scorer.score(query, row).final_score,
                reverse=True,
            )
        )

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(query)

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(query)

    def _details(self, external_id: str, query_kind: object) -> ProviderCandidate:
        from mce.application.identification.models import SearchKind

        kind = query_kind if isinstance(query_kind, SearchKind) else SearchKind.SERIES
        rows = self.client.get_entities((external_id,))
        if not rows:
            raise ProviderNotFoundError("Wikidata: entidad no encontrada")
        candidate = self.mapper.map(rows[0], kind)
        if candidate is None:
            raise ProviderNotFoundError("Wikidata: entidad incompatible")
        return candidate

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        from mce.application.identification.models import SearchKind

        return self._details(external_id, SearchKind.MOVIE)

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        from mce.application.identification.models import SearchKind

        return self._details(external_id, SearchKind.SERIES)

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        raise ProviderNotFoundError("Wikidata no ofrece detalle operativo de temporadas")

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        raise ProviderNotFoundError("Wikidata no ofrece detalle operativo de episodios")
