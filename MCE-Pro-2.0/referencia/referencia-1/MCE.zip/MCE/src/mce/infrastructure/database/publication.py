"""Construcción y activación atómica de snapshots publicables."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast
from uuid import NAMESPACE_URL, uuid4, uuid5

from sqlalchemy import create_engine, func, select, text
from sqlalchemy.orm import Session, sessionmaker

from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.database.models import (
    AuditEventModel,
    AvailabilityModel,
    CatalogPublicationEntryModel,
    CatalogPublicationModel,
    ContentModel,
    MetadataConflictModel,
    PhysicalFileModel,
)

PUBLICATION_LOCK = 170017


@dataclass(frozen=True, slots=True)
class PublicationResult:
    publication_id: str
    catalog_version: int
    status: str
    entry_count: int
    validation_report: dict[str, Any]


class CatalogPublicationService:
    """Publica una versión completa o no modifica la versión activa."""

    def __init__(
        self,
        factory: sessionmaker[Session],
        *,
        clock: Callable[[], datetime] | None = None,
        before_activate: Callable[[], None] | None = None,
    ) -> None:
        self.factory = factory
        self.clock = clock or (lambda: datetime.now(UTC))
        self.before_activate = before_activate

    @classmethod
    def from_runtime_environment(cls) -> CatalogPublicationService | None:
        raw = runtime_database_url()
        if raw is None:
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    def publish(self) -> PublicationResult:
        with self.factory.begin() as database:
            self._lock(database)
            previous = self._active(database, for_update=True)
            version = self._next_version(database)
            publication_id = str(uuid4())
            now = self.clock()
            entries, report = self._build_snapshot(database)
            if report["errors"]:
                database.add(
                    CatalogPublicationModel(
                        id=publication_id,
                        catalog_version=version,
                        previous_version_id=previous.id if previous else None,
                        status="failed",
                        validation_report=report,
                        created_at=now,
                        published_at=None,
                    )
                )
                return PublicationResult(publication_id, version, "failed", 0, report)

            if previous is not None:
                previous.status = "superseded"
                database.flush()
            publication = CatalogPublicationModel(
                id=publication_id,
                catalog_version=version,
                previous_version_id=previous.id if previous else None,
                status="active",
                validation_report=report,
                created_at=now,
                published_at=now,
            )
            database.add(publication)
            database.flush()
            for content, availability, paths in entries:
                database.add(
                    CatalogPublicationEntryModel(
                        id=str(
                            uuid5(
                                NAMESPACE_URL,
                                f"mce:publication:{publication_id}:{content.id}:{availability.bank_id}",
                            )
                        ),
                        publication_id=publication_id,
                        content_id=content.id,
                        bank_id=availability.bank_id,
                        payload=self._payload(content, availability, paths, version),
                        created_at=now,
                    )
                )
                content.catalog_stage = "published"
                content.publication_status = "published"
            if self.before_activate is not None:
                self.before_activate()
            return PublicationResult(publication_id, version, "active", len(entries), report)

    def rollback_to(self, catalog_version: int) -> PublicationResult:
        with self.factory.begin() as database:
            self._lock(database)
            current = self._active(database, for_update=True)
            target = database.scalar(
                select(CatalogPublicationModel)
                .where(CatalogPublicationModel.catalog_version == catalog_version)
                .with_for_update()
            )
            if target is None or target.status not in {"active", "superseded"}:
                raise ValueError("catalog version is not available for rollback")
            target_ids = set(
                database.scalars(
                    select(CatalogPublicationEntryModel.content_id).where(
                        CatalogPublicationEntryModel.publication_id == target.id
                    )
                )
            )
            current_ids = (
                set(
                    database.scalars(
                        select(CatalogPublicationEntryModel.content_id).where(
                            CatalogPublicationEntryModel.publication_id == current.id
                        )
                    )
                )
                if current is not None
                else set()
            )
            if current is not None and current.id != target.id:
                current.status = "superseded"
                database.flush()
            target.status = "active"
            for content in database.scalars(
                select(ContentModel).where(ContentModel.id.in_(target_ids | current_ids))
            ):
                active = content.id in target_ids
                content.catalog_stage = "published" if active else "approved"
                content.publication_status = "published" if active else "publication_ready"
            count = database.scalar(
                select(func.count())
                .select_from(CatalogPublicationEntryModel)
                .where(CatalogPublicationEntryModel.publication_id == target.id)
            )
            return PublicationResult(
                target.id,
                target.catalog_version,
                "active",
                int(count or 0),
                dict(target.validation_report),
            )

    def quarantine_invalid(self, publication_id: str, *, actor: str) -> int:
        """Devuelve a staging incidencias estructurales, con auditoría reversible."""
        structural_codes = {
            "MISSING_AVAILABILITY",
            "INVALID_AVAILABILITY",
            "INVALID_PATHS",
            "INVALID_METADATA",
        }
        with self.factory.begin() as database:
            self._lock(database)
            publication = database.get(CatalogPublicationModel, publication_id)
            if publication is None or publication.status != "failed":
                raise ValueError("only a failed publication can be quarantined")
            errors = cast(list[dict[str, str]], publication.validation_report.get("errors", []))
            content_ids = {
                error.get("content_id", "")
                for error in errors
                if error.get("code") in structural_codes and error.get("content_id")
            }
            correlation_id = str(uuid4())
            changed = 0
            for content in database.scalars(
                select(ContentModel).where(ContentModel.id.in_(content_ids)).with_for_update()
            ):
                previous = {
                    "catalog_stage": content.catalog_stage,
                    "publication_status": content.publication_status,
                    "publication_block_reason": content.publication_block_reason,
                }
                content.catalog_stage = "staging"
                content.publication_status = "publication_blocked"
                content.publication_block_reason = f"failed_publication:{publication_id}"
                database.add(
                    AuditEventModel(
                        id=str(uuid4()),
                        occurred_at=self.clock(),
                        actor=actor,
                        action="quarantine_invalid_publication",
                        object_type="content",
                        object_id=content.id,
                        previous_value=previous,
                        new_value={
                            "catalog_stage": "staging",
                            "publication_status": "publication_blocked",
                            "publication_id": publication_id,
                        },
                        correlation_id=correlation_id,
                        reversible=True,
                        reversed_by=None,
                    )
                )
                changed += 1
            return changed

    def restore_quarantined(self, publication_id: str, *, actor: str) -> int:
        """Restaura exactamente los estados guardados por `quarantine_invalid`."""
        with self.factory.begin() as database:
            self._lock(database)
            candidates = tuple(
                database.scalars(
                    select(AuditEventModel).where(
                        AuditEventModel.action == "quarantine_invalid_publication",
                        AuditEventModel.reversed_by.is_(None),
                    )
                )
            )
            audits = tuple(
                audit
                for audit in candidates
                if (audit.new_value or {}).get("publication_id") == publication_id
            )
            restored = 0
            for audit in audits:
                content = database.get(ContentModel, audit.object_id)
                if content is None:
                    continue
                previous = dict(audit.previous_value or {})
                content.catalog_stage = str(previous["catalog_stage"])
                content.publication_status = str(previous["publication_status"])
                content.publication_block_reason = cast(
                    str | None, previous.get("publication_block_reason")
                )
                reverse_id = str(uuid4())
                database.add(
                    AuditEventModel(
                        id=reverse_id,
                        occurred_at=self.clock(),
                        actor=actor,
                        action="restore_quarantined_publication",
                        object_type="content",
                        object_id=content.id,
                        previous_value=dict(audit.new_value or {}),
                        new_value=previous,
                        correlation_id=audit.correlation_id,
                        reversible=False,
                        reversed_by=None,
                    )
                )
                database.flush()
                audit.reversed_by = reverse_id
                restored += 1
            return restored

    def active_catalog(self, *, bank_id: str | None = None) -> tuple[dict[str, Any], ...]:
        with self.factory() as database:
            active = self._active(database)
            if active is None:
                return ()
            statement = select(CatalogPublicationEntryModel).where(
                CatalogPublicationEntryModel.publication_id == active.id
            )
            if bank_id is not None:
                statement = statement.where(CatalogPublicationEntryModel.bank_id == bank_id)
            statement = statement.order_by(
                CatalogPublicationEntryModel.bank_id,
                CatalogPublicationEntryModel.content_id,
            )
            return tuple(dict(row.payload) for row in database.scalars(statement))

    def _build_snapshot(
        self, database: Session
    ) -> tuple[
        list[tuple[ContentModel, AvailabilityModel, tuple[str, ...]]],
        dict[str, Any],
    ]:
        contents = tuple(
            database.scalars(
                select(ContentModel).where(
                    ContentModel.catalog_stage.in_(("approved", "published")),
                    ContentModel.review_status.in_(("approved", "corrected")),
                    ContentModel.status == "active",
                )
            )
        )
        content_ids = {content.id for content in contents}
        availabilities = tuple(
            database.scalars(
                select(AvailabilityModel).where(AvailabilityModel.content_id.in_(content_ids))
            )
        ) if content_ids else ()
        by_content: dict[str, list[AvailabilityModel]] = {}
        for availability in availabilities:
            by_content.setdefault(availability.content_id, []).append(availability)
        conflicts = (
            tuple(
                database.scalars(
                    select(MetadataConflictModel).where(
                        cast(Any, MetadataConflictModel).content_id.in_(content_ids)
                    )
                )
            )
            if content_ids
            else ()
        )
        unresolved = {
            cast(Any, conflict).content_id
            for conflict in conflicts
            if not bool((cast(Any, conflict).payload or {}).get("resolved"))
        }
        errors: list[dict[str, str]] = []
        entries: list[tuple[ContentModel, AvailabilityModel, tuple[str, ...]]] = []
        seen: set[tuple[str, str]] = set()
        for content in contents:
            if not content.main_title.strip() or not content.content_type.strip():
                errors.append({"code": "INVALID_METADATA", "content_id": content.id})
            if content.id in unresolved:
                errors.append({"code": "UNRESOLVED_CONFLICT", "content_id": content.id})
            options = by_content.get(content.id, [])
            if not options:
                errors.append({"code": "MISSING_AVAILABILITY", "content_id": content.id})
            for availability in options:
                key = (content.id, availability.bank_id)
                if key in seen:
                    errors.append({"code": "DUPLICATE_AVAILABILITY", "content_id": content.id})
                    continue
                seen.add(key)
                if (availability.payload or {}).get("status") != "available":
                    errors.append({"code": "INVALID_AVAILABILITY", "content_id": content.id})
                referenced_ids = tuple(
                    str(value)
                    for value in (availability.payload or {}).get("physical_file_ids", [])
                )
                path_scope = PhysicalFileModel.content_id == content.id
                if referenced_ids:
                    path_scope = path_scope | PhysicalFileModel.id.in_(referenced_ids)
                paths = tuple(
                    database.scalars(
                        select(PhysicalFileModel.original_path)
                        .where(
                            path_scope,
                            PhysicalFileModel.bank_id == availability.bank_id,
                            PhysicalFileModel.status == "present",
                        )
                        .order_by(PhysicalFileModel.normalized_path)
                    )
                )
                if not paths or any(not path.strip() for path in paths):
                    errors.append({"code": "INVALID_PATHS", "content_id": content.id})
                entries.append((content, availability, paths))
        if not contents:
            errors.append({"code": "EMPTY_CATALOG", "content_id": ""})
        report: dict[str, Any] = {
            "valid": not errors,
            "contents": len(contents),
            "entries": len(entries),
            "excluded_staging": int(
                database.scalar(
                    select(func.count())
                    .select_from(ContentModel)
                    .where(ContentModel.catalog_stage == "staging")
                )
                or 0
            ),
            "errors": errors,
        }
        return entries, report

    @staticmethod
    def _payload(
        content: ContentModel,
        availability: AvailabilityModel,
        paths: tuple[str, ...],
        version: int,
    ) -> dict[str, Any]:
        return {
            "catalog_version": version,
            "work_id": content.id,
            "title": content.main_title,
            "original_title": content.original_title,
            "spanish_title": content.spanish_title,
            "category": content.content_type,
            "year": content.release_year,
            "bank_id": availability.bank_id,
            "availability": "available",
            "paths": list(paths),
            "confidence": content.metadata_confidence,
            "approval_status": content.review_status,
        }

    @staticmethod
    def _lock(database: Session) -> None:
        database.execute(text("SELECT pg_advisory_xact_lock(:key)"), {"key": PUBLICATION_LOCK})

    @staticmethod
    def _active(database: Session, *, for_update: bool = False) -> CatalogPublicationModel | None:
        statement = select(CatalogPublicationModel).where(
            CatalogPublicationModel.status == "active"
        )
        if for_update:
            statement = statement.with_for_update()
        return database.scalar(statement)

    @staticmethod
    def _next_version(database: Session) -> int:
        current = database.scalar(select(func.max(CatalogPublicationModel.catalog_version)))
        return int(current or 0) + 1
