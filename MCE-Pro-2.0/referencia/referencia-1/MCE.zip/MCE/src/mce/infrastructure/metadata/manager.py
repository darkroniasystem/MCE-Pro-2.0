"""Orquestación selectiva de proveedores según tipo y capacidades."""

from __future__ import annotations

from dataclasses import dataclass, fields, replace
from typing import Any, cast

from mce.application.identification.models import (
    IdentificationQuery,
    ProviderAttempt,
    ProviderAttemptStatus,
    ProviderCandidate,
    SearchKind,
)
from mce.application.identification.service import (
    ProviderAuthenticationError,
    ProviderError,
    ProviderNotFoundError,
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderTimeoutError,
)
from mce.application.ports.metadata_provider import MetadataProvider


@dataclass(frozen=True, slots=True)
class ProviderRegistration:
    provider: MetadataProvider
    movies: bool
    series: bool
    anime: bool = False
    primary_for: tuple[SearchKind, ...] = ()
    searchable: bool = True
    role: str = "standard"


class MetadataProviderManager:
    """Consulta solo proveedores compatibles y tolera fallos opcionales aislados."""

    name = "cached:provider-manager"

    def __init__(self, registrations: tuple[ProviderRegistration, ...]) -> None:
        self.registrations = registrations
        self.last_from_cache = False
        self.last_attempts: tuple[ProviderAttempt, ...] = ()
        self.last_primary_incomplete = False

    def _search(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        self.last_from_cache = False
        self.last_attempts = ()
        self.last_primary_incomplete = False
        compatible = [
            entry
            for entry in self.registrations
            if entry.searchable
            and (
                (query.kind is SearchKind.MOVIE and entry.movies)
                or (query.kind is SearchKind.SERIES and entry.series)
                or (query.kind is SearchKind.ANIME and entry.anime)
            )
        ]
        if not compatible:
            raise ProviderOfflineError(
                f"no hay proveedor de búsqueda configurado para {query.kind.value}"
            )
        compatible.sort(key=lambda entry: query.kind not in entry.primary_for)
        results: list[ProviderCandidate] = []
        attempts: list[ProviderAttempt] = []
        primary_incomplete = not any(query.kind in entry.primary_for for entry in compatible)
        seen: set[tuple[str, str]] = set()
        for entry in compatible:
            try:
                found = (
                    entry.provider.search_movie(query)
                    if query.kind is SearchKind.MOVIE
                    else entry.provider.search_series(query)
                )
            except ProviderNotFoundError as exc:
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.SUCCESS_NO_RESULTS,
                        message=str(exc),
                    )
                )
                continue
            except ProviderRateLimitError as exc:
                primary_incomplete = primary_incomplete or query.kind in entry.primary_for
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.RATE_LIMITED,
                        message=str(exc),
                    )
                )
                continue
            except ProviderTimeoutError as exc:
                primary_incomplete = primary_incomplete or query.kind in entry.primary_for
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.TIMEOUT,
                        message=str(exc),
                    )
                )
                continue
            except ProviderAuthenticationError as exc:
                primary_incomplete = primary_incomplete or query.kind in entry.primary_for
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.AUTHENTICATION_ERROR,
                        message=str(exc),
                    )
                )
                continue
            except ProviderResponseError as exc:
                primary_incomplete = primary_incomplete or query.kind in entry.primary_for
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.INVALID_RESPONSE,
                        message=str(exc),
                    )
                )
                continue
            except ProviderError as exc:
                primary_incomplete = primary_incomplete or query.kind in entry.primary_for
                attempts.append(
                    ProviderAttempt(
                        entry.provider.name,
                        ProviderAttemptStatus.UNAVAILABLE,
                        message=str(exc),
                    )
                )
                continue
            self.last_from_cache = self.last_from_cache or bool(
                getattr(entry.provider, "last_from_cache", False)
            )
            for candidate in found:
                identity = (candidate.provider, candidate.external_id)
                if identity not in seen:
                    seen.add(identity)
                    results.append(candidate)
            attempts.append(
                ProviderAttempt(
                    entry.provider.name,
                    (
                        ProviderAttemptStatus.SUCCESS_WITH_RESULTS
                        if found
                        else ProviderAttemptStatus.SUCCESS_NO_RESULTS
                    ),
                    len(found),
                )
            )
        self.last_attempts = tuple(attempts)
        self.last_primary_incomplete = primary_incomplete
        return tuple(results)

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(query)

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(query)

    def _find(self, provider_name: str) -> MetadataProvider:
        for entry in self.registrations:
            if entry.provider.name.endswith(provider_name):
                return entry.provider
        raise ProviderNotFoundError(f"{provider_name}: proveedor no disponible")

    def get_candidate_details(self, candidate: ProviderCandidate) -> ProviderCandidate:
        provider = self._find(candidate.provider)
        primary = (
            provider.get_movie_details(candidate.external_id)
            if candidate.kind is SearchKind.MOVIE
            else provider.get_series_details(candidate.external_id)
        )
        merged = primary
        identifiers = dict(primary.external_ids)
        art = None
        try:
            fanart = self._find("fanart")
            art_id = (
                identifiers.get("tmdb_movie")
                if primary.kind is SearchKind.MOVIE
                else identifiers.get("thetvdb")
            )
            if art_id:
                art = (
                    fanart.get_movie_details(art_id)
                    if primary.kind is SearchKind.MOVIE
                    else fanart.get_series_details(art_id)
                )
        except ProviderError:
            art = None
        if art is not None:
            merged = replace(merged, images=self._deduplicate(art.images + merged.images))
        try:
            wikidata = self._find("wikidata")
            wiki_results = (
                wikidata.search_movie(
                    IdentificationQuery(
                        primary.title,
                        primary.kind,
                        primary.year,
                        primary.original_title,
                        primary.aliases,
                    )
                )
                if primary.kind is SearchKind.MOVIE
                else wikidata.search_series(
                    IdentificationQuery(
                        primary.title,
                        primary.kind,
                        primary.year,
                        primary.original_title,
                        primary.aliases,
                    )
                )
            )
            supplement = self._matching_supplement(primary, wiki_results)
            if supplement is not None:
                merged = self._merge_missing(merged, supplement)
        except ProviderError:
            pass
        return merged

    @staticmethod
    def _matching_supplement(
        primary: ProviderCandidate,
        candidates: tuple[ProviderCandidate, ...],
    ) -> ProviderCandidate | None:
        primary_ids = dict(primary.external_ids)
        expected_type = "tmdb_movie" if primary.kind is SearchKind.MOVIE else "tmdb_tv"
        expected_id = primary_ids.get(expected_type) or (
            primary.external_id if primary.provider == "tmdb" else None
        )
        if expected_id:
            for candidate in candidates:
                if dict(candidate.external_ids).get(expected_type) == expected_id:
                    return candidate
        normalized = primary.title.casefold().strip()
        return next(
            (
                candidate
                for candidate in candidates
                if candidate.title.casefold().strip() == normalized
                and (
                    primary.year is None or candidate.year is None or primary.year == candidate.year
                )
            ),
            None,
        )

    @staticmethod
    def _deduplicate(values: tuple[tuple[str, str], ...]) -> tuple[tuple[str, str], ...]:
        return tuple(dict.fromkeys(values))

    @staticmethod
    def _merge_missing(
        primary: ProviderCandidate, supplement: ProviderCandidate
    ) -> ProviderCandidate:
        changes: dict[str, object] = {}
        additive = {
            "aliases",
            "genres",
            "languages",
            "cast_names",
            "external_ids",
            "images",
            "ratings",
            "title_aliases",
        }
        protected = {"provider", "external_id", "kind", "title", "source_url"}
        for field in fields(primary):
            name = field.name
            if name in protected:
                continue
            current = getattr(primary, name)
            extra = getattr(supplement, name)
            if name in additive and isinstance(current, tuple) and isinstance(extra, tuple):
                changes[name] = tuple(dict.fromkeys(current + extra))
            elif current in (None, "", ()) and extra not in (None, "", ()):
                changes[name] = extra
        return replace(primary, **cast(Any, changes))

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return self._find("tmdb").get_movie_details(external_id)

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return self._find("tmdb").get_series_details(external_id)

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        return self._find("tmdb").get_season_details(external_id, season)

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        return self._find("tmdb").get_episode_details(external_id, season, episode)
