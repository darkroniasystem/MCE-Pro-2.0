"""Almacenamiento atómico y validado de checkpoints JSON."""

from __future__ import annotations

import hashlib
import json
import os
from contextlib import suppress
from datetime import datetime
from pathlib import Path
from uuid import UUID, uuid4

from mce.application.dto.session_models import (
    ProcessingSession,
    ProcessingStage,
    SessionItem,
    SessionItemStatus,
    SessionStatus,
)
from mce.domain.value_objects import (
    ImportId,
    NormalizedPath,
    PhysicalFileId,
    ScanScope,
    ScanScopeType,
    SourceId,
)

CHECKPOINT_FORMAT_VERSION = 1


class InvalidCheckpointError(ValueError):
    """El checkpoint está dañado o no cumple su contrato."""


class IncompatibleCheckpointError(InvalidCheckpointError):
    """La versión del checkpoint no es compatible con esta aplicación."""


class JsonCheckpointStore:
    """Guarda un documento JSON explícito dentro de un directorio controlado."""

    def __init__(self, directory: Path) -> None:
        if directory.is_symlink():
            raise ValueError("checkpoint directory must not be a symbolic link")
        self._directory = directory.resolve()
        self._directory.mkdir(parents=True, exist_ok=True)

    def save(self, session: ProcessingSession) -> Path:
        """Escribe mediante reemplazo atómico para tolerar interrupciones."""
        session_id = _uuid(session.session_id, "session_id")
        target = self._directory / f"{session_id}.json"
        if target.is_symlink():
            raise ValueError("checkpoint target must not be a symbolic link")
        session_payload = {
            "session_id": session.session_id,
            "workspace_id": session.workspace_id,
            "import_id": str(session.import_id),
            "package_hash": session.package_hash,
            "bank_name": session.bank_name,
            "scan_scope": {
                "scope_type": session.scan_scope.scope_type.value,
                "source_ids": [str(value) for value in session.scan_scope.source_ids],
                "included_paths": [value.original for value in session.scan_scope.included_paths],
            },
            "items": [
                {
                    "item_id": item.item_id,
                    "import_id": str(item.import_id),
                    "source_id": str(item.source_id),
                    "physical_file_id": str(item.physical_file_id),
                    "original_path": item.original_path,
                    "original_name": item.original_name,
                    "bank_id": item.bank_id,
                    "installation_id": item.installation_id,
                    "size_bytes": item.size_bytes,
                    "file_hash": item.file_hash,
                    "stage": item.stage.value,
                    "status": item.status.value,
                    "warning": item.warning,
                    "error": item.error,
                    "detected_category": item.detected_category,
                    "category_confidence": item.category_confidence,
                    "classification_reason": item.classification_reason,
                    "matched_rules": list(item.matched_rules),
                    "classification_version": item.classification_version,
                    "classified_at": item.classified_at.isoformat() if item.classified_at else None,
                    "classification_status": item.classification_status,
                    "clean_title": item.clean_title,
                    "detected_year": item.detected_year,
                    "season_number": item.season_number,
                    "episode_number": item.episode_number,
                    "technical_tags": list(item.technical_tags),
                    "language_hints": list(item.language_hints),
                    "cleaning_reason": item.cleaning_reason,
                    "cleaning_version": item.cleaning_version,
                    "cleaned_at": item.cleaned_at.isoformat() if item.cleaned_at else None,
                    "cleaning_status": item.cleaning_status,
                    "parent_content_id": item.parent_content_id,
                    "work_group_id": item.work_group_id,
                    "work_title": item.work_title,
                    "grouping_confidence": item.grouping_confidence,
                    "grouping_reason": item.grouping_reason,
                    "grouping_version": item.grouping_version,
                    "grouping_status": item.grouping_status,
                    "enrichment_status": item.enrichment_status,
                    "identification_confidence": item.identification_confidence,
                    "metadata_confidence": item.metadata_confidence,
                    "final_confidence": item.final_confidence,
                    "review_reason": item.review_reason,
                    "final_category": item.final_category,
                    "classification_resolution_status": item.classification_resolution_status,
                    "classification_resolution_explanation": (
                        item.classification_resolution_explanation
                    ),
                    "classification_conflicts": list(item.classification_conflicts),
                    "human_title_correction": item.human_title_correction,
                    "human_title_locked": item.human_title_locked,
                    "human_decision_at": (
                        item.human_decision_at.isoformat() if item.human_decision_at else None
                    ),
                    "providers_completed": list(item.providers_completed),
                    "providers_pending": list(item.providers_pending),
                    "providers_failed": list(item.providers_failed),
                    "metadata_from_cache": item.metadata_from_cache,
                    "web_search_used": item.web_search_used,
                    "web_search_reason": item.web_search_reason,
                    "web_search_decision": item.web_search_decision,
                    "web_search_query": item.web_search_query,
                    "web_search_evidence": list(item.web_search_evidence),
                    "web_search_from_cache": item.web_search_from_cache,
                    "next_retry_at": item.next_retry_at.isoformat() if item.next_retry_at else None,
                }
                for item in session.items
            ],
            "created_at": session.created_at.isoformat(),
            "updated_at": session.updated_at.isoformat(),
            "status": session.status.value,
            "failure_reason": session.failure_reason,
            "retry_count": session.retry_count,
        }
        checksum = hashlib.sha256(_canonical_json(session_payload)).hexdigest()
        payload = {
            "format_version": CHECKPOINT_FORMAT_VERSION,
            "checksum": checksum,
            "session": session_payload,
        }
        encoded = _canonical_json(payload)
        temporary = self._directory / f".{session_id}.{uuid4().hex}.tmp"
        try:
            with temporary.open("xb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        return target

    def load(self, session_id: str) -> ProcessingSession:
        """Valida y reconstruye una sesión sin ejecutar datos arbitrarios."""
        safe_id = _uuid(session_id, "session_id")
        path = self._directory / f"{safe_id}.json"
        if path.is_symlink():
            raise InvalidCheckpointError("checkpoint must not be a symbolic link")
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise InvalidCheckpointError("checkpoint is unreadable JSON") from exc
        if not isinstance(payload, dict):
            raise InvalidCheckpointError("checkpoint root must be an object")
        version = payload.get("format_version")
        if version != CHECKPOINT_FORMAT_VERSION:
            raise IncompatibleCheckpointError(f"unsupported checkpoint version: {version!r}")
        data = payload.get("session")
        if not isinstance(data, dict):
            raise InvalidCheckpointError("checkpoint session must be an object")
        checksum = payload.get("checksum")
        if checksum is not None and (
            not isinstance(checksum, str)
            or hashlib.sha256(_canonical_json(data)).hexdigest() != checksum
        ):
            raise InvalidCheckpointError("checkpoint checksum mismatch")
        try:
            scope_data = data["scan_scope"]
            scope = ScanScope(
                ScanScopeType(scope_data["scope_type"]),
                tuple(SourceId(value) for value in scope_data["source_ids"]),
                tuple(NormalizedPath(value) for value in scope_data["included_paths"]),
            )
            items = tuple(
                SessionItem(
                    item_id=_uuid(item["item_id"], "item_id"),
                    import_id=ImportId(item["import_id"]),
                    source_id=SourceId(item["source_id"]),
                    physical_file_id=PhysicalFileId(item["physical_file_id"]),
                    original_path=item["original_path"],
                    original_name=item.get("original_name"),
                    bank_id=item.get("bank_id"),
                    installation_id=item.get("installation_id"),
                    size_bytes=item.get("size_bytes"),
                    file_hash=item.get("file_hash"),
                    stage=ProcessingStage(item["stage"]),
                    status=SessionItemStatus(item["status"]),
                    warning=item.get("warning"),
                    error=item.get("error"),
                    detected_category=item.get("detected_category"),
                    category_confidence=item.get("category_confidence"),
                    classification_reason=item.get("classification_reason"),
                    matched_rules=tuple(item.get("matched_rules", ())),
                    classification_version=item.get("classification_version"),
                    classified_at=(
                        datetime.fromisoformat(item["classified_at"])
                        if item.get("classified_at")
                        else None
                    ),
                    classification_status=item.get(
                        "classification_status", "classification_pending"
                    ),
                    clean_title=item.get("clean_title"),
                    detected_year=item.get("detected_year"),
                    season_number=item.get("season_number"),
                    episode_number=item.get("episode_number"),
                    technical_tags=tuple(item.get("technical_tags", ())),
                    language_hints=tuple(item.get("language_hints", ())),
                    cleaning_reason=item.get("cleaning_reason"),
                    cleaning_version=item.get("cleaning_version"),
                    cleaned_at=(
                        datetime.fromisoformat(item["cleaned_at"])
                        if item.get("cleaned_at")
                        else None
                    ),
                    cleaning_status=item.get("cleaning_status", "cleaning_pending"),
                    parent_content_id=item.get("parent_content_id"),
                    work_group_id=item.get("work_group_id"),
                    work_title=item.get("work_title"),
                    grouping_confidence=item.get("grouping_confidence"),
                    grouping_reason=item.get("grouping_reason"),
                    grouping_version=item.get("grouping_version"),
                    grouping_status=item.get("grouping_status", "grouping_pending"),
                    enrichment_status=item.get("enrichment_status", "pending_enrichment"),
                    identification_confidence=item.get("identification_confidence"),
                    metadata_confidence=item.get("metadata_confidence"),
                    final_confidence=item.get("final_confidence"),
                    review_reason=item.get("review_reason"),
                    final_category=item.get("final_category"),
                    classification_resolution_status=item.get(
                        "classification_resolution_status"
                    ),
                    classification_resolution_explanation=item.get(
                        "classification_resolution_explanation"
                    ),
                    classification_conflicts=tuple(item.get("classification_conflicts", ())),
                    human_title_correction=item.get("human_title_correction"),
                    human_title_locked=bool(item.get("human_title_locked", False)),
                    human_decision_at=(
                        datetime.fromisoformat(item["human_decision_at"])
                        if item.get("human_decision_at")
                        else None
                    ),
                    providers_completed=tuple(item.get("providers_completed", ())),
                    providers_pending=tuple(item.get("providers_pending", ())),
                    providers_failed=tuple(item.get("providers_failed", ())),
                    metadata_from_cache=bool(item.get("metadata_from_cache", False)),
                    web_search_used=bool(item.get("web_search_used", False)),
                    web_search_reason=item.get("web_search_reason"),
                    web_search_decision=item.get("web_search_decision"),
                    web_search_query=item.get("web_search_query"),
                    web_search_evidence=tuple(item.get("web_search_evidence", ())),
                    web_search_from_cache=bool(item.get("web_search_from_cache", False)),
                    next_retry_at=(
                        datetime.fromisoformat(item["next_retry_at"])
                        if item.get("next_retry_at")
                        else None
                    ),
                )
                for item in data["items"]
            )
            session = ProcessingSession(
                session_id=_uuid(data["session_id"], "session_id"),
                workspace_id=_uuid(data["workspace_id"], "workspace_id"),
                import_id=ImportId(data["import_id"]),
                package_hash=data["package_hash"],
                scan_scope=scope,
                items=items,
                created_at=datetime.fromisoformat(data["created_at"]),
                updated_at=datetime.fromisoformat(data["updated_at"]),
                status=SessionStatus(data["status"]),
                failure_reason=data.get("failure_reason"),
                retry_count=data["retry_count"],
                bank_name=data.get("bank_name"),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise InvalidCheckpointError("checkpoint session data is invalid") from exc
        if session.session_id != safe_id:
            raise InvalidCheckpointError("checkpoint identity does not match its filename")
        if session.created_at.tzinfo is None or session.updated_at.tzinfo is None:
            raise InvalidCheckpointError("checkpoint timestamps require timezone information")
        return session

    def delete(self, session_id: str) -> None:
        """Elimina exclusivamente el checkpoint identificado dentro del directorio controlado."""
        safe_id = _uuid(session_id, "session_id")
        path = self._directory / f"{safe_id}.json"
        if path.is_symlink():
            raise InvalidCheckpointError("checkpoint must not be a symbolic link")
        try:
            path.unlink()
        except FileNotFoundError as exc:
            raise FileNotFoundError(session_id) from exc


class CheckpointSessionRepository:
    """Repositorio perezoso: conserva índices pequeños y carga un árbol bajo demanda."""

    def __init__(self, store: JsonCheckpointStore) -> None:
        self._store = store
        self._hashes: dict[str, str] = {}

    def register(self, session: ProcessingSession) -> None:
        self._hashes[session.package_hash] = session.session_id

    def get(self, session_id: str) -> ProcessingSession | None:
        if session_id not in self._hashes.values():
            return None
        try:
            return self._store.load(session_id)
        except FileNotFoundError:
            return None

    def find_by_package_hash(self, package_hash: str) -> ProcessingSession | None:
        session_id = self._hashes.get(package_hash)
        return None if session_id is None else self.get(session_id)

    def save(self, session: ProcessingSession) -> None:
        self._store.save(session)
        self.register(session)

    def delete(self, session_id: str) -> None:
        matching = [
            package_hash
            for package_hash, known_id in self._hashes.items()
            if known_id == session_id
        ]
        for package_hash in matching:
            self._hashes.pop(package_hash, None)
        with suppress(FileNotFoundError):
            self._store.delete(session_id)


def _uuid(value: str, field: str) -> str:
    try:
        return str(UUID(value))
    except (ValueError, TypeError, AttributeError) as exc:
        raise InvalidCheckpointError(f"{field} must be a UUID") from exc


def _canonical_json(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
