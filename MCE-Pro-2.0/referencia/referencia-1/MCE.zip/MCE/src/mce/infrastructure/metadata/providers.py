"""Decoradores resilientes, caché y adaptador real inyectable de TMDb."""

from __future__ import annotations

import hashlib
import json
import os
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from threading import BoundedSemaphore, Lock
from typing import Any, Protocol, cast

from mce.application.identification.models import (
    IdentificationQuery,
    ProviderCandidate,
    ProviderTitleAlias,
    SearchKind,
)
from mce.application.identification.service import (
    ProviderCancelledError,
    ProviderError,
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderServerError,
    ProviderTimeoutError,
)
from mce.application.ports.metadata_provider import MetadataProvider


@dataclass(frozen=True, slots=True)
class MetadataProviderSettings:
    timeout_seconds: float = 10
    retries: int = 2
    max_requests: int = 40
    language: str = "es-ES"
    region: str | None = None
    offline: bool = False
    cache_ttl: timedelta = timedelta(hours=24)
    max_concurrency: int = 1
    min_interval_seconds: float = 0.0
    circuit_failure_threshold: int = 3
    circuit_cooldown_seconds: float = 30.0


@dataclass(slots=True)
class CacheEntry:
    value: tuple[ProviderCandidate, ...]
    created_at: datetime
    version: int = 1


class InMemoryMetadataCache:
    def __init__(self) -> None:
        self.entries: dict[str, CacheEntry] = {}

    def get(self, key: str, now: datetime, ttl: timedelta) -> tuple[ProviderCandidate, ...] | None:
        entry = self.entries.get(key)
        return entry.value if entry and now - entry.created_at <= ttl else None

    def put(self, key: str, value: tuple[ProviderCandidate, ...], now: datetime) -> None:
        self.entries[key] = CacheEntry(value, now)


class MetadataCache(Protocol):
    def get(
        self, key: str, now: datetime, ttl: timedelta
    ) -> tuple[ProviderCandidate, ...] | None: ...

    def put(self, key: str, value: tuple[ProviderCandidate, ...], now: datetime) -> None: ...


class UnavailableMetadataProvider:
    """Proveedor explícito para una configuración online todavía incompleta."""

    name = "unavailable"

    def __init__(self, reason: str) -> None:
        self.reason = reason

    def _raise(self) -> tuple[ProviderCandidate, ...]:
        raise ProviderOfflineError(self.reason)

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._raise()

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._raise()

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        raise ProviderOfflineError(self.reason)

    get_series_details = get_movie_details

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        raise ProviderOfflineError(self.reason)

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        raise ProviderOfflineError(self.reason)


class CachedMetadataProvider:
    """Evita llamadas repetidas y permite usar caché vigente offline."""

    def __init__(
        self,
        provider: MetadataProvider,
        cache: MetadataCache,
        ttl: timedelta = timedelta(hours=24),
        offline: bool = False,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
    ) -> None:
        self.provider = provider
        self.cache = cache
        self.ttl = ttl
        self.offline = offline
        self.clock = clock
        self.name = f"cached:{provider.name}"
        self.last_from_cache = False
        self.cache_hits = 0
        self.cache_misses = 0

    def _search(self, method: str, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        raw = json.dumps(
            {
                "provider": self.provider.name,
                "method": method,
                "query": query.__dict__
                if hasattr(query, "__dict__")
                else {field: getattr(query, field) for field in query.__dataclass_fields__},
            },
            sort_keys=True,
            default=str,
            ensure_ascii=False,
        )
        key = hashlib.sha256(raw.encode()).hexdigest()
        cached = self.cache.get(key, self.clock(), self.ttl)
        if cached is not None:
            self.last_from_cache = True
            self.cache_hits += 1
            return cached
        if self.offline:
            raise ProviderOfflineError("modo offline sin caché vigente")
        self.last_from_cache = False
        self.cache_misses += 1
        value = cast(tuple[ProviderCandidate, ...], getattr(self.provider, method)(query))
        self.cache.put(key, value, self.clock())
        return value

    def search_movie(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search("search_movie", q)

    def search_series(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search("search_series", q)

    def _detail(self, method: str, external_id: str) -> ProviderCandidate:
        raw = json.dumps(
            {"provider": self.provider.name, "method": method, "id": external_id},
            sort_keys=True,
        )
        key = hashlib.sha256(raw.encode()).hexdigest()
        cached = self.cache.get(key, self.clock(), self.ttl)
        if cached:
            self.last_from_cache = True
            self.cache_hits += 1
            return cached[0]
        if self.offline:
            raise ProviderOfflineError("modo offline sin caché vigente")
        self.last_from_cache = False
        self.cache_misses += 1
        value = cast(ProviderCandidate, getattr(self.provider, method)(external_id))
        self.cache.put(key, (value,), self.clock())
        return value

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return self._detail("get_movie_details", external_id)

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return self._detail("get_series_details", external_id)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.provider, name)


class ResilientMetadataProvider:
    """Reintenta solamente fallos transitorios con espera exponencial limitada."""

    def __init__(
        self,
        provider: MetadataProvider,
        retries: int = 2,
        base_delay: float = 0.01,
        sleep: Callable[[float], None] = time.sleep,
        cancelled: Callable[[], bool] = lambda: False,
    ) -> None:
        self.provider = provider
        self.name = f"resilient:{provider.name}"
        self.retries = retries
        self.base_delay = base_delay
        self.sleep = sleep
        self.cancelled = cancelled

    def _call(self, method: str, *args: Any) -> Any:
        for attempt in range(self.retries + 1):
            if self.cancelled():
                raise ProviderCancelledError("operación cancelada")
            try:
                return getattr(self.provider, method)(*args)
            except (ProviderTimeoutError, ProviderRateLimitError, ProviderServerError) as exc:
                if attempt == self.retries:
                    raise
                retry_after = float(getattr(exc, "retry_after", 0))
                self.sleep(max(self.base_delay * (2**attempt), retry_after))

    def search_movie(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_movie", q))

    def search_series(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_series", q))

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_movie_details", external_id))

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_series_details", external_id))

    def __getattr__(self, name: str) -> Any:
        return getattr(self.provider, name)


class RateLimitedMetadataProvider:
    """Impone un límite local explícito sin llamadas ilimitadas."""

    def __init__(self, provider: MetadataProvider, max_requests: int) -> None:
        if max_requests <= 0:
            raise ValueError("max_requests must be positive")
        self.provider = provider
        self.max_requests = max_requests
        self.calls = 0
        self.successes = 0
        self.errors = 0
        self.rate_limited = 0
        self.name = f"limited:{provider.name}"

    def _call(self, method: str, *args: Any) -> Any:
        if self.calls >= self.max_requests:
            self.rate_limited += 1
            raise ProviderRateLimitError("límite local de solicitudes alcanzado")
        self.calls += 1
        try:
            result = getattr(self.provider, method)(*args)
        except ProviderRateLimitError:
            self.rate_limited += 1
            self.errors += 1
            raise
        except ProviderError:
            self.errors += 1
            raise
        self.successes += 1
        return result

    def search_movie(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_movie", q))

    def search_series(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_series", q))

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_movie_details", external_id))

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_series_details", external_id))

    def __getattr__(self, name: str) -> Any:
        return getattr(self.provider, name)


class ControlledMetadataProvider:
    """Aísla concurrencia, ritmo y circuito de un proveedor concreto."""

    def __init__(
        self,
        provider: MetadataProvider,
        *,
        max_concurrency: int = 1,
        min_interval_seconds: float = 0.0,
        failure_threshold: int = 3,
        cooldown_seconds: float = 30.0,
        cancelled: Callable[[], bool] = lambda: False,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if max_concurrency < 1 or failure_threshold < 1:
            raise ValueError("provider control limits must be positive")
        if min_interval_seconds < 0 or cooldown_seconds < 0:
            raise ValueError("provider control durations must be non-negative")
        self.provider = provider
        self.name = f"controlled:{provider.name}"
        self._slots = BoundedSemaphore(max_concurrency)
        self._lock = Lock()
        self._interval = min_interval_seconds
        self._threshold = failure_threshold
        self._cooldown = cooldown_seconds
        self._cancelled = cancelled
        self._monotonic = monotonic
        self._sleep = sleep
        self._last_started: float | None = None
        self._failures = 0
        self._opened_at: float | None = None

    def _call(self, method: str, *args: Any) -> Any:
        now = self._monotonic()
        if self._opened_at is not None:
            if now - self._opened_at < self._cooldown:
                raise ProviderOfflineError("circuito temporalmente abierto")
            self._opened_at = None
            self._failures = 0
        while not self._slots.acquire(timeout=0.1):
            if self._cancelled():
                raise ProviderCancelledError("operación cancelada")
        try:
            with self._lock:
                if self._cancelled():
                    raise ProviderCancelledError("operación cancelada")
                now = self._monotonic()
                if self._last_started is not None:
                    delay = self._interval - (now - self._last_started)
                    if delay > 0:
                        self._sleep(delay)
                self._last_started = self._monotonic()
            try:
                value = getattr(self.provider, method)(*args)
            except ProviderCancelledError:
                raise
            except ProviderError:
                self._failures += 1
                if self._failures >= self._threshold:
                    self._opened_at = self._monotonic()
                raise
            self._failures = 0
            self._opened_at = None
            return value
        finally:
            self._slots.release()

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_movie", query))

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return cast(tuple[ProviderCandidate, ...], self._call("search_series", query))

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_movie_details", external_id))

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return cast(ProviderCandidate, self._call("get_series_details", external_id))

    def __getattr__(self, name: str) -> Any:
        return getattr(self.provider, name)


class JsonTransport(Protocol):
    def get_json(
        self, path: str, params: dict[str, object], timeout: float
    ) -> dict[str, object] | list[object]: ...


class TmdbMetadataProvider:
    """Adaptador TMDb sin red implícita; recibe transporte y credencial."""

    name = "tmdb"

    def __init__(
        self,
        api_key: str,
        transport: JsonTransport,
        timeout: float = 10,
        language: str = "es-ES",
        region: str | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("TMDB_API_KEY is required")
        self.key = api_key
        self.transport = transport
        self.timeout = timeout
        self.language = language
        self.region = region

    @classmethod
    def from_environment(
        cls, transport: JsonTransport, settings: MetadataProviderSettings | None = None
    ) -> TmdbMetadataProvider:
        """Construye el adaptador desde `TMDB_API_KEY` sin registrar su valor."""
        chosen = settings or MetadataProviderSettings()
        return cls(
            os.environ.get("TMDB_API_KEY", "").strip(),
            transport,
            chosen.timeout_seconds,
            chosen.language,
            chosen.region,
        )

    def _search(self, query: IdentificationQuery, media: str) -> tuple[ProviderCandidate, ...]:
        params: dict[str, object] = {
            "api_key": self.key,
            "query": query.title,
            "language": self.language,
            "region": self.region,
            "include_adult": False,
        }
        if query.year is not None:
            params["primary_release_year" if media == "movie" else "year"] = query.year
        data = self.transport.get_json(
            f"/search/{media}",
            params,
            self.timeout,
        )
        if not isinstance(data, dict):
            raise ProviderResponseError("respuesta TMDb inválida")
        results = data.get("results")
        if not isinstance(results, list):
            raise ProviderResponseError("respuesta TMDb inválida")
        kind = SearchKind.MOVIE if media == "movie" else SearchKind.SERIES
        candidates: list[ProviderCandidate] = []
        for item in results:
            if not isinstance(item, dict) or "id" not in item:
                raise ProviderResponseError("candidato TMDb inválido")
            title = item.get("title") or item.get("name")
            if not isinstance(title, str) or not title.strip():
                raise ProviderResponseError("candidato TMDb sin título")
            raw_date = str(item.get("release_date") or item.get("first_air_date") or "")
            year_text = raw_date[:4]
            origin = item.get("origin_country")
            country = str(origin[0]) if isinstance(origin, list) and origin else None
            candidates.append(
                ProviderCandidate(
                    "tmdb",
                    str(item["id"]),
                    kind,
                    title.strip(),
                    str(item.get("original_title") or item.get("original_name") or "") or None,
                    year=int(year_text) if year_text.isdigit() else None,
                    country=country,
                )
            )
        return tuple(candidates)

    def search_movie(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(q, "movie")

    def search_series(self, q: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(q, "tv")

    def _details(self, external_id: str, media: str) -> ProviderCandidate:
        data = self.transport.get_json(
            f"/{media}/{external_id}",
            {
                "api_key": self.key,
                "language": self.language,
                "append_to_response": (
                    "external_ids,credits,alternative_titles,translations,images"
                ),
                "include_image_language": "es,null,en",
            },
            self.timeout,
        )
        if not isinstance(data, dict) or "id" not in data:
            raise ProviderResponseError("detalle TMDb inválido")
        kind = SearchKind.MOVIE if media == "movie" else SearchKind.SERIES
        title = str(data.get("title") or data.get("name") or "").strip()
        if not title:
            raise ProviderResponseError("detalle TMDb sin título")
        date = str(data.get("release_date") or data.get("first_air_date") or "")
        credits = data.get("credits") if isinstance(data.get("credits"), dict) else {}
        cast_rows = credits.get("cast") if isinstance(credits, dict) else []
        crew_rows = credits.get("crew") if isinstance(credits, dict) else []
        cast_names = (
            tuple(
                str(row["name"]).strip()
                for row in cast_rows[:20]
                if isinstance(row, dict) and row.get("name")
            )
            if isinstance(cast_rows, list)
            else ()
        )
        director = (
            next(
                (
                    str(row["name"]).strip()
                    for row in crew_rows
                    if isinstance(row, dict)
                    and row.get("job") in {"Director", "Creator"}
                    and row.get("name")
                ),
                None,
            )
            if isinstance(crew_rows, list)
            else None
        )
        external = data.get("external_ids") if isinstance(data.get("external_ids"), dict) else {}
        identifiers = [("tmdb_movie" if media == "movie" else "tmdb_tv", str(data["id"]))]
        for source, key in (("imdb", "imdb_id"), ("thetvdb", "tvdb_id")):
            value = external.get(key) if isinstance(external, dict) else None
            if value:
                identifiers.append((source, str(value)))
        images_data = data.get("images") if isinstance(data.get("images"), dict) else {}
        image_rows: list[tuple[str, str]] = []
        for category in ("posters", "backdrops", "logos"):
            rows = images_data.get(category) if isinstance(images_data, dict) else []
            if isinstance(rows, list):
                for row in rows[:5]:
                    if isinstance(row, dict) and row.get("file_path"):
                        image_rows.append(
                            (category, f"https://image.tmdb.org/t/p/original{row['file_path']}")
                        )
        genre_rows = data.get("genres")
        genres = (
            tuple(
                str(row["name"]).strip()
                for row in cast(list[object], genre_rows)
                if isinstance(row, dict) and row.get("name")
            )
            if isinstance(genre_rows, list)
            else ()
        )
        language_rows = data.get("spoken_languages")
        languages = (
            tuple(
                str(row.get("iso_639_1") or row.get("english_name")).strip()
                for row in cast(list[object], language_rows)
                if isinstance(row, dict) and (row.get("iso_639_1") or row.get("english_name"))
            )
            if isinstance(language_rows, list)
            else ()
        )
        runtime = data.get("runtime")
        episode_count = data.get("number_of_episodes")
        season_count = data.get("number_of_seasons")
        alternative = data.get("alternative_titles")
        alternative_rows = (
            alternative.get("titles") or alternative.get("results")
            if isinstance(alternative, dict)
            else []
        )
        if not isinstance(alternative_rows, list):
            alternative_rows = []
        title_aliases = [
            ProviderTitleAlias(
                str(row.get("title") or row.get("name")).strip(),
                country=str(row.get("iso_3166_1") or "").strip() or None,
                alias_type=str(row.get("type") or "alternative").strip().casefold(),
                provenance="tmdb:alternative_titles",
            )
            for row in alternative_rows
            if isinstance(row, dict) and (row.get("title") or row.get("name"))
        ]
        translated: list[str] = []
        spanish_title = title if self.language.casefold().startswith("es") else None
        english_title = None
        translations = data.get("translations")
        translation_rows = (
            translations.get("translations") if isinstance(translations, dict) else []
        )
        if isinstance(translation_rows, list):
            for row in translation_rows:
                if not isinstance(row, dict) or not isinstance(row.get("data"), dict):
                    continue
                language = str(row.get("iso_639_1") or "").strip() or None
                country_code = str(row.get("iso_3166_1") or "").strip() or None
                translated_title = str(
                    row["data"].get("title") or row["data"].get("name") or ""
                ).strip()
                if not translated_title:
                    continue
                translated.append(translated_title)
                title_aliases.append(
                    ProviderTitleAlias(
                        translated_title,
                        language,
                        country_code,
                        "translated",
                        "tmdb:translations",
                    )
                )
                if language == "es" and spanish_title is None:
                    spanish_title = translated_title
                if language == "en" and english_title is None:
                    english_title = translated_title
        return ProviderCandidate(
            "tmdb",
            str(data["id"]),
            kind,
            title,
            str(data.get("original_title") or data.get("original_name") or "") or None,
            year=int(date[:4]) if date[:4].isdigit() else None,
            cast=cast_names,
            director=director,
            duration_minutes=runtime if isinstance(runtime, int) else None,
            overview=str(data.get("overview") or "").strip() or None,
            genres=genres,
            languages=languages,
            cast_names=cast_names,
            status=str(data.get("status") or "").strip() or None,
            episode_count=episode_count if isinstance(episode_count, int) else None,
            season_count=season_count if isinstance(season_count, int) else None,
            external_ids=tuple(identifiers),
            images=tuple(image_rows),
            ratings=(("tmdb", str(data["vote_average"])),)
            if data.get("vote_average") is not None
            else (),
            source_url=f"https://www.themoviedb.org/{media}/{data['id']}",
            spanish_title=spanish_title,
            english_title=english_title,
            translated_titles=tuple(dict.fromkeys(translated)),
            aliases=tuple(dict.fromkeys(alias.title for alias in title_aliases)),
            title_aliases=tuple(title_aliases),
        )

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return self._details(external_id, "movie")

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return self._details(external_id, "tv")

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        result = self.transport.get_json(
            f"/tv/{external_id}/season/{season}",
            {"api_key": self.key, "language": self.language},
            self.timeout,
        )
        if not isinstance(result, dict):
            raise ProviderResponseError("respuesta TMDb inválida")
        return result

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        result = self.transport.get_json(
            f"/tv/{external_id}/season/{season}/episode/{episode}",
            {"api_key": self.key, "language": self.language},
            self.timeout,
        )
        if not isinstance(result, dict):
            raise ProviderResponseError("respuesta TMDb inválida")
        return result
