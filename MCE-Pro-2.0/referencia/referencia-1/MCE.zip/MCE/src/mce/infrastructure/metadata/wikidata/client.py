"""Cliente mínimo de Wikibase; no realiza scraping de Wikipedia."""

from __future__ import annotations

from mce.infrastructure.metadata.providers import JsonTransport

from .config import WikidataProviderConfig
from .parser import WikidataResponseParser


class WikidataClient:
    def __init__(
        self,
        transport: JsonTransport,
        config: WikidataProviderConfig,
        parser: WikidataResponseParser | None = None,
    ) -> None:
        self.transport = transport
        self.config = config
        self.parser = parser or WikidataResponseParser()

    def search(self, title: str, language: str) -> tuple[str, ...]:
        payload = self.transport.get_json(
            "/w/api.php",
            {
                "action": "wbsearchentities",
                "search": title,
                "language": language,
                "uselang": language,
                "type": "item",
                "format": "json",
                "limit": self.config.max_candidates,
            },
            self.config.timeout_seconds,
        )
        return self.parser.search_ids(payload)

    def get_entities(self, qids: tuple[str, ...]) -> tuple[dict[str, object], ...]:
        if not qids:
            return ()
        payload = self.transport.get_json(
            "/w/api.php",
            {
                "action": "wbgetentities",
                "ids": "|".join(qids[: self.config.max_candidates]),
                "props": "labels|descriptions|aliases|sitelinks|claims",
                "languages": "|".join(self.config.languages),
                "languagefallback": 1,
                "format": "json",
            },
            self.config.timeout_seconds,
        )
        return self.parser.entities(payload)
