"""Mapeo de evidencia de navegador a metadatos parciales con procedencia."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime

from mce.application.ai_review.models import EvidenceSource
from mce.application.enrichment.models import MetadataField
from mce.application.web_search import utc_now
from mce.domain.value_objects import FieldProvenance, FieldSourceType
from mce.infrastructure.metadata.browser_extractor import (
    BrowserPageExtraction,
    ExtractedBrowserEvidence,
)
from mce.infrastructure.metadata.browser_search import BrowserSearchStatus

_EXPECTED_FIELDS = (
    "title",
    "year",
    "type",
    "season_count",
    "episode_count",
    "genres",
    "cast",
    "director",
    "duration_minutes",
    "ratings",
    "platforms",
    "aliases",
    "overview",
    "source_url",
    "poster",
)


@dataclass(frozen=True, slots=True)
class BrowserPartialEnrichment:
    """Conjunto trazable de campos demostrados por una evidencia concreta."""

    fields: dict[str, MetadataField]
    missing_fields: tuple[str, ...]
    origin: str
    source_url: str | None

    @property
    def is_partial(self) -> bool:
        return bool(self.missing_fields)

    @property
    def completeness_percent(self) -> float:
        return round(len(self.fields) * 100.0 / len(_EXPECTED_FIELDS), 1)


class BrowserPartialEnrichmentMapper:
    """Reutiliza MetadataField y FieldProvenance; nunca materializa ausencias."""

    def __init__(self, clock: Callable[[], datetime] = utc_now) -> None:
        self.clock = clock

    def map(
        self,
        extraction: BrowserPageExtraction,
    ) -> tuple[BrowserPartialEnrichment, ...]:
        if extraction.status not in {
            BrowserSearchStatus.SUCCESS,
            BrowserSearchStatus.PARTIAL,
        }:
            return ()
        obtained_at = self.clock()
        return tuple(self._map_evidence(evidence, obtained_at) for evidence in extraction.evidence)

    @staticmethod
    def _map_evidence(
        evidence: ExtractedBrowserEvidence,
        obtained_at: datetime,
    ) -> BrowserPartialEnrichment:
        source_url = evidence.source_url or None
        provenance = FieldProvenance(
            FieldSourceType.PROVIDER,
            "browser_search",
            source_url,
            obtained_at,
            confidence=None,
        )
        fields: dict[str, MetadataField] = {}

        def add(name: str, value: object) -> None:
            if value is None or value == "" or value == ():
                return
            fields[name] = MetadataField(value, provenance)

        add("title", evidence.title)
        add("year", evidence.year)
        add("type", evidence.media_type)
        add("season_count", evidence.seasons)
        add("genres", evidence.genres)
        add("cast", evidence.cast)
        add(
            "ratings",
            (("browser_search", f"{evidence.rating:g}"),)
            if evidence.rating is not None
            else None,
        )
        add("platforms", evidence.platforms)
        add("aliases", evidence.alternate_titles)
        add("overview", evidence.snippet)
        add("source_url", source_url)

        missing = tuple(name for name in _EXPECTED_FIELDS if name not in fields)
        return BrowserPartialEnrichment(
            fields=fields,
            missing_fields=missing,
            origin=evidence.origin,
            source_url=source_url,
        )


class BrowserQwenEvidenceAdapter:
    """Convierte campos parciales trazables al contexto compacto de Qwen."""

    @staticmethod
    def adapt(
        values: tuple[BrowserPartialEnrichment, ...],
    ) -> tuple[EvidenceSource, ...]:
        return tuple(BrowserQwenEvidenceAdapter._source(value) for value in values)

    @staticmethod
    def _source(value: BrowserPartialEnrichment) -> EvidenceSource:
        fields = value.fields

        def field(name: str) -> object | None:
            item = fields.get(name)
            return None if item is None else item.value

        def strings(name: str) -> tuple[str, ...]:
            raw = field(name)
            if not isinstance(raw, (list, tuple)):
                return ()
            return tuple(str(item) for item in raw if str(item).strip())

        title = field("title")
        overview = field("overview")
        year = field("year")
        media_type = field("type")
        season_count = field("season_count")
        ratings = field("ratings")
        rating: float | None = None
        if isinstance(ratings, tuple) and ratings:
            first = ratings[0]
            if isinstance(first, tuple) and len(first) >= 2:
                try:
                    rating = float(first[1])
                except (TypeError, ValueError):
                    rating = None
        return EvidenceSource(
            url=value.source_url or "",
            title=str(title or ""),
            snippet=str(overview or ""),
            provider="browser_search",
            year=year if isinstance(year, int) else None,
            media_type=str(media_type) if media_type else None,
            seasons=(season_count,) if isinstance(season_count, int) else (),
            genres=strings("genres"),
            cast=strings("cast"),
            rating=rating,
            platforms=strings("platforms"),
            alternative_titles=strings("aliases"),
            origin=value.origin,
        )


__all__ = [
    "BrowserPartialEnrichment",
    "BrowserPartialEnrichmentMapper",
    "BrowserQwenEvidenceAdapter",
]
