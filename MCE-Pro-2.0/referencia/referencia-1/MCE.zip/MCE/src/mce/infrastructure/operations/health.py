"""Diagnóstico operativo sin exposición de secretos."""

from __future__ import annotations

import platform
import shutil
import sqlite3
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, text

from mce.infrastructure.database.diagnostics import (
    inspect_runtime_database_configuration,
    runtime_database_url,
)
from mce.version import __version__


@dataclass(frozen=True, slots=True)
class HealthCheck:
    name: str
    status: str
    message: str


@dataclass(frozen=True, slots=True)
class HealthReport:
    checks: tuple[HealthCheck, ...]

    @property
    def healthy(self) -> bool:
        return all(item.status != "error" for item in self.checks)


def migration_head(project_dir: Path) -> str | None:
    """Resuelve las migraciones desde el paquete, no desde el CWD del proceso."""
    config = Config(str(project_dir / "alembic.ini"))
    config.set_main_option("script_location", str(project_dir / "migrations"))
    return ScriptDirectory.from_config(config).get_current_head()


class HealthService:
    def __init__(
        self,
        database_checker: Callable[[Path], tuple[HealthCheck, HealthCheck]] | None = None,
    ) -> None:
        self._database_checker = database_checker or self._check_database

    def inspect(self, project_dir: Path, cache_path: Path) -> HealthReport:
        root = project_dir.resolve()
        checks = [
            HealthCheck("mce_version", "ok", __version__),
            HealthCheck("python", "ok", platform.python_version()),
            HealthCheck("platform", "ok", sys.platform),
        ]
        checks.extend(self._database_checker(root))
        free = shutil.disk_usage(root).free
        checks.append(
            HealthCheck(
                "disk",
                "ok" if free >= 1_073_741_824 else "warning",
                f"{free} bytes libres",
            )
        )
        for name in ("data", "data/session_checkpoints"):
            path = root / name
            try:
                path.mkdir(parents=True, exist_ok=True)
                writable = path.is_dir()
            except OSError:
                writable = False
            checks.append(
                HealthCheck(
                    name,
                    "ok" if writable else "error",
                    "disponible" if writable else "sin acceso",
                )
            )
        checks.append(self._cache_check(cache_path))
        return HealthReport(tuple(checks))

    @staticmethod
    def _check_database(project_dir: Path) -> tuple[HealthCheck, HealthCheck]:
        configuration = inspect_runtime_database_configuration()
        if not configuration.safe:
            warning = HealthCheck("postgresql", "warning", configuration.message)
            return warning, HealthCheck("migrations", "warning", "sin comprobar")
        raw = runtime_database_url()
        if raw is None:
            warning = HealthCheck("postgresql", "warning", "destino rechazado")
            return warning, HealthCheck("migrations", "warning", "sin comprobar")
        engine = create_engine(raw, pool_pre_ping=True, connect_args={"connect_timeout": 3})
        try:
            with engine.connect() as connection:
                connection.execute(text("SELECT 1"))
                current = connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar()
            head = migration_head(project_dir)
            migration_status = "ok" if current == head else "warning"
            migration_message = "al día" if current == head else "migraciones pendientes"
            return (
                HealthCheck("postgresql", "ok", "conexión disponible"),
                HealthCheck("migrations", migration_status, migration_message),
            )
        except Exception as exc:
            return (
                HealthCheck("postgresql", "error", f"conexión fallida: {type(exc).__name__}"),
                HealthCheck("migrations", "warning", "sin comprobar"),
            )
        finally:
            engine.dispose()

    @staticmethod
    def _cache_check(path: Path) -> HealthCheck:
        if not path.exists():
            return HealthCheck("cache", "ok", "se creará al utilizarse")
        try:
            with sqlite3.connect(path) as connection:
                result = connection.execute("PRAGMA quick_check").fetchone()
            healthy = bool(result and result[0] == "ok")
        except sqlite3.Error:
            healthy = False
        return HealthCheck(
            "cache", "ok" if healthy else "error", "íntegra" if healthy else "dañada"
        )
