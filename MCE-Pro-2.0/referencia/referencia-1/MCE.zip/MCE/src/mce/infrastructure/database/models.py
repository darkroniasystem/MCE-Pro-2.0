"""Modelos ORM separados del dominio."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Metadatos del esquema MCE."""


class BankModel(Base):
    __tablename__ = "banks"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    external_bank_id: Mapped[str | None] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255))
    code: Mapped[str | None] = mapped_column(String(64), unique=True)
    branch: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class InstallationModel(Base):
    __tablename__ = "installations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    bank_id: Mapped[str] = mapped_column(ForeignKey("banks.id", ondelete="RESTRICT"), index=True)
    name: Mapped[str] = mapped_column(String(255))
    machine_identifier: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("bank_id", "machine_identifier"),)


class SourceModel(Base):
    __tablename__ = "sources"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    installation_id: Mapped[str] = mapped_column(
        ForeignKey("installations.id", ondelete="RESTRICT"), index=True
    )
    source_type: Mapped[str] = mapped_column(String(32))
    display_name: Mapped[str] = mapped_column(String(255))
    root_path: Mapped[str] = mapped_column(Text)
    normalized_root_path: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32))
    __table_args__ = (UniqueConstraint("installation_id", "normalized_root_path"),)


class ScanModel(Base):
    __tablename__ = "scans"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    installation_id: Mapped[str] = mapped_column(
        ForeignKey("installations.id", ondelete="RESTRICT"), index=True
    )
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    scope_type: Mapped[str] = mapped_column(String(32))
    scope_data: Mapped[dict[str, Any]] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(32))
    msl_version: Mapped[str] = mapped_column(String(32))
    schema_version: Mapped[str] = mapped_column(String(32))


class ScanImportModel(Base):
    __tablename__ = "scan_imports"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id", ondelete="RESTRICT"), index=True)
    bank_id: Mapped[str] = mapped_column(ForeignKey("banks.id", ondelete="RESTRICT"), index=True)
    original_filename: Mapped[str] = mapped_column(String(255))
    file_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(32))
    is_duplicate: Mapped[bool] = mapped_column(Boolean, default=False)
    reverted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    errors: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    __table_args__ = (CheckConstraint("length(file_hash)=64"),)


class OriginalJsonModel(Base):
    __tablename__ = "original_jsons"
    file_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    storage_reference: Mapped[str] = mapped_column(Text, unique=True)
    original_filename: Mapped[str] = mapped_column(String(255))
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    schema_version: Mapped[str | None] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32), default="verified")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    verified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint("length(file_hash)=64"),
        CheckConstraint("size_bytes>=0"),
    )


class ImportStagingDocumentModel(Base):
    __tablename__ = "import_staging_documents"
    import_id: Mapped[str] = mapped_column(
        ForeignKey("scan_imports.id", ondelete="CASCADE"), primary_key=True
    )
    original_hash: Mapped[str] = mapped_column(
        ForeignKey("original_jsons.file_hash", ondelete="RESTRICT"), index=True
    )
    header: Mapped[dict[str, Any]] = mapped_column(JSON)
    source_count: Mapped[int] = mapped_column(Integer)
    video_count: Mapped[int] = mapped_column(Integer)
    subtitle_count: Mapped[int] = mapped_column(Integer)
    warning_count: Mapped[int] = mapped_column(Integer)
    error_count: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32), default="validated")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class ProcessingSessionModel(Base):
    __tablename__ = "processing_sessions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    workspace_id: Mapped[str] = mapped_column(String(36), index=True)
    import_id: Mapped[str] = mapped_column(
        ForeignKey("scan_imports.id", ondelete="RESTRICT"), unique=True
    )
    package_hash: Mapped[str] = mapped_column(String(64))
    scan_id: Mapped[str | None] = mapped_column(String(36), index=True)
    bank_id: Mapped[str | None] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True
    )
    external_bank_id: Mapped[str | None] = mapped_column(String(255), index=True)
    schema_version: Mapped[str | None] = mapped_column(String(32))
    msl_app_version: Mapped[str | None] = mapped_column(String(32))
    original_filename: Mapped[str | None] = mapped_column(String(255))
    source_path: Mapped[str | None] = mapped_column(Text)
    original_size: Mapped[int | None] = mapped_column(BigInteger)
    original_reference: Mapped[str | None] = mapped_column(Text)
    scope_data: Mapped[dict[str, Any]] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(32))
    failure_reason: Mapped[str | None] = mapped_column(Text)
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    interrupted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    recoverable: Mapped[bool] = mapped_column(Boolean, default=False)
    current_stage: Mapped[str | None] = mapped_column(String(32))
    total_expected: Mapped[int] = mapped_column(Integer, default=0)
    processed_count: Mapped[int] = mapped_column(Integer, default=0)
    inserted_count: Mapped[int] = mapped_column(Integer, default=0)
    updated_count: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_count: Mapped[int] = mapped_column(Integer, default=0)
    skipped_count: Mapped[int] = mapped_column(Integer, default=0)
    warning_count: Mapped[int] = mapped_column(Integer, default=0)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
    uncertain_count: Mapped[int] = mapped_column(Integer, default=0)
    enrichment_summary: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    version: Mapped[int] = mapped_column(Integer, default=1)
    __table_args__ = (CheckConstraint("retry_count>=0"),)


class ProcessingJobModel(Base):
    __tablename__ = "processing_jobs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        ForeignKey("processing_sessions.id", ondelete="CASCADE"), index=True
    )
    status: Mapped[str] = mapped_column(String(32))
    stage: Mapped[str | None] = mapped_column(String(32))
    progress: Mapped[float] = mapped_column(Float, default=0)
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    job_type: Mapped[str] = mapped_column(String(32), default="import")
    total: Mapped[int] = mapped_column(Integer, default=0)
    processed: Mapped[int] = mapped_column(Integer, default=0)
    succeeded: Mapped[int] = mapped_column(Integer, default=0)
    failed: Mapped[int] = mapped_column(Integer, default=0)
    skipped: Mapped[int] = mapped_column(Integer, default=0)
    cache_hits: Mapped[int] = mapped_column(Integer, default=0)
    current_checkpoint: Mapped[str | None] = mapped_column(String(36))
    worker_owner: Mapped[str | None] = mapped_column(String(255))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    error_summary: Mapped[str | None] = mapped_column(Text)
    __table_args__ = (CheckConstraint("progress>=0 AND progress<=100"),)


class ProcessingCheckpointModel(Base):
    __tablename__ = "processing_checkpoints"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    job_id: Mapped[str] = mapped_column(
        ForeignKey("processing_jobs.id", ondelete="CASCADE"), index=True
    )
    stage: Mapped[str] = mapped_column(String(32))
    batch_number: Mapped[int] = mapped_column(Integer)
    last_completed_item: Mapped[str | None] = mapped_column(String(36))
    processed_count: Mapped[int] = mapped_column(Integer)
    resume_data: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    checksum: Mapped[str] = mapped_column(String(64))
    __table_args__ = (UniqueConstraint("job_id", "stage", "batch_number"),)


class ProcessingSessionItemModel(Base):
    __tablename__ = "processing_session_items"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        ForeignKey("processing_sessions.id", ondelete="CASCADE"), index=True
    )
    physical_file_id: Mapped[str] = mapped_column(
        ForeignKey("physical_files.id", ondelete="CASCADE"), unique=True
    )
    ordinal: Mapped[int] = mapped_column(Integer)
    state: Mapped[dict[str, Any]] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("session_id", "ordinal"),)


class AIReviewRunModel(Base):
    """Auditoria versionada de cada intento IA por obra logica."""

    __tablename__ = "ai_review_runs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        ForeignKey("processing_sessions.id", ondelete="CASCADE"), index=True
    )
    bank_id: Mapped[str | None] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True
    )
    work_group_id: Mapped[str] = mapped_column(String(255), index=True)
    query_fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    search_provider: Mapped[str] = mapped_column(String(32))
    ai_provider: Mapped[str] = mapped_column(String(32))
    ai_model: Mapped[str | None] = mapped_column(String(128))
    prompt_version: Mapped[str] = mapped_column(String(64))
    schema_version: Mapped[str] = mapped_column(String(64))
    sanitized_query: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    sources: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    contradictions: Mapped[list[str]] = mapped_column(JSON, default=list)
    structured_response: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    model_confidence: Mapped[float | None] = mapped_column(Float)
    mce_score: Mapped[float | None] = mapped_column(Float)
    state: Mapped[str] = mapped_column(String(32))
    decision: Mapped[str] = mapped_column(String(32))
    cached: Mapped[bool] = mapped_column(Boolean, default=False)
    attempt_count: Mapped[int] = mapped_column(Integer, default=1)
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    input_tokens: Mapped[int | None] = mapped_column(Integer)
    output_tokens: Mapped[int | None] = mapped_column(Integer)
    error: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        UniqueConstraint(
            "session_id",
            "work_group_id",
            "query_fingerprint",
            name="uq_ai_review_session_work_fingerprint",
        ),
    )


class BankConsolidationModel(Base):
    __tablename__ = "bank_consolidations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    external_bank_id: Mapped[str] = mapped_column(String(255), index=True)
    canonical_bank_id: Mapped[str] = mapped_column(String(36))
    merged_bank_ids: Mapped[list[str]] = mapped_column(JSON)
    affected_tables: Mapped[dict[str, int]] = mapped_column(JSON)
    moved_records: Mapped[int] = mapped_column(Integer)
    conflicts: Mapped[list[dict[str, Any]]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    result: Mapped[str] = mapped_column(String(32))
    rollback_reference: Mapped[str | None] = mapped_column(Text)


class CanonicalWorkModel(Base):
    __tablename__ = "canonical_works"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    provider: Mapped[str] = mapped_column(String(32))
    content_type: Mapped[str] = mapped_column(String(32))
    external_id: Mapped[str] = mapped_column(String(255))
    official_title: Mapped[str] = mapped_column(String(500))
    release_year: Mapped[int | None] = mapped_column(Integer)
    metadata_payload: Mapped[dict[str, Any]] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        UniqueConstraint(
            "provider", "content_type", "external_id", name="uq_canonical_work_identity"
        ),
    )


class ContentModel(Base):
    __tablename__ = "contents"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_type: Mapped[str] = mapped_column(String(32))
    main_title: Mapped[str] = mapped_column(String(500))
    original_title: Mapped[str | None] = mapped_column(String(500))
    raw_bank_title: Mapped[str | None] = mapped_column(String(500))
    clean_bank_title: Mapped[str | None] = mapped_column(String(500))
    spanish_title: Mapped[str | None] = mapped_column(String(500))
    english_title: Mapped[str | None] = mapped_column(String(500))
    preferred_display_title: Mapped[str | None] = mapped_column(String(500))
    normalized_search_text: Mapped[str | None] = mapped_column(Text)
    release_year: Mapped[int | None] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32))
    identification_status: Mapped[str] = mapped_column(String(32))
    review_status: Mapped[str] = mapped_column(String(32))
    catalog_stage: Mapped[str] = mapped_column(String(16), default="staging", index=True)
    catalog_code: Mapped[str | None] = mapped_column(String(100), unique=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    bank_id: Mapped[str | None] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True, nullable=True
    )
    parent_content_id: Mapped[str | None] = mapped_column(
        ForeignKey("contents.id", ondelete="SET NULL"), index=True
    )
    canonical_work_id: Mapped[str | None] = mapped_column(
        ForeignKey("canonical_works.id", ondelete="RESTRICT"), index=True
    )
    work_group_id: Mapped[str | None] = mapped_column(String(36), index=True)
    publication_status: Mapped[str] = mapped_column(
        String(32), default="publication_blocked", index=True
    )
    publication_block_reason: Mapped[str | None] = mapped_column(Text)
    identification_confidence: Mapped[float | None] = mapped_column(Float)
    metadata_confidence: Mapped[float | None] = mapped_column(Float)
    matching_version: Mapped[str | None] = mapped_column(String(64))
    metadata_merge_version: Mapped[str | None] = mapped_column(String(64))
    publication_policy_version: Mapped[str | None] = mapped_column(String(64))
    __table_args__ = (
        CheckConstraint(
            "catalog_stage IN ('staging','approved','published')",
            name="ck_contents_catalog_stage",
        ),
    )


class ExternalIdentifierModel(Base):
    __tablename__ = "external_identifiers"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    provider: Mapped[str] = mapped_column(String(32))
    identifier_type: Mapped[str] = mapped_column(String(32))
    external_id: Mapped[str] = mapped_column(String(255))
    source_url: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        UniqueConstraint("content_id", "identifier_type", name="uq_content_identifier_type"),
    )


class ContentAliasModel(Base):
    __tablename__ = "content_aliases"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    bank_id: Mapped[str | None] = mapped_column(
        ForeignKey("banks.id", ondelete="CASCADE"), index=True
    )
    alias: Mapped[str] = mapped_column(String(500))
    normalized_alias: Mapped[str] = mapped_column(String(500))
    source: Mapped[str] = mapped_column(String(32))
    provider: Mapped[str | None] = mapped_column(String(32), index=True)
    provider_entity_id: Mapped[str | None] = mapped_column(String(64), index=True)
    language: Mapped[str | None] = mapped_column(String(32))
    country: Mapped[str | None] = mapped_column(String(8))
    alias_type: Mapped[str] = mapped_column(String(32), default="alternative")
    provenance: Mapped[str | None] = mapped_column(String(255))
    confirmed: Mapped[bool] = mapped_column(Boolean, default=False)
    is_manual: Mapped[bool] = mapped_column(Boolean, default=False)
    confidence: Mapped[float | None] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        UniqueConstraint(
            "content_id", "bank_id", "normalized_alias", name="uq_content_bank_normalized_alias"
        ),
        Index("ix_content_aliases_language", "language"),
        Index("ix_content_aliases_normalized", "normalized_alias"),
    )


class NormalizedMetadataModel(Base):
    __tablename__ = "normalized_metadata"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    field_name: Mapped[str] = mapped_column(String(64))
    value: Mapped[Any] = mapped_column(JSON)
    provider: Mapped[str] = mapped_column(String(32))
    external_reference: Mapped[str | None] = mapped_column(String(255))
    confidence: Mapped[float | None] = mapped_column(Float)
    obtained_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    locked: Mapped[bool] = mapped_column(Boolean, default=False)
    __table_args__ = (
        UniqueConstraint("content_id", "field_name", name="uq_content_metadata_field"),
    )


class ProviderQueryModel(Base):
    __tablename__ = "provider_queries"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str | None] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    provider: Mapped[str] = mapped_column(String(32), index=True)
    operation: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32))
    queried_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    diagnostic: Mapped[str | None] = mapped_column(Text)
    result_count: Mapped[int | None] = mapped_column(Integer)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AuditEventModel(Base):
    __tablename__ = "audit_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    actor: Mapped[str] = mapped_column(String(255))
    action: Mapped[str] = mapped_column(String(64), index=True)
    object_type: Mapped[str] = mapped_column(String(64), index=True)
    object_id: Mapped[str] = mapped_column(String(255), index=True)
    previous_value: Mapped[Any] = mapped_column(JSON, nullable=True)
    new_value: Mapped[Any] = mapped_column(JSON, nullable=True)
    correlation_id: Mapped[str] = mapped_column(String(36), index=True)
    reversible: Mapped[bool] = mapped_column(Boolean, default=False)
    reversed_by: Mapped[str | None] = mapped_column(
        ForeignKey("audit_events.id", ondelete="RESTRICT"), nullable=True
    )


class ContentVersionModel(Base):
    __tablename__ = "content_versions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(255))
    edition_type: Mapped[str | None] = mapped_column(String(100))
    language_variant: Mapped[str | None] = mapped_column(String(100))
    notes: Mapped[str | None] = mapped_column(Text)


class CatalogPublicationModel(Base):
    __tablename__ = "catalog_publications"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    catalog_version: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    previous_version_id: Mapped[str | None] = mapped_column(
        ForeignKey("catalog_publications.id", ondelete="RESTRICT"), nullable=True
    )
    status: Mapped[str] = mapped_column(String(24), index=True)
    validation_report: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    __table_args__ = (
        CheckConstraint(
            "status IN ('failed','active','superseded')",
            name="ck_catalog_publications_status",
        ),
    )


class CatalogPublicationEntryModel(Base):
    __tablename__ = "catalog_publication_entries"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    publication_id: Mapped[str] = mapped_column(
        ForeignKey("catalog_publications.id", ondelete="CASCADE"), index=True
    )
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="RESTRICT"), index=True
    )
    bank_id: Mapped[str] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True
    )
    payload: Mapped[dict[str, Any]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    __table_args__ = (UniqueConstraint("publication_id", "content_id", "bank_id"),)


class PhysicalFileModel(Base):
    __tablename__ = "physical_files"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    bank_id: Mapped[str] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True
    )
    catalog_file_id: Mapped[str | None] = mapped_column(
        ForeignKey("catalog_file_identities.id", ondelete="RESTRICT"), index=True
    )
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id", ondelete="RESTRICT"), index=True)
    source_id: Mapped[str] = mapped_column(
        ForeignKey("sources.id", ondelete="RESTRICT"), index=True
    )
    content_id: Mapped[str | None] = mapped_column(
        ForeignKey("contents.id", ondelete="SET NULL"), index=True
    )
    content_version_id: Mapped[str | None] = mapped_column(
        ForeignKey("content_versions.id", ondelete="SET NULL")
    )
    original_name: Mapped[str] = mapped_column(String(255))
    relative_path: Mapped[str] = mapped_column(Text)
    original_path: Mapped[str] = mapped_column(Text)
    normalized_path: Mapped[str] = mapped_column(Text)
    extension: Mapped[str] = mapped_column(String(32))
    size_bytes: Mapped[int | None] = mapped_column(BigInteger)
    cryptographic_hash: Mapped[str | None] = mapped_column(String(128))
    fingerprint_key: Mapped[str] = mapped_column(String(1000))
    status: Mapped[str] = mapped_column(String(32))
    duration_seconds: Mapped[float | None] = mapped_column(Float)
    detected_category: Mapped[str | None] = mapped_column(String(64), index=True)
    category_confidence: Mapped[float | None] = mapped_column(Float)
    classification_status: Mapped[str] = mapped_column(
        String(32), default="classification_pending", index=True
    )
    clean_title: Mapped[str | None] = mapped_column(String(500))
    original_group_title: Mapped[str | None] = mapped_column(String(500))
    order_prefix: Mapped[str | None] = mapped_column(String(32))
    detected_year: Mapped[int | None] = mapped_column(Integer)
    season_number: Mapped[int | None] = mapped_column(Integer)
    episode_number: Mapped[int | None] = mapped_column(Integer)
    technical_tags: Mapped[list[str] | None] = mapped_column(JSON)
    language_hints: Mapped[list[str] | None] = mapped_column(JSON)
    normalization_trace: Mapped[list[str] | None] = mapped_column(JSON)
    normalization_version: Mapped[str | None] = mapped_column(String(64))
    possible_extra: Mapped[bool] = mapped_column(Boolean, default=False)
    cleaning_status: Mapped[str] = mapped_column(String(32), default="cleaning_pending", index=True)
    enrichment_status: Mapped[str] = mapped_column(
        String(32), default="pending_enrichment", index=True
    )
    final_confidence: Mapped[float | None] = mapped_column(Float)
    review_reason: Mapped[str | None] = mapped_column(Text)
    next_retry_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    work_group_id: Mapped[str | None] = mapped_column(String(36), index=True)
    grouping_confidence: Mapped[float | None] = mapped_column(Float)
    grouping_reason: Mapped[str | None] = mapped_column(Text)
    grouping_version: Mapped[str | None] = mapped_column(String(64))
    grouping_status: Mapped[str] = mapped_column(String(32), default="grouping_pending", index=True)
    __table_args__ = (
        UniqueConstraint("scan_id", "source_id", "fingerprint_key"),
        CheckConstraint("size_bytes IS NULL OR size_bytes>=0"),
        Index("ix_files_source_path", "source_id", "normalized_path"),
        Index("ix_physical_files_bank_source_path", "bank_id", "source_id", "normalized_path"),
    )


class CatalogFileIdentityModel(Base):
    __tablename__ = "catalog_file_identities"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    bank_id: Mapped[str] = mapped_column(ForeignKey("banks.id", ondelete="RESTRICT"), index=True)
    source_id: Mapped[str] = mapped_column(
        ForeignKey("sources.id", ondelete="RESTRICT"), index=True
    )
    normalized_path: Mapped[str] = mapped_column(Text)
    first_seen_scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id", ondelete="RESTRICT"))
    last_seen_scan_id: Mapped[str] = mapped_column(
        ForeignKey("scans.id", ondelete="RESTRICT"), index=True
    )
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(32), default="present")
    missing_since_scan_id: Mapped[str | None] = mapped_column(
        ForeignKey("scans.id", ondelete="RESTRICT"), nullable=True
    )
    availability_checked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    __table_args__ = (UniqueConstraint("bank_id", "source_id", "normalized_path"),)


class AvailabilityEventModel(Base):
    __tablename__ = "availability_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    catalog_file_id: Mapped[str] = mapped_column(
        ForeignKey("catalog_file_identities.id", ondelete="CASCADE"), index=True
    )
    scan_id: Mapped[str] = mapped_column(ForeignKey("scans.id", ondelete="RESTRICT"), index=True)
    previous_status: Mapped[str] = mapped_column(String(32))
    new_status: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class SubtitleModel(Base):
    __tablename__ = "subtitles"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    physical_file_id: Mapped[str | None] = mapped_column(
        ForeignKey("physical_files.id", ondelete="SET NULL")
    )
    content_id: Mapped[str | None] = mapped_column(ForeignKey("contents.id", ondelete="SET NULL"))
    language: Mapped[str | None] = mapped_column(String(32))
    format: Mapped[str | None] = mapped_column(String(32))
    hearing_impaired: Mapped[bool | None] = mapped_column(Boolean)
    forced: Mapped[bool | None] = mapped_column(Boolean)


def _simple(name: str, table: str, fk: str | None = None) -> type[Base]:
    attrs = {
        "__tablename__": table,
        "id": mapped_column(String(36), primary_key=True),
        "payload": mapped_column(JSON, default=dict),
        "created_at": mapped_column(DateTime(timezone=True), nullable=True),
    }
    if fk:
        attrs["content_id"] = mapped_column(
            ForeignKey("contents.id", ondelete="CASCADE"), index=True, nullable=True
        )
    return type(name, (Base,), attrs)


CollectionModel = _simple("CollectionModel", "collections", "content")
SeasonModel = _simple("SeasonModel", "seasons", "content")
EpisodeModel = _simple("EpisodeModel", "episodes", "content")
class AvailabilityModel(Base):
    __tablename__ = "availabilities"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    content_id: Mapped[str] = mapped_column(
        ForeignKey("contents.id", ondelete="CASCADE"), index=True
    )
    bank_id: Mapped[str] = mapped_column(
        ForeignKey("banks.id", ondelete="RESTRICT"), index=True
    )
    payload: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__ = (UniqueConstraint("content_id", "bank_id"),)


CorrectionModel = _simple("CorrectionModel", "corrections")
FieldLockModel = _simple("FieldLockModel", "field_locks")
FieldProvenanceModel = _simple("FieldProvenanceModel", "field_provenance")
ClassificationSessionModel = _simple("ClassificationSessionModel", "classification_sessions")
CleaningSessionModel = _simple("CleaningSessionModel", "cleaning_sessions")
EnrichmentSessionModel = _simple("EnrichmentSessionModel", "enrichment_sessions")
OperationBatchModel = _simple("OperationBatchModel", "operation_batches")
CorrectionRuleModel = _simple("CorrectionRuleModel", "correction_rules")
ReviewDecisionModel = _simple("ReviewDecisionModel", "review_decisions")
ContentCandidateModel = _simple("ContentCandidateModel", "content_candidates", "content")
MetadataCandidateModel = _simple("MetadataCandidateModel", "metadata_candidates", "content")
MatchEvidenceModel = _simple("MatchEvidenceModel", "match_evidence", "content")
MetadataConflictModel = _simple("MetadataConflictModel", "metadata_conflicts", "content")
