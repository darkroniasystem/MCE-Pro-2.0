"""Adaptadores reales desacoplados para Fanart.tv, AniList y TVMaze."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import Protocol, cast

from mce.application.identification.models import (
    IdentificationQuery,
    ProviderCandidate,
    ProviderTitleAlias,
    SearchKind,
)
from mce.application.identification.service import (
    ProviderNotFoundError,
    ProviderResponseError,
)


class JsonApiTransport(Protocol):
    def get_json(
        self,
        path: str,
        params: dict[str, object],
        timeout: float,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]: ...

    def post_json(
        self,
        path: str,
        payload: dict[str, object],
        timeout: float,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]: ...


@dataclass(frozen=True, slots=True)
class ProviderCapabilities:
    movies: bool = False
    series: bool = False
    anime: bool = False
    episodes: bool = False
    people: bool = False
    images: bool = False
    search_by_imdb: bool = False
    search_by_title: bool = False
    external_ids: bool = False


def _text(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return None if not cleaned or cleaned.casefold() == "n/a" else cleaned


def _integer(value: object) -> int | None:
    match = re.search(r"\d+", str(value or ""))
    return int(match.group()) if match else None


def _strings(value: object, separator: str = ",") -> tuple[str, ...]:
    if isinstance(value, list):
        return tuple(item.strip() for item in value if isinstance(item, str) and item.strip())
    text = _text(value)
    return tuple(part.strip() for part in text.split(separator) if part.strip()) if text else ()


def _strip_html(value: object) -> str | None:
    text = _text(value)
    if text is None:
        return None
    return html.unescape(re.sub(r"<[^>]+>", "", text)).strip() or None


class FanartMetadataProvider:
    name = "fanart"
    capabilities = ProviderCapabilities(movies=True, series=True, images=True)

    def __init__(self, api_key: str, transport: JsonApiTransport, timeout: float = 10) -> None:
        self.api_key = api_key.strip()
        if not self.api_key:
            raise ValueError("FANART_API_KEY is required")
        self.transport = transport
        self.timeout = timeout

    def get_images(self, external_id: str, kind: SearchKind) -> tuple[tuple[str, str], ...]:
        resource = "movies" if kind is SearchKind.MOVIE else "tv"
        payload = self.transport.get_json(
            f"/v3.2/{resource}/{external_id}", {"api_key": self.api_key}, self.timeout
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("Fanart.tv: respuesta inesperada")
        ranked: list[tuple[int, int, str, str]] = []
        for category, entries in payload.items():
            if not isinstance(entries, list):
                continue
            for entry in entries:
                if not isinstance(entry, dict) or not _text(entry.get("url")):
                    continue
                language = _text(entry.get("lang")) or ""
                language_rank = (
                    0 if language == "es" else 1 if not language else 2 if language == "en" else 3
                )
                ranked.append(
                    (
                        language_rank,
                        -(_integer(entry.get("likes")) or 0),
                        str(category),
                        cast(str, _text(entry.get("url"))),
                    )
                )
        seen: set[str] = set()
        selected: list[tuple[str, str]] = []
        for _, _, category, url in sorted(ranked):
            if url not in seen:
                seen.add(url)
                selected.append((category, url))
        return tuple(selected)

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return ()

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return ()

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return ProviderCandidate(
            "fanart",
            external_id,
            SearchKind.MOVIE,
            "artwork",
            images=self.get_images(external_id, SearchKind.MOVIE),
        )

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        return ProviderCandidate(
            "fanart",
            external_id,
            SearchKind.SERIES,
            "artwork",
            images=self.get_images(external_id, SearchKind.SERIES),
        )

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        return {"images": self.get_images(external_id, SearchKind.SERIES), "season": season}

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        return {
            "images": self.get_images(external_id, SearchKind.SERIES),
            "season": season,
            "episode": episode,
        }


ANILIST_QUERY = """query ($search: String, $year: Int) {
  Page(page: 1, perPage: 10) { media(search: $search, seasonYear: $year, type: ANIME) {
    id idMal title { romaji english native } synonyms format status episodes duration
    season seasonYear startDate { year month day } endDate { year month day }
    genres countryOfOrigin description averageScore popularity
    studios(isMain: true) { nodes { name } } coverImage { extraLarge } bannerImage
  } }
}"""


class AniListMetadataProvider:
    name = "anilist"
    capabilities = ProviderCapabilities(
        anime=True, series=True, images=True, search_by_title=True, external_ids=True
    )

    def __init__(self, transport: JsonApiTransport, timeout: float = 10) -> None:
        self.transport = transport
        self.timeout = timeout

    def _search(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        payload = self.transport.post_json(
            "/",
            {"query": ANILIST_QUERY, "variables": {"search": query.title, "year": query.year}},
            self.timeout,
        )
        if not isinstance(payload, dict) or payload.get("errors"):
            raise ProviderResponseError("AniList: GraphQL devolvió errores")
        data = payload.get("data")
        page = data.get("Page") if isinstance(data, dict) else None
        media = page.get("media") if isinstance(page, dict) else None
        if not isinstance(media, list):
            raise ProviderResponseError("AniList: data nulo o mal formado")
        return tuple(self._candidate(item) for item in media if isinstance(item, dict))

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return tuple(item for item in self._search(query) if item.kind is SearchKind.MOVIE)

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search(query)

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return self._details(external_id)

    get_series_details = get_movie_details

    def _details(self, external_id: str) -> ProviderCandidate:
        payload = self.transport.post_json(
            "/",
            {
                "query": ANILIST_QUERY.replace("$search: String, $year: Int", "$id: Int").replace(
                    "search: $search, seasonYear: $year, ", "id: $id, "
                ),
                "variables": {"id": int(external_id)},
            },
            self.timeout,
        )
        if not isinstance(payload, dict) or payload.get("errors"):
            raise ProviderResponseError("AniList: GraphQL devolvió errores")
        data = payload.get("data")
        page = data.get("Page") if isinstance(data, dict) else None
        media = page.get("media") if isinstance(page, dict) else None
        if not isinstance(media, list) or not media or not isinstance(media[0], dict):
            raise ProviderNotFoundError("AniList: no encontrado")
        return self._candidate(media[0])

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        return {"candidate": self._details(external_id), "season": season}

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        return {"candidate": self._details(external_id), "season": season, "episode": episode}

    @staticmethod
    def _candidate(data: dict[str, object]) -> ProviderCandidate:
        titles = data.get("title") if isinstance(data.get("title"), dict) else {}
        title = _text(cast(dict[str, object], titles).get("english")) or _text(
            cast(dict[str, object], titles).get("romaji")
        )
        identifier = _integer(data.get("id"))
        if not title or identifier is None:
            raise ProviderResponseError("AniList: candidato inválido")
        fmt = _text(data.get("format")) or "TV"
        kind = SearchKind.MOVIE if fmt == "MOVIE" else SearchKind.ANIME
        mal = _integer(data.get("idMal"))
        ids = (
            (("anilist", str(identifier)), ("mal", str(mal)))
            if mal
            else (("anilist", str(identifier)),)
        )
        studios = data.get("studios") if isinstance(data.get("studios"), dict) else {}
        nodes = cast(dict[str, object], studios).get("nodes") if studios else []
        studio_names = tuple(
            _text(item.get("name")) or ""
            for item in cast(list[dict[str, object]], nodes or [])
            if _text(item.get("name"))
        )
        cover = data.get("coverImage") if isinstance(data.get("coverImage"), dict) else {}
        images = tuple(
            (key, value)
            for key, value in (
                ("poster", _text(cast(dict[str, object], cover).get("extraLarge"))),
                ("banner", _text(data.get("bannerImage"))),
            )
            if value
        )
        return ProviderCandidate(
            "anilist",
            str(identifier),
            kind,
            title,
            original_title=_text(cast(dict[str, object], titles).get("native")),
            translated_titles=tuple(
                filter(
                    None,
                    (
                        _text(cast(dict[str, object], titles).get("romaji")),
                        _text(cast(dict[str, object], titles).get("english")),
                    ),
                )
            ),
            aliases=_strings(data.get("synonyms")),
            year=_integer(data.get("seasonYear")),
            country=_text(data.get("countryOfOrigin")),
            duration_minutes=_integer(data.get("duration")),
            overview=_strip_html(data.get("description")),
            genres=_strings(data.get("genres")),
            studios=studio_names,
            status=_text(data.get("status")),
            episode_count=_integer(data.get("episodes")),
            external_ids=ids,
            images=images,
            ratings=(("anilist", str(data.get("averageScore"))),)
            if data.get("averageScore") is not None
            else (),
            source_url=f"https://anilist.co/anime/{identifier}",
            english_title=_text(cast(dict[str, object], titles).get("english")),
            title_aliases=tuple(
                [
                    ProviderTitleAlias(
                        value,
                        "ja-Latn",
                        alias_type="romanized",
                        provenance="anilist:title.romaji",
                    )
                    for value in (_text(cast(dict[str, object], titles).get("romaji")),)
                    if value
                ]
                + [
                    ProviderTitleAlias(
                        value,
                        alias_type="alternative",
                        provenance="anilist:synonyms",
                    )
                    for value in _strings(data.get("synonyms"))
                ]
            ),
        )


class TvMazeMetadataProvider:
    name = "tvmaze"
    capabilities = ProviderCapabilities(
        series=True,
        episodes=True,
        people=True,
        images=True,
        search_by_imdb=True,
        search_by_title=True,
        external_ids=True,
    )

    def __init__(self, transport: JsonApiTransport, timeout: float = 10) -> None:
        self.transport = transport
        self.timeout = timeout

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return ()

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        payload = self.transport.get_json("/search/shows", {"q": query.title}, self.timeout)
        if not isinstance(payload, list):
            raise ProviderResponseError("TVMaze: respuesta de búsqueda inválida")
        return tuple(
            self._candidate(item["show"])
            for item in payload
            if isinstance(item, dict) and isinstance(item.get("show"), dict)
        )

    def lookup(self, *, imdb: str | None = None, thetvdb: str | None = None) -> ProviderCandidate:
        payload = self.transport.get_json(
            "/lookup/shows", {"imdb": imdb, "thetvdb": thetvdb}, self.timeout
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("TVMaze: lookup inválido")
        return self._candidate(payload)

    def get_series_details(self, external_id: str) -> ProviderCandidate:
        payload = self.transport.get_json(f"/shows/{external_id}", {}, self.timeout)
        if not isinstance(payload, dict):
            raise ProviderResponseError("TVMaze: detalle inválido")
        return self._candidate(payload)

    get_movie_details = get_series_details

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        payload = self.transport.get_json(f"/shows/{external_id}/seasons", {}, self.timeout)
        return {"seasons": payload, "requested": season}

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        payload = self.transport.get_json(
            f"/shows/{external_id}/episodebynumber",
            {"season": season, "number": episode},
            self.timeout,
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("TVMaze: episodio inválido")
        return payload

    @staticmethod
    def _candidate(data: dict[str, object]) -> ProviderCandidate:
        identifier, title = _integer(data.get("id")), _text(data.get("name"))
        if identifier is None or not title:
            raise ProviderResponseError("TVMaze: candidato inválido")
        premiered = _text(data.get("premiered"))
        externals = data.get("externals") if isinstance(data.get("externals"), dict) else {}
        ids = [("tvmaze", str(identifier))]
        for source in ("imdb", "thetvdb", "tvrage"):
            value = cast(dict[str, object], externals).get(source)
            if value:
                ids.append((source, str(value)))
        image = data.get("image") if isinstance(data.get("image"), dict) else {}
        network = data.get("network") or data.get("webChannel")
        network_name = (
            _text(cast(dict[str, object], network).get("name"))
            if isinstance(network, dict)
            else None
        )
        official_url = _text(data.get("officialSite")) or _text(data.get("url"))
        return ProviderCandidate(
            "tvmaze",
            str(identifier),
            SearchKind.SERIES,
            title,
            year=int(premiered[:4]) if premiered and premiered[:4].isdigit() else None,
            country=_text(
                cast(dict[str, object], cast(dict[str, object], network).get("country", {})).get(
                    "code"
                )
            )
            if isinstance(network, dict) and isinstance(network.get("country"), dict)
            else None,
            duration_minutes=_integer(data.get("averageRuntime") or data.get("runtime")),
            overview=_strip_html(data.get("summary")),
            genres=_strings(data.get("genres")),
            networks=(network_name,) if network_name else (),
            status=_text(data.get("status")),
            external_ids=tuple(ids),
            images=tuple(
                (key, value)
                for key, value in (
                    ("poster", _text(cast(dict[str, object], image).get("original"))),
                )
                if value
            ),
            ratings=(
                ("tvmaze", str(cast(dict[str, object], data.get("rating", {})).get("average"))),
            )
            if isinstance(data.get("rating"), dict)
            and cast(dict[str, object], data["rating"]).get("average") is not None
            else (),
            source_url=official_url,
        )
