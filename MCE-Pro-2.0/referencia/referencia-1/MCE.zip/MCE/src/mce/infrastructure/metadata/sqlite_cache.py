"""Caché local, persistente y acotada para candidatos externos."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import zlib
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path

from mce.application.identification.models import (
    ProviderCandidate,
    ProviderTitleAlias,
    SearchKind,
)


class SqliteMetadataCache:
    """Guarda solo candidatos compactos y elimina entradas antiguas por LRU."""

    def __init__(self, path: Path, *, max_entries: int = 10_000) -> None:
        if max_entries <= 0:
            raise ValueError("max_entries must be positive")
        if path.is_symlink():
            raise ValueError("metadata cache must not be a symbolic link")
        self.path = path.resolve()
        self.max_entries = max_entries
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._initialize()
        except sqlite3.DatabaseError:
            if not self.path.exists():
                raise
            preserved = self.path.with_name(
                f"{self.path.name}.corrupt-{datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')}"
            )
            os.replace(self.path, preserved)
            self._initialize()

    def _initialize(self) -> None:
        with self._connection() as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS metadata_cache (
                cache_key TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL,
                accessed_at TEXT NOT NULL,
                version INTEGER NOT NULL
                )"""
            )
            columns = {
                str(row[1]) for row in connection.execute("PRAGMA table_info(metadata_cache)")
            }
            if "payload_checksum" not in columns:
                connection.execute("ALTER TABLE metadata_cache ADD COLUMN payload_checksum TEXT")

    def get(self, key: str, now: datetime, ttl: timedelta) -> tuple[ProviderCandidate, ...] | None:
        with self._connection() as connection:
            row = connection.execute(
                "SELECT payload, created_at, version, payload_checksum "
                "FROM metadata_cache WHERE cache_key=?",
                (key,),
            ).fetchone()
            if row is None:
                return None
            created_at = datetime.fromisoformat(str(row[1])).astimezone(UTC)
            if int(row[2]) != 1 or now - created_at > ttl:
                connection.execute("DELETE FROM metadata_cache WHERE cache_key=?", (key,))
                return None
            payload_bytes = self._payload_bytes(row[0])
            if row[3] is not None and hashlib.sha256(payload_bytes).hexdigest() != row[3]:
                connection.execute("DELETE FROM metadata_cache WHERE cache_key=?", (key,))
                return None
            connection.execute(
                "UPDATE metadata_cache SET accessed_at=? WHERE cache_key=?",
                (now.astimezone(UTC).isoformat(), key),
            )
            try:
                return self._decode(row[0])
            except (KeyError, TypeError, ValueError, UnicodeDecodeError, zlib.error):
                connection.execute("DELETE FROM metadata_cache WHERE cache_key=?", (key,))
                return None

    def put(self, key: str, value: tuple[ProviderCandidate, ...], now: datetime) -> None:
        if not isinstance(key, str) or not key.strip():
            raise ValueError("cache key must not be empty")
        timestamp = now.astimezone(UTC).isoformat()
        encoded = self._encode(value)
        checksum = hashlib.sha256(encoded).hexdigest()
        with self._connection() as connection:
            connection.execute(
                """INSERT INTO metadata_cache(
                cache_key,payload,created_at,accessed_at,version,payload_checksum
                ) VALUES(?,?,?,?,1,?) ON CONFLICT(cache_key) DO UPDATE SET
                payload=excluded.payload, created_at=excluded.created_at,
                accessed_at=excluded.accessed_at, version=excluded.version,
                payload_checksum=excluded.payload_checksum""",
                (key, encoded, timestamp, timestamp, checksum),
            )
            connection.execute(
                """DELETE FROM metadata_cache WHERE cache_key IN (
                SELECT cache_key FROM metadata_cache ORDER BY accessed_at DESC
                LIMIT -1 OFFSET ?
                )""",
                (self.max_entries,),
            )

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path, timeout=5)
        try:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=FULL")
            with connection:
                yield connection
        finally:
            connection.close()

    @staticmethod
    def _encode(values: tuple[ProviderCandidate, ...]) -> bytes:
        payload = json.dumps(
            [
                {
                    "provider": item.provider,
                    "external_id": item.external_id,
                    "kind": item.kind.value,
                    "title": item.title,
                    "original_title": item.original_title,
                    "translated_titles": item.translated_titles,
                    "aliases": item.aliases,
                    "spanish_title": item.spanish_title,
                    "english_title": item.english_title,
                    "title_aliases": [
                        {
                            "title": alias.title,
                            "language": alias.language,
                            "country": alias.country,
                            "alias_type": alias.alias_type,
                            "provenance": alias.provenance,
                        }
                        for alias in item.title_aliases
                    ],
                    "year": item.year,
                    "country": item.country,
                    "cast": item.cast,
                    "director": item.director,
                    "duration_minutes": item.duration_minutes,
                    "overview": item.overview,
                    "genres": item.genres,
                    "languages": item.languages,
                    "cast_names": item.cast_names,
                    "creators": item.creators,
                    "studios": item.studios,
                    "networks": item.networks,
                    "status": item.status,
                    "episode_count": item.episode_count,
                    "season_count": item.season_count,
                    "external_ids": item.external_ids,
                    "images": item.images,
                    "ratings": item.ratings,
                    "source_url": item.source_url,
                }
                for item in values
            ],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return zlib.compress(payload.encode("utf-8"), level=6)

    @staticmethod
    def _decode(payload: object) -> tuple[ProviderCandidate, ...]:
        if isinstance(payload, bytes):
            text = zlib.decompress(payload).decode("utf-8")
        else:
            text = str(payload)
        raw = json.loads(text)
        if not isinstance(raw, list):
            return ()
        return tuple(
            ProviderCandidate(
                provider=str(item["provider"]),
                external_id=str(item["external_id"]),
                kind=SearchKind(str(item["kind"])),
                title=str(item["title"]),
                original_title=item.get("original_title"),
                translated_titles=tuple(item.get("translated_titles") or ()),
                aliases=tuple(item.get("aliases") or ()),
                spanish_title=item.get("spanish_title"),
                english_title=item.get("english_title"),
                title_aliases=tuple(
                    ProviderTitleAlias(**alias)
                    for alias in item.get("title_aliases") or ()
                    if isinstance(alias, dict)
                ),
                year=item.get("year"),
                country=item.get("country"),
                cast=tuple(item.get("cast") or ()),
                director=item.get("director"),
                duration_minutes=item.get("duration_minutes"),
                overview=item.get("overview"),
                genres=tuple(item.get("genres") or ()),
                languages=tuple(item.get("languages") or ()),
                cast_names=tuple(item.get("cast_names") or ()),
                creators=tuple(item.get("creators") or ()),
                studios=tuple(item.get("studios") or ()),
                networks=tuple(item.get("networks") or ()),
                status=item.get("status"),
                episode_count=item.get("episode_count"),
                season_count=item.get("season_count"),
                external_ids=tuple(tuple(row) for row in item.get("external_ids") or ()),
                images=tuple(tuple(row) for row in item.get("images") or ()),
                ratings=tuple(tuple(row) for row in item.get("ratings") or ()),
                source_url=item.get("source_url"),
            )
            for item in raw
            if isinstance(item, dict)
        )

    @staticmethod
    def _payload_bytes(payload: object) -> bytes:
        return payload if isinstance(payload, bytes) else str(payload).encode("utf-8")
