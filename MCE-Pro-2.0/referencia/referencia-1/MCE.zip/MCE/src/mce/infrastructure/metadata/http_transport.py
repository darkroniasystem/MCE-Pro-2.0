"""Transporte HTTPS JSON compartido, cancelable y sin filtrar credenciales."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from mce.application.identification.service import (
    ProviderAuthenticationError,
    ProviderCancelledError,
    ProviderClientError,
    ProviderConnectionError,
    ProviderNotFoundError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderServerError,
    ProviderTimeoutError,
)


class UrllibJsonTransport:
    """GET/POST JSON limitado a un host HTTPS conocido.

    Las credenciales viajan únicamente en la solicitud. Ningún error incluye URL,
    parámetros, cabeceras ni cuerpo, evitando filtrarlas a UI o logs.
    """

    def __init__(
        self,
        base_url: str = "https://api.themoviedb.org/3",
        *,
        provider_name: str = "Proveedor",
        cancelled: Callable[[], bool] = lambda: False,
    ) -> None:
        normalized = base_url.rstrip("/")
        if not normalized.startswith("https://"):
            raise ValueError("metadata provider base URL must use HTTPS")
        self.base_url = normalized
        self.provider_name = provider_name
        self.cancelled = cancelled

    def get_json(
        self,
        path: str,
        params: dict[str, object],
        timeout: float,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]:
        query = urlencode({key: value for key, value in params.items() if value is not None})
        suffix = f"?{query}" if query else ""
        return self._request(path, timeout, "GET", suffix=suffix, headers=headers)

    def post_json(
        self,
        path: str,
        payload: dict[str, object],
        timeout: float,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        return self._request(path, timeout, "POST", body=body, headers=headers)

    def _request(
        self,
        path: str,
        timeout: float,
        method: str,
        *,
        suffix: str = "",
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]:
        if self.cancelled():
            raise ProviderCancelledError("operación cancelada")
        if not path.startswith("/") or path.startswith("//"):
            raise ValueError("provider path must be relative to the configured host")
        safe_headers = {
            "Accept": "application/json",
            "User-Agent": "MCE-Desktop/0.10 (metadata-enrichment)",
        }
        if body is not None:
            safe_headers["Content-Type"] = "application/json"
        if headers:
            safe_headers.update(headers)
        request = Request(
            f"{self.base_url}{path}{suffix}", headers=safe_headers, data=body, method=method
        )
        try:
            with urlopen(request, timeout=timeout) as response:
                raw = response.read()
        except HTTPError as exc:
            if exc.code == 401 or exc.code == 403:
                raise ProviderAuthenticationError(
                    f"{self.provider_name}: credencial inválida"
                ) from exc
            if exc.code == 404:
                raise ProviderNotFoundError(f"{self.provider_name}: no encontrado") from exc
            if exc.code in {429, 432, 433}:
                error = ProviderRateLimitError(
                    
                        f"{self.provider_name}: cuota del plan agotada"
                        if exc.code in {432, 433}
                        else f"{self.provider_name}: límite temporal de solicitudes"
                    
                )
                error.quota_exhausted = (  # type: ignore[attr-defined]
                    exc.code in {432, 433} or _http_error_indicates_quota(exc)
                )
                retry_after = exc.headers.get("Retry-After")
                if retry_after and retry_after.isdigit():
                    error.retry_after = min(int(retry_after), 60)  # type: ignore[attr-defined]
                raise error from exc
            if exc.code in {500, 502, 503, 504}:
                raise ProviderServerError(
                    f"{self.provider_name}: error temporal {exc.code}"
                ) from exc
            raise ProviderClientError(
                f"{self.provider_name}: solicitud rechazada ({exc.code})"
            ) from exc
        except TimeoutError as exc:
            raise ProviderTimeoutError(f"{self.provider_name}: tiempo de espera agotado") from exc
        except URLError as exc:
            if isinstance(exc.reason, TimeoutError):
                raise ProviderTimeoutError(
                    f"{self.provider_name}: tiempo de espera agotado"
                ) from exc
            raise ProviderConnectionError(f"{self.provider_name}: conexión fallida") from exc
        if self.cancelled():
            raise ProviderCancelledError("operación cancelada")
        if not raw:
            raise ProviderResponseError(f"{self.provider_name}: respuesta vacía")
        try:
            payload: Any = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ProviderResponseError(f"{self.provider_name}: respuesta JSON inválida") from exc
        if not isinstance(payload, (dict, list)):
            raise ProviderResponseError(f"{self.provider_name}: respuesta inesperada")
        return payload


def _http_error_indicates_quota(error: HTTPError) -> bool:
    """Clasifica una cuota agotada sin propagar el cuerpo remoto a logs o UI."""
    try:
        raw = error.read(4_096)
    except (AttributeError, OSError, TypeError):
        return False
    lowered = raw.decode("utf-8", errors="ignore").casefold()
    return any(
        marker in lowered
        for marker in ("quota", "credit", "crédito", "agotad", "exhausted")
    )
