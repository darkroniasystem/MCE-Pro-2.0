"""Persistencia transaccional corta para resultados confirmados de proveedores."""

from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import PureWindowsPath
from uuid import NAMESPACE_URL, uuid5

from sqlalchemy import create_engine, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from mce.application.dto import ProcessingSession
from mce.application.dto.session_models import SessionItem
from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.application.identification.title_search import normalize_search_title
from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.database.models import (
    AvailabilityModel,
    BankModel,
    CanonicalWorkModel,
    ContentAliasModel,
    ContentModel,
    ContentVersionModel,
    InstallationModel,
    PhysicalFileModel,
    ProcessingSessionModel,
    ScanImportModel,
    ScanModel,
    SourceModel,
)
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork


class MetadataPersistenceService:
    def __init__(self, factory: sessionmaker) -> None:  # type: ignore[type-arg]
        self.factory = factory

    @classmethod
    def from_test_environment(cls) -> MetadataPersistenceService | None:
        raw = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
        if not raw:
            return None
        url = make_url(raw)
        if url.get_backend_name() != "postgresql" or url.database != "mce_test":
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    @classmethod
    def from_runtime_environment(cls) -> MetadataPersistenceService | None:
        raw = runtime_database_url()
        if raw is None:
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    def find_known_candidate(
        self, title: str, kind: SearchKind, bank_id: str | None
    ) -> ProviderCandidate | None:
        """Resuelve una identidad confirmada sin consultar proveedores."""
        normalized = normalize_search_title(title)
        if not normalized:
            return None
        with self.factory() as session:
            statement = (
                select(ContentModel, CanonicalWorkModel)
                .join(
                    CanonicalWorkModel,
                    CanonicalWorkModel.id == ContentModel.canonical_work_id,
                )
                .join(ContentAliasModel, ContentAliasModel.content_id == ContentModel.id)
                .where(
                    ContentAliasModel.normalized_alias == normalized,
                    ContentModel.content_type == kind.value,
                    (ContentAliasModel.bank_id.is_(None) | (ContentAliasModel.bank_id == bank_id)),
                )
            )
            rows = session.execute(statement).all()
            canonical = {row[1].id: row[1] for row in rows}
            if len(canonical) != 1:
                return None
            work = next(iter(canonical.values()))
            return ProviderCandidate(
                provider=work.provider,
                external_id=work.external_id,
                kind=kind,
                title=work.official_title,
                year=work.release_year,
            )

    def save(
        self,
        candidate: ProviderCandidate,
        bank_id: str | None,
        alias: str,
        confidence: float,
        *,
        raw_bank_title: str | None = None,
        confirmed_alias: bool = False,
        bank_name: str | None = None,
    ) -> str:
        with SqlAlchemyUnitOfWork(self.factory) as uow:
            if bank_id and uow.session is not None:
                bank = uow.session.get(BankModel, bank_id)
                if bank is None:
                    uow.session.add(
                        BankModel(
                            id=bank_id,
                            name=(bank_name or "").strip() or f"Banco {bank_id}",
                            code=None,
                            branch=None,
                            status="active",
                            created_at=datetime.now(UTC),
                        )
                    )
                    uow.session.flush()
                elif (bank_name or "").strip():
                    bank.name = str(bank_name).strip()
            content = uow.metadata_catalog.save_candidate(
                candidate,
                bank_id=bank_id,
                alias=alias,
                raw_bank_title=raw_bank_title,
                confirmed_alias=confirmed_alias,
                confidence=confidence,
            )
            uow.commit()
            return content.id

    def save_approved_group(
        self,
        candidate: ProviderCandidate | None,
        processing_session: ProcessingSession,
        items: tuple[SessionItem, ...],
        *,
        alias: str,
        confidence: float,
    ) -> str:
        """Guarda obra, procedencia, archivos y disponibilidad en una transacción."""
        if not items:
            raise ValueError("an approved group requires at least one physical file")
        bank_ids = {item.bank_id for item in items}
        if len(bank_ids) != 1 or None in bank_ids:
            raise ValueError("approved files must belong to exactly one bank")
        bank_id = next(iter(bank_ids))
        group_ids = {item.work_group_id for item in items}
        if len(group_ids) != 1 or None in group_ids:
            raise ValueError("approved files must belong to exactly one work group")
        group_id = next(iter(group_ids))
        category = items[0].detected_category or "unclassified"
        manual_identification = candidate is None
        if candidate is None:
            kind = (
                SearchKind.ANIME
                if category == "anime"
                else SearchKind.SERIES
                if category
                in {"series", "novela", "dorama", "concurso", "tv_show", "western_animation"}
                else SearchKind.MOVIE
            )
            candidate = ProviderCandidate(
                "manual",
                str(group_id),
                kind,
                alias,
                year=items[0].detected_year,
            )
        now = datetime.now(UTC)
        with SqlAlchemyUnitOfWork(self.factory) as uow:
            session = uow.session
            if session is None:
                raise RuntimeError("database session unavailable")
            bank = session.get(BankModel, bank_id)
            if bank is None:
                bank = BankModel(
                    id=bank_id,
                    name=processing_session.bank_name or f"Banco {bank_id}",
                    code=None,
                    branch=None,
                    status="active",
                    created_at=now,
                )
                session.add(bank)
            installation_id = items[0].installation_id or str(
                uuid5(NAMESPACE_URL, f"mce-installation:{bank_id}")
            )
            if session.get(InstallationModel, installation_id) is None:
                session.add(
                    InstallationModel(
                        id=installation_id,
                        bank_id=bank_id,
                        name=f"MCE {processing_session.bank_name or bank_id}",
                        machine_identifier=None,
                        status="active",
                        created_at=now,
                    )
                )
            scan_id = str(uuid5(NAMESPACE_URL, f"mce-scan:{processing_session.import_id}"))
            if session.get(ScanModel, scan_id) is None:
                session.add(
                    ScanModel(
                        id=scan_id,
                        installation_id=installation_id,
                        started_at=processing_session.created_at,
                        finished_at=processing_session.updated_at,
                        scope_type=processing_session.scan_scope.scope_type.value,
                        scope_data={
                            "type": processing_session.scan_scope.scope_type.value,
                            "source_ids": [
                                str(value) for value in processing_session.scan_scope.source_ids
                            ],
                        },
                        status="completed",
                        msl_version="2.2",
                        schema_version="2.2",
                    )
                )
            import_id = str(processing_session.import_id)
            if session.get(ScanImportModel, import_id) is None:
                session.add(
                    ScanImportModel(
                        id=import_id,
                        scan_id=scan_id,
                        bank_id=bank_id,
                        original_filename="MSL checkpoint",
                        file_hash=processing_session.package_hash,
                        received_at=processing_session.created_at,
                        status="completed",
                        is_duplicate=False,
                        errors=[],
                    )
                )
            if session.get(ProcessingSessionModel, processing_session.session_id) is None:
                session.add(
                    ProcessingSessionModel(
                        id=processing_session.session_id,
                        workspace_id=processing_session.workspace_id,
                        import_id=import_id,
                        package_hash=processing_session.package_hash,
                        scope_data={"type": processing_session.scan_scope.scope_type.value},
                        status=processing_session.status.value,
                        failure_reason=processing_session.failure_reason,
                        retry_count=processing_session.retry_count,
                        created_at=processing_session.created_at,
                        updated_at=processing_session.updated_at,
                        version=1,
                    )
                )
            content = uow.metadata_catalog.save_candidate(
                candidate,
                bank_id=bank_id,
                alias=alias,
                raw_bank_title=items[0].original_name,
                confirmed_alias=True,
                confidence=confidence,
            )
            content.work_group_id = group_id
            content.identification_confidence = confidence or None
            content.metadata_confidence = None if manual_identification else confidence
            content.identification_status = (
                "manual_unverified" if manual_identification else "identified"
            )
            content.review_status = (
                "approved_manual_incomplete" if manual_identification else "approved"
            )
            content.catalog_stage = "approved"
            content.publication_status = (
                "publication_blocked" if manual_identification else "publication_ready"
            )
            content.publication_block_reason = (
                "manual identification without confirmed external id"
                if manual_identification
                else None
            )
            version_id = str(uuid5(NAMESPACE_URL, f"mce-version:{content.id}:default"))
            if session.get(ContentVersionModel, version_id) is None:
                session.add(
                    ContentVersionModel(
                        id=version_id,
                        content_id=content.id,
                        name="Versión del banco",
                        edition_type=None,
                        language_variant=None,
                        notes=None,
                    )
                )
            physical_ids: list[str] = []
            for item in items:
                source_id = str(item.source_id)
                path = PureWindowsPath(item.original_path)
                root = path.anchor or str(path.parent)
                if session.get(SourceModel, source_id) is None:
                    session.add(
                        SourceModel(
                            id=source_id,
                            installation_id=installation_id,
                            source_type="network_share" if root.startswith("\\\\") else "volume",
                            display_name=root.rstrip("\\") or root,
                            root_path=root,
                            normalized_root_path=root.casefold(),
                            status="active",
                        )
                    )
                physical_id = str(item.physical_file_id)
                physical = session.get(PhysicalFileModel, physical_id)
                if physical is None:
                    physical = PhysicalFileModel(
                        id=physical_id,
                        bank_id=bank_id,
                        scan_id=scan_id,
                        source_id=source_id,
                        original_name=item.original_name or path.name,
                        relative_path=str(path)[len(root) :].lstrip("\\"),
                        original_path=item.original_path,
                        normalized_path=item.original_path.casefold(),
                        extension=path.suffix.casefold(),
                        size_bytes=item.size_bytes,
                        cryptographic_hash=item.file_hash,
                        fingerprint_key=item.file_hash or item.original_path.casefold(),
                        status="present",
                    )
                    session.add(physical)
                elif physical.bank_id != bank_id:
                    raise ValueError("physical file belongs to a different bank")
                physical.content_id = content.id
                physical.content_version_id = version_id
                physical.detected_category = item.detected_category
                physical.category_confidence = item.category_confidence
                physical.classification_status = item.classification_status
                physical.clean_title = item.clean_title
                physical.original_group_title = item.original_group_title
                physical.order_prefix = item.order_prefix
                physical.detected_year = item.detected_year
                physical.season_number = item.season_number
                physical.episode_number = item.episode_number
                physical.technical_tags = list(item.technical_tags)
                physical.language_hints = list(item.language_hints)
                physical.normalization_trace = list(item.normalization_trace)
                physical.normalization_version = item.normalization_version
                physical.possible_extra = item.possible_extra
                physical.cleaning_status = item.cleaning_status
                physical.enrichment_status = "enrichment_complete"
                physical.final_confidence = confidence
                physical.review_reason = None
                physical.work_group_id = item.work_group_id
                physical.grouping_confidence = item.grouping_confidence
                physical.grouping_reason = item.grouping_reason
                physical.grouping_version = item.grouping_version
                physical.grouping_status = item.grouping_status
                physical_ids.append(physical_id)
            availability_id = str(uuid5(NAMESPACE_URL, f"mce-availability:{content.id}:{bank_id}"))
            availability = session.get(AvailabilityModel, availability_id)
            payload = {
                "bank_id": bank_id,
                "status": "available",
                "physical_file_ids": physical_ids,
            }
            if availability is None:
                session.add(
                    AvailabilityModel(
                        id=availability_id,
                        content_id=content.id,
                        bank_id=bank_id,
                        payload=payload,
                        created_at=now,
                    )
                )
            else:
                setattr(availability, "payload", payload)  # noqa: B010
            uow.commit()
            return content.id
