"""Logging rotativo, correlacionado y con redacción de credenciales."""

from __future__ import annotations

import contextvars
import logging
import os
import re
from collections.abc import Iterator
from contextlib import contextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from uuid import uuid4

_correlation_id = contextvars.ContextVar("mce_correlation_id", default="-")
_url_credentials = re.compile(r"(?i)(postgresql(?:\+\w+)?://[^:\s/]+:)([^@\s]+)(@)")


class PrivacyFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        message = _url_credentials.sub(r"\1***\3", message)
        for name in ("TMDB_API_KEY", "FANART_API_KEY", "TAVILY_API_KEY"):
            secret = os.environ.get(name, "").strip()
            if secret:
                message = message.replace(secret, "***")
        record.msg = message
        record.args = ()
        record.correlation_id = _correlation_id.get()
        return True


def configure_logging(directory: Path, *, level: str | None = None) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / "mce-desktop.log"
    configured_level = (level or os.environ.get("MCE_LOG_LEVEL", "INFO")).upper()
    numeric_level = getattr(logging, configured_level, logging.INFO)
    handler = RotatingFileHandler(
        destination,
        maxBytes=5 * 1024 * 1024,
        backupCount=5,
        encoding="utf-8",
    )
    handler.addFilter(PrivacyFilter())
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s correlation=%(correlation_id)s %(message)s"
        )
    )
    root = logging.getLogger()
    for existing in tuple(root.handlers):
        root.removeHandler(existing)
        existing.close()
    root.addHandler(handler)
    root.setLevel(numeric_level)
    logging.captureWarnings(True)
    return destination


@contextmanager
def correlation_scope(identifier: str | None = None) -> Iterator[str]:
    value = identifier or str(uuid4())
    token = _correlation_id.set(value)
    try:
        yield value
    finally:
        _correlation_id.reset(token)
