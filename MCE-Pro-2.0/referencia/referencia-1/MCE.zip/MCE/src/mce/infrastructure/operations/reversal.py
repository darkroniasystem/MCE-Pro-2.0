"""Reversión transaccional con auditoría en la misma confirmación."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from uuid import uuid4

from sqlalchemy.orm import Session, sessionmaker

from mce.infrastructure.database.models import AuditEventModel

ReversalHandler = Callable[[Session, AuditEventModel], None]


class TransactionalReversalService:
    def __init__(self, factory: sessionmaker[Session]):
        self._factory = factory

    def revert(self, event_id: str, *, actor: str, handler: ReversalHandler) -> str:
        reversal_id = str(uuid4())
        with self._factory.begin() as session:
            original = session.get(AuditEventModel, event_id, with_for_update=True)
            if original is None:
                raise KeyError(event_id)
            if not original.reversible or original.reversed_by is not None:
                raise ValueError("audit event is not reversible")
            handler(session, original)
            reversal = AuditEventModel(
                id=reversal_id,
                occurred_at=datetime.now(UTC),
                actor=actor,
                action=f"revert:{original.action}",
                object_type=original.object_type,
                object_id=original.object_id,
                previous_value=original.new_value,
                new_value=original.previous_value,
                correlation_id=original.correlation_id,
                reversible=False,
            )
            session.add(reversal)
            session.flush()
            original.reversed_by = reversal_id
        return reversal_id
