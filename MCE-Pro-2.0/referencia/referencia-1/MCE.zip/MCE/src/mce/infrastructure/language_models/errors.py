"""Errores seguros para integraciones opcionales de modelos de lenguaje."""


class InvalidLanguageModelResponseError(ValueError):
    pass


class LanguageModelUnavailableError(RuntimeError):
    pass
