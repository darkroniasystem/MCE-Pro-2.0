"""Composición de producción para identificación online."""

from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import Any

from mce.application.ai_review import (
    AIReviewInput,
    AIReviewOrchestrator,
    AIReviewResult,
    EvidenceValidator,
    ValidatedAnalyzerChain,
)
from mce.application.identification.models import SearchKind
from mce.application.ports.metadata_provider import MetadataProvider
from mce.application.web_search import WebSearchFallbackService
from mce.infrastructure.ai_review import (
    GeminiStructuredAnalyzer,
    GroqStructuredAnalyzer,
    SqliteAIReviewStore,
    SqliteRateLimitStore,
    WebEvidenceSearchAdapter,
    create_gemini_client,
    create_groq_client,
)
from mce.infrastructure.local_ai import OllamaQwenAnalyzer, UrllibOllamaTransport
from mce.infrastructure.metadata.browser_playwright import PlaywrightBrowserAutomationBackend
from mce.infrastructure.metadata.browser_search import (
    BrowserSearchProvider,
    BrowserSearchSettings,
)
from mce.infrastructure.metadata.external_providers import (
    AniListMetadataProvider,
    FanartMetadataProvider,
    TvMazeMetadataProvider,
)
from mce.infrastructure.metadata.http_transport import UrllibJsonTransport
from mce.infrastructure.metadata.manager import MetadataProviderManager, ProviderRegistration
from mce.infrastructure.metadata.providers import (
    CachedMetadataProvider,
    ControlledMetadataProvider,
    MetadataProviderSettings,
    RateLimitedMetadataProvider,
    ResilientMetadataProvider,
    TmdbMetadataProvider,
)
from mce.infrastructure.metadata.sqlite_cache import SqliteMetadataCache
from mce.infrastructure.metadata.web_search import (
    CachedWebSearchProvider,
    ExaWebSearchProvider,
    ResilientControlledWebSearchProvider,
    SequentialWebSearchProvider,
    SerperWebSearchProvider,
    TavilyWebSearchProvider,
    WebProviderRegistration,
)
from mce.infrastructure.metadata.wikidata import (
    WikidataClient,
    WikidataEntityMapper,
    WikidataProviderConfig,
    WikidataSearchProvider,
)


@dataclass(frozen=True, slots=True)
class ProviderUsage:
    name: str
    calls: int = 0
    limit: int | None = None
    remaining: int | None = None
    successes: int = 0
    errors: int = 0
    rate_limited: int = 0
    cache_hits: int = 0
    tokens_remaining: int | None = None
    detail: str = ""
    cooldown_seconds: float | None = None
    cooldown_known: bool = False


@dataclass(frozen=True, slots=True)
class MetadataRuntime:
    provider: MetadataProvider
    configured: bool
    offline: bool
    message: str
    provider_statuses: tuple[tuple[str, str], ...] = ()
    web_fallback: WebSearchFallbackService | None = None
    ai_reviewer: Callable[[AIReviewInput], AIReviewResult] | None = None
    usage_snapshot: Callable[[], tuple[ProviderUsage, ...]] | None = None


def build_metadata_runtime(
    cache_path: Path,
    *,
    cancelled: Callable[[], bool] = lambda: False,
) -> MetadataRuntime:
    """Construye TMDb real o un fallo explícito; nunca usa el proveedor falso."""

    settings = _settings_from_environment()
    api_key = os.environ.get("TMDB_API_KEY", "").strip()
    fanart_key = os.environ.get("FANART_API_KEY", "").strip()
    tavily_key = os.environ.get("TAVILY_API_KEY", "").strip()
    serper_key = os.environ.get("SERPER_API_KEY", "").strip()
    exa_key = os.environ.get("EXA_API_KEY", "").strip()
    tavily_enabled = _bool_env("MCE_TAVILY_ENABLED", True)
    serper_enabled = _bool_env("MCE_SERPER_ENABLED", True)
    exa_enabled = _bool_env("MCE_EXA_ENABLED", True)
    browser_settings = BrowserSearchSettings(
        enabled=_bool_env("BROWSER_SEARCH_ENABLED", False),
        headless=_bool_env("BROWSER_HEADLESS", True),
        timeout_seconds=_float_env("BROWSER_TIMEOUT", 20.0, minimum=0.1),
        max_concurrency=_int_env("BROWSER_MAX_CONCURRENCY", 1, minimum=1),
        delay_min_ms=_int_env("BROWSER_DELAY_MIN_MS", 1_000, minimum=0),
        delay_max_ms=_int_env("BROWSER_DELAY_MAX_MS", 2_500, minimum=0),
        max_results=_int_env("BROWSER_MAX_RESULTS", 5, minimum=1),
        max_page_text_chars=_int_env(
            "BROWSER_MAX_PAGE_TEXT_CHARS", 12_000, minimum=1
        ),
    )
    gemini_key = os.environ.get("GEMINI_API_KEY", "").strip()
    groq_key = os.environ.get("GROQ_API_KEY", "").strip()
    ollama_enabled = _bool_env("OLLAMA_ENABLED", False)
    ollama_model = os.environ.get("OLLAMA_MODEL", "qwen2.5:3b").strip() or "qwen2.5:3b"
    statuses = (
        ("TMDb", "configurada" if api_key else "no configurada"),
        ("Fanart.tv", "configurada" if fanart_key else "no configurada"),
        ("AniList", "disponible sin credenciales"),
        ("TVMaze", "disponible sin credenciales"),
        ("Wikidata", "disponible sin credenciales · alias, IDs y respaldo"),
        (
            "Tavily",
            "configurada"
            if tavily_key and tavily_enabled
            else "desactivada (respaldo opcional)",
        ),
        ("Serper", "configurada" if serper_key and serper_enabled else "desactivada"),
        ("Exa", "configurada" if exa_key and exa_enabled else "desactivada"),
        (
            "Browser web",
            "integrado · Playwright/Chrome se comprueba al usar"
            if browser_settings.enabled
            else "desactivado",
        ),
        ("Groq IA", "configurada" if groq_key else "no configurada"),
        (
            "Ollama Qwen",
            f"habilitado · {ollama_model}" if ollama_enabled else "desactivado",
        ),
        ("Gemini IA", "desactivada · incompatibilidad regional"),
    )
    cache = SqliteMetadataCache(
        cache_path, max_entries=_int_env("MCE_METADATA_CACHE_MAX_ENTRIES", 5_000, minimum=1)
    )

    def wrap(provider: MetadataProvider) -> MetadataProvider:
        resilient = ResilientMetadataProvider(
            provider,
            retries=settings.retries,
            base_delay=_float_env("MCE_METADATA_RETRY_DELAY_SECONDS", 0.5, minimum=0),
            cancelled=cancelled,
        )
        controlled = ControlledMetadataProvider(
            resilient,
            max_concurrency=settings.max_concurrency,
            min_interval_seconds=settings.min_interval_seconds,
            failure_threshold=settings.circuit_failure_threshold,
            cooldown_seconds=settings.circuit_cooldown_seconds,
            cancelled=cancelled,
        )
        limited = RateLimitedMetadataProvider(controlled, settings.max_requests)
        return CachedMetadataProvider(
            limited, cache, ttl=settings.cache_ttl, offline=settings.offline
        )

    registrations: list[ProviderRegistration] = []
    if api_key:
        transport = UrllibJsonTransport(
            "https://api.themoviedb.org/3", provider_name="TMDb", cancelled=cancelled
        )
        tmdb = TmdbMetadataProvider(
            api_key,
            transport,
            settings.timeout_seconds,
            settings.language,
            settings.region,
        )
        registrations.append(
            ProviderRegistration(
                wrap(tmdb), True, True, True, (SearchKind.MOVIE, SearchKind.SERIES)
            )
        )
    anilist = AniListMetadataProvider(
        UrllibJsonTransport(
            "https://graphql.anilist.co", provider_name="AniList", cancelled=cancelled
        ),
        settings.timeout_seconds,
    )
    registrations.append(
        ProviderRegistration(wrap(anilist), False, False, True, (SearchKind.ANIME,))
    )
    tvmaze = TvMazeMetadataProvider(
        UrllibJsonTransport("https://api.tvmaze.com", provider_name="TVMaze", cancelled=cancelled),
        settings.timeout_seconds,
    )
    registrations.append(ProviderRegistration(wrap(tvmaze), False, True))
    wikidata_config = WikidataProviderConfig(
        timeout_seconds=settings.timeout_seconds,
        language=settings.language.split("-", 1)[0],
        max_candidates=_int_env("MCE_WIKIDATA_MAX_CANDIDATES", 8, minimum=1),
        max_search_variants=_int_env("MCE_WIKIDATA_MAX_SEARCH_VARIANTS", 3, minimum=1),
        enabled=_bool_env("MCE_WIKIDATA_ENABLED", True),
        complementary=_bool_env("MCE_WIKIDATA_COMPLEMENTARY", True),
        fallback=_bool_env("MCE_WIKIDATA_FALLBACK", True),
    )
    if wikidata_config.enabled:
        wikidata_transport = UrllibJsonTransport(
            "https://www.wikidata.org", provider_name="Wikidata", cancelled=cancelled
        )
        wikidata = WikidataSearchProvider(
            WikidataClient(wikidata_transport, wikidata_config),
            wikidata_config,
            WikidataEntityMapper(wikidata_config),
        )
        registrations.append(
            ProviderRegistration(
                wrap(wikidata),
                True,
                True,
                True,
                role="complementary",
            )
        )
    # Fanart.tv no busca por título: se registra para detalles una vez existan IDs compatibles.
    if fanart_key:
        fanart = FanartMetadataProvider(
            fanart_key,
            UrllibJsonTransport(
                "https://webservice.fanart.tv", provider_name="Fanart.tv", cancelled=cancelled
            ),
            settings.timeout_seconds,
        )
        registrations.append(ProviderRegistration(wrap(fanart), True, True, searchable=False))
    manager = MetadataProviderManager(tuple(registrations))
    web_fallback = None
    web_providers: list[
        tuple[str, str, int, ResilientControlledWebSearchProvider]
    ] = []
    cached_web: CachedWebSearchProvider | None = None

    def controlled_web(
        provider: Any,
    ) -> ResilientControlledWebSearchProvider:
        return ResilientControlledWebSearchProvider(
            provider,
            retries=settings.retries,
            max_requests=settings.max_requests,
            max_concurrency=settings.max_concurrency,
            min_interval_seconds=settings.min_interval_seconds,
            failure_threshold=settings.circuit_failure_threshold,
            cooldown_seconds=settings.circuit_cooldown_seconds,
            base_delay=_float_env("MCE_METADATA_RETRY_DELAY_SECONDS", 0.5, minimum=0),
            cancelled=cancelled,
        )

    web_registrations: list[WebProviderRegistration] = []
    if tavily_key and tavily_enabled:
        tavily = controlled_web(
            TavilyWebSearchProvider(
                tavily_key,
                UrllibJsonTransport(
                    "https://api.tavily.com",
                    provider_name="Tavily",
                    cancelled=cancelled,
                ),
                timeout=settings.timeout_seconds,
            )
        )
        tavily_priority = _int_env("MCE_TAVILY_PRIORITY", 30, minimum=1)
        web_providers.append(("Tavily web", "tavily", tavily_priority, tavily))
        web_registrations.append(
            WebProviderRegistration(
                tavily,
                "tavily",
                True,
                tavily_priority,
            )
        )
    if serper_key and serper_enabled:
        serper = controlled_web(
            SerperWebSearchProvider(
                serper_key,
                UrllibJsonTransport(
                    "https://google.serper.dev",
                    provider_name="Serper",
                    cancelled=cancelled,
                ),
                timeout=settings.timeout_seconds,
                max_characters=_int_env(
                    "MCE_WEB_RESULT_MAX_CHARACTERS", 1_500, minimum=100
                ),
            )
        )
        serper_priority = _int_env("MCE_SERPER_PRIORITY", 20, minimum=1)
        web_providers.append(("Serper web", "serper", serper_priority, serper))
        web_registrations.append(
            WebProviderRegistration(
                serper,
                "serper",
                True,
                serper_priority,
            )
        )
    if exa_key and exa_enabled:
        exa = controlled_web(
            ExaWebSearchProvider(
                exa_key,
                UrllibJsonTransport(
                    "https://api.exa.ai",
                    provider_name="Exa",
                    cancelled=cancelled,
                ),
                timeout=settings.timeout_seconds,
                max_characters=_int_env(
                    "MCE_WEB_RESULT_MAX_CHARACTERS", 1_500, minimum=100
                ),
            )
        )
        exa_priority = _int_env("MCE_EXA_PRIORITY", 10, minimum=1)
        web_providers.append(("Exa web", "exa", exa_priority, exa))
        web_registrations.append(
            WebProviderRegistration(
                exa,
                "exa",
                True,
                exa_priority,
            )
        )
    if browser_settings.enabled:
        browser = ResilientControlledWebSearchProvider(
            BrowserSearchProvider(
                PlaywrightBrowserAutomationBackend(
                    channel=os.environ.get("MCE_BROWSER_CHANNEL", "chrome"),
                    search_url_template=os.environ.get(
                        "MCE_BROWSER_SEARCH_URL_TEMPLATE",
                        "https://www.bing.com/search?q={query}",
                    ),
                ),
                browser_settings,
            ),
            retries=0,
            max_requests=settings.max_requests,
            max_concurrency=browser_settings.max_concurrency,
            min_interval_seconds=browser_settings.delay_min_ms / 1_000,
            failure_threshold=settings.circuit_failure_threshold,
            cooldown_seconds=settings.circuit_cooldown_seconds,
            base_delay=0,
            cancelled=cancelled,
        )
        browser_priority = _int_env("MCE_BROWSER_PRIORITY", 40, minimum=1)
        web_providers.append(("Browser web", "browser", browser_priority, browser))
        web_registrations.append(
            WebProviderRegistration(
                browser,
                "browser",
                True,
                browser_priority,
            )
        )
    if web_registrations:
        web_manager = SequentialWebSearchProvider(tuple(web_registrations))
        cached_web = CachedWebSearchProvider(
            web_manager,
            cache_path,
            ttl=timedelta(hours=_float_env("MCE_WEB_SEARCH_CACHE_TTL_HOURS", 24, minimum=0.1)),
        )
        web_fallback = WebSearchFallbackService(
            cached_web,
            limit=_int_env("MCE_WEB_SEARCH_MAX_CANDIDATES", 8, minimum=2),
        )
    ai_reviewer = None
    groq_analyzer: GroqStructuredAnalyzer | None = None
    qwen_analyzer: OllamaQwenAnalyzer | None = None
    analyzer_chain: ValidatedAnalyzerChain | None = None
    analyzer: Any = None
    if ollama_enabled:
        qwen_analyzer = OllamaQwenAnalyzer(
            UrllibOllamaTransport(
                os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
            ),
            model=ollama_model,
            timeout=_float_env("OLLAMA_TIMEOUT", 120, minimum=1),
            max_concurrency=_int_env("LOCAL_LLM_MAX_CONCURRENCY", 1, minimum=1),
            max_web_results=_int_env("LOCAL_LLM_MAX_WEB_RESULTS", 5, minimum=1),
            max_context_chars=_int_env(
                "LOCAL_LLM_MAX_CONTEXT_CHARS", 8_000, minimum=500
            ),
            max_output_tokens=_int_env(
                "LOCAL_LLM_MAX_OUTPUT_TOKENS", 800, minimum=50
            ),
            failure_threshold=_int_env(
                "LOCAL_LLM_CIRCUIT_FAILURE_THRESHOLD", 3, minimum=1
            ),
            cooldown_seconds=_float_env(
                "LOCAL_LLM_CIRCUIT_COOLDOWN_SECONDS", 60, minimum=0
            ),
        )
        analyzer = qwen_analyzer
    if groq_key and _bool_env("MCE_GROQ_ENABLED", True):
        if web_fallback is None:
            groq_analyzer = None
        else:
            models = [os.environ.get("MCE_GROQ_PRIMARY_MODEL", "openai/gpt-oss-120b")]
            if _bool_env("MCE_GROQ_FALLBACK_ENABLED", True):
                models.append(
                    os.environ.get("MCE_GROQ_FALLBACK_MODEL", "openai/gpt-oss-20b")
                )
            if _bool_env("MCE_GROQ_QWEN_FALLBACK", False):
                models.append(os.environ.get("MCE_GROQ_QWEN_MODEL", "qwen/qwen3.6-27b"))
            rate_limit_store = SqliteRateLimitStore(cache_path)
            groq_analyzer = GroqStructuredAnalyzer(
                create_groq_client(groq_key, timeout=settings.timeout_seconds),
                tuple(models),
                rate_limit_store=rate_limit_store,
            )
            if qwen_analyzer is not None:
                analyzer_chain = ValidatedAnalyzerChain(
                    qwen_analyzer, groq_analyzer, EvidenceValidator()
                )
                analyzer = analyzer_chain
            else:
                analyzer = groq_analyzer
    if analyzer is not None and web_fallback is not None:
        ai_store = SqliteAIReviewStore(
            cache_path,
            daily_limit=_int_env("MCE_AI_DAILY_WORK_LIMIT", 1_000, minimum=1),
        )
        orchestrator = AIReviewOrchestrator(
            WebEvidenceSearchAdapter(web_fallback.provider, limit=5),
            analyzer,
            EvidenceValidator(),
            ai_store,
            ai_store,
            test_mode=_bool_env("MCE_AI_TEST_MODE", False),
        )
        ai_reviewer = orchestrator.review
    elif analyzer is None and (
        gemini_key
        and web_fallback is not None
        and _bool_env("MCE_GEMINI_AI_ENABLED", False)
    ):
        ai_store = SqliteAIReviewStore(cache_path, daily_limit=20)
        orchestrator = AIReviewOrchestrator(
            WebEvidenceSearchAdapter(web_fallback.provider, limit=5),
            GeminiStructuredAnalyzer(create_gemini_client(gemini_key)),
            EvidenceValidator(),
            ai_store,
            ai_store,
            test_mode=True,
        )
        ai_reviewer = orchestrator.review
    mode = "modo offline con caché" if settings.offline else "online"
    message = " · ".join(f"{name}: {status}" for name, status in statuses) + f" · {mode}"
    return MetadataRuntime(
        manager,
        bool(registrations),
        settings.offline,
        message,
        statuses,
        web_fallback,
        ai_reviewer,
        lambda: _usage_snapshot(
            registrations,
            web_providers,
            cached_web,
            qwen_analyzer,
            groq_analyzer,
            analyzer_chain,
            ollama_enabled,
            ollama_model,
        ),
    )


def _usage_snapshot(
    registrations: list[ProviderRegistration],
    web_providers: list[
        tuple[str, str, int, ResilientControlledWebSearchProvider]
    ],
    cached_web: CachedWebSearchProvider | None,
    qwen_analyzer: OllamaQwenAnalyzer | None,
    groq_analyzer: GroqStructuredAnalyzer | None,
    analyzer_chain: ValidatedAnalyzerChain | None,
    ollama_enabled: bool,
    ollama_model: str,
) -> tuple[ProviderUsage, ...]:
    rows: list[ProviderUsage] = []
    labels = {
        "tmdb": "TMDb",
        "anilist": "AniList",
        "tvmaze": "TVMaze",
        "wikidata": "Wikidata",
        "fanart": "Fanart.tv",
    }
    for registration in registrations:
        provider: Any = registration.provider
        cached = provider
        limited: Any = None
        base = provider
        while True:
            if isinstance(base, RateLimitedMetadataProvider):
                limited = base
            nested = getattr(base, "provider", None)
            if nested is None:
                break
            base = nested
        raw_name = str(getattr(base, "name", "proveedor")).casefold()
        name = next((label for key, label in labels.items() if key in raw_name), raw_name)
        calls = int(getattr(limited, "calls", 0))
        limit = int(getattr(limited, "max_requests", 0)) or None
        rows.append(
            ProviderUsage(
                name,
                calls,
                limit,
                max(0, limit - calls) if limit is not None else None,
                int(getattr(limited, "successes", 0)),
                int(getattr(limited, "errors", 0)),
                int(getattr(limited, "rate_limited", 0)),
                int(getattr(cached, "cache_hits", 0)),
                detail="límite local",
            )
        )
    for label, provider_id, priority, web_provider in web_providers:
        state = web_provider.telemetry(
            provider_id,
            priority=priority,
            cache_hits=int(getattr(cached_web, "cache_hits", 0)),
        )
        calls = state.total_requests
        limit = int(web_provider.max_requests)
        rows.append(
            ProviderUsage(
                label,
                calls,
                limit,
                max(0, limit - web_provider.calls),
                state.total_success,
                state.total_failures,
                state.rate_limit_hits,
                state.cache_hits,
                detail=(
                    f"búsqueda web · prioridad {state.priority} · "
                    f"circuito {state.circuit_state} · "
                    f"fallos consecutivos {state.consecutive_failures} · "
                    f"cuota agotada {state.quota_exhausted_count}"
                ),
            )
        )
    if groq_analyzer is not None:
        headers = groq_analyzer.last_headers
        limit = _optional_int(headers.get("x-ratelimit-limit-requests"))
        remaining = _optional_int(headers.get("x-ratelimit-remaining-requests"))
        tokens = _optional_int(headers.get("x-ratelimit-remaining-tokens"))
        average = (
            sum(groq_analyzer.latencies_ms) / len(groq_analyzer.latencies_ms)
            if groq_analyzer.latencies_ms
            else 0
        )
        route_detail = (
            f"ruta Qwen a Groq: {analyzer_chain.fallback_calls}"
            if analyzer_chain is not None
            else "ruta directa; Qwen desactivado"
        )
        cooldown = groq_analyzer.cooldown_remaining_seconds
        cooldown_detail = (
            f"enfriamiento {cooldown:.0f} s por {groq_analyzer.quota_kind} "
            f"({'proveedor' if groq_analyzer.cooldown_is_authoritative else 'seguridad'}) "
            f"· omitidas {groq_analyzer.cooldown_skips}"
            if cooldown
            else f"disponible · omitidas {groq_analyzer.cooldown_skips}"
        )
        rows.append(
            ProviderUsage(
                "Groq IA",
                groq_analyzer.calls,
                limit,
                remaining,
                groq_analyzer.successes,
                groq_analyzer.errors,
                groq_analyzer.rate_limited,
                0,
                tokens,
                f"modelos respaldo: {groq_analyzer.fallback_calls} · "
                f"media {average:,.0f} ms · {cooldown_detail} · {route_detail}",
                cooldown_seconds=cooldown if cooldown else None,
                cooldown_known=groq_analyzer.cooldown_is_authoritative,
            )
        )
    if qwen_analyzer is not None:
        average = (
            sum(qwen_analyzer.latencies_ms) / len(qwen_analyzer.latencies_ms)
            if qwen_analyzer.latencies_ms
            else 0
        )
        rows.append(
            ProviderUsage(
                "Qwen local",
                qwen_analyzer.calls,
                None,
                None,
                qwen_analyzer.successes,
                qwen_analyzer.errors,
                0,
                0,
                None,
                (
                    f"{qwen_analyzer.model} · media {average:,.0f} ms · "
                    f"timeouts {qwen_analyzer.timeouts} · circuito "
                    f"{qwen_analyzer.circuit_state} · aceptadas "
                    f"{analyzer_chain.primary_accepted if analyzer_chain else 0} · "
                    f"a Groq {analyzer_chain.fallback_calls if analyzer_chain else 0}"
                ),
            )
        )
    else:
        rows.append(
            ProviderUsage(
                "Qwen local",
                detail=(
                    f"{ollama_model} · habilitado sin analizador"
                    if ollama_enabled
                    else "desactivado en Configuración; Groq usa la ruta directa"
                ),
            )
        )
    return tuple(rows)


def _optional_int(value: str | None) -> int | None:
    try:
        return int(float(value)) if value is not None else None
    except ValueError:
        return None


def _settings_from_environment() -> MetadataProviderSettings:
    return MetadataProviderSettings(
        timeout_seconds=_float_env("MCE_METADATA_TIMEOUT_SECONDS", 10, minimum=0.1),
        retries=_int_env("MCE_METADATA_RETRIES", 2, minimum=0),
        max_requests=_int_env("MCE_METADATA_MAX_REQUESTS", 100_000, minimum=1),
        language=os.environ.get("MCE_METADATA_LANGUAGE", "es-ES").strip() or "es-ES",
        region=os.environ.get("MCE_METADATA_REGION", "").strip() or None,
        offline=_bool_env("MCE_OFFLINE", False),
        cache_ttl=timedelta(hours=_float_env("MCE_METADATA_CACHE_TTL_HOURS", 24, minimum=0.1)),
        max_concurrency=_int_env("MCE_METADATA_MAX_CONCURRENCY", 1, minimum=1),
        min_interval_seconds=_float_env("MCE_METADATA_MIN_INTERVAL_SECONDS", 0.0, minimum=0.0),
        circuit_failure_threshold=_int_env("MCE_METADATA_CIRCUIT_FAILURES", 3, minimum=1),
        circuit_cooldown_seconds=_float_env(
            "MCE_METADATA_CIRCUIT_COOLDOWN_SECONDS", 30.0, minimum=0.0
        ),
    )


def _bool_env(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    normalized = raw.strip().casefold()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} debe ser true o false")


def _int_env(name: str, default: int, *, minimum: int) -> int:
    raw = os.environ.get(name)
    try:
        value = default if raw is None else int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} debe ser un entero") from exc
    if value < minimum:
        raise ValueError(f"{name} debe ser mayor o igual que {minimum}")
    return value


def _float_env(name: str, default: float, *, minimum: float) -> float:
    raw = os.environ.get(name)
    try:
        value = default if raw is None else float(raw)
    except ValueError as exc:
        raise ValueError(f"{name} debe ser numérico") from exc
    if value < minimum:
        raise ValueError(f"{name} debe ser mayor o igual que {minimum}")
    return value
