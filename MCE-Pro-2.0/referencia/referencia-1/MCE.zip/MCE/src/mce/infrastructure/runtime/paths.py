"""Directorios de instalación y datos mutables independientes del CWD."""

from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class RuntimePaths:
    data: Path
    logs: Path
    cache: Path
    checkpoints: Path
    originals: Path
    exports: Path
    configuration: Path
    backups: Path

    @classmethod
    def discover(cls) -> RuntimePaths:
        override = os.environ.get("MCE_DATA_DIR", "").strip()
        if override:
            root = Path(override).expanduser().resolve()
        else:
            local = os.environ.get("LOCALAPPDATA", "").strip()
            root = (
                Path(local) / "MCE Desktop"
                if local
                else Path.home() / "AppData" / "Local" / "MCE Desktop"
            ).resolve()
        paths = cls(
            root,
            root / "logs",
            root / "cache",
            root / "checkpoints",
            root / "originals",
            root / "exports",
            root / "config",
            root / "backups",
        )
        paths.ensure()
        return paths

    def ensure(self) -> None:
        for path in (
            self.data,
            self.logs,
            self.cache,
            self.checkpoints,
            self.originals,
            self.exports,
            self.configuration,
            self.backups,
        ):
            path.mkdir(parents=True, exist_ok=True)

    def import_legacy(self, project_root: Path) -> int:
        """Copia datos locales anteriores sin borrar ni sobrescribir originales."""
        legacy = project_root.resolve() / "data" / "session_checkpoints"
        if not legacy.is_dir() or legacy.is_symlink():
            return 0
        copied = 0
        for source in legacy.glob("*.json"):
            if source.is_symlink() or not source.is_file():
                continue
            target = self.checkpoints / source.name
            if not target.exists():
                shutil.copy2(source, target)
                copied += 1
        legacy_cache = project_root.resolve() / "data" / "metadata_cache.sqlite3"
        target_cache = self.cache / "metadata_cache.sqlite3"
        if legacy_cache.is_file() and not legacy_cache.is_symlink() and not target_cache.exists():
            shutil.copy2(legacy_cache, target_cache)
            copied += 1
        return copied


def resource_root() -> Path:
    bundled = getattr(sys, "_MEIPASS", None)
    if bundled:
        return Path(str(bundled)).resolve()
    return Path(__file__).resolve().parents[4]


def resource_path(relative: str | Path) -> Path:
    value = Path(relative)
    if value.is_absolute() or ".." in value.parts:
        raise ValueError("resource path must be relative and remain inside the bundle")
    root = resource_root()
    target = (root / value).resolve()
    if target != root and root not in target.parents:
        raise ValueError("resource path escapes the bundle")
    return target
