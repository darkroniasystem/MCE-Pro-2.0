"""Transforma entidades Wikidata en candidatos MCE conservando procedencia."""

from __future__ import annotations

from datetime import datetime
from typing import Any, ClassVar

from mce.application.identification.models import (
    ProviderCandidate,
    ProviderTitleAlias,
    SearchKind,
)

from .config import WikidataProviderConfig


class WikidataEntityMapper:
    # Instancias audiovisuales comunes. Las desconocidas no se aceptan a ciegas.
    MOVIE_TYPES = frozenset({"Q11424", "Q202866", "Q506240", "Q93204"})
    SERIES_TYPES = frozenset({"Q5398426", "Q130232", "Q15416", "Q3464665"})
    ANIME_TYPES = frozenset({"Q1107", "Q63952888"})
    BLOCKED_TYPES = frozenset({"Q5", "Q7366", "Q482994", "Q571", "Q7889", "Q43229", "Q4167410"})
    EXTERNAL_PROPERTIES: ClassVar[dict[str, str]] = {
        "P345": "imdb",
        "P4947": "tmdb_movie",
        "P4983": "tmdb_tv",
        "P4835": "tvmaze",
        "P8729": "anilist",
    }

    def __init__(self, config: WikidataProviderConfig) -> None:
        self.config = config

    def map(self, entity: dict[str, object], expected: SearchKind) -> ProviderCandidate | None:
        qid = str(entity.get("id") or "")
        if not qid.startswith("Q"):
            return None
        claims = entity.get("claims")
        claims = claims if isinstance(claims, dict) else {}
        instance_ids = self._entity_ids(claims.get("P31"))
        if instance_ids & self.BLOCKED_TYPES or not self._compatible(instance_ids, expected):
            return None
        labels = self._language_values(entity.get("labels"))
        aliases = self._alias_values(entity.get("aliases"))
        title = labels.get("es") or labels.get("en") or next(iter(labels.values()), None)
        if not title:
            return None
        typed_aliases = tuple(
            ProviderTitleAlias(
                value,
                language=language,
                alias_type="alternative_title",
                provenance=f"wikidata:{qid}:aliases",
            )
            for language, values in aliases.items()
            for value in values
        )
        descriptions = self._language_values(entity.get("descriptions"))
        year = self._year(claims.get("P577"))
        external_ids = [("wikidata", qid)]
        for prop, identifier_type in self.EXTERNAL_PROPERTIES.items():
            for value in self._literal_values(claims.get(prop)):
                external_ids.append((identifier_type, value))
        sitelinks = entity.get("sitelinks")
        wiki_links = self._sitelinks(sitelinks)
        source_url = wiki_links.get("eswiki") or wiki_links.get("enwiki")
        return ProviderCandidate(
            provider="wikidata",
            external_id=qid,
            kind=expected,
            title=title,
            original_title=labels.get("en") or title,
            translated_titles=tuple(dict.fromkeys(labels.values())),
            aliases=tuple(dict.fromkeys(a.title for a in typed_aliases)),
            year=year,
            overview=descriptions.get("es") or descriptions.get("en"),
            external_ids=tuple(dict.fromkeys(external_ids)),
            source_url=source_url or f"https://www.wikidata.org/wiki/{qid}",
            spanish_title=labels.get("es"),
            english_title=labels.get("en"),
            title_aliases=typed_aliases,
        )

    def _compatible(self, values: set[str], expected: SearchKind) -> bool:
        allowed = {
            SearchKind.MOVIE: self.MOVIE_TYPES,
            SearchKind.SERIES: self.SERIES_TYPES,
            SearchKind.ANIME: self.ANIME_TYPES | self.SERIES_TYPES,
        }[expected]
        return bool(values & allowed)

    @staticmethod
    def _language_values(raw: object) -> dict[str, str]:
        if not isinstance(raw, dict):
            return {}
        return {
            str(language): str(row["value"]).strip()
            for language, row in raw.items()
            if isinstance(row, dict) and row.get("value")
        }

    @staticmethod
    def _alias_values(raw: object) -> dict[str, tuple[str, ...]]:
        if not isinstance(raw, dict):
            return {}
        result: dict[str, tuple[str, ...]] = {}
        for language, rows in raw.items():
            if isinstance(rows, list):
                values = tuple(
                    str(row["value"]).strip()
                    for row in rows
                    if isinstance(row, dict) and row.get("value")
                )
                if values:
                    result[str(language)] = values
        return result

    @staticmethod
    def _snaks(raw: object) -> tuple[dict[str, Any], ...]:
        if not isinstance(raw, list):
            return ()
        return tuple(
            row["mainsnak"]
            for row in raw
            if isinstance(row, dict) and isinstance(row.get("mainsnak"), dict)
        )

    @classmethod
    def _entity_ids(cls, raw: object) -> set[str]:
        values: set[str] = set()
        for snak in cls._snaks(raw):
            datavalue = snak.get("datavalue")
            value = datavalue.get("value") if isinstance(datavalue, dict) else None
            if isinstance(value, dict) and isinstance(value.get("id"), str):
                values.add(value["id"])
        return values

    @classmethod
    def _literal_values(cls, raw: object) -> tuple[str, ...]:
        values: list[str] = []
        for snak in cls._snaks(raw):
            datavalue = snak.get("datavalue")
            value = datavalue.get("value") if isinstance(datavalue, dict) else None
            if isinstance(value, (str, int)):
                values.append(str(value))
        return tuple(values)

    @classmethod
    def _year(cls, raw: object) -> int | None:
        for snak in cls._snaks(raw):
            datavalue = snak.get("datavalue")
            value = datavalue.get("value") if isinstance(datavalue, dict) else None
            text = value.get("time") if isinstance(value, dict) else None
            if isinstance(text, str):
                try:
                    return datetime.fromisoformat(text.lstrip("+").replace("Z", "+00:00")).year
                except ValueError:
                    if len(text) >= 5 and text[1:5].isdigit():
                        return int(text[1:5])
        return None

    @staticmethod
    def _sitelinks(raw: object) -> dict[str, str]:
        if not isinstance(raw, dict):
            return {}
        result: dict[str, str] = {}
        for site in ("eswiki", "enwiki"):
            row = raw.get(site)
            if isinstance(row, dict) and row.get("title"):
                language = site.removesuffix("wiki")
                title = str(row["title"]).replace(" ", "_")
                result[site] = f"https://{language}.wikipedia.org/wiki/{title}"
        return result
