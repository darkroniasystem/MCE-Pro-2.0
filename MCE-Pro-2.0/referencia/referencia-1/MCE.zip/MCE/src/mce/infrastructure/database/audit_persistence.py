"""Persistencia breve de auditoría para acciones de escritorio."""

from __future__ import annotations

import os
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from sqlalchemy import create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session, sessionmaker

from mce.application.operations import AuditEvent, AuditService
from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork


class AuditPersistenceService:
    def __init__(self, factory: sessionmaker[Session]):
        self.factory = factory

    @classmethod
    def from_test_environment(cls) -> AuditPersistenceService | None:
        raw = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
        if not raw:
            return None
        url = make_url(raw)
        if url.get_backend_name() != "postgresql" or url.database != "mce_test":
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    @classmethod
    def from_runtime_environment(cls) -> AuditPersistenceService | None:
        raw = runtime_database_url()
        if raw is None:
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    def record(
        self,
        action: str,
        object_type: str,
        object_id: str,
        *,
        previous_value: Any = None,
        new_value: Any = None,
        actor: str = "local_operator",
        correlation_id: str | None = None,
        reversible: bool = False,
    ) -> str:
        event_id = str(uuid4())
        event = AuditEvent(
            event_id,
            datetime.now(UTC),
            actor,
            action,
            object_type,
            object_id,
            previous_value,
            new_value,
            correlation_id or str(uuid4()),
            reversible,
        )
        with SqlAlchemyUnitOfWork(self.factory) as uow:
            AuditService(uow.audit_events).record(event)
            uow.commit()
        return event_id
