"""Cliente opcional de Ollama y analizador Qwen limitado a evidencia suministrada."""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass
from threading import BoundedSemaphore, Lock
from typing import Any, Literal, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from mce.application.ai_review.models import (
    AIFieldEvidence,
    AIReviewInput,
    AIReviewResult,
    EvidenceSource,
)
from mce.application.ai_review.sanitizer import sanitized_payload


class QwenSourceProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")
    url: str
    evidence: str


class QwenFieldProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")
    value: str | int | float | list[str] | list[int] | None = None
    confidence: float = Field(default=0, ge=0, le=100)
    sources: list[str] = Field(default_factory=list)


class QwenReviewProposal(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Literal["matched", "partial_match", "ambiguous", "insufficient_evidence"]
    canonical_title: str | None = None
    original_title: str | None = None
    year: int | None = None
    media_type: str | None = None
    seasons: list[int] = Field(default_factory=list)
    confidence: float = Field(default=0, ge=0, le=100)
    fields: dict[str, QwenFieldProposal] = Field(default_factory=dict)
    matched_sources: list[QwenSourceProposal] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    reasoning_summary: str = "evidencia insuficiente"
    recommended_action: Literal[
        "accept", "partial_accept", "escalate", "human_review"
    ] = "human_review"


_ALLOWED_QWEN_FIELDS = frozenset(
    {
        "canonical_title",
        "original_title",
        "year",
        "media_type",
        "seasons",
        "genres",
        "cast",
        "rating",
        "platforms",
        "alternative_titles",
    }
)


class OllamaTransport(Protocol):
    def tags(self, timeout: float) -> dict[str, object]: ...

    def chat(self, payload: dict[str, object], timeout: float) -> dict[str, object]: ...


@dataclass(frozen=True, slots=True)
class OllamaDiagnostic:
    connected: bool
    model_present: bool
    inference_ok: bool
    message: str


class UrllibOllamaTransport:
    """Habla únicamente con un servicio Ollama local explícito."""

    def __init__(self, base_url: str = "http://localhost:11434") -> None:
        normalized = base_url.rstrip("/")
        parsed = urlparse(normalized)
        if parsed.scheme not in {"http", "https"} or parsed.hostname not in {
            "localhost",
            "127.0.0.1",
            "::1",
        }:
            raise ValueError("Ollama base URL must point to the local computer")
        self.base_url = normalized

    def tags(self, timeout: float) -> dict[str, object]:
        return self._request("/api/tags", None, timeout)

    def chat(self, payload: dict[str, object], timeout: float) -> dict[str, object]:
        return self._request("/api/chat", payload, timeout)

    def _request(
        self,
        path: str,
        payload: dict[str, object] | None,
        timeout: float,
    ) -> dict[str, object]:
        body = None if payload is None else json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self.base_url}{path}",
            data=body,
            method="GET" if body is None else "POST",
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        try:
            with urlopen(request, timeout=timeout) as response:
                raw = response.read()
        except HTTPError as exc:
            raise RuntimeError(f"Ollama rechazó la solicitud ({exc.code})") from exc
        except (URLError, TimeoutError) as exc:
            raise RuntimeError("Ollama no está disponible") from exc
        try:
            value: Any = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("Ollama devolvió JSON inválido") from exc
        if not isinstance(value, dict):
            raise RuntimeError("Ollama devolvió una respuesta inesperada")
        return value


class OllamaQwenAnalyzer:
    """Analiza evidencia con Qwen local; nunca usa el modelo como fuente."""

    name = "ollama"

    def __init__(
        self,
        transport: OllamaTransport,
        *,
        model: str = "qwen2.5:3b",
        timeout: float = 120,
        max_concurrency: int = 1,
        max_web_results: int = 5,
        max_context_chars: int = 8_000,
        max_output_tokens: int = 800,
        invalid_json_retries: int = 1,
        failure_threshold: int = 3,
        cooldown_seconds: float = 60,
        preflight_timeout: float = 3,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if min(
            max_concurrency,
            max_web_results,
            max_context_chars,
            max_output_tokens,
            failure_threshold,
        ) < 1:
            raise ValueError("Ollama limits must be positive")
        self.transport = transport
        self.model = model
        self.timeout = timeout
        self.max_web_results = max_web_results
        self.max_context_chars = max_context_chars
        self.max_output_tokens = max_output_tokens
        self.invalid_json_retries = max(0, invalid_json_retries)
        self.failure_threshold = failure_threshold
        self.cooldown_seconds = max(0.0, cooldown_seconds)
        self.preflight_timeout = max(0.1, min(timeout, preflight_timeout))
        self._monotonic = monotonic
        self._slots = BoundedSemaphore(max_concurrency)
        self._state_lock = Lock()
        self._consecutive_failures = 0
        self._circuit_opened_at: float | None = None
        self.calls = 0
        self.successes = 0
        self.errors = 0
        self.invalid_json = 0
        self.timeouts = 0
        self.latencies_ms: list[int] = []

    @property
    def circuit_state(self) -> str:
        with self._state_lock:
            if self._circuit_opened_at is None:
                return "closed"
            if self._monotonic() - self._circuit_opened_at >= self.cooldown_seconds:
                return "half-open"
            return "open"

    def diagnose(self, *, inference: bool = True) -> OllamaDiagnostic:
        try:
            payload = self.transport.tags(self.timeout)
        except Exception as exc:
            return OllamaDiagnostic(False, False, False, str(exc)[:300])
        models = payload.get("models")
        model_rows = models if isinstance(models, list) else []
        names = {
            str(row.get("name") or row.get("model") or "")
            for row in model_rows
            if isinstance(row, dict)
        }
        present = self.model in names or any(
            value.split("@", 1)[0] == self.model for value in names
        )
        if not present:
            return OllamaDiagnostic(
                True,
                False,
                False,
                f"Ollama está funcionando, pero {self.model} no está instalado.",
            )
        if not inference:
            return OllamaDiagnostic(True, True, False, "Modelo instalado")
        try:
            response = self.transport.chat(
                {
                    "model": self.model,
                    "stream": False,
                    "messages": [{"role": "user", "content": "Responde solo: OK"}],
                    "options": {"temperature": 0, "num_predict": 4},
                },
                self.timeout,
            )
            content = _message_content(response)
        except Exception as exc:
            return OllamaDiagnostic(True, True, False, str(exc)[:300])
        return OllamaDiagnostic(
            True,
            True,
            bool(content.strip()),
            "Ollama conectado; modelo disponible e inferencia correcta",
        )

    def analyze(
        self,
        item: AIReviewInput,
        sources: tuple[EvidenceSource, ...],
    ) -> AIReviewResult:
        self._ensure_circuit_available()
        self._ensure_model_available()
        compact_sources = tuple(sources[: self.max_web_results])
        payload = _bounded_qwen_context(item, compact_sources, self.max_context_chars)
        request = {
            "model": self.model,
            "stream": False,
            "format": QwenReviewProposal.model_json_schema(),
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "Interpreta únicamente la evidencia suministrada. No inventes URLs "
                        "ni datos. Usa como título canónico exactamente un título respaldado "
                        "por las fuentes; elimina prefijos, episodios, calidad, idioma y otras "
                        "etiquetas técnicas del nombre local. Devuelve exclusivamente JSON "
                        "válido según el esquema. Marca matched/accept solo cuando al menos "
                        "dos dominios suministrados coincidan en el mismo título canónico y "
                        "tipo, sin conflictos; incluye ambas URLs en matched_sources. Si hay "
                        "una sola fuente usa escalate, y si la evidencia contradice el título "
                        "usa human_review. No seas ambiguo cuando dos fuentes sí coinciden. "
                        "Usa partial_match/partial_accept si solo algunos campos están "
                        "demostrados, pero nunca lo autoapruebes. Cada campo debe citar "
                        "solamente URLs presentes en la evidencia."
                    ),
                },
                {"role": "user", "content": payload},
            ],
            "options": {
                "temperature": 0,
                "num_predict": self.max_output_tokens,
            },
        }
        with self._slots:
            for attempt in range(self.invalid_json_retries + 1):
                started = time.perf_counter()
                self.calls += 1
                try:
                    response = self.transport.chat(request, self.timeout)
                    proposal = _parse_qwen_proposal(_message_content(response))
                except (ValidationError, ValueError, TypeError, KeyError) as exc:
                    self.errors += 1
                    self.invalid_json += 1
                    if attempt >= self.invalid_json_retries:
                        self._record_failure()
                        raise RuntimeError("Qwen devolvió JSON o esquema inválido") from exc
                    continue
                except Exception as exc:
                    self.errors += 1
                    if isinstance(exc, TimeoutError) or "timeout" in str(exc).casefold():
                        self.timeouts += 1
                    self._record_failure(immediate=_ollama_unavailable(exc))
                    raise
                latency_ms = round((time.perf_counter() - started) * 1000)
                self.successes += 1
                self.latencies_ms.append(latency_ms)
                self._record_success()
                return _decode_qwen(proposal, compact_sources, self.model, latency_ms)
        raise RuntimeError("Qwen no produjo un resultado")

    def _ensure_circuit_available(self) -> None:
        with self._state_lock:
            opened_at = self._circuit_opened_at
            if opened_at is None:
                return
            if self._monotonic() - opened_at < self.cooldown_seconds:
                raise RuntimeError("Circuito de Ollama abierto temporalmente")
            self._circuit_opened_at = None
            self._consecutive_failures = 0

    def _ensure_model_available(self) -> None:
        try:
            payload = self.transport.tags(self.preflight_timeout)
        except Exception as exc:
            self._record_failure(immediate=True)
            raise RuntimeError("Ollama no está disponible") from exc
        models = payload.get("models")
        rows = models if isinstance(models, list) else []
        names = {
            str(row.get("name") or row.get("model") or "")
            for row in rows
            if isinstance(row, dict)
        }
        if self.model not in names and not any(
            value.split("@", 1)[0] == self.model for value in names
        ):
            self._record_failure(immediate=True)
            raise RuntimeError(f"Ollama no tiene instalado el modelo {self.model}")

    def _record_failure(self, *, immediate: bool = False) -> None:
        with self._state_lock:
            self._consecutive_failures += 1
            if immediate or self._consecutive_failures >= self.failure_threshold:
                self._circuit_opened_at = self._monotonic()

    def _record_success(self) -> None:
        with self._state_lock:
            self._consecutive_failures = 0
            self._circuit_opened_at = None


def _ollama_unavailable(exc: Exception) -> bool:
    message = str(exc).casefold()
    return "no está disponible" in message or "connection refused" in message


def _message_content(response: dict[str, object]) -> str:
    message = response.get("message")
    if not isinstance(message, dict):
        raise ValueError("Ollama no devolvió message")
    content = message.get("content")
    if not isinstance(content, str) or not content.strip():
        raise ValueError("Ollama devolvió contenido vacío")
    return content


def _parse_qwen_proposal(content: str) -> QwenReviewProposal:
    """Recupera JSON valido de respuestas locales con cercas o texto accesorio."""
    text = content.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        data = json.loads(text[start : end + 1])
    if not isinstance(data, dict):
        raise ValueError("Qwen no devolvio un objeto JSON")
    aliases = {
        "reason": "reasoning_summary",
        "reasoning": "reasoning_summary",
        "action": "recommended_action",
        "sources": "matched_sources",
    }
    for source, target in aliases.items():
        if target not in data and source in data:
            data[target] = data[source]
        if source != target:
            data.pop(source, None)
    fields = data.get("fields", {})
    if not isinstance(fields, dict):
        raise ValueError("Qwen devolvio fields invalido")
    unknown_fields = set(fields) - _ALLOWED_QWEN_FIELDS
    if unknown_fields:
        raise ValueError(f"Qwen devolvio campos no permitidos: {sorted(unknown_fields)}")
    return QwenReviewProposal.model_validate(data)


def _bounded_qwen_context(
    item: AIReviewInput,
    sources: tuple[EvidenceSource, ...],
    max_chars: int,
) -> str:
    """Produce siempre JSON completo y compacto; nunca corta texto serializado."""

    rows = [_compact_source(source, snippet_limit=900) for source in sources]

    def encode(values: list[dict[str, object]]) -> str:
        return json.dumps(
            {
                "local": sanitized_payload(item),
                "untrusted_web_evidence": values,
            },
            ensure_ascii=False,
            separators=(",", ":"),
        )

    payload = encode(rows)
    if len(payload) <= max_chars:
        return payload
    rows = [_compact_source(source, snippet_limit=180) for source in sources]
    while rows:
        payload = encode(rows)
        if len(payload) <= max_chars:
            return payload
        rows.pop()
    payload = encode([])
    if len(payload) <= max_chars:
        return payload
    raise ValueError("El limite de contexto no permite ni siquiera la entrada local")


def _compact_source(source: EvidenceSource, *, snippet_limit: int) -> dict[str, object]:
    values = asdict(source)
    values["title"] = source.title[:300]
    values["snippet"] = source.snippet[:snippet_limit]
    for name in ("seasons", "genres", "cast", "platforms", "alternative_titles"):
        raw = values.get(name)
        if isinstance(raw, tuple):
            values[name] = raw[:20]
    return values


def _decode_qwen(
    proposal: QwenReviewProposal,
    sources: tuple[EvidenceSource, ...],
    model: str,
    latency_ms: int,
) -> AIReviewResult:
    from mce.application.ai_review.models import (
        SCHEMA_VERSION,
        AIReviewDecision,
        AIReviewState,
    )

    cited_urls = {entry.url for entry in proposal.matched_sources}
    cited_urls.update(
        url for field in proposal.fields.values() for url in field.sources
    )
    available_urls = {source.url for source in sources}
    verified = tuple(source for source in sources if source.url in cited_urls)
    hallucinated_source = bool(cited_urls - available_urls)
    accept = (
        proposal.status == "matched"
        and proposal.recommended_action == "accept"
        and not hallucinated_source
    )
    decision = (
        AIReviewDecision.APPROVE
        if accept
        else AIReviewDecision.HUMAN_REVIEW
    )
    return AIReviewResult(
        schema_version=SCHEMA_VERSION,
        state=AIReviewState.PENDING if accept else AIReviewState.HUMAN,
        decision=decision,
        canonical_title=proposal.canonical_title,
        media_type=proposal.media_type,
        year=proposal.year,
        seasons=tuple(proposal.seasons),
        deterministic_score=0,
        sources=verified,
        contradictions=tuple(value[:300] for value in proposal.conflicts),
        reason=proposal.reasoning_summary[:1000],
        model=model,
        provider="ollama",
        model_confidence=proposal.confidence,
        latency_ms=latency_ms,
        hallucinated_source=hallucinated_source,
        field_evidence=tuple(
            AIFieldEvidence(
                field_name=name,
                value=tuple(field.value) if isinstance(field.value, list) else field.value,
                confidence=field.confidence,
                source_urls=tuple(field.sources),
            )
            for name, field in proposal.fields.items()
        ),
        analysis_status=proposal.status,
        recommended_action=proposal.recommended_action,
    )
