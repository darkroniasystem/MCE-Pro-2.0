"""Contrato de navegación web excepcional, independiente de Playwright."""

from __future__ import annotations

import base64
import re
import unicodedata
from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol
from urllib.parse import parse_qs, unquote, urlparse

from mce.application.identification.service import (
    ProviderConfigurationError,
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderTimeoutError,
)
from mce.application.web_search import WebSearchEvidence, utc_now
from mce.infrastructure.metadata.web_search import (
    _compact_text,
    _infer_type,
    _infer_year,
    _safe_url,
    _source,
)


class BrowserSearchStatus(StrEnum):
    SUCCESS = "success"
    PARTIAL = "partial"
    NO_EVIDENCE = "no_evidence"
    BLOCKED = "blocked"
    CAPTCHA = "captcha"
    RATE_LIMITED = "rate_limited"
    TIMEOUT = "timeout"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True, slots=True)
class BrowserSearchSettings:
    enabled: bool = False
    headless: bool = True
    timeout_seconds: float = 20.0
    max_concurrency: int = 1
    delay_min_ms: int = 1_000
    delay_max_ms: int = 2_500
    max_results: int = 5
    max_page_text_chars: int = 12_000

    def __post_init__(self) -> None:
        if self.timeout_seconds <= 0:
            raise ValueError("browser timeout must be positive")
        if min(self.max_concurrency, self.max_results, self.max_page_text_chars) < 1:
            raise ValueError("browser limits must be positive")
        if self.delay_min_ms < 0 or self.delay_max_ms < self.delay_min_ms:
            raise ValueError("browser delay range is invalid")


@dataclass(frozen=True, slots=True)
class BrowserSearchHit:
    title: str
    source_url: str
    snippet: str = ""
    year: int | None = None
    media_type: str | None = None
    score: float = 75.0


@dataclass(frozen=True, slots=True)
class BrowserSearchResponse:
    status: BrowserSearchStatus
    hits: tuple[BrowserSearchHit, ...] = ()
    message: str = ""


class BrowserAutomationBackend(Protocol):
    def search(
        self,
        query: str,
        *,
        limit: int,
        settings: BrowserSearchSettings,
    ) -> BrowserSearchResponse: ...


class UnavailableBrowserAutomationBackend:
    """Marcador seguro hasta que la Fase H compruebe Playwright y Chromium."""

    def __init__(self, reason: str) -> None:
        self.reason = reason

    def search(
        self,
        query: str,
        *,
        limit: int,
        settings: BrowserSearchSettings,
    ) -> BrowserSearchResponse:
        return BrowserSearchResponse(BrowserSearchStatus.UNAVAILABLE, message=self.reason)


class BrowserSearchProvider:
    """Convierte una extracción DOM inyectada en evidencia web de MCE."""

    name = "web:browser"

    def __init__(
        self,
        backend: BrowserAutomationBackend,
        settings: BrowserSearchSettings,
    ) -> None:
        self.backend = backend
        self.settings = settings
        self.timeout = settings.timeout_seconds
        self.last_from_cache = False
        self.last_status: BrowserSearchStatus | None = None
        self.last_message = ""

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        if not self.settings.enabled:
            raise ProviderConfigurationError("Browser: proveedor deshabilitado")
        effective_limit = min(max(1, limit), self.settings.max_results)
        response = self.backend.search(
            query,
            limit=effective_limit,
            settings=self.settings,
        )
        self.last_status = response.status
        self.last_message = response.message
        if response.status is BrowserSearchStatus.UNAVAILABLE:
            raise ProviderConfigurationError(
                response.message or "Browser: entorno no disponible"
            )
        if response.status is BrowserSearchStatus.TIMEOUT:
            raise ProviderTimeoutError(response.message or "Browser: tiempo agotado")
        if response.status is BrowserSearchStatus.RATE_LIMITED:
            raise ProviderRateLimitError(response.message or "Browser: frecuencia limitada")
        if response.status in {BrowserSearchStatus.BLOCKED, BrowserSearchStatus.CAPTCHA}:
            raise ProviderOfflineError(
                response.message or f"Browser: {response.status.value} detectado"
            )
        if response.status is BrowserSearchStatus.NO_EVIDENCE:
            return ()

        now = utc_now()
        evidence: list[WebSearchEvidence] = []
        for hit in response.hits[:effective_limit]:
            title = " ".join(hit.title.split())
            description = _compact_text(
                hit.snippet,
                max_characters=self.settings.max_page_text_chars,
            )
            if not title or not _browser_hit_is_relevant(query, title, description):
                continue
            url = _unwrap_browser_url(hit.source_url.strip())
            if not _safe_url(url):
                continue
            context = f"{title} {description} {hit.year or ''}"
            evidence.append(
                WebSearchEvidence(
                    source=_source(url),
                    title=title,
                    media_type=hit.media_type or _infer_type(context),
                    year=hit.year or _infer_year(context),
                    description=description,
                    source_url=url,
                    score=max(0.0, min(100.0, float(hit.score))),
                    collected_at=now,
                    query=query,
                    provider="browser_search",
                )
            )
        if response.hits and not evidence:
            self.last_status = BrowserSearchStatus.NO_EVIDENCE
            self.last_message = "Browser: evidencia no relacionada descartada"
        return tuple(evidence)


_GENERIC_QUERY_TERMS = {
    "and",
    "anime",
    "animado",
    "animated",
    "cast",
    "coreana",
    "coreano",
    "creator",
    "director",
    "del",
    "the",
    "dorama",
    "drama",
    "elenco",
    "las",
    "los",
    "episode",
    "episodio",
    "film",
    "japanese",
    "korean",
    "movie",
    "para",
    "novela",
    "reparto",
    "season",
    "serie",
    "series",
    "television",
}


def _normalized_tokens(value: str) -> tuple[str, ...]:
    folded = unicodedata.normalize("NFKD", value.casefold())
    ascii_text = "".join(
        character for character in folded if not unicodedata.combining(character)
    )
    return tuple(re.findall(r"[a-z0-9]+", ascii_text))


def _browser_hit_is_relevant(query: str, title: str, description: str) -> bool:
    query_terms = {
        token
        for token in _normalized_tokens(query)
        if len(token) >= 3 and not token.isdigit() and token not in _GENERIC_QUERY_TERMS
    }
    if not query_terms:
        return False
    evidence_terms = set(_normalized_tokens(f"{title} {description}"))
    minimum_matches = 2 if len(query_terms) >= 3 else 1
    return len(query_terms & evidence_terms) >= minimum_matches


def _unwrap_browser_url(value: str) -> str:
    parsed = urlparse(value)
    host = (parsed.hostname or "").casefold()
    if host != "bing.com" and not host.endswith(".bing.com"):
        return value
    encoded = parse_qs(parsed.query).get("u", [""])[0]
    if not encoded:
        return value
    decoded_directly = unquote(encoded)
    if _safe_url(decoded_directly):
        return decoded_directly
    if not encoded.startswith("a1"):
        return value
    payload = encoded[2:]
    try:
        payload += "=" * (-len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload).decode("utf-8")
    except (ValueError, UnicodeDecodeError):
        return value
    return decoded if _safe_url(decoded) else value


__all__ = [
    "BrowserAutomationBackend",
    "BrowserSearchHit",
    "BrowserSearchProvider",
    "BrowserSearchResponse",
    "BrowserSearchSettings",
    "BrowserSearchStatus",
    "UnavailableBrowserAutomationBackend",
]
