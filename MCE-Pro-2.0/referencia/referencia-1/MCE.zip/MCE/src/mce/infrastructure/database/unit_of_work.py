"""Unidad de trabajo transaccional."""

from types import TracebackType
from typing import Self

from sqlalchemy.orm import Session, sessionmaker

from mce.infrastructure.database.repositories import (
    AuditEventRepository,
    BankRepository,
    CatalogLayerRepository,
    MetadataCatalogRepository,
    ScanImportRepository,
)


class SqlAlchemyUnitOfWork:
    """Confirma todo o revierte todo al salir del contexto."""

    def __init__(self, factory: sessionmaker[Session]):
        self._factory = factory
        self.session: Session | None = None

    def __enter__(self) -> Self:
        self.session = self._factory()
        self.banks = BankRepository(self.session)
        self.catalog_layers = CatalogLayerRepository(self.session)
        self.audit_events = AuditEventRepository(self.session)
        self.scan_imports = ScanImportRepository(self.session)
        self.metadata_catalog = MetadataCatalogRepository(self.session)
        return self

    def commit(self) -> None:
        if self.session is None:
            raise RuntimeError("unit of work is not active")
        self.session.commit()

    def rollback(self) -> None:
        if self.session is not None:
            self.session.rollback()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if self.session is not None:
            if exc_type is not None:
                self.session.rollback()
            self.session.close()
