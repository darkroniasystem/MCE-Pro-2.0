"""Validación estricta de respuestas de la Action API."""

from __future__ import annotations

from typing import Any, cast

from mce.application.identification.service import ProviderResponseError


class WikidataResponseParser:
    @staticmethod
    def search_ids(payload: object) -> tuple[str, ...]:
        if not isinstance(payload, dict) or "error" in payload:
            raise ProviderResponseError("Wikidata: respuesta de búsqueda inválida")
        rows = payload.get("search")
        if not isinstance(rows, list):
            raise ProviderResponseError("Wikidata: respuesta de búsqueda incompleta")
        result: list[str] = []
        for row in rows:
            if not isinstance(row, dict):
                raise ProviderResponseError("Wikidata: candidato inválido")
            qid = row.get("id")
            if isinstance(qid, str) and qid.startswith("Q") and qid[1:].isdigit():
                result.append(qid)
        return tuple(dict.fromkeys(result))

    @staticmethod
    def entities(payload: object) -> tuple[dict[str, Any], ...]:
        if not isinstance(payload, dict) or "error" in payload:
            raise ProviderResponseError("Wikidata: respuesta de entidades inválida")
        raw = payload.get("entities")
        if not isinstance(raw, dict):
            raise ProviderResponseError("Wikidata: respuesta de entidades incompleta")
        rows: list[dict[str, Any]] = []
        for qid, entity in raw.items():
            if (
                isinstance(qid, str)
                and qid.startswith("Q")
                and isinstance(entity, dict)
                and "missing" not in entity
            ):
                rows.append(cast(dict[str, Any], entity))
        return tuple(rows)
