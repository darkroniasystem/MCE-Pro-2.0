"""Archivo inmutable y direccionado por contenido para JSON originales."""

from __future__ import annotations

import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4


@dataclass(frozen=True, slots=True)
class ArchivedOriginal:
    file_hash: str
    storage_reference: str
    size_bytes: int


class OriginalJsonArchive:
    """Copia bytes sin transformarlos, verifica SHA-256 y publica atómicamente."""

    def __init__(self, root: Path) -> None:
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def preserve(self, source: Path, expected_hash: str) -> ArchivedOriginal:
        source = source.resolve()
        if source.is_symlink() or not source.is_file():
            raise ValueError("the original JSON must be a regular file")
        if len(expected_hash) != 64 or any(c not in "0123456789abcdef" for c in expected_hash):
            raise ValueError("expected_hash must be a lowercase SHA-256 digest")
        directory = self.root / expected_hash[:2]
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / f"{expected_hash}.json"
        if target.exists():
            return self._verify_existing(target, expected_hash)
        temporary = directory / f".{expected_hash}.{uuid4().hex}.part"
        digest = hashlib.sha256()
        size = 0
        try:
            with source.open("rb") as reader, temporary.open("xb") as writer:
                for chunk in iter(lambda: reader.read(1024 * 1024), b""):
                    writer.write(chunk)
                    digest.update(chunk)
                    size += len(chunk)
                writer.flush()
                os.fsync(writer.fileno())
            if digest.hexdigest() != expected_hash:
                raise ValueError("the selected JSON changed after validation")
            os.replace(temporary, target)
            target.chmod(stat.S_IREAD)
            return ArchivedOriginal(expected_hash, str(target), size)
        finally:
            temporary.unlink(missing_ok=True)

    @staticmethod
    def _verify_existing(target: Path, expected_hash: str) -> ArchivedOriginal:
        digest = hashlib.sha256()
        size = 0
        with target.open("rb") as reader:
            for chunk in iter(lambda: reader.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
        if digest.hexdigest() != expected_hash:
            raise ValueError("archived original failed integrity verification")
        return ArchivedOriginal(expected_hash, str(target), size)
