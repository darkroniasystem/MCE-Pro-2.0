"""Asistencia segura para pg_dump y pg_restore."""

from __future__ import annotations

import os
import shutil
import subprocess
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy.engine import URL, make_url

Runner = Callable[..., subprocess.CompletedProcess[str]]


@dataclass(frozen=True, slots=True)
class BackupResult:
    operation: str
    success: bool
    path: Path
    database: str
    message: str


class PostgresBackupService:
    """Invoca herramientas oficiales sin shell ni credenciales en argumentos."""

    def __init__(self, runner: Runner = subprocess.run):
        self._runner = runner

    def create(self, raw_url: str, destination: Path) -> BackupResult:
        url = self._validated_url(raw_url)
        if destination.is_symlink():
            raise ValueError("backup destination must not be a symbolic link")
        target = destination.resolve()
        if target.suffix.casefold() != ".dump":
            raise ValueError("backup destination must end with .dump")
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(".dump.tmp")
        command = [
            self._tool("pg_dump"),
            "--format=custom",
            "--file",
            str(temporary),
            *self._connection_arguments(url),
        ]
        result = self._run(command, url)
        if result.returncode != 0 or not temporary.is_file() or temporary.stat().st_size == 0:
            temporary.unlink(missing_ok=True)
            return BackupResult("backup", False, target, str(url.database), "pg_dump falló")
        temporary.replace(target)
        return BackupResult("backup", True, target, str(url.database), "copia creada")

    def validate(self, backup: Path) -> BackupResult:
        if backup.is_symlink():
            raise ValueError("backup must not be a symbolic link")
        source = backup.resolve()
        if not source.is_file() or source.stat().st_size == 0:
            return BackupResult("validate", False, source, "", "copia inexistente o vacía")
        result = self._runner(
            [self._tool("pg_restore"), "--list", str(source)],
            check=False,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return BackupResult(
            "validate",
            result.returncode == 0,
            source,
            "",
            "copia válida" if result.returncode == 0 else "pg_restore rechazó la copia",
        )

    def restore(self, raw_url: str, backup: Path, *, allow_master: bool = False) -> BackupResult:
        url = self._validated_url(raw_url, restore=True, allow_master=allow_master)
        if backup.is_symlink():
            raise ValueError("backup must not be a symbolic link")
        source = backup.resolve()
        validated = self.validate(source)
        if not validated.success:
            return BackupResult("restore", False, source, str(url.database), validated.message)
        command = [
            self._tool("pg_restore"),
            "--exit-on-error",
            "--clean",
            "--if-exists",
            "--no-owner",
            *self._connection_arguments(url),
            str(source),
        ]
        result = self._run(command, url)
        return BackupResult(
            "restore",
            result.returncode == 0,
            source,
            str(url.database),
            "restauración completada" if result.returncode == 0 else "pg_restore falló",
        )

    def restore_safely(
        self,
        raw_url: str,
        backup: Path,
        restore_point: Path,
        *,
        allow_master: bool = False,
    ) -> BackupResult:
        """Crea y valida un punto de restauración antes de limpiar el destino."""
        source = backup.resolve()
        safety = restore_point.resolve()
        if source == safety:
            raise ValueError("restore point must differ from backup source")
        created = self.create(raw_url, safety)
        if not created.success:
            return BackupResult(
                "restore",
                False,
                source,
                created.database,
                "no se creó el punto de restauración; destino intacto",
            )
        validated = self.validate(safety)
        if not validated.success:
            safety.unlink(missing_ok=True)
            return BackupResult(
                "restore",
                False,
                source,
                created.database,
                "punto de restauración inválido; destino intacto",
            )
        return self.restore(raw_url, source, allow_master=allow_master)

    def _run(self, command: Sequence[str], url: URL) -> subprocess.CompletedProcess[str]:
        environment = os.environ.copy()
        if url.password:
            environment["PGPASSWORD"] = url.password
        return self._runner(
            list(command),
            check=False,
            capture_output=True,
            text=True,
            timeout=3600,
            env=environment,
        )

    @staticmethod
    def _validated_url(raw_url: str, *, restore: bool = False, allow_master: bool = False) -> URL:
        url = make_url(raw_url)
        if url.get_backend_name() != "postgresql" or not url.database:
            raise ValueError("PostgreSQL URL required")
        if restore and url.database not in {"mce_test", "mce"}:
            raise ValueError("restore destination must be mce_test or mce")
        if restore and url.database == "mce" and not allow_master:
            raise ValueError("master restore requires explicit authorization")
        return url

    @staticmethod
    def _connection_arguments(url: URL) -> list[str]:
        values = ["--dbname", str(url.database)]
        if url.host:
            values.extend(("--host", url.host))
        if url.port:
            values.extend(("--port", str(url.port)))
        if url.username:
            values.extend(("--username", url.username))
        return values

    @staticmethod
    def _tool(name: str) -> str:
        configured = os.environ.get("MCE_POSTGRES_BIN", "").strip()
        if configured:
            candidate = Path(configured).expanduser().resolve() / f"{name}.exe"
            if candidate.is_file():
                return str(candidate)
        discovered = shutil.which(name)
        if discovered:
            return discovered
        program_files = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        roots = sorted(
            (program_files / "PostgreSQL").glob("*/bin"),
            key=lambda path: path.parent.name,
            reverse=True,
        )
        for root in roots:
            candidate = root / f"{name}.exe"
            if candidate.is_file():
                return str(candidate)
        return name
