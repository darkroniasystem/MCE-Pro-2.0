"""Repositorios SQLAlchemy con mapeo explícito."""

from datetime import UTC, datetime
from typing import Any
from uuid import NAMESPACE_URL, uuid4, uuid5

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from mce.application.identification.models import ProviderCandidate
from mce.application.identification.title_search import normalize_search_title
from mce.application.operations import AuditEvent
from mce.domain.entities import Bank
from mce.domain.value_objects import BankId, LifecycleStatus
from mce.domain.value_objects.states import CatalogStage
from mce.infrastructure.database.models import (
    AuditEventModel,
    AvailabilityModel,
    BankModel,
    CanonicalWorkModel,
    ContentAliasModel,
    ContentModel,
    ExternalIdentifierModel,
    NormalizedMetadataModel,
    PhysicalFileModel,
    ScanImportModel,
)


class BankScopedCatalogRepository:
    """Expone rutas y disponibilidad solo con un banco explícito."""

    def __init__(self, session: Session):
        self._session = session

    @staticmethod
    def _required_bank(bank_id: str) -> str:
        value = bank_id.strip()
        if not value:
            raise ValueError("bank_id is required for inventory queries")
        return value

    def paths_for_content(self, content_id: str, *, bank_id: str) -> tuple[str, ...]:
        scope = self._required_bank(bank_id)
        return tuple(
            self._session.scalars(
                select(PhysicalFileModel.original_path)
                .where(
                    PhysicalFileModel.content_id == content_id,
                    PhysicalFileModel.bank_id == scope,
                )
                .order_by(PhysicalFileModel.normalized_path)
            )
        )

    def availability_for_content(
        self, content_id: str, *, bank_id: str
    ) -> AvailabilityModel | None:
        scope = self._required_bank(bank_id)
        return self._session.scalar(
            select(AvailabilityModel).where(
                AvailabilityModel.content_id == content_id,
                AvailabilityModel.bank_id == scope,
            )
        )


class CatalogLayerRepository:
    """Lecturas que nunca mezclan staging, aprobado y publicado."""

    def __init__(self, session: Session):
        self._session = session

    def list_stage(self, stage: CatalogStage) -> tuple[ContentModel, ...]:
        return tuple(
            self._session.scalars(
                select(ContentModel)
                .where(ContentModel.catalog_stage == stage.value)
                .order_by(ContentModel.main_title, ContentModel.id)
            )
        )

    def staging(self) -> tuple[ContentModel, ...]:
        return self.list_stage(CatalogStage.STAGING)

    def approved(self) -> tuple[ContentModel, ...]:
        return self.list_stage(CatalogStage.APPROVED)

    def published(self) -> tuple[ContentModel, ...]:
        """Fuente exclusiva para consumidores futuros; inicialmente estará vacía."""
        return self.list_stage(CatalogStage.PUBLISHED)


class AuditEventRepository:
    """Registro append-only de operaciones observables."""

    def __init__(self, session: Session):
        self._session = session

    def add(self, event: AuditEvent) -> None:
        self._session.add(
            AuditEventModel(
                id=event.event_id,
                occurred_at=event.occurred_at,
                actor=event.actor,
                action=event.action,
                object_type=event.object_type,
                object_id=event.object_id,
                previous_value=event.previous_value,
                new_value=event.new_value,
                correlation_id=event.correlation_id,
                reversible=event.reversible,
                reversed_by=event.reversed_by,
            )
        )

    def get(self, event_id: str) -> AuditEvent | None:
        row = self._session.get(AuditEventModel, event_id)
        return None if row is None else self._to_application(row)

    def list_page(self, *, offset: int = 0, limit: int = 100) -> tuple[AuditEvent, ...]:
        rows = self._session.scalars(
            select(AuditEventModel)
            .order_by(AuditEventModel.occurred_at.desc(), AuditEventModel.id)
            .offset(offset)
            .limit(limit)
        )
        return tuple(self._to_application(row) for row in rows)

    @staticmethod
    def _to_application(row: AuditEventModel) -> AuditEvent:
        occurred_at = (
            row.occurred_at.replace(tzinfo=UTC)
            if row.occurred_at.tzinfo is None
            else row.occurred_at.astimezone(UTC)
        )
        return AuditEvent(
            row.id,
            occurred_at,
            row.actor,
            row.action,
            row.object_type,
            row.object_id,
            row.previous_value,
            row.new_value,
            row.correlation_id,
            row.reversible,
            row.reversed_by,
        )


class BankRepository:
    """Persistencia de bancos sin filtrar ORM al dominio."""

    def __init__(self, session: Session):
        self._session = session

    def add(self, entity: Bank) -> None:
        self._session.add(
            BankModel(
                id=str(entity.bank_id),
                external_bank_id=None,
                name=entity.name,
                code=entity.code,
                branch=entity.branch,
                status=entity.status.value,
                created_at=entity.created_at,
            )
        )

    def resolve_external(
        self,
        external_bank_id: str,
        *,
        name: str,
        created_at: datetime,
    ) -> BankId:
        """Resuelve concurrentemente una identidad externa a un UUID interno estable."""
        normalized = external_bank_id.strip()
        if not normalized:
            raise ValueError("external_bank_id must not be empty")
        try:
            internal = BankId(normalized)
        except ValueError:
            internal = BankId(str(uuid5(NAMESPACE_URL, f"mce:msl-bank:{normalized}")))
        statement = (
            insert(BankModel)
            .values(
                id=str(internal),
                external_bank_id=normalized,
                name=name.strip() or f"Banco {normalized}",
                code=None,
                branch=None,
                status="active",
                created_at=created_at,
            )
            .on_conflict_do_nothing(index_elements=[BankModel.external_bank_id])
        )
        self._session.execute(statement)
        stored = self._session.scalar(
            select(BankModel.id).where(BankModel.external_bank_id == normalized)
        )
        if stored is None:
            raise RuntimeError("external bank identity could not be resolved")
        return BankId(stored)

    def get(self, identifier: BankId) -> Bank | None:
        row = self._session.get(BankModel, str(identifier))
        return None if row is None else self._to_domain(row)

    def list_page(self, *, offset: int = 0, limit: int = 100) -> tuple[Bank, ...]:
        rows = self._session.scalars(
            select(BankModel).order_by(BankModel.name).offset(offset).limit(limit)
        )
        return tuple(self._to_domain(row) for row in rows)

    @staticmethod
    def _to_domain(row: BankModel) -> Bank:
        created = (
            row.created_at.replace(tzinfo=UTC)
            if row.created_at.tzinfo is None
            else row.created_at.astimezone(UTC)
        )
        return Bank(
            BankId(row.id), row.name, created, LifecycleStatus(row.status), row.code, row.branch
        )


class JsonRepository:
    """Operaciones mínimas para agregados cuyo dominio se completará después."""

    def __init__(self, session: Session, model: type[Any]) -> None:
        self._session = session
        self._model = model

    def add(self, identifier: str, payload: dict[str, Any]) -> None:
        self._session.add(self._model(id=identifier, payload=payload))

    def get(self, identifier: str) -> Any | None:
        return self._session.get(self._model, identifier)


class ScanImportRepository:
    """Consultas de importaciones siempre aislables por banco."""

    def __init__(self, session: Session):
        self._session = session

    def add(self, model: ScanImportModel) -> None:
        """Agrega una importación preparada por el mapper de persistencia."""
        self._session.add(model)

    def get_for_bank(self, identifier: str, bank_id: str) -> ScanImportModel | None:
        """Nunca devuelve una importación perteneciente a otro banco."""
        statement = select(ScanImportModel).where(
            ScanImportModel.id == identifier, ScanImportModel.bank_id == bank_id
        )
        return self._session.scalar(statement)

    def find_by_hash(self, file_hash: str) -> ScanImportModel | None:
        """Busca duplicados mediante SHA-256 único."""
        return self._session.scalar(
            select(ScanImportModel).where(ScanImportModel.file_hash == file_hash)
        )

    def revert(self, identifier: str, bank_id: str, *, at: datetime) -> bool:
        """Revierte de forma controlada solo una importación completada del banco."""
        model = self.get_for_bank(identifier, bank_id)
        if model is None or model.status != "completed":
            return False
        model.status = "reverted"
        model.reverted_at = at
        return True


class MetadataCatalogRepository:
    """Persistencia idempotente, trazable y aislada por banco."""

    def __init__(self, session: Session):
        self._session = session

    def save_candidate(
        self,
        candidate: ProviderCandidate,
        *,
        bank_id: str | None,
        alias: str | None = None,
        raw_bank_title: str | None = None,
        confirmed_alias: bool = False,
        confidence: float | None = None,
    ) -> ContentModel:
        canonical = self._session.scalar(
            select(CanonicalWorkModel).where(
                CanonicalWorkModel.provider == candidate.provider,
                CanonicalWorkModel.content_type == candidate.kind.value,
                CanonicalWorkModel.external_id == candidate.external_id,
            )
        )
        now = datetime.now(UTC)
        if canonical is None:
            canonical = CanonicalWorkModel(
                id=str(
                    uuid5(
                        NAMESPACE_URL,
                        f"mce-canonical:{candidate.provider}:{candidate.kind.value}:{candidate.external_id}",
                    )
                ),
                provider=candidate.provider,
                content_type=candidate.kind.value,
                external_id=candidate.external_id,
                official_title=candidate.title,
                release_year=candidate.year,
                metadata_payload={},
                created_at=now,
                updated_at=now,
            )
            self._session.add(canonical)
        else:
            canonical.official_title = candidate.title
            canonical.release_year = candidate.year
            canonical.updated_at = now
        identity = f"{bank_id or 'global'}:{candidate.provider}:{candidate.external_id}"
        content_id = str(uuid5(NAMESPACE_URL, identity))
        content = self._session.get(ContentModel, content_id)
        if content is None:
            content = ContentModel(
                id=content_id,
                bank_id=bank_id,
                content_type=candidate.kind.value,
                main_title=candidate.title,
                original_title=candidate.original_title,
                raw_bank_title=raw_bank_title,
                clean_bank_title=alias,
                spanish_title=candidate.spanish_title,
                english_title=candidate.english_title,
                preferred_display_title=(
                    candidate.spanish_title or candidate.title or candidate.english_title
                ),
                normalized_search_text="",
                release_year=candidate.year,
                status="active",
                identification_status="identified",
                review_status="approved" if confirmed_alias else "not_required",
                catalog_stage=(
                    CatalogStage.APPROVED.value
                    if confirmed_alias
                    else CatalogStage.STAGING.value
                ),
                version=1,
            )
            self._session.add(content)
        else:
            content.main_title = candidate.title
            content.original_title = candidate.original_title
            content.raw_bank_title = raw_bank_title or content.raw_bank_title
            content.clean_bank_title = alias or content.clean_bank_title
            content.spanish_title = candidate.spanish_title
            content.english_title = candidate.english_title
            content.preferred_display_title = (
                candidate.spanish_title
                or content.preferred_display_title
                or candidate.title
                or candidate.english_title
            )
            content.release_year = candidate.year
            content.version += 1
        content.canonical_work_id = canonical.id
        self._session.flush()
        identifiers = dict(candidate.external_ids)
        identifiers.setdefault(candidate.provider, candidate.external_id)
        for identifier_type, external_id in identifiers.items():
            identifier_row = self._session.scalar(
                select(ExternalIdentifierModel).where(
                    ExternalIdentifierModel.content_id == content_id,
                    ExternalIdentifierModel.identifier_type == identifier_type,
                )
            )
            if identifier_row is None:
                self._session.add(
                    ExternalIdentifierModel(
                        id=str(uuid4()),
                        content_id=content_id,
                        provider=candidate.provider,
                        identifier_type=identifier_type,
                        external_id=external_id,
                        source_url=candidate.source_url,
                        created_at=datetime.now(UTC),
                    )
                )
            else:
                identifier_row.external_id = external_id
                identifier_row.source_url = candidate.source_url
        fields: dict[str, object | None] = {
            "overview": candidate.overview,
            "genres": candidate.genres,
            "languages": candidate.languages,
            "cast": candidate.cast_names or candidate.cast,
            "director": candidate.director,
            "creators": candidate.creators,
            "studios": candidate.studios,
            "networks": candidate.networks,
            "status": candidate.status,
            "duration_minutes": candidate.duration_minutes,
            "episode_count": candidate.episode_count,
            "season_count": candidate.season_count,
            "images": candidate.images,
            "ratings": candidate.ratings,
        }
        for field_name, value in fields.items():
            if value in (None, "", (), []):
                continue
            metadata_row = self._session.scalar(
                select(NormalizedMetadataModel).where(
                    NormalizedMetadataModel.content_id == content_id,
                    NormalizedMetadataModel.field_name == field_name,
                )
            )
            if metadata_row is None:
                self._session.add(
                    NormalizedMetadataModel(
                        id=str(uuid4()),
                        content_id=content_id,
                        field_name=field_name,
                        value=value,
                        provider=candidate.provider,
                        external_reference=candidate.external_id,
                        confidence=confidence,
                        obtained_at=datetime.now(UTC),
                        locked=False,
                    )
                )
            elif not metadata_row.locked:
                metadata_row.value = value
                metadata_row.provider = candidate.provider
                metadata_row.external_reference = candidate.external_id
                metadata_row.confidence = confidence
                metadata_row.obtained_at = datetime.now(UTC)
        aliases: list[tuple[str, str | None, str | None, str, str, bool]] = []
        for value, language, country, alias_type, provenance in (
            (candidate.title, None, None, "provider_title", candidate.provider),
            (
                candidate.original_title,
                None,
                candidate.country,
                "original",
                candidate.provider,
            ),
            (candidate.spanish_title, "es", None, "translated", candidate.provider),
            (candidate.english_title, "en", None, "translated", candidate.provider),
            *(
                (value, None, None, "alternative", candidate.provider)
                for value in (*candidate.translated_titles, *candidate.aliases)
            ),
            *(
                (
                    item.title,
                    item.language,
                    item.country,
                    item.alias_type,
                    item.provenance or candidate.provider,
                )
                for item in candidate.title_aliases
            ),
        ):
            if value and normalize_search_title(value):
                aliases.append((value, language, country, alias_type, provenance, False))
        if raw_bank_title:
            aliases.append((raw_bank_title, None, None, "raw_bank_title", "msl", False))
        if alias:
            aliases.append(
                (
                    alias,
                    None,
                    None,
                    "manual" if confirmed_alias else "clean_bank_title",
                    "manual" if confirmed_alias else "mce-local",
                    confirmed_alias,
                )
            )
        seen_aliases: set[tuple[str | None, str]] = set()
        for value, language, country, alias_type, provenance, confirmed in aliases:
            alias_bank_id = (
                bank_id if alias_type in {"raw_bank_title", "clean_bank_title", "manual"} else None
            )
            normalized = normalize_search_title(value)
            dedupe_key = (alias_bank_id, normalized)
            if dedupe_key in seen_aliases:
                continue
            seen_aliases.add(dedupe_key)
            existing = self._session.scalar(
                select(ContentAliasModel).where(
                    ContentAliasModel.content_id == content_id,
                    ContentAliasModel.bank_id == alias_bank_id,
                    ContentAliasModel.normalized_alias == normalized,
                )
            )
            if existing is None:
                self._session.add(
                    ContentAliasModel(
                        id=str(uuid4()),
                        content_id=content_id,
                        bank_id=alias_bank_id,
                        alias=value,
                        normalized_alias=normalized,
                        source=candidate.provider,
                        provider=("manual" if confirmed else candidate.provider),
                        provider_entity_id=(
                            candidate.external_id if candidate.provider == "wikidata" else None
                        ),
                        language=language,
                        country=country,
                        alias_type=alias_type,
                        provenance=provenance,
                        confirmed=confirmed,
                        is_manual=confirmed,
                        confidence=confidence,
                        created_at=datetime.now(UTC),
                    )
                )
            elif confirmed:
                existing.confirmed = True
                existing.source = "manual"
                existing.provider = "manual"
                existing.is_manual = True
        search_values = {
            normalize_search_title(value) for value, *_ in aliases if normalize_search_title(value)
        }
        content.normalized_search_text = " | ".join(sorted(search_values))
        return content

    def search_by_title(self, title: str, *, bank_id: str) -> tuple[ContentModel, ...]:
        """Busca en todos los títulos sin cruzar disponibilidades entre bancos."""
        normalized = normalize_search_title(title)
        if not normalized:
            return ()
        return tuple(
            self._session.scalars(
                select(ContentModel)
                .join(ContentAliasModel)
                .where(
                    ContentModel.bank_id == bank_id,
                    ContentAliasModel.normalized_alias == normalized,
                    (ContentAliasModel.bank_id == bank_id) | ContentAliasModel.bank_id.is_(None),
                )
                .distinct()
            )
        )

    def add_manual_alias(
        self,
        content_id: str,
        alias: str,
        *,
        bank_id: str | None,
        language: str | None = None,
        country: str | None = None,
    ) -> ContentAliasModel:
        """Añade un alias confirmado con alcance de banco o global explícito."""
        content = self._session.get(ContentModel, content_id)
        if content is None:
            raise KeyError(content_id)
        if bank_id is not None and content.bank_id != bank_id:
            raise ValueError("manual alias bank_id must match the content bank")
        normalized = normalize_search_title(alias)
        if not normalized:
            raise ValueError("manual alias must contain searchable characters")
        existing = self._session.scalar(
            select(ContentAliasModel).where(
                ContentAliasModel.content_id == content_id,
                ContentAliasModel.bank_id == bank_id,
                ContentAliasModel.normalized_alias == normalized,
            )
        )
        if existing is not None:
            existing.confirmed = True
            return existing
        row = ContentAliasModel(
            id=str(uuid4()),
            content_id=content_id,
            bank_id=bank_id,
            alias=alias.strip(),
            normalized_alias=normalized,
            source="manual",
            language=language,
            country=country,
            alias_type="manual",
            provenance="desktop-user",
            confirmed=True,
            created_at=datetime.now(UTC),
        )
        self._session.add(row)
        return row

    def get_by_external_id(
        self, provider: str, external_id: str, *, bank_id: str
    ) -> ContentModel | None:
        return self._session.scalar(
            select(ContentModel)
            .join(ExternalIdentifierModel)
            .where(
                ContentModel.bank_id == bank_id,
                ExternalIdentifierModel.provider == provider,
                ExternalIdentifierModel.external_id == external_id,
            )
        )
