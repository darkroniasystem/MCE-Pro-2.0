"""Ledger PostgreSQL autoritativo para sesiones, trabajos y checkpoints."""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import fields
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any
from uuid import NAMESPACE_URL, uuid4, uuid5

from sqlalchemy import create_engine, insert, select, text
from sqlalchemy.orm import Session, sessionmaker

from mce.application.dto import ImportResult, ProcessingSession
from mce.application.dto.session_models import (
    ProcessingStage,
    SessionItem,
    SessionItemStatus,
    SessionStatus,
)
from mce.application.exceptions import DuplicateSessionError
from mce.application.processing.selection import (
    enrichment_category,
    matches_enrichment_selection,
)
from mce.application.reconciliation import ScopeMatcher
from mce.domain.value_objects import (
    ImportId,
    NormalizedPath,
    PhysicalFileId,
    ScanScope,
    ScanScopeType,
    SourceId,
)
from mce.domain.value_objects.identifiers import DomainId
from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.database.models import (
    AvailabilityEventModel,
    CatalogFileIdentityModel,
    ImportStagingDocumentModel,
    InstallationModel,
    OriginalJsonModel,
    PhysicalFileModel,
    ProcessingCheckpointModel,
    ProcessingJobModel,
    ProcessingSessionItemModel,
    ProcessingSessionModel,
    ScanImportModel,
    ScanModel,
    SourceModel,
)
from mce.infrastructure.database.repositories import BankRepository
from mce.infrastructure.imports import OriginalJsonArchive

logger = logging.getLogger(__name__)


class PostgresSessionRepository:
    """Implementa SessionRepository sin conservar inventarios confirmados en RAM."""

    def __init__(
        self,
        factory: sessionmaker[Session],
        original_archive: OriginalJsonArchive | None = None,
    ) -> None:
        self._factory = factory
        self._original_archive = original_archive
        self._pending: dict[str, ProcessingSession] = {}

    @classmethod
    def from_runtime_environment(
        cls, originals_dir: Path | None = None
    ) -> PostgresSessionRepository | None:
        raw = runtime_database_url()
        if raw is None:
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        archive = OriginalJsonArchive(originals_dir) if originals_dir is not None else None
        return cls(sessionmaker(engine, expire_on_commit=False), archive)

    def seed(self, session: ProcessingSession, result: ImportResult) -> str:
        package = result.package
        if package is None:
            raise ValueError("a successful import package is required")
        bank_data = dict(package.scan.bank_data)
        external_bank_id = str(bank_data.get("bank_id") or "").strip()
        if not external_bank_id:
            raise ValueError("external bank identity is required")
        now = session.created_at
        job_id = str(uuid5(NAMESPACE_URL, f"mce:session-job:{session.session_id}"))
        source_path = Path(result.source_file)
        archived = (
            self._original_archive.preserve(source_path, package.original_file_hash)
            if self._original_archive is not None
            else None
        )
        original_size = archived.size_bytes if archived is not None else source_path.stat().st_size
        original_reference = (
            archived.storage_reference if archived is not None else str(source_path.resolve())
        )
        selected_source_path = str(source_path.resolve())
        with self._factory.begin() as database:
            bank_id = BankRepository(database).resolve_external(
                external_bank_id, name=session.bank_name or external_bank_id, created_at=now
            )
            database.flush()
            if str(bank_id) != str(package.domain_import.bank_id):
                raise ValueError("mapped bank identity disagrees with PostgreSQL")
            installation_data = dict(package.scan.installation_data)
            machine_identifier = str(installation_data.get("installation_id") or "").strip() or None
            installation = database.scalar(
                select(InstallationModel).where(
                    InstallationModel.bank_id == str(bank_id),
                    InstallationModel.machine_identifier == machine_identifier,
                )
            )
            installation_id = (
                installation.id
                if installation is not None
                else str(package.domain_scan.installation_id)
            )
            if installation is None:
                database.add(
                    InstallationModel(
                        id=installation_id,
                        bank_id=str(bank_id),
                        name=str(installation_data.get("name") or "Instalación MSL"),
                        machine_identifier=machine_identifier,
                        status="active",
                        created_at=now,
                    )
                )
                database.flush()
            source_ids: dict[str, str] = {}
            for source in package.domain_sources:
                existing_source = database.scalar(
                    select(SourceModel).where(
                        SourceModel.installation_id == installation_id,
                        SourceModel.normalized_root_path == source.root_path.normalized,
                    )
                )
                resolved_source_id = (
                    existing_source.id if existing_source is not None else str(source.source_id)
                )
                source_ids[str(source.source_id)] = resolved_source_id
                if existing_source is None:
                    database.add(
                        SourceModel(
                            id=resolved_source_id,
                            installation_id=installation_id,
                            source_type=source.source_type.value,
                            display_name=source.display_name,
                            root_path=source.root_path.original,
                            normalized_root_path=source.root_path.normalized,
                            status=source.status.value,
                        )
                    )
            database.flush()
            scan = package.domain_scan
            if database.get(ScanModel, str(scan.scan_id)) is not None:
                raise DuplicateSessionError("scan_id already imported")
            database.add(
                ScanModel(
                    id=str(scan.scan_id),
                    installation_id=installation_id,
                    started_at=scan.started_at,
                    finished_at=scan.finished_at,
                    scope_type=scan.scope.scope_type.value,
                    scope_data=_scope_payload(scan.scope),
                    status=scan.status.value,
                    msl_version=scan.msl_version,
                    schema_version=scan.schema_version,
                )
            )
            database.flush()
            if archived is not None:
                stored_original = database.get(OriginalJsonModel, archived.file_hash)
                if stored_original is None:
                    database.add(
                        OriginalJsonModel(
                            file_hash=archived.file_hash,
                            storage_reference=archived.storage_reference,
                            original_filename=package.original_filename,
                            size_bytes=archived.size_bytes,
                            schema_version=package.detected_schema_version,
                            status="verified",
                            created_at=now,
                            verified_at=now,
                        )
                    )
                elif (
                    stored_original.storage_reference != archived.storage_reference
                    or stored_original.size_bytes != archived.size_bytes
                ):
                    raise ValueError("archived original metadata disagrees with PostgreSQL")
            imported = package.domain_import
            database.add(
                ScanImportModel(
                    id=str(imported.import_id),
                    scan_id=str(scan.scan_id),
                    bank_id=str(bank_id),
                    original_filename=package.original_filename,
                    file_hash=package.original_file_hash,
                    received_at=imported.received_at,
                    status=imported.status.value,
                    is_duplicate=False,
                    errors=[
                        {"code": issue.code, "severity": issue.severity.value}
                        for issue in result.issues
                    ],
                )
            )
            database.flush()
            if archived is not None:
                database.add(
                    ImportStagingDocumentModel(
                        import_id=str(imported.import_id),
                        original_hash=archived.file_hash,
                        header={
                            "scan_id": package.scan.declared_scan_id,
                            "schema_version": package.detected_schema_version,
                            "generator_name": package.scan.generator_name,
                            "generator_version": package.scan.generator_version,
                            "started_at": package.scan.started_at_raw,
                            "finished_at": package.scan.finished_at_raw,
                            "bank": dict(package.scan.bank_data),
                            "installation": dict(package.scan.installation_data),
                        },
                        source_count=len(package.sources),
                        video_count=len(package.video_files),
                        subtitle_count=len(package.subtitle_files),
                        warning_count=result.statistics.warnings,
                        error_count=(result.statistics.errors + result.statistics.fatal_errors),
                        status="validated",
                        created_at=now,
                    )
                )
                database.flush()
            session_row = ProcessingSessionModel(
                id=session.session_id,
                workspace_id=session.workspace_id,
                import_id=str(session.import_id),
                package_hash=session.package_hash,
                scan_id=str(scan.scan_id),
                bank_id=str(bank_id),
                external_bank_id=external_bank_id,
                schema_version=package.detected_schema_version,
                msl_app_version=package.scan.generator_version,
                original_filename=package.original_filename,
                source_path=selected_source_path,
                original_size=original_size,
                original_reference=original_reference,
                scope_data=_scope_payload(session.scan_scope),
                status=session.status.value,
                failure_reason=session.failure_reason,
                retry_count=session.retry_count,
                created_at=session.created_at,
                updated_at=session.updated_at,
                completed_at=None,
                interrupted_at=None,
                recoverable=False,
                current_stage=ProcessingStage.IMPORTED.value,
                total_expected=len(session.items),
                processed_count=0,
                inserted_count=0,
                updated_count=0,
                duplicate_count=0,
                skipped_count=0,
                warning_count=result.statistics.warnings,
                error_count=result.statistics.errors + result.statistics.fatal_errors,
                version=1,
            )
            database.add(session_row)
            database.flush()
            database.add(
                ProcessingJobModel(
                    id=job_id,
                    session_id=session.session_id,
                    status="ready",
                    stage=ProcessingStage.IMPORTED.value,
                    progress=0,
                    payload={"storage": "processing_session_items", "format": 1},
                    job_type="import",
                    total=len(session.items),
                    processed=0,
                    succeeded=0,
                    failed=0,
                    skipped=0,
                    cache_hits=0,
                    current_checkpoint=None,
                    worker_owner=None,
                    started_at=None,
                    updated_at=now,
                    completed_at=None,
                    error_summary=None,
                )
            )
            database.flush()
            item_rows: list[dict[str, Any]] = []
            inserted_count = 0
            updated_count = 0
            duplicate_count = 0
            missing_count = 0
            reappeared_count = 0
            observed_identity_ids: set[str] = set()
            for ordinal, item in enumerate(session.items):
                resolved_source_id = source_ids[str(item.source_id)]
                normalized_path = NormalizedPath(item.original_path).normalized
                identity = database.scalar(
                    select(CatalogFileIdentityModel).where(
                        CatalogFileIdentityModel.bank_id == str(bank_id),
                        CatalogFileIdentityModel.source_id == resolved_source_id,
                        CatalogFileIdentityModel.normalized_path == normalized_path,
                    )
                )
                if identity is None:
                    identity_id = str(
                        uuid5(
                            NAMESPACE_URL,
                            f"mce:catalog-file:{bank_id}:{resolved_source_id}:{normalized_path}",
                        )
                    )
                    identity = CatalogFileIdentityModel(
                        id=identity_id,
                        bank_id=str(bank_id),
                        source_id=resolved_source_id,
                        normalized_path=normalized_path,
                        first_seen_scan_id=str(scan.scan_id),
                        last_seen_scan_id=str(scan.scan_id),
                        first_seen_at=now,
                        last_seen_at=now,
                        status="present",
                        missing_since_scan_id=None,
                        availability_checked_at=now,
                    )
                    database.add(identity)
                    historical = tuple(
                        database.scalars(
                            select(PhysicalFileModel).where(
                                PhysicalFileModel.bank_id == str(bank_id),
                                PhysicalFileModel.source_id == resolved_source_id,
                                PhysicalFileModel.normalized_path == normalized_path,
                                PhysicalFileModel.catalog_file_id.is_(None),
                            )
                        )
                    )
                    for observation in historical:
                        observation.catalog_file_id = identity_id
                    inserted_count += 1
                else:
                    if identity.status == "missing":
                        database.add(
                            AvailabilityEventModel(
                                id=str(
                                    uuid5(
                                        NAMESPACE_URL,
                                        f"mce:availability:{scan.scan_id}:{identity.id}:present",
                                    )
                                ),
                                catalog_file_id=identity.id,
                                scan_id=str(scan.scan_id),
                                previous_status="missing",
                                new_status="present",
                                reason="reappeared_in_scope",
                                created_at=now,
                            )
                        )
                        reappeared_count += 1
                    previous = database.scalar(
                        select(PhysicalFileModel).where(
                            PhysicalFileModel.catalog_file_id == identity.id,
                            PhysicalFileModel.scan_id == identity.last_seen_scan_id,
                        )
                    )
                    unchanged = previous is not None and (
                        previous.original_name
                        == (item.original_name or Path(item.original_path).name)
                        and previous.size_bytes == item.size_bytes
                        and previous.cryptographic_hash == item.file_hash
                    )
                    if unchanged:
                        duplicate_count += 1
                    else:
                        updated_count += 1
                    identity.last_seen_scan_id = str(scan.scan_id)
                    identity.last_seen_at = now
                    identity.status = "present"
                    identity.missing_since_scan_id = None
                    identity.availability_checked_at = now
                observed_identity_ids.add(identity.id)
                observation_id = str(
                    uuid5(
                        NAMESPACE_URL,
                        f"mce:file-observation:{scan.scan_id}:{resolved_source_id}:{normalized_path}",
                    )
                )
                database.add(
                    PhysicalFileModel(
                        id=observation_id,
                        bank_id=str(bank_id),
                        catalog_file_id=identity.id,
                        scan_id=str(scan.scan_id),
                        source_id=resolved_source_id,
                        original_name=item.original_name or Path(item.original_path).name,
                        relative_path=item.original_path,
                        original_path=item.original_path,
                        normalized_path=normalized_path,
                        extension=Path(item.original_path).suffix or ".unknown",
                        size_bytes=item.size_bytes,
                        cryptographic_hash=item.file_hash,
                        fingerprint_key=f"{resolved_source_id}:{normalized_path}:{item.size_bytes}",
                        status="present",
                        detected_category=item.detected_category,
                        category_confidence=item.category_confidence,
                        classification_status=item.classification_status,
                        clean_title=item.clean_title,
                        detected_year=item.detected_year,
                        season_number=item.season_number,
                        episode_number=item.episode_number,
                        cleaning_status=item.cleaning_status,
                        enrichment_status=item.enrichment_status,
                        final_confidence=item.final_confidence,
                        review_reason=item.review_reason,
                    )
                )
                item_state = _item_payload(item)
                item_state["source_id"] = resolved_source_id
                item_state["installation_id"] = installation_id
                item_state["physical_file_id"] = observation_id
                item_rows.append(
                    {
                        "id": item.item_id,
                        "session_id": session.session_id,
                        "physical_file_id": observation_id,
                        "ordinal": ordinal,
                        "state": item_state,
                        "updated_at": session.updated_at,
                    }
                )
                if len(item_rows) >= 500:
                    database.flush()
                    database.execute(insert(ProcessingSessionItemModel), item_rows)
                    item_rows.clear()
            if item_rows:
                database.flush()
                database.execute(insert(ProcessingSessionItemModel), item_rows)
            matcher = ScopeMatcher(
                scan.scope.scope_type,
                frozenset(
                    source_ids.get(str(source_id), str(source_id))
                    for source_id in scan.scope.source_ids
                ),
                tuple(path.normalized for path in scan.scope.included_paths),
            )
            installation_identities = tuple(
                database.scalars(
                    select(CatalogFileIdentityModel)
                    .join(
                        SourceModel,
                        SourceModel.id == CatalogFileIdentityModel.source_id,
                    )
                    .where(
                        CatalogFileIdentityModel.bank_id == str(bank_id),
                        SourceModel.installation_id == installation_id,
                    )
                )
            )
            for identity in installation_identities:
                if identity.id in observed_identity_ids:
                    continue
                if not matcher.covers(identity.source_id, identity.normalized_path):
                    continue
                identity.availability_checked_at = now
                if identity.status == "missing":
                    continue
                database.add(
                    AvailabilityEventModel(
                        id=str(
                            uuid5(
                                NAMESPACE_URL,
                                f"mce:availability:{scan.scan_id}:{identity.id}:missing",
                            )
                        ),
                        catalog_file_id=identity.id,
                        scan_id=str(scan.scan_id),
                        previous_status=identity.status,
                        new_status="missing",
                        reason=f"absent_from_{scan.scope.scope_type.value}_scope",
                        created_at=now,
                    )
                )
                identity.status = "missing"
                identity.missing_since_scan_id = str(scan.scan_id)
                missing_count += 1
            session_row.inserted_count = inserted_count
            session_row.updated_count = updated_count
            session_row.duplicate_count = duplicate_count
        self._pending.pop(session.session_id, None)
        if archived is not None:
            logger.info(
                "event=original_json_archived json_hash=%s size_bytes=%d status=verified",
                archived.file_hash,
                archived.size_bytes,
            )
            logger.info(
                "event=import_staging_created import_id=%s json_hash=%s "
                "sources=%d videos=%d subtitles=%d warnings=%d errors=%d",
                package.domain_import.import_id,
                archived.file_hash,
                len(package.sources),
                len(package.video_files),
                len(package.subtitle_files),
                result.statistics.warnings,
                result.statistics.errors + result.statistics.fatal_errors,
            )
        logger.info(
            "event=session_created session_id=%s job_id=%s scan_id=%s "
            "external_bank_id=%s internal_bank_uuid=%s json_hash=%s total=%d "
            "inserted=%d updated=%d unchanged=%d",
            session.session_id,
            job_id,
            package.scan.declared_scan_id or package.domain_scan.scan_id,
            external_bank_id,
            package.domain_import.bank_id,
            package.original_file_hash,
            len(session.items),
            inserted_count,
            updated_count,
            duplicate_count,
        )
        logger.info(
            "event=availability_reconciled scan_id=%s scope=%s missing=%d reappeared=%d",
            package.scan.declared_scan_id or package.domain_scan.scan_id,
            package.domain_scan.scope.scope_type.value,
            missing_count,
            reappeared_count,
        )
        return job_id

    def get(self, session_id: str) -> ProcessingSession | None:
        if session_id in self._pending:
            return self._pending[session_id]
        with self._factory() as database:
            row = database.get(ProcessingSessionModel, session_id)
            if row is None:
                return None
            items = tuple(
                _item_from_payload(value)
                for value in database.scalars(
                    select(ProcessingSessionItemModel.state)
                    .where(ProcessingSessionItemModel.session_id == session_id)
                    .order_by(ProcessingSessionItemModel.ordinal)
                    .execution_options(yield_per=500)
                )
            )
            return _session_from_rows(row, items)

    def find_by_package_hash(self, package_hash: str) -> ProcessingSession | None:
        pending = next(
            (value for value in self._pending.values() if value.package_hash == package_hash),
            None,
        )
        if pending is not None:
            return pending
        with self._factory() as database:
            identifier = database.scalar(
                select(ProcessingSessionModel.id).where(
                    ProcessingSessionModel.package_hash == package_hash
                )
            )
        return None if identifier is None else self.get(identifier)

    def list_ids(self) -> tuple[str, ...]:
        self.recover_interrupted()
        with self._factory() as database:
            return tuple(
                database.scalars(
                    select(ProcessingSessionModel.id)
                    .where(ProcessingSessionModel.status != SessionStatus.ARCHIVED.value)
                    .order_by(ProcessingSessionModel.created_at)
                )
            )

    def list_summaries(self) -> tuple[dict[str, object], ...]:
        # Es una consulta de refresco usada repetidamente por la interfaz. La
        # recuperación de trabajos abandonados pertenece exclusivamente al
        # arranque (list_ids); ejecutarla aquí marcaba como interrumpido el lote
        # que seguía vivo en el mismo proceso.
        with self._factory() as database:
            rows = database.execute(
                select(ProcessingSessionModel, ProcessingJobModel)
                .join(
                    ProcessingJobModel,
                    ProcessingJobModel.session_id == ProcessingSessionModel.id,
                )
                .where(ProcessingSessionModel.status != SessionStatus.ARCHIVED.value)
                .order_by(ProcessingSessionModel.created_at)
            )
            return tuple(
                {
                    "sesión": session.id,
                    "nombre": session.original_filename or "—",
                    "ubicación del JSON": session.source_path or "—",
                    "estado": session.status,
                    "progreso": (
                        "100.0 %"
                        if job.stage == ProcessingStage.CONSOLIDATED.value
                        else f"{job.progress:.1f} %"
                    ),
                    "etapa": (
                        "lista para enriquecimiento"
                        if job.stage == ProcessingStage.CONSOLIDATED.value
                        and session.status
                        in {SessionStatus.READY.value, SessionStatus.PAUSED.value}
                        else job.stage or ProcessingStage.IMPORTED.value
                    ),
                    "inciertos": session.uncertain_count,
                }
                for session, job in rows
            )

    def list_enrichment_summaries(self) -> tuple[dict[str, object], ...]:
        """Lee resúmenes pequeños sin escanear el inventario completo."""
        with self._factory() as database:
            sessions = database.execute(
                select(
                    ProcessingSessionModel.id,
                    ProcessingSessionModel.external_bank_id,
                    ProcessingSessionModel.enrichment_summary,
                    ProcessingSessionModel.status,
                )
                .join(
                    ProcessingJobModel,
                    ProcessingJobModel.session_id == ProcessingSessionModel.id,
                )
                .where(ProcessingSessionModel.status != SessionStatus.ARCHIVED.value)
                .order_by(ProcessingSessionModel.created_at)
            )
            rows: list[dict[str, object]] = []
            for session_id, bank, summary, session_status in sessions:
                for category, counts in sorted((summary or {}).items()):
                    rows.append(
                        {
                            "session_id": session_id,
                            "bank": bank,
                            "category": category,
                            "session_status": session_status,
                            **counts,
                        }
                    )
            return tuple(rows)

    def list_pending_review_rows(self) -> tuple[dict[str, object], ...]:
        """Restaura obras pendientes sin materializar sesiones completas."""
        statement = text(
            """
            WITH pending AS (
                SELECT i.session_id,
                       COALESCE(i.state->>'work_group_id', i.state->>'item_id') AS group_id,
                       i.ordinal,
                       i.state
                FROM processing_session_items i
                JOIN processing_sessions s ON s.id = i.session_id
                WHERE s.status <> 'archived'
                  AND i.state->>'enrichment_status' = 'needs_human_review'
                  AND i.state->>'stage' = 'reviewed'
            ), grouped AS (
                SELECT session_id, group_id,
                       array_agg(state->>'item_id' ORDER BY ordinal) AS item_ids,
                       count(*) AS file_count
                FROM pending
                GROUP BY session_id, group_id
            ), representative AS (
                SELECT DISTINCT ON (session_id, group_id)
                       session_id, group_id, state
                FROM pending
                ORDER BY session_id, group_id,
                         COALESCE((state->>'possible_extra')::boolean, false), ordinal
            )
            SELECT g.session_id, g.group_id, g.item_ids, g.file_count,
                   r.state, s.external_bank_id
            FROM grouped g
            JOIN representative r USING (session_id, group_id)
            JOIN processing_sessions s ON s.id = g.session_id
            ORDER BY s.created_at, g.group_id
            """
        )
        with self._factory() as database:
            rows = database.execute(statement).mappings()
            restored: list[dict[str, object]] = []
            for row in rows:
                state = dict(row["state"] or {})
                title = str(
                    state.get("human_title_correction")
                    or state.get("work_title")
                    or state.get("clean_title")
                    or state.get("original_name")
                    or ""
                )
                web_evidence = tuple(state.get("web_search_evidence") or ())
                restored.append(
                    {
                        "id": str(row["group_id"]),
                        "archivo": state.get("original_name") or "—",
                        "grupo": state.get("work_title") or title,
                        "archivos agrupados": int(row["file_count"]),
                        "ruta": state.get("original_path") or "—",
                        "título candidato": title,
                        "tipo": state.get("detected_category") or "unclassified",
                        "confianza": round(float(state.get("category_confidence") or 0), 1),
                        "Coincidencia": (
                            "Evidencia web disponible" if web_evidence else "Sin coincidencias"
                        ),
                        "identificación": state.get("review_reason") or "needs_human_review",
                        "estado de identidad": (
                            "evidencia web encontrada; identificación pendiente"
                            if web_evidence
                            else "sin identificación externa"
                        ),
                        "aprobación resultante": "identificación manual incompleta",
                        "consulta usada": state.get("web_search_query") or title,
                        "año pista": state.get("detected_year"),
                        "evidencia web": " | ".join(str(value) for value in web_evidence) or "—",
                        "candidatos externos": "sin coincidencias",
                        "proveedor candidato": "—",
                        "puntuación externa": state.get("identification_confidence"),
                        "banco": row["external_bank_id"] or state.get("bank_id") or "—",
                        "_session_id": str(row["session_id"]),
                        "_candidate": None,
                        "_ai_review_state": state.get("ai_review_state"),
                        "_ai_score": state.get("ai_mce_score"),
                        "_ai_sources": tuple(state.get("ai_sources") or ()),
                        "_ai_contradictions": tuple(state.get("ai_contradictions") or ()),
                        "_candidate_approvable": False,
                        "_item_ids": list(row["item_ids"] or ()),
                        "_physical_file_id": state.get("physical_file_id") or "",
                        "_source_id": state.get("source_id") or "",
                        "_installation_id": state.get("installation_id") or "",
                        "_original_name": state.get("original_name") or "",
                        "_size_bytes": state.get("size_bytes"),
                        "_file_hash": state.get("file_hash") or "",
                    }
                )
            return tuple(restored)

    def catalog_completion_summary(self) -> dict[str, int]:
        """Cuenta estados por obra logica sin materializar archivos fisicos."""
        statement = text(
            """
            WITH logical_works AS (
                SELECT i.session_id,
                       COALESCE(i.state->>'work_group_id', i.state->>'item_id') AS group_id,
                       bool_or(i.state->>'enrichment_status' = 'enrichment_complete') AS approved,
                       bool_or(i.state->>'enrichment_status' = 'review_rejected') AS rejected,
                       bool_or(i.state->>'enrichment_status' = 'needs_human_review') AS review
                FROM processing_session_items i
                JOIN processing_sessions s ON s.id = i.session_id
                WHERE s.status <> 'archived'
                  AND i.state->>'detected_category' IN
                      ('movie', 'series', 'novela', 'dorama', 'anime',
                       'concurso', 'western_animation')
                GROUP BY i.session_id,
                         COALESCE(i.state->>'work_group_id', i.state->>'item_id')
            )
            SELECT count(*) AS total,
                   count(*) FILTER (WHERE approved OR rejected OR review) AS processed,
                   count(*) FILTER (WHERE approved OR rejected) AS resolved,
                   count(*) FILTER (WHERE review AND NOT approved AND NOT rejected) AS review
            FROM logical_works
            """
        )
        with self._factory() as database:
            row = database.execute(statement).mappings().one()
            return {key: int(row[key] or 0) for key in ("total", "processed", "resolved", "review")}

    def recover_interrupted(self) -> int:
        """Convierte trabajos activos de una ejecución anterior en pausados recuperables."""
        now = datetime.now(UTC)
        recovered = 0
        with self._factory.begin() as database:
            rows = tuple(
                database.scalars(
                    select(ProcessingSessionModel).where(
                        ProcessingSessionModel.status == SessionStatus.RUNNING.value
                    )
                )
            )
            for row in rows:
                row.status = SessionStatus.PAUSED.value
                row.interrupted_at = now
                row.updated_at = now
                row.recoverable = True
                job = database.scalar(
                    select(ProcessingJobModel).where(
                        ProcessingJobModel.session_id == row.id,
                        ProcessingJobModel.status == SessionStatus.RUNNING.value,
                    )
                )
                if job is not None:
                    checkpoint = (
                        database.get(ProcessingCheckpointModel, job.current_checkpoint)
                        if job.current_checkpoint is not None
                        else None
                    )
                    if job.current_checkpoint is not None and not self._valid_checkpoint(
                        checkpoint
                    ):
                        row.status = SessionStatus.FAILED.value
                        row.failure_reason = "checkpoint integrity verification failed"
                        row.recoverable = False
                        job.status = "checkpoint_invalid"
                        job.error_summary = row.failure_reason
                        job.updated_at = now
                        logger.error(
                            "event=checkpoint_invalid session_id=%s job_id=%s checkpoint_id=%s",
                            row.id,
                            job.id,
                            job.current_checkpoint,
                        )
                        continue
                    job.status = "interrupted"
                    job.updated_at = now
                recovered += 1
                logger.warning(
                    "event=job_interrupted session_id=%s job_id=%s recoverable=true",
                    row.id,
                    job.id if job else None,
                )
        return recovered

    @staticmethod
    def _valid_checkpoint(checkpoint: ProcessingCheckpointModel | None) -> bool:
        if checkpoint is None:
            return False
        payload = checkpoint.resume_data
        if not isinstance(payload, dict):
            return False
        if payload.get("processed") != checkpoint.processed_count:
            return False
        return hashlib.sha256(_canonical_payload(payload)).hexdigest() == checkpoint.checksum

    def save(self, session: ProcessingSession) -> None:
        with self._factory.begin() as database:
            row = database.get(ProcessingSessionModel, session.session_id)
            if row is None:
                self._pending[session.session_id] = session
                return
            row.status = session.status.value
            row.failure_reason = session.failure_reason
            row.retry_count = session.retry_count
            row.updated_at = session.updated_at
            row.current_stage = max(
                (item.stage for item in session.items),
                default=ProcessingStage.IMPORTED,
                key=lambda value: list(ProcessingStage).index(value),
            ).value
            row.processed_count = sum(
                item.status
                in {
                    SessionItemStatus.COMPLETED,
                    SessionItemStatus.WARNING,
                    SessionItemStatus.FAILED,
                    SessionItemStatus.SKIPPED,
                }
                for item in session.items
            )
            row.warning_count = sum(item.warning is not None for item in session.items)
            row.error_count = sum(item.error is not None for item in session.items)
            row.uncertain_count = sum(
                item.classification_status in {"classification_uncertain", "unclassified"}
                for item in session.items
            )
            row.enrichment_summary = _enrichment_summary(session.items)
            row.recoverable = session.status in {
                SessionStatus.RUNNING,
                SessionStatus.PAUSED,
                SessionStatus.FAILED,
            }
            job = database.scalar(
                select(ProcessingJobModel).where(
                    ProcessingJobModel.session_id == session.session_id
                )
            )
            if job is not None:
                job.status = session.status.value
                job.stage = row.current_stage
                if job.job_type == "enrichment":
                    selected = frozenset(job.payload.get("selected_categories", ()))
                    baseline = int(job.payload.get("baseline_processed", 0))
                    baseline_failed = int(job.payload.get("baseline_failed", 0))
                    baseline_cache = int(job.payload.get("baseline_cache_hits", 0))
                    eligible = tuple(
                        item
                        for item in session.items
                        if item.work_group_id is not None
                        and matches_enrichment_selection(item, selected)
                        and item.detected_category != "subtitle"
                    )
                    groups = {item.work_group_id or item.item_id for item in eligible}
                    pending = {
                        item.work_group_id or item.item_id
                        for item in eligible
                        if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
                    }
                    failed = {
                        item.work_group_id or item.item_id
                        for item in eligible
                        if item.status is SessionItemStatus.FAILED
                    }
                    job.processed = min(job.total, max(0, len(groups - pending) - baseline))
                    job.failed = min(job.processed, max(0, len(failed) - baseline_failed))
                    job.succeeded = max(0, job.processed - job.failed)
                    job.skipped = 0
                else:
                    job.processed = row.processed_count
                    job.succeeded = sum(
                        item.status in {SessionItemStatus.COMPLETED, SessionItemStatus.WARNING}
                        for item in session.items
                    )
                    job.failed = row.error_count
                    job.skipped = sum(
                        item.status is SessionItemStatus.SKIPPED for item in session.items
                    )
                cache_groups = {
                    item.work_group_id or item.item_id
                    for item in session.items
                    if item.metadata_from_cache
                }
                job.cache_hits = max(
                    0,
                    len(cache_groups) - (baseline_cache if job.job_type == "enrichment" else 0),
                )
                job.progress = 100 * job.processed / job.total if job.total else 100
                for start in range(0, len(session.items), 500):
                    batch = session.items[start : start + 500]
                    database.bulk_update_mappings(
                        ProcessingSessionItemModel,
                        [
                            {
                                "id": item.item_id,
                                "state": _item_payload(item),
                                "updated_at": session.updated_at,
                            }
                            for item in batch
                        ],
                    )
                job.updated_at = session.updated_at
                self._checkpoint(database, job, session)

    def configure_enrichment_job(
        self,
        session: ProcessingSession,
        selected_categories: frozenset[str] | None,
    ) -> None:
        """Congela total y categorías sin contar archivos físicos ni subtítulos."""
        selected = tuple(sorted(selected_categories or ()))
        total = len(
            {
                item.work_group_id or item.item_id
                for item in session.items
                if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
                and matches_enrichment_selection(item, selected)
            }
        )
        eligible_groups = {
            item.work_group_id or item.item_id
            for item in session.items
            if item.work_group_id is not None
            and matches_enrichment_selection(item, selected)
            and item.detected_category != "subtitle"
        }
        pending_groups = {
            item.work_group_id or item.item_id
            for item in session.items
            if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
            and matches_enrichment_selection(item, selected)
        }
        baseline_processed = len(eligible_groups - pending_groups)
        baseline_failed = len(
            {
                item.work_group_id or item.item_id
                for item in session.items
                if item.status is SessionItemStatus.FAILED
                and matches_enrichment_selection(item, selected)
            }
        )
        baseline_cache_hits = len(
            {
                item.work_group_id or item.item_id
                for item in session.items
                if item.metadata_from_cache and matches_enrichment_selection(item, selected)
            }
        )
        with self._factory.begin() as database:
            job = database.scalar(
                select(ProcessingJobModel).where(
                    ProcessingJobModel.session_id == session.session_id
                )
            )
            if job is None:
                raise KeyError(session.session_id)
            job.job_type = "enrichment"
            job.total = total
            job.processed = 0
            job.succeeded = 0
            job.failed = 0
            job.skipped = 0
            job.cache_hits = 0
            job.payload = {
                **(job.payload or {}),
                "selected_categories": list(selected),
                "baseline_processed": baseline_processed,
                "baseline_failed": baseline_failed,
                "baseline_cache_hits": baseline_cache_hits,
            }
            job.updated_at = session.updated_at

    def delete(self, session_id: str) -> None:
        self._pending.pop(session_id, None)
        with self._factory.begin() as database:
            row = database.get(ProcessingSessionModel, session_id)
            if row is not None:
                row.status = SessionStatus.ARCHIVED.value
                row.updated_at = datetime.now(UTC)

    def discard_pending(self, session_id: str) -> None:
        """Descarta exclusivamente una sesión provisional cuya transacción falló."""
        self._pending.pop(session_id, None)

    @staticmethod
    def _checkpoint(database: Session, job: ProcessingJobModel, session: ProcessingSession) -> None:
        batch = database.scalar(
            select(ProcessingCheckpointModel.batch_number)
            .where(ProcessingCheckpointModel.job_id == job.id)
            .order_by(ProcessingCheckpointModel.batch_number.desc())
            .limit(1)
        )
        last_completed = next(
            (
                item.item_id
                for item in reversed(session.items)
                if item.status in {SessionItemStatus.COMPLETED, SessionItemStatus.WARNING}
            ),
            None,
        )
        payload: dict[str, Any] = {
            "processed": job.processed,
            "stage": job.stage,
            "last_completed_item": last_completed,
        }
        encoded = _canonical_payload(payload)
        checkpoint = ProcessingCheckpointModel(
            id=str(uuid4()),
            job_id=job.id,
            stage=job.stage or ProcessingStage.IMPORTED.value,
            batch_number=(batch or 0) + 1,
            last_completed_item=last_completed,
            processed_count=job.processed,
            resume_data=payload,
            created_at=session.updated_at,
            checksum=hashlib.sha256(encoded).hexdigest(),
        )
        database.add(checkpoint)
        database.flush()
        job.current_checkpoint = checkpoint.id
        logger.info(
            "event=checkpoint_committed session_id=%s job_id=%s checkpoint_id=%s "
            "stage=%s batch=%d processed=%d",
            session.session_id,
            job.id,
            checkpoint.id,
            checkpoint.stage,
            checkpoint.batch_number,
            checkpoint.processed_count,
        )


class PostgresImportRegistry:
    """Índice de duplicados confirmado exclusivamente por scan_imports."""

    def __init__(self, factory: sessionmaker[Session]) -> None:
        self._factory = factory

    @classmethod
    def from_runtime_environment(cls) -> PostgresImportRegistry | None:
        raw = runtime_database_url()
        if raw is None:
            return None
        engine = create_engine(raw, pool_pre_ping=True)
        return cls(sessionmaker(engine, expire_on_commit=False))

    def contains_hash(self, file_hash: str) -> bool:
        with self._factory() as database:
            return (
                database.scalar(
                    select(ScanImportModel.id).where(ScanImportModel.file_hash == file_hash)
                )
                is not None
            )

    def add_hash(self, file_hash: str) -> None:
        # ImportService valida antes de que el usuario confirme "Crear sesión".
        # El hash solo se vuelve autoritativo cuando seed() inserta scan_imports.
        return None


def _enrichment_summary(items: tuple[SessionItem, ...]) -> dict[str, dict[str, int]]:
    counts: dict[str, dict[str, int]] = {}
    works: dict[str, set[str]] = {}
    for item in items:
        category = enrichment_category(item)
        bucket = counts.setdefault(
            category,
            {
                "total": 0,
                "works": 0,
                "ready": 0,
                "uncertain": 0,
                "completed": 0,
                "rejected": 0,
                "reviews": 0,
            },
        )
        bucket["total"] += 1
        works.setdefault(category, set()).add(item.work_group_id or item.item_id)
        if item.stage is ProcessingStage.READY_FOR_ENRICHMENT:
            bucket["ready"] += 1
        if item.classification_status in {"classification_uncertain", "unclassified"}:
            bucket["uncertain"] += 1
        if item.enrichment_status == "enrichment_complete":
            bucket["completed"] += 1
        elif item.enrichment_status == "review_rejected":
            bucket["rejected"] += 1
        elif item.enrichment_status == "needs_human_review":
            bucket["reviews"] += 1
    for category, group_ids in works.items():
        counts[category]["works"] = len(group_ids)
    return counts


def _canonical_payload(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _scope_payload(scope: ScanScope) -> dict[str, Any]:
    return {
        "type": scope.scope_type.value,
        "source_ids": [str(value) for value in scope.source_ids],
        "included_paths": [value.original for value in scope.included_paths],
    }


def _item_payload(item: SessionItem) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    for field in fields(item):
        value = getattr(item, field.name)
        if isinstance(value, DomainId):
            payload[field.name] = str(value)
        elif isinstance(value, Enum):
            payload[field.name] = value.value
        elif isinstance(value, datetime):
            payload[field.name] = value.isoformat()
        elif isinstance(value, tuple):
            payload[field.name] = list(value)
        else:
            payload[field.name] = value
    return payload


def _item_from_payload(payload: dict[str, Any]) -> SessionItem:
    data = dict(payload)
    data["import_id"] = ImportId(data["import_id"])
    data["source_id"] = SourceId(data["source_id"])
    data["physical_file_id"] = PhysicalFileId(data["physical_file_id"])
    data["stage"] = ProcessingStage(data["stage"])
    data["status"] = SessionItemStatus(data["status"])
    for name in (
        "matched_rules",
        "technical_tags",
        "language_hints",
        "providers_completed",
        "providers_pending",
        "providers_failed",
        "web_search_evidence",
        "classification_conflicts",
    ):
        data[name] = tuple(data.get(name, ()))
    data["metadata_from_cache"] = bool(data.get("metadata_from_cache", False))
    data["web_search_used"] = bool(data.get("web_search_used", False))
    data["web_search_from_cache"] = bool(data.get("web_search_from_cache", False))
    data["human_title_locked"] = bool(data.get("human_title_locked", False))
    for name in ("classified_at", "cleaned_at", "next_retry_at", "human_decision_at"):
        if data.get(name):
            data[name] = datetime.fromisoformat(data[name])
    return SessionItem(**data)


def _session_from_rows(
    row: ProcessingSessionModel, items: tuple[SessionItem, ...]
) -> ProcessingSession:
    scope = row.scope_data or {}
    return ProcessingSession(
        session_id=row.id,
        workspace_id=row.workspace_id,
        import_id=ImportId(row.import_id),
        package_hash=row.package_hash,
        scan_scope=ScanScope(
            ScanScopeType(scope.get("type", "partial")),
            tuple(SourceId(value) for value in scope.get("source_ids", ())),
            tuple(NormalizedPath(value) for value in scope.get("included_paths", ())),
        ),
        items=items,
        created_at=row.created_at.replace(tzinfo=row.created_at.tzinfo or UTC),
        updated_at=row.updated_at.replace(tzinfo=row.updated_at.tzinfo or UTC),
        status=SessionStatus(row.status),
        failure_reason=row.failure_reason,
        retry_count=row.retry_count,
        bank_name=None,
    )
