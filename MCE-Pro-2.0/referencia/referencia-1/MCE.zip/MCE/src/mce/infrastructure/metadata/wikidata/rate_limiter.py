"""Nombre específico para el limitador compartido usado por Wikidata."""

from mce.infrastructure.metadata.providers import RateLimitedMetadataProvider

WikidataRateLimiter = RateLimitedMetadataProvider

__all__ = ["WikidataRateLimiter"]
