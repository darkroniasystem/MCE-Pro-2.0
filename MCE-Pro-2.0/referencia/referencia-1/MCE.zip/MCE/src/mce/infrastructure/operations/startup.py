"""Verificación cerrada de integridad antes de habilitar escrituras."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import create_engine, inspect, text

from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.operations.health import HealthCheck, HealthService, migration_head
from mce.infrastructure.operations.maintenance import MaintenanceService
from mce.infrastructure.runtime.paths import RuntimePaths

CRITICAL_CHECKS = {"postgresql", "migrations", "tables", "integrity", "configuration"}
REQUIRED_TABLES = {
    "alembic_version",
    "availabilities",
    "banks",
    "catalog_publication_entries",
    "catalog_publications",
    "contents",
    "processing_checkpoints",
    "processing_jobs",
    "processing_sessions",
}


@dataclass(frozen=True, slots=True)
class StartupReport:
    checks: tuple[HealthCheck, ...]

    @property
    def safe_mode(self) -> bool:
        return any(
            check.name in CRITICAL_CHECKS and check.status == "error" for check in self.checks
        )

    @property
    def healthy(self) -> bool:
        return all(check.status != "error" for check in self.checks)


class StartupIntegrityService:
    """Comprueba servicios, esquema y datos sin modificar PostgreSQL."""

    def __init__(
        self,
        health: HealthService | None = None,
        maintenance: MaintenanceService | None = None,
    ) -> None:
        self.health = health or HealthService()
        self.maintenance = maintenance or MaintenanceService()

    def inspect(self, project_dir: Path, paths: RuntimePaths) -> StartupReport:
        base = self.health.inspect(project_dir, paths.cache / "metadata_cache.sqlite3")
        checks = list(base.checks)
        checks.extend(self._database_integrity(project_dir))
        checks.append(self._interrupted_sessions())
        checks.append(self._configuration(paths.configuration))
        checkpoint_report = self.maintenance.inspect_checkpoints(paths.checkpoints)
        if checkpoint_report.invalid_checkpoints:
            checks.append(
                HealthCheck(
                    "checkpoint_files",
                    "warning",
                    f"{len(checkpoint_report.invalid_checkpoints)} inválido(s)",
                )
            )
        else:
            checks.append(
                HealthCheck(
                    "checkpoint_files",
                    "warning" if checkpoint_report.interrupted_sessions else "ok",
                    (
                        f"{len(checkpoint_report.interrupted_sessions)} local(es) interrumpido(s); "
                        f"{len(checkpoint_report.deferred_checkpoints)} grande(s) bajo demanda"
                    ),
                )
            )
        checks.append(self._providers())
        return StartupReport(tuple(checks))

    @staticmethod
    def _database_integrity(project_dir: Path) -> tuple[HealthCheck, HealthCheck]:
        raw = runtime_database_url()
        if raw is None:
            return (
                HealthCheck("tables", "error", "base PostgreSQL no disponible"),
                HealthCheck("integrity", "error", "integridad sin comprobar"),
            )
        engine = create_engine(raw, pool_pre_ping=True, connect_args={"connect_timeout": 3})
        try:
            with engine.connect() as connection:
                existing = set(inspect(connection).get_table_names())
                missing = sorted(REQUIRED_TABLES - existing)
                if missing:
                    return (
                        HealthCheck("tables", "error", f"faltan {len(missing)} tabla(s)"),
                        HealthCheck("integrity", "error", "esquema incompleto"),
                    )
                current = connection.execute(
                    text("SELECT version_num FROM alembic_version")
                ).scalar_one()
                head = migration_head(project_dir)
                orphan_availability = connection.execute(
                    text(
                        """
                        SELECT count(*) FROM availabilities AS availability
                        LEFT JOIN contents AS content ON content.id = availability.content_id
                        LEFT JOIN banks AS bank ON bank.id = availability.bank_id
                        WHERE content.id IS NULL OR bank.id IS NULL
                        """
                    )
                ).scalar_one()
                active_versions = connection.execute(
                    text("SELECT count(*) FROM catalog_publications WHERE status = 'active'")
                ).scalar_one()
            compatible = current == head and orphan_availability == 0 and active_versions <= 1
            detail = (
                "restricciones básicas válidas"
                if compatible
                else "migración, referencias o versión activa incompatibles"
            )
            return (
                HealthCheck("tables", "ok", f"{len(REQUIRED_TABLES)} esenciales presentes"),
                HealthCheck("integrity", "ok" if compatible else "error", detail),
            )
        except Exception as exc:
            return (
                HealthCheck("tables", "error", f"inspección fallida: {type(exc).__name__}"),
                HealthCheck("integrity", "error", "integridad sin comprobar"),
            )
        finally:
            engine.dispose()

    @staticmethod
    def _configuration(path: Path) -> HealthCheck:
        try:
            probe = path / ".write-probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
        except OSError:
            return HealthCheck("configuration", "error", "directorio sin escritura")
        return HealthCheck("configuration", "ok", "directorio disponible")

    @staticmethod
    def _interrupted_sessions() -> HealthCheck:
        raw = runtime_database_url()
        if raw is None:
            return HealthCheck("checkpoints", "warning", "sesiones sin comprobar")
        engine = create_engine(raw, pool_pre_ping=True, connect_args={"connect_timeout": 3})
        try:
            with engine.connect() as connection:
                count = connection.execute(
                    text(
                        """
                        SELECT count(*) FROM processing_sessions
                        WHERE status IN ('running', 'paused', 'waiting_internet')
                        """
                    )
                ).scalar_one()
            return HealthCheck(
                "checkpoints",
                "warning" if count else "ok",
                f"{count} sesión(es) recuperable(s) en PostgreSQL",
            )
        except Exception as exc:
            return HealthCheck(
                "checkpoints", "warning", f"sesiones sin comprobar: {type(exc).__name__}"
            )
        finally:
            engine.dispose()

    @staticmethod
    def _providers() -> HealthCheck:
        keyed = ("TMDB_API_KEY", "FANART_API_KEY", "TAVILY_API_KEY")
        configured = sum(bool(os.environ.get(name, "").strip()) for name in keyed)
        return HealthCheck(
            "providers",
            "ok" if configured else "warning",
            f"{configured}/{len(keyed)} credenciales opcionales presentes; valores ocultos",
        )
