"""Puntuación explicable específica de candidatos Wikidata."""

from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher

from mce.application.identification.models import IdentificationQuery, ProviderCandidate
from mce.application.identification.title_search import normalize_search_title


@dataclass(frozen=True, slots=True)
class WikidataScoreBreakdown:
    title_score: float
    alias_score: float
    year_score: float
    type_score: float
    external_id_score: float
    provider_agreement_score: float
    route_context_score: float
    final_score: float


class WikidataCandidateScorer:
    def score(
        self, query: IdentificationQuery, candidate: ProviderCandidate
    ) -> WikidataScoreBreakdown:
        wanted = normalize_search_title(query.title)
        title = normalize_search_title(candidate.title)
        title_score = SequenceMatcher(None, wanted, title).ratio()
        alias_score = max(
            (
                SequenceMatcher(None, wanted, normalize_search_title(alias)).ratio()
                for alias in candidate.aliases
            ),
            default=0.0,
        )
        year_score = (
            1.0
            if query.year and candidate.year == query.year
            else 0.5
            if query.year is None or candidate.year is None
            else 0.0
        )
        type_score = 1.0 if candidate.kind is query.kind else 0.0
        external_id_score = 1.0 if len(candidate.external_ids) > 1 else 0.0
        final = (
            max(title_score, alias_score) * 0.55
            + year_score * 0.15
            + type_score * 0.2
            + external_id_score * 0.1
        )
        return WikidataScoreBreakdown(
            title_score,
            alias_score,
            year_score,
            type_score,
            external_id_score,
            0.0,
            0.0,
            final,
        )
