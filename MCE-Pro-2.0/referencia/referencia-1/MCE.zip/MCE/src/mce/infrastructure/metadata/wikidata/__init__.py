"""Proveedor Wikidata basado exclusivamente en MediaWiki Action API."""

from .client import WikidataClient
from .config import WikidataProviderConfig
from .mapper import WikidataEntityMapper
from .parser import WikidataResponseParser
from .provider import WikidataSearchProvider
from .rate_limiter import WikidataRateLimiter
from .scoring import WikidataCandidateScorer, WikidataScoreBreakdown

__all__ = [
    "WikidataCandidateScorer",
    "WikidataClient",
    "WikidataEntityMapper",
    "WikidataProviderConfig",
    "WikidataRateLimiter",
    "WikidataResponseParser",
    "WikidataScoreBreakdown",
    "WikidataSearchProvider",
]
