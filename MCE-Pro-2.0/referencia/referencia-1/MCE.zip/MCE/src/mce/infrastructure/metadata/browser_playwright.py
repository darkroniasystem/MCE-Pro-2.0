"""Backend Playwright reutilizable para la búsqueda web excepcional de MCE."""

from __future__ import annotations

import atexit
from collections.abc import Callable
from contextlib import suppress
from dataclasses import dataclass
from queue import Empty, Full, Queue
from threading import Lock, Thread
from typing import Any
from urllib.parse import quote_plus

from mce.infrastructure.metadata.browser_extractor import BrowserEvidenceExtractor
from mce.infrastructure.metadata.browser_search import (
    BrowserSearchHit,
    BrowserSearchResponse,
    BrowserSearchSettings,
    BrowserSearchStatus,
)


@dataclass(frozen=True, slots=True)
class _BrowserRequest:
    query: str
    limit: int
    settings: BrowserSearchSettings
    response: Queue[BrowserSearchResponse]


@dataclass(frozen=True, slots=True)
class BrowserDiagnostic:
    """Estado comprobable del soporte local de navegación."""

    playwright_available: bool
    chromium_available: bool
    message: str


class PlaywrightBrowserAutomationBackend:
    """Mantiene un navegador en un hilo dedicado y cierra cada página usada."""

    def __init__(
        self,
        *,
        channel: str = "chrome",
        search_url_template: str = "https://www.bing.com/search?q={query}",
        playwright_factory: Callable[[], Any] | None = None,
    ) -> None:
        if "{query}" not in search_url_template:
            raise ValueError("browser search URL template must contain {query}")
        self.channel = channel.strip()
        self.search_url_template = search_url_template
        self._playwright_factory = playwright_factory or _sync_playwright
        self._requests: Queue[_BrowserRequest | None] = Queue(maxsize=1)
        self._thread: Thread | None = None
        self._thread_lock = Lock()
        self._closed = False
        atexit.register(self.close)

    def search(
        self,
        query: str,
        *,
        limit: int,
        settings: BrowserSearchSettings,
    ) -> BrowserSearchResponse:
        if self._closed:
            return BrowserSearchResponse(
                BrowserSearchStatus.UNAVAILABLE,
                message="Browser: backend cerrado",
            )
        self._ensure_worker()
        response: Queue[BrowserSearchResponse] = Queue(maxsize=1)
        request = _BrowserRequest(query, limit, settings, response)
        try:
            self._requests.put(request, timeout=settings.timeout_seconds)
            return response.get(timeout=settings.timeout_seconds + 10)
        except (Empty, Full, TimeoutError):
            return BrowserSearchResponse(
                BrowserSearchStatus.TIMEOUT,
                message="Browser: tiempo agotado esperando al navegador",
            )

    def diagnose(self, *, headless: bool = True) -> BrowserDiagnostic:
        """Comprueba Playwright y el navegador sin realizar búsquedas web."""

        manager: Any = None
        browser: Any = None
        try:
            manager = self._playwright_factory()
            playwright = manager.start()
        except Exception as exc:
            return BrowserDiagnostic(False, False, _diagnostic_cause(exc))
        try:
            browser = self._launch(playwright, headless)
        except Exception as exc:
            return BrowserDiagnostic(True, False, _diagnostic_cause(exc))
        finally:
            if browser is not None:
                with suppress(Exception):
                    browser.close()
            if manager is not None:
                with suppress(Exception):
                    manager.stop()
        return BrowserDiagnostic(True, True, "Playwright y Chrome/Chromium disponibles")

    def close(self) -> None:
        with self._thread_lock:
            if self._closed:
                return
            self._closed = True
            thread = self._thread
        if thread is None:
            return
        try:
            self._requests.put_nowait(None)
        except Exception:
            return
        thread.join(timeout=10)

    def _ensure_worker(self) -> None:
        with self._thread_lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = Thread(
                target=self._worker,
                name="mce-browser-search",
                daemon=True,
            )
            self._thread.start()

    def _worker(self) -> None:
        manager: Any = None
        playwright: Any = None
        browser: Any = None
        browser_headless: bool | None = None
        try:
            while True:
                request = self._requests.get()
                if request is None:
                    break
                try:
                    if manager is None:
                        manager = self._playwright_factory()
                        playwright = manager.start()
                    if browser is None or browser_headless != request.settings.headless:
                        if browser is not None:
                            browser.close()
                        browser = self._launch(playwright, request.settings.headless)
                        browser_headless = request.settings.headless
                    result = self._execute(browser, request)
                except Exception as exc:
                    result = self._failure(exc)
                    if browser is not None and not browser.is_connected():
                        browser = None
                        browser_headless = None
                    if playwright is None:
                        manager = None
                request.response.put(result)
        finally:
            if browser is not None:
                with suppress(Exception):
                    browser.close()
            if manager is not None:
                with suppress(Exception):
                    manager.stop()

    def _launch(self, playwright: Any, headless: bool) -> Any:
        options: dict[str, object] = {"headless": headless}
        if self.channel and self.channel.casefold() != "chromium":
            options["channel"] = self.channel
        return playwright.chromium.launch(**options)

    def _execute(self, browser: Any, request: _BrowserRequest) -> BrowserSearchResponse:
        page = browser.new_page()
        try:
            url = self.search_url_template.format(query=quote_plus(request.query))
            page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=round(request.settings.timeout_seconds * 1_000),
            )
            extraction = BrowserEvidenceExtractor().extract(
                page,
                settings=request.settings,
                limit=request.limit,
            )
            hits = tuple(
                BrowserSearchHit(
                    item.title,
                    item.source_url,
                    item.snippet or item.visible_text,
                    item.year,
                    item.media_type,
                    80.0 if item.origin == "knowledge_panel" else 75.0,
                )
                for item in extraction.evidence
                if item.source_url
            )
            status = extraction.status
            if extraction.evidence and not hits:
                status = BrowserSearchStatus.NO_EVIDENCE
            return BrowserSearchResponse(status, hits, extraction.message)
        finally:
            page.close()

    @staticmethod
    def _failure(exc: Exception) -> BrowserSearchResponse:
        name = type(exc).__name__.casefold()
        message = str(exc).casefold()
        if "timeout" in name or "timeout" in message:
            return BrowserSearchResponse(
                BrowserSearchStatus.TIMEOUT,
                message="Browser: tiempo agotado durante la navegación",
            )
        if "executable" in message or "playwright" in message or "browser" in message:
            return BrowserSearchResponse(
                BrowserSearchStatus.UNAVAILABLE,
                message=(
                    "Browser: Playwright está instalado, pero Chrome/Chromium "
                    "no pudo iniciarse"
                ),
            )
        return BrowserSearchResponse(
            BrowserSearchStatus.UNAVAILABLE,
            message="Browser: entorno de navegación no disponible",
        )


def _sync_playwright() -> Any:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Browser: Playwright no está instalado") from exc
    return sync_playwright()


def _diagnostic_cause(exc: Exception) -> str:
    message = str(exc).strip()
    if not message:
        message = type(exc).__name__
    return message.replace("\n", " ")[:300]


__all__ = ["BrowserDiagnostic", "PlaywrightBrowserAutomationBackend"]
