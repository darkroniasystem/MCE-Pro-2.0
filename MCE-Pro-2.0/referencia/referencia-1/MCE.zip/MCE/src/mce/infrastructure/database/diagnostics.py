"""Diagnóstico seguro de la configuración PostgreSQL."""

import os
import sys
import winreg
from dataclasses import dataclass

from sqlalchemy.engine import make_url


@dataclass(frozen=True, slots=True)
class DatabaseConfigurationStatus:
    """Estado seguro que nunca expone usuario ni contraseña."""

    configured: bool
    safe: bool
    database: str | None
    message: str


def inspect_runtime_database_configuration() -> DatabaseConfigurationStatus:
    """Prefiere `mce`; el ejecutable instalado nunca cae silenciosamente en pruebas."""
    production = _inspect("MCE_DATABASE_URL", "mce", "catálogo maestro configurado")
    if production.configured:
        return production
    if getattr(sys, "frozen", False):
        return DatabaseConfigurationStatus(False, False, None, "catálogo maestro sin configurar")
    return inspect_test_database_configuration()


def inspect_test_database_configuration() -> DatabaseConfigurationStatus:
    """Inspecciona solo la URL de pruebas sin abrir una conexión."""
    return _inspect("MCE_TEST_DATABASE_URL", "mce_test", "mce_test configurada")


def runtime_database_url() -> str | None:
    """Devuelve una URL validada sin permitir bases ambiguas o administrativas."""
    production = _environment_value("MCE_DATABASE_URL")
    if production and _safe_database(production, "mce"):
        return production
    if getattr(sys, "frozen", False):
        return None
    test = _environment_value("MCE_TEST_DATABASE_URL")
    if not production and test and _safe_database(test, "mce_test"):
        return test
    return None


def _inspect(variable: str, expected: str, success: str) -> DatabaseConfigurationStatus:
    raw = _environment_value(variable)
    if not raw:
        return DatabaseConfigurationStatus(False, False, None, "sin configurar")
    try:
        url = make_url(raw)
    except (TypeError, ValueError):
        return DatabaseConfigurationStatus(True, False, None, "URL inválida")
    safe = url.get_backend_name() == "postgresql" and url.database == expected
    return DatabaseConfigurationStatus(
        True,
        safe,
        url.database,
        success if safe else "destino rechazado",
    )


def _safe_database(raw: str, expected: str) -> bool:
    try:
        url = make_url(raw)
    except (TypeError, ValueError):
        return False
    return url.get_backend_name() == "postgresql" and url.database == expected


def _environment_value(variable: str) -> str:
    value = os.environ.get(variable, "").strip()
    if value or not getattr(sys, "frozen", False) or os.name != "nt":
        return value
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            stored, _kind = winreg.QueryValueEx(key, variable)
    except (FileNotFoundError, OSError):
        return ""
    return str(stored).strip()
