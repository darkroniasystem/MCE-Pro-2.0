"""Configuración tipada y acotada del proveedor Wikidata."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class WikidataProviderConfig:
    timeout_seconds: float = 10
    language: str = "es"
    fallback_languages: tuple[str, ...] = ("en",)
    max_candidates: int = 8
    max_search_variants: int = 3
    enabled: bool = True
    complementary: bool = True
    fallback: bool = True

    @property
    def languages(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((self.language, *self.fallback_languages)))
