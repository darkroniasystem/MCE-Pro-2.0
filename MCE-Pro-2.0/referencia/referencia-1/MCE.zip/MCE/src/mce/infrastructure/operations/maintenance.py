"""Mantenimiento local conservador y recuperable."""

from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path


@dataclass(frozen=True, slots=True)
class MaintenanceReport:
    expired_cache_entries: int = 0
    archived_sessions: int = 0
    interrupted_sessions: tuple[str, ...] = ()
    invalid_checkpoints: tuple[str, ...] = ()
    deferred_checkpoints: tuple[str, ...] = ()


class MaintenanceService:
    def clear_expired_cache(self, cache_path: Path, *, older_than: datetime) -> int:
        if not cache_path.exists():
            return 0
        with sqlite3.connect(cache_path) as connection:
            cursor = connection.execute(
                "DELETE FROM metadata_cache WHERE created_at < ?",
                (older_than.astimezone(UTC).isoformat(),),
            )
            return max(0, cursor.rowcount)

    def inspect_checkpoints(
        self, directory: Path, *, maximum_eager_bytes: int = 8 * 1024 * 1024
    ) -> MaintenanceReport:
        interrupted: list[str] = []
        invalid: list[str] = []
        deferred: list[str] = []
        for path in directory.resolve().glob("*.json"):
            try:
                if path.stat().st_size > maximum_eager_bytes:
                    deferred.append(path.name)
                    continue
            except OSError:
                invalid.append(path.name)
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                status = payload["session"]["status"]
                if status in {"running", "paused", "waiting_internet"}:
                    interrupted.append(path.stem)
            except (OSError, KeyError, TypeError, json.JSONDecodeError):
                invalid.append(path.name)
        return MaintenanceReport(
            interrupted_sessions=tuple(sorted(interrupted)),
            invalid_checkpoints=tuple(sorted(invalid)),
            deferred_checkpoints=tuple(sorted(deferred)),
        )

    def archive_session(self, checkpoint: Path, archive_directory: Path) -> Path:
        if checkpoint.is_symlink() or archive_directory.is_symlink():
            raise ValueError("symbolic links are not allowed for session archives")
        source = checkpoint.resolve()
        if not source.is_file() or source.suffix.casefold() != ".json":
            raise ValueError("a valid checkpoint JSON is required")
        data = json.loads(source.read_text(encoding="utf-8"))
        status = data.get("session", {}).get("status")
        if status not in {"completed", "cancelled", "failed"}:
            raise ValueError("only terminal sessions can be archived")
        target_dir = archive_directory.resolve()
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / source.name
        if target.exists():
            raise FileExistsError(target)
        shutil.move(str(source), str(target))
        return target

    @staticmethod
    def default_expiration(now: datetime) -> datetime:
        return now.astimezone(UTC) - timedelta(days=30)
