"""Proveedor web JSON configurable y caché persistente independiente de sesiones."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import BoundedSemaphore, Lock
from typing import Protocol
from urllib.parse import urlparse

from mce.application.identification.service import (
    ProviderCancelledError,
    ProviderError,
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderServerError,
    ProviderTimeoutError,
)
from mce.application.web_search import WebSearchEvidence, WebSearchProvider, utc_now


class JsonTransport(Protocol):
    def post_json(
        self,
        path: str,
        payload: dict[str, object],
        timeout: float,
        headers: dict[str, str] | None = None,
    ) -> dict[str, object] | list[object]: ...


class TavilyWebSearchProvider:
    """Adaptador Tavily JSON inyectable, sin llamadas implícitas ni secretos en logs."""

    name = "web:tavily"

    def __init__(self, api_key: str, transport: JsonTransport, *, timeout: float = 10) -> None:
        if not api_key.strip():
            raise ValueError("TAVILY_API_KEY is required")
        self.api_key = api_key.strip()
        self.transport = transport
        self.timeout = timeout
        self.last_from_cache = False

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        payload = self.transport.post_json(
            "/search",
            {
                "query": query,
                "search_depth": "basic",
                "max_results": limit,
                "include_answer": False,
                "include_raw_content": False,
                "topic": "general",
            },
            self.timeout,
            {"Authorization": f"Bearer {self.api_key}"},
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("Tavily: respuesta web inesperada")
        rows = payload.get("results")
        if rows is None:
            return ()
        if not isinstance(rows, list):
            raise ProviderResponseError("Tavily: candidatos web inválidos")
        now = utc_now()
        evidence: list[WebSearchEvidence] = []
        for position, row in enumerate(rows[:limit]):
            if not isinstance(row, dict):
                continue
            title, url = str(row.get("title") or "").strip(), str(row.get("url") or "").strip()
            if not title or not _safe_url(url):
                continue
            description = str(row.get("content") or "").strip()
            raw_score = row.get("score")
            score = (
                max(0.0, min(100.0, float(raw_score) * 100.0))
                if isinstance(raw_score, (int, float))
                else max(0.0, 100.0 - position * 5.0)
            )
            evidence.append(
                WebSearchEvidence(
                    source=_source(url),
                    title=title,
                    media_type=_infer_type(f"{title} {description}"),
                    year=_infer_year(f"{title} {description}"),
                    description=description,
                    source_url=url,
                    score=score,
                    collected_at=now,
                    query=query,
                    provider="tavily",
                )
            )
        return tuple(evidence)


class SerperWebSearchProvider:
    """Adaptador mínimo para Google Serper; solo conserva evidencia pública."""

    name = "web:serper"

    def __init__(
        self,
        api_key: str,
        transport: JsonTransport,
        *,
        timeout: float = 10,
        max_characters: int = 1_500,
    ) -> None:
        if not api_key.strip():
            raise ValueError("SERPER_API_KEY is required")
        if max_characters < 100:
            raise ValueError("Serper max_characters must be at least 100")
        self.api_key = api_key.strip()
        self.transport = transport
        self.timeout = timeout
        self.max_characters = max_characters
        self.last_from_cache = False

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        payload = self.transport.post_json(
            "/search",
            {"q": query, "num": limit},
            self.timeout,
            {"X-API-KEY": self.api_key},
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("Serper: respuesta web inesperada")
        rows = payload.get("organic")
        if rows is None:
            return ()
        if not isinstance(rows, list):
            raise ProviderResponseError("Serper: resultados orgánicos inválidos")
        now = utc_now()
        evidence: list[WebSearchEvidence] = []
        for position, row in enumerate(rows[:limit]):
            if not isinstance(row, dict):
                continue
            title = str(row.get("title") or "").strip()
            url = str(row.get("link") or "").strip()
            if not title or not _safe_url(url):
                continue
            description = _compact_text(
                row.get("snippet"), row.get("date"), max_characters=self.max_characters
            )
            classification_text = f"{title} {description} {row.get('date') or ''}"
            evidence.append(
                WebSearchEvidence(
                    source=_source(url),
                    title=title,
                    media_type=_infer_type(classification_text),
                    year=_infer_year(classification_text),
                    description=description,
                    source_url=url,
                    score=max(0.0, 100.0 - position * 5.0),
                    collected_at=now,
                    query=query,
                    provider="serper",
                )
            )
        return tuple(evidence)


class ExaWebSearchProvider:
    """Adaptador Exa Search con fragmentos limitados para no acumular páginas."""

    name = "web:exa"

    def __init__(
        self,
        api_key: str,
        transport: JsonTransport,
        *,
        timeout: float = 10,
        max_characters: int = 1_500,
    ) -> None:
        if not api_key.strip():
            raise ValueError("EXA_API_KEY is required")
        if max_characters < 100:
            raise ValueError("Exa max_characters must be at least 100")
        self.api_key = api_key.strip()
        self.transport = transport
        self.timeout = timeout
        self.max_characters = max_characters
        self.last_from_cache = False

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        payload = self.transport.post_json(
            "/search",
            {
                "query": query,
                "numResults": limit,
                "type": "auto",
                "contents": {"text": {"maxCharacters": self.max_characters}},
            },
            self.timeout,
            {"x-api-key": self.api_key},
        )
        if not isinstance(payload, dict):
            raise ProviderResponseError("Exa: respuesta web inesperada")
        rows = payload.get("results")
        if rows is None:
            return ()
        if not isinstance(rows, list):
            raise ProviderResponseError("Exa: resultados inválidos")
        now = utc_now()
        evidence: list[WebSearchEvidence] = []
        for position, row in enumerate(rows[:limit]):
            if not isinstance(row, dict):
                continue
            title = str(row.get("title") or "").strip()
            url = str(row.get("url") or "").strip()
            if not title or not _safe_url(url):
                continue
            highlights = row.get("highlights")
            highlight_text = highlights if isinstance(highlights, list) else ()
            description = _compact_text(
                row.get("text"),
                *highlight_text,
                row.get("publishedDate"),
                max_characters=self.max_characters,
            )
            classification_text = f"{title} {description} {row.get('publishedDate') or ''}"
            raw_score = row.get("score")
            score = (
                max(0.0, min(100.0, float(raw_score) * 100.0))
                if isinstance(raw_score, (int, float))
                else max(0.0, 100.0 - position * 5.0)
            )
            evidence.append(
                WebSearchEvidence(
                    source=_source(url),
                    title=title,
                    media_type=_infer_type(classification_text),
                    year=_infer_year(classification_text),
                    description=description,
                    source_url=url,
                    score=score,
                    collected_at=now,
                    query=query,
                    provider="exa",
                )
            )
        return tuple(evidence)


class ResilientControlledWebSearchProvider:
    """Aplica reintentos, cuota local, concurrencia, ritmo y circuit breaker por proveedor."""

    def __init__(
        self,
        provider: WebSearchProvider,
        *,
        retries: int = 2,
        max_requests: int = 100_000,
        max_concurrency: int = 1,
        min_interval_seconds: float = 0.0,
        failure_threshold: int = 3,
        cooldown_seconds: float = 30.0,
        base_delay: float = 0.5,
        cancelled: Callable[[], bool] = lambda: False,
        monotonic: Callable[[], float] = time.monotonic,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if min(retries, min_interval_seconds, cooldown_seconds, base_delay) < 0:
            raise ValueError("web provider control values must be non-negative")
        if min(max_requests, max_concurrency, failure_threshold) < 1:
            raise ValueError("web provider control limits must be positive")
        self.provider = provider
        self.name = f"controlled:{provider.name}"
        self.retries = retries
        self.max_requests = max_requests
        self.calls = 0
        self.http_calls = 0
        self.successes = 0
        self.errors = 0
        self.rate_limited = 0
        self.quota_exhausted_count = 0
        self.last_error: str | None = None
        self.last_success: datetime | None = None
        self._slots = BoundedSemaphore(max_concurrency)
        self._lock = Lock()
        self._interval = min_interval_seconds
        self._threshold = failure_threshold
        self._cooldown = cooldown_seconds
        self._base_delay = base_delay
        self._cancelled = cancelled
        self._monotonic = monotonic
        self._sleep = sleep
        self._last_started: float | None = None
        self._failures = 0
        self._opened_at: float | None = None
        self.last_attempts = 0

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        now = self._monotonic()
        if self._opened_at is not None:
            if now - self._opened_at < self._cooldown:
                raise ProviderOfflineError(
                    f"{self.provider.name}: circuito temporalmente abierto"
                )
            self._opened_at = None
            self._failures = 0
        if self.calls >= self.max_requests:
            self.quota_exhausted_count += 1
            self.last_error = "quota_exhausted"
            raise ProviderRateLimitError(
                f"{self.provider.name}: límite local de solicitudes alcanzado"
            )
        while not self._slots.acquire(timeout=0.1):
            if self._cancelled():
                raise ProviderCancelledError("operación cancelada")
        try:
            with self._lock:
                if self._cancelled():
                    raise ProviderCancelledError("operación cancelada")
                now = self._monotonic()
                delay = (
                    0.0
                    if self._last_started is None
                    else self._interval - (now - self._last_started)
                )
                if delay > 0:
                    self._sleep(delay)
                self._last_started = self._monotonic()
                self.calls += 1
            for attempt in range(self.retries + 1):
                self.last_attempts = attempt + 1
                self.http_calls += 1
                try:
                    result = self.provider.search(query, limit=limit)
                except ProviderRateLimitError as exc:
                    self.rate_limited += 1
                    self.errors += 1
                    quota_exhausted = bool(
                        getattr(exc, "quota_exhausted", False)
                    ) or _looks_like_quota_exhaustion(str(exc))
                    if quota_exhausted:
                        self.quota_exhausted_count += 1
                    self.last_error = "quota_exhausted" if quota_exhausted else "rate_limit"
                    self._failures += 1
                    if self._failures >= self._threshold:
                        self._opened_at = self._monotonic()
                    # Un 429 no mejora con reintentos inmediatos: se entrega al
                    # coordinador para continuar con el siguiente proveedor.
                    raise
                except (ProviderTimeoutError, ProviderServerError):
                    self.errors += 1
                    self.last_error = "transient_error"
                    self._failures += 1
                    if self._failures >= self._threshold:
                        self._opened_at = self._monotonic()
                    if attempt == self.retries:
                        raise
                    self._sleep(self._base_delay * (2**attempt))
                    continue
                except ProviderError:
                    self.errors += 1
                    self.last_error = "provider_error"
                    self._failures += 1
                    if self._failures >= self._threshold:
                        self._opened_at = self._monotonic()
                    raise
                self._failures = 0
                self._opened_at = None
                self.successes += 1
                self.last_error = None
                self.last_success = utc_now()
                return result
            raise AssertionError("unreachable retry state")
        finally:
            self._slots.release()

    @property
    def consecutive_failures(self) -> int:
        return self._failures

    @property
    def cooldown_until(self) -> float | None:
        return (
            None
            if self._opened_at is None
            else self._opened_at + self._cooldown
        )

    @property
    def circuit_state(self) -> str:
        if self._opened_at is None:
            return "closed"
        if self._monotonic() - self._opened_at >= self._cooldown:
            return "half-open"
        return "open"

    def telemetry(
        self,
        provider_id: str,
        *,
        enabled: bool = True,
        priority: int = 100,
        cache_hits: int = 0,
    ) -> WebProviderTelemetry:
        """Expone un estado común sin asumir métricas remotas inexistentes."""
        return WebProviderTelemetry(
            provider_id=provider_id,
            enabled=enabled,
            priority=priority,
            timeout=float(getattr(self.provider, "timeout", 0.0)) or None,
            retries=self.retries,
            consecutive_failures=self.consecutive_failures,
            cooldown_until=self.cooldown_until,
            circuit_state=self.circuit_state,
            last_error=self.last_error,
            last_success=self.last_success,
            total_requests=self.http_calls,
            total_success=self.successes,
            total_failures=self.errors,
            rate_limit_hits=self.rate_limited,
            quota_exhausted_count=self.quota_exhausted_count,
            cache_hits=max(0, cache_hits),
        )


@dataclass(frozen=True, slots=True)
class WebProviderTelemetry:
    provider_id: str
    enabled: bool
    priority: int
    timeout: float | None
    retries: int
    consecutive_failures: int
    cooldown_until: float | None
    circuit_state: str
    last_error: str | None
    last_success: datetime | None
    total_requests: int
    total_success: int
    total_failures: int
    rate_limit_hits: int
    quota_exhausted_count: int
    cache_hits: int = 0


@dataclass(frozen=True, slots=True)
class WebProviderRegistration:
    provider: WebSearchProvider
    provider_id: str
    enabled: bool = True
    priority: int = 100


@dataclass(frozen=True, slots=True)
class WebProviderAttempt:
    provider_id: str
    status: str
    result_count: int = 0
    message: str = ""
    new_result_count: int = 0
    accumulated_result_count: int = 0
    cache_hit: bool = False


class SequentialWebSearchProvider:
    """Acumula proveedores por prioridad y se detiene con evidencia suficiente."""

    name = "web:multi-v1"

    def __init__(
        self,
        registrations: tuple[WebProviderRegistration, ...],
        *,
        sufficient: Callable[[tuple[WebSearchEvidence, ...]], bool] | None = None,
    ) -> None:
        self.registrations = tuple(sorted(registrations, key=lambda value: value.priority))
        self.sufficient = sufficient or sufficient_web_evidence
        self.last_attempts: tuple[WebProviderAttempt, ...] = ()
        self.last_provider: str | None = None
        self.last_from_cache = False

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        attempts: list[WebProviderAttempt] = []
        accumulated: dict[str, WebSearchEvidence] = {}
        self.last_provider = None
        self.last_from_cache = False
        for registration in self.registrations:
            if not registration.enabled:
                attempts.append(
                    WebProviderAttempt(
                        registration.provider_id,
                        "disabled",
                        accumulated_result_count=len(accumulated),
                    )
                )
                continue
            try:
                result = registration.provider.search(query, limit=limit)
            except ProviderRateLimitError as exc:
                attempts.append(
                    WebProviderAttempt(
                        registration.provider_id,
                        "rate_limited",
                        message=str(exc),
                        accumulated_result_count=len(accumulated),
                    )
                )
                continue
            except ProviderTimeoutError as exc:
                attempts.append(
                    WebProviderAttempt(
                        registration.provider_id,
                        "timeout",
                        message=str(exc),
                        accumulated_result_count=len(accumulated),
                    )
                )
                continue
            except ProviderOfflineError as exc:
                attempts.append(
                    WebProviderAttempt(
                        registration.provider_id,
                        "offline",
                        message=str(exc),
                        accumulated_result_count=len(accumulated),
                    )
                )
                continue
            except ProviderError as exc:
                attempts.append(
                    WebProviderAttempt(
                        registration.provider_id,
                        "error",
                        message=str(exc),
                        accumulated_result_count=len(accumulated),
                    )
                )
                continue
            before = len(accumulated)
            for evidence in result:
                accumulated.setdefault(_evidence_identity(evidence.source_url), evidence)
            combined = tuple(accumulated.values())
            enough = self.sufficient(combined)
            cache_hit = bool(getattr(registration.provider, "last_from_cache", False))
            attempts.append(
                WebProviderAttempt(
                    registration.provider_id,
                    "sufficient" if enough else "insufficient",
                    len(result),
                    new_result_count=len(accumulated) - before,
                    accumulated_result_count=len(accumulated),
                    cache_hit=cache_hit,
                )
            )
            self.last_provider = registration.provider_id
            self.last_from_cache = self.last_from_cache or cache_hit
            if enough:
                self.last_attempts = tuple(attempts)
                return _limit_diverse_evidence(combined, limit)
        self.last_attempts = tuple(attempts)
        return _limit_diverse_evidence(tuple(accumulated.values()), limit)


def sufficient_web_evidence(values: tuple[WebSearchEvidence, ...]) -> bool:
    """Exige dos dominios y títulos útiles antes de gastar menos proveedores."""
    usable = tuple(
        value
        for value in values
        if value.title.strip() and value.description.strip() and _safe_url(value.source_url)
    )
    domains = {_source(value.source_url).casefold() for value in usable}
    return len(usable) >= 2 and len(domains) >= 2


def _evidence_identity(url: str) -> str:
    parsed = urlparse(url.strip())
    host = (parsed.hostname or "").casefold()
    port = parsed.port
    default_port = (parsed.scheme.casefold() == "https" and port == 443) or (
        parsed.scheme.casefold() == "http" and port == 80
    )
    netloc = host if port is None or default_port else f"{host}:{port}"
    path = parsed.path.rstrip("/") or "/"
    return parsed._replace(
        scheme=parsed.scheme.casefold(),
        netloc=netloc,
        path=path,
        fragment="",
    ).geturl()


def _limit_diverse_evidence(
    values: tuple[WebSearchEvidence, ...], limit: int
) -> tuple[WebSearchEvidence, ...]:
    """Conserva diversidad de dominios antes de completar el límite visual."""
    if limit <= 0:
        return ()
    selected: list[WebSearchEvidence] = []
    selected_urls: set[str] = set()
    selected_domains: set[str] = set()
    for value in values:
        identity = _evidence_identity(value.source_url)
        domain = _source(value.source_url).casefold()
        if identity in selected_urls or domain in selected_domains:
            continue
        selected.append(value)
        selected_urls.add(identity)
        selected_domains.add(domain)
        if len(selected) >= limit:
            return tuple(selected)
    for value in values:
        identity = _evidence_identity(value.source_url)
        if identity in selected_urls:
            continue
        selected.append(value)
        selected_urls.add(identity)
        if len(selected) >= limit:
            break
    return tuple(selected)


class CachedWebSearchProvider:
    name = "cached:web-search"

    def __init__(
        self,
        provider: WebSearchProvider,
        path: Path,
        *,
        ttl: timedelta = timedelta(hours=24),
    ) -> None:
        self.provider = provider
        self.path = path.resolve()
        self.ttl = ttl
        self.last_from_cache = False
        self.cache_hits = 0
        self.cache_misses = 0
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as connection:
            connection.execute(
                """CREATE TABLE IF NOT EXISTS web_search_cache (
                cache_key TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at TEXT NOT NULL
                )"""
            )
            columns = {
                str(row[1])
                for row in connection.execute("PRAGMA table_info(web_search_cache)")
            }
            if "payload_checksum" not in columns:
                connection.execute(
                    "ALTER TABLE web_search_cache ADD COLUMN payload_checksum TEXT"
                )

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        normalized_query = " ".join(query.casefold().split())
        key = hashlib.sha256(
            f"web-shared-v2|{limit}|{normalized_query}".encode()
        ).hexdigest()
        legacy_keys = tuple(
            hashlib.sha256(f"{name}|{limit}|{query}".encode()).hexdigest()
            for name in dict.fromkeys(
                (self.provider.name, "controlled:web:tavily")
            )
        )
        now = utc_now()
        with sqlite3.connect(self.path) as connection:
            matched_key = key
            row = connection.execute(
                "SELECT payload,created_at,payload_checksum FROM web_search_cache "
                "WHERE cache_key=?",
                (key,),
            ).fetchone()
            if row is None:
                for legacy_key in legacy_keys:
                    row = connection.execute(
                        "SELECT payload,created_at,payload_checksum FROM web_search_cache "
                        "WHERE cache_key=?",
                        (legacy_key,),
                    ).fetchone()
                    if row is not None:
                        matched_key = legacy_key
                        break
            if (
                row is not None
                and now - datetime.fromisoformat(str(row[1])).astimezone(UTC) <= self.ttl
            ):
                payload = str(row[0])
                checksum = str(row[2]) if row[2] is not None else None
                valid_checksum = checksum is None or hashlib.sha256(
                    payload.encode("utf-8")
                ).hexdigest() == checksum
                try:
                    result = _decode(payload) if valid_checksum else None
                except (json.JSONDecodeError, KeyError, TypeError, ValueError):
                    result = None
                if result is not None:
                    stored_checksum = hashlib.sha256(payload.encode("utf-8")).hexdigest()
                    self.last_from_cache = True
                    self.cache_hits += 1
                    connection.execute(
                        "INSERT OR REPLACE INTO web_search_cache"
                        "(cache_key,payload,created_at,payload_checksum) VALUES(?,?,?,?)",
                        (key, payload, str(row[1]), stored_checksum),
                    )
                    return result
                connection.execute(
                    "DELETE FROM web_search_cache WHERE cache_key=?", (matched_key,)
                )
            elif row is not None:
                connection.execute(
                    "DELETE FROM web_search_cache WHERE cache_key=?", (matched_key,)
                )
        self.last_from_cache = False
        self.cache_misses += 1
        result = self.provider.search(query, limit=limit)
        payload = _encode(result)
        checksum = hashlib.sha256(payload.encode("utf-8")).hexdigest()
        with sqlite3.connect(self.path) as connection:
            connection.execute(
                "INSERT OR REPLACE INTO web_search_cache"
                "(cache_key,payload,created_at,payload_checksum) VALUES(?,?,?,?)",
                (key, payload, now.isoformat(), checksum),
            )
        return result


def _encode(values: tuple[WebSearchEvidence, ...]) -> str:
    return json.dumps(
        [
            {
                "source": item.source,
                "title": item.title,
                "media_type": item.media_type,
                "year": item.year,
                "description": item.description,
                "source_url": item.source_url,
                "score": item.score,
                "collected_at": item.collected_at.isoformat(),
                "query": item.query,
                "provider": item.provider,
            }
            for item in values
        ],
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _decode(payload: str) -> tuple[WebSearchEvidence, ...]:
    return tuple(
        WebSearchEvidence(
            source=str(row["source"]),
            title=str(row["title"]),
            media_type=row.get("media_type"),
            year=row.get("year"),
            description=str(row.get("description") or ""),
            source_url=str(row["source_url"]),
            score=float(row["score"]),
            collected_at=datetime.fromisoformat(str(row["collected_at"])),
            query=str(row["query"]),
            provider=str(row.get("provider") or "tavily"),
        )
        for row in json.loads(payload)
        if isinstance(row, dict)
    )


def _safe_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.scheme == "https" and bool(parsed.hostname)


def _source(url: str) -> str:
    return urlparse(url).hostname or "web"


def _compact_text(*values: object, max_characters: int) -> str:
    parts: list[str] = []
    for value in values:
        if value is None:
            continue
        text = " ".join(str(value).split())
        if text and text not in parts:
            parts.append(text)
    return " ".join(parts)[:max_characters]


def _looks_like_quota_exhaustion(message: str) -> bool:
    lowered = message.casefold()
    return any(
        marker in lowered
        for marker in (
            "quota",
            "credit",
            "crédito",
            "agotad",
            "exhausted",
            "límite local",
            "limite local",
        )
    )


def _infer_year(text: str) -> int | None:
    import re

    match = re.search(r"\b(19\d{2}|20\d{2}|2100)\b", text)
    return int(match.group(1)) if match else None


def _infer_type(text: str) -> str | None:
    lowered = text.casefold()
    if any(word in lowered for word in ("serie", "series", "temporada", "episode")):
        return "series"
    if any(word in lowered for word in ("película", "pelicula", "movie", "film")):
        return "movie"
    if "anime" in lowered:
        return "anime"
    return None
