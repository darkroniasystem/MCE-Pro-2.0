"""Versión pública del paquete MCE."""

__version__ = "0.12.0"
