"""View models puros para tablas, navegación y estados de pantalla."""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ScreenState(StrEnum):
    EMPTY = "empty"
    LOADING = "loading"
    READY = "ready"
    ERROR = "error"


@dataclass(slots=True)
class TableViewModel:
    rows: list[dict[str, Any]] = field(default_factory=list)
    query: str = ""
    page: int = 1
    page_size: int = 50
    sort_column: str | None = None
    sort_descending: bool = False

    @property
    def matching(self) -> list[dict[str, Any]]:
        """Devuelve todo el alcance filtrado, sin limitarlo a la página visible."""
        text = self.query.casefold().strip()
        values = self.rows if not text else [
            row
            for row in self.rows
            if text in " ".join(str(v) for v in row.values()).casefold()
        ]
        if self.sort_column is None:
            return values
        sort_column = self.sort_column

        def sort_key(row: dict[str, Any]) -> tuple[int, float | str]:
            value = row.get(sort_column)
            if isinstance(value, (int, float)):
                return (0, float(value))
            try:
                return (0, float(str(value).replace(",", "")))
            except (TypeError, ValueError):
                return (1, str(value or "").casefold())

        return sorted(values, key=sort_key, reverse=self.sort_descending)

    @property
    def filtered(self) -> list[dict[str, Any]]:
        values = self.matching
        start = (max(1, self.page) - 1) * self.page_size
        return values[start : start + self.page_size]

    @property
    def total(self) -> int:
        return len(self.matching)


@dataclass(slots=True)
class ScreenViewModel:
    title: str
    state: ScreenState = ScreenState.EMPTY
    message: str = ""
    progress: int = 0

    def loading(self, message: str = "Procesando...") -> None:
        self.state = ScreenState.LOADING
        self.message = message
        self.progress = 0

    def ready(self, message: str = "") -> None:
        self.state = ScreenState.READY
        self.message = message
        self.progress = 100

    def fail(self, message: object) -> None:
        self.state = ScreenState.ERROR
        self.message = str(message)
