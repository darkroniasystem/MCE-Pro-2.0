"""Punto de entrada de la aplicación PySide6."""

import logging
import sys
from pathlib import Path
from typing import cast

from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QApplication

from mce import __version__
from mce.application.importers import ImportService
from mce.infrastructure.database.session_ledger import PostgresImportRegistry
from mce.infrastructure.operations import StartupIntegrityService
from mce.infrastructure.runtime import RuntimePaths, configure_logging, resource_path
from mce.presentation.main_window import MainWindow
from mce.presentation.presenters import ImportPresenter

logger = logging.getLogger(__name__)


def main() -> int:
    paths = RuntimePaths.discover()
    configure_logging(paths.logs)
    logger.info(
        "event=application_started version=%s compiled=%s executable=%s",
        __version__,
        bool(getattr(sys, "frozen", False)),
        Path(sys.executable).name,
    )
    paths.import_legacy(resource_path("alembic.ini").parent)
    startup_report = StartupIntegrityService().inspect(resource_path("alembic.ini").parent, paths)
    for check in startup_report.checks:
        logger.info(
            "event=startup_check name=%s status=%s message=%s",
            check.name,
            check.status,
            check.message,
        )
    logger.info(
        "event=startup_integrity safe_mode=%s errors=%s warnings=%s",
        startup_report.safe_mode,
        sum(check.status == "error" for check in startup_report.checks),
        sum(check.status == "warning" for check in startup_report.checks),
    )
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    app = cast(QApplication, QApplication.instance()) or QApplication(sys.argv)
    app.setApplicationName("MCE Desktop")
    app.setOrganizationName("MCE")
    app.setStyle("Fusion")
    window = MainWindow(
        settings=QSettings(str(paths.configuration / "settings.ini"), QSettings.Format.IniFormat),
        session_presenter=MainWindow.build_session_presenter(
            paths.checkpoints, paths.originals, use_postgresql=not startup_report.safe_mode
        ),
        import_presenter=ImportPresenter(
            ImportService(
                registry=(
                    None
                    if startup_report.safe_mode
                    else PostgresImportRegistry.from_runtime_environment()
                )
            )
        ),
        runtime_paths=paths,
        startup_report=startup_report,
    )
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
