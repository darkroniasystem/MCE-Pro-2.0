"""Presentadores que traducen acciones visuales a casos de uso."""

from collections import Counter
from collections.abc import Callable, Iterator, Sequence
from dataclasses import replace
from pathlib import Path
from typing import Any, cast, overload

from mce.application.dto import (
    ImportRequest,
    ImportResult,
    ProcessingSession,
    ProcessingStage,
    SessionStatus,
)
from mce.application.dto.session_models import SessionItem, SessionItemStatus
from mce.application.processing import (
    LocalPreparationService,
    LocalPreparationSummary,
    ProcessingBatchResult,
    ProcessingProgress,
    SessionPipelineService,
    enrichment_category,
)
from mce.application.workspaces import CancellationToken, SessionService
from mce.infrastructure.runtime import correlation_scope


class ImportPresenter:
    def __init__(self, import_service: Any) -> None:
        self.service = import_service

    def validate(self, path: str) -> ImportResult:
        if not path or Path(path).suffix.casefold() != ".json":
            raise ValueError("Seleccione un archivo JSON de MSL")
        return cast(ImportResult, self.service.import_file(ImportRequest(Path(path))))


class SessionPresenter:
    """Expone la creación de sesiones sin filtrar detalles del repositorio a Qt."""

    def __init__(
        self,
        service: SessionService,
        workspace_id: str,
        sessions: Any,
        checkpoints: Any,
    ) -> None:
        self.service = service
        self.workspace_id = workspace_id
        self.sessions = sessions
        self.checkpoints = checkpoints
        self._known_ids: list[str] = []
        self._focused_id: str | None = None

    def create(
        self, import_result: ImportResult, bank_name: str | None = None
    ) -> ProcessingSession:
        with correlation_scope():
            session = self.service.create(self.workspace_id, import_result, bank_name)
            seed = getattr(self.sessions, "seed", None)
            if callable(seed):
                try:
                    seed(session, import_result)
                except Exception:
                    discard = getattr(self.sessions, "discard_pending", None)
                    if callable(discard):
                        discard(session.session_id)
                    raise
            self.checkpoints.save(session)
        self._known_ids.append(session.session_id)
        return session

    def register_restored(self, session: ProcessingSession) -> None:
        self.sessions.save(session)
        if session.session_id not in self._known_ids:
            self._known_ids.append(session.session_id)

    def register_persisted(self, session_id: str) -> None:
        if session_id not in self._known_ids:
            self._known_ids.append(session_id)

    def transition(self, session_id: str, target: SessionStatus) -> ProcessingSession:
        with correlation_scope(session_id):
            session = self.service.transition(session_id, target)
            self.checkpoints.save(session)
        return session

    def retry(self, session_id: str) -> ProcessingSession:
        """Prepara y persiste un reintento sin perder elementos ya procesados."""
        session = self.service.retry(session_id)
        self.checkpoints.save(session)
        return session

    def delete(self, session_id: str) -> None:
        self.service.delete(session_id)
        self._known_ids = [value for value in self._known_ids if value != session_id]

    def process(
        self,
        session_id: str,
        pipeline: SessionPipelineService,
        token: CancellationToken,
        progress: Callable[[int], None],
        progress_detail: Callable[[ProcessingProgress], None] = lambda value: None,
        selected_categories: frozenset[str] | None = None,
    ) -> tuple[ProcessingBatchResult, ProcessingSession]:
        session = self.sessions.get(session_id)
        if session is None:
            raise KeyError(session_id)
        self._focused_id = session_id
        self.service.configure_enrichment_job(session_id, selected_categories)
        if session.status in {
            SessionStatus.READY,
            SessionStatus.PAUSED,
            SessionStatus.WAITING_REVIEW,
            SessionStatus.WAITING_INTERNET,
        }:
            session = self.transition(session_id, SessionStatus.RUNNING)
        try:

            def persist_completed(items: tuple[SessionItem, ...]) -> None:
                current = self.sessions.get(session_id)
                if current is None:
                    raise KeyError(session_id)
                updates = {item.item_id: item for item in items}
                changed_items = tuple(updates.get(item.item_id, item) for item in current.items)
                durable = self.service.save_processed_items(session_id, changed_items)
                self.checkpoints.save(durable)

            result = pipeline.process(
                session,
                cancelled=lambda: token.is_cancelled,
                wait_if_paused=token.wait_if_paused,
                progress=progress,
                progress_detail=progress_detail,
                selected_categories=selected_categories,
                persist_completed=persist_completed,
            )
        except Exception as exc:
            current = self.sessions.get(session_id)
            if current is not None and current.status is SessionStatus.RUNNING:
                reason = str(exc).strip() or type(exc).__name__
                failed = self.service.fail(session_id, reason)
                self.checkpoints.save(failed)
            raise
        processed_by_id = {item.item.item_id: item.item for item in result.items}
        changed = self.service.save_processed_items(
            session_id,
            tuple(processed_by_id.get(item.item_id, item) for item in session.items),
        )
        target = (
            SessionStatus.WAITING_INTERNET
            if result.deferred_reason
            else SessionStatus.READY
            if any(item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in changed.items)
            else SessionStatus.WAITING_REVIEW
            if any(item.stage is ProcessingStage.REVIEWED for item in changed.items)
            else SessionStatus.COMPLETED
        )
        changed = self.service.transition(changed.session_id, target)
        self.checkpoints.save(changed)
        return result, changed

    def prepare_local(
        self,
        session_id: str,
        *,
        progress_detail: Callable[[ProcessingProgress], None] = lambda value: None,
        token: CancellationToken | None = None,
    ) -> tuple[ProcessingSession, LocalPreparationSummary]:
        """Clasifica y limpia sin red, caché externa ni llamadas a proveedores."""
        session = self.sessions.get(session_id)
        if session is None:
            raise KeyError(session_id)
        self._focused_id = session_id
        if session.status in {
            SessionStatus.READY,
            SessionStatus.PAUSED,
            SessionStatus.WAITING_REVIEW,
            SessionStatus.WAITING_INTERNET,
        }:
            session = self.transition(session_id, SessionStatus.RUNNING)
        cancellation = token or CancellationToken()
        preparation = LocalPreparationService()
        classified, _ = preparation.classify(
            session,
            progress=progress_detail,
            cancelled=lambda: cancellation.is_cancelled,
            wait_if_paused=cancellation.wait_if_paused,
        )
        self.sessions.save(classified)
        self.checkpoints.save(classified)
        cleaned, _ = preparation.clean(
            classified,
            progress=progress_detail,
            cancelled=lambda: cancellation.is_cancelled,
            wait_if_paused=cancellation.wait_if_paused,
        )
        self.sessions.save(cleaned)
        self.checkpoints.save(cleaned)
        grouped, summary = preparation.group(
            cleaned,
            progress=progress_detail,
            cancelled=lambda: cancellation.is_cancelled,
            wait_if_paused=cancellation.wait_if_paused,
        )
        self.sessions.save(grouped)
        if grouped.status is SessionStatus.CANCELLED:
            grouped = self.service.reactivate_after_local_preparation(session_id)
        elif grouped.status is SessionStatus.RUNNING:
            grouped = self.service.transition(session_id, SessionStatus.READY)
        self.checkpoints.save(grouped)
        return grouped, summary

    def all(self) -> Sequence[ProcessingSession]:
        return _LazySessions(tuple(self._known_ids), self.sessions)

    def rows(self) -> list[dict[str, object]]:
        summaries = getattr(self.sessions, "list_summaries", None)
        if callable(summaries):
            return list(summaries())
        return [self.row(session) for session in self.all()]

    def enrichment_rows(self) -> list[dict[str, object]]:
        """Resume categorías sin materializar cientos de miles de filas en Qt."""
        labels = {
            "anime": "Anime",
            "anime_vob": "Anime VOB",
            "concurso": "Concursos",
            "concurso_vob": "Concursos VOB",
            "documentary": "Documentales",
            "dorama": "Doramas",
            "dorama_vob": "Doramas VOB",
            "movie": "Películas",
            "movie_vob": "Películas VOB",
            "novela": "Novelas",
            "novela_vob": "Novelas VOB",
            "series": "Series",
            "series_vob": "Series VOB",
            "western_animation": "Animación occidental",
            "western_animation_vob": "Animación occidental VOB",
            "subtitle": "Subtítulos",
            "unsupported_media": "Multimedia no compatible",
            "tv_show": "Programas de TV",
            "other": "Otros",
            "pending_retry": "Pendientes",
            "unclassified": "Sin clasificar",
        }
        rows: list[dict[str, object]] = []
        summaries = getattr(self.sessions, "list_enrichment_summaries", None)
        if callable(summaries):
            for summary in summaries():
                category = str(summary["category"])
                unique_works = int(summary["works"])
                tmdb_categories = {
                    "anime",
                    "anime_vob",
                    "concurso_vob",
                    "documentary",
                    "dorama",
                    "dorama_vob",
                    "episode",
                    "movie",
                    "movie_vob",
                    "novela",
                    "novela_vob",
                    "season",
                    "series",
                    "series_vob",
                    "tv_show",
                    "western_animation",
                    "western_animation_vob",
                    "pending_retry",
                }
                completed = int(summary["completed"])
                rejected = int(summary["rejected"])
                reviews = int(summary["reviews"])
                ready = int(summary["ready"])
                rows.append(
                    {
                        "Sesión": str(summary["session_id"]),
                        "Categoría": labels.get(category, category.replace("_", " ").title()),
                        "Archivos": int(summary["total"]),
                        "Obras": unique_works,
                        "Listos": ready,
                        "Inciertos": int(summary["uncertain"]),
                        "TMDb": unique_works if category in tmdb_categories else 0,
                        "AniList": (
                            unique_works
                            if category in {"anime", "anime_vob", "pending_retry"}
                            else 0
                        ),
                        "TVMaze": (
                            unique_works
                            if category
                            in {
                                "series",
                                "series_vob",
                                "episode",
                                "season",
                                "novela",
                                "novela_vob",
                                "dorama",
                                "dorama_vob",
                                "concurso",
                                "concurso_vob",
                                "tv_show",
                                "pending_retry",
                            }
                            else 0
                        ),
                        "Estado": (
                            "lista"
                            if ready
                            else "revisión pendiente"
                            if reviews
                            else "completada"
                            if completed or rejected
                            else "sin elementos elegibles"
                        ),
                        "_categoría": category,
                        "_sesión": str(summary["session_id"]),
                        "_banco": str(summary.get("bank") or "—"),
                        "_estado_sesión": str(summary.get("session_status") or ""),
                        "_enriquecidos": completed,
                    }
                )
            return self._consolidate_enrichment_rows(rows)
        sessions = (
            (self.sessions.get(self._focused_id),)
            if hasattr(self.sessions, "list_summaries") and self._focused_id
            else ()
            if hasattr(self.sessions, "list_summaries")
            else self.all()
        )
        for session in sessions:
            if session is None:
                continue
            categories: dict[str, Counter[str]] = {}
            works_by_category: dict[str, set[str]] = {}
            for item in session.items:
                category = enrichment_category(item)
                counts = categories.setdefault(category, Counter())
                counts["total"] += 1
                works_by_category.setdefault(category, set()).add(
                    item.work_group_id or item.item_id
                )
                if item.stage is ProcessingStage.READY_FOR_ENRICHMENT:
                    counts["listos"] += 1
                if item.classification_status in {
                    "classification_uncertain",
                    "unclassified",
                }:
                    counts["inciertos"] += 1
                if item.enrichment_status == "enrichment_complete":
                    counts["terminados"] += 1
                elif item.enrichment_status == "review_rejected":
                    counts["rechazados"] += 1
                elif item.enrichment_status == "needs_human_review":
                    counts["revisiones"] += 1
            for category, counts in sorted(categories.items()):
                unique_works = len(works_by_category[category])
                tmdb_categories = {
                    "anime",
                    "anime_vob",
                    "concurso_vob",
                    "documentary",
                    "dorama",
                    "dorama_vob",
                    "episode",
                    "movie",
                    "movie_vob",
                    "novela",
                    "novela_vob",
                    "season",
                    "series",
                    "series_vob",
                    "tv_show",
                    "western_animation",
                    "western_animation_vob",
                    "pending_retry",
                }
                tmdb_queries = unique_works if category in tmdb_categories else 0
                anilist_queries = (
                    unique_works
                    if category in {"anime", "anime_vob", "pending_retry"}
                    else 0
                )
                tvmaze_queries = (
                    unique_works
                    if category
                    in {
                        "series",
                        "series_vob",
                        "episode",
                        "season",
                        "novela",
                        "novela_vob",
                        "dorama",
                        "dorama_vob",
                        "concurso",
                        "concurso_vob",
                        "tv_show",
                        "pending_retry",
                    }
                    else 0
                )
                rows.append(
                    {
                        "Categoría": labels.get(category, category.replace("_", " ").title()),
                        "Archivos": counts["total"],
                        "Obras": unique_works,
                        "Listos": counts["listos"],
                        "Inciertos": counts["inciertos"],
                        "TMDb": tmdb_queries,
                        "AniList": anilist_queries,
                        "TVMaze": tvmaze_queries,
                        "Estado": (
                            "lista"
                            if counts["listos"]
                            else "revisión pendiente"
                            if counts["revisiones"]
                            else "completada"
                            if counts["terminados"] or counts["rechazados"]
                            else "sin elementos elegibles"
                        ),
                        "_categoría": category,
                        "_sesión": session.session_id,
                        "_banco": session.bank_name or "—",
                        "_estado_sesión": session.status.value,
                        "_enriquecidos": counts["terminados"],
                    }
                )
        return self._consolidate_enrichment_rows(rows)

    def catalog_completion(self) -> dict[str, int]:
        """Devuelve cobertura estricta por obra logica para el indicador visual."""
        persisted = getattr(self.sessions, "catalog_completion_summary", None)
        if callable(persisted):
            return dict(persisted())
        groups: dict[tuple[str, str], set[str]] = {}
        eligible = {
            "movie",
            "movie_vob",
            "series",
            "series_vob",
            "novela",
            "novela_vob",
            "dorama",
            "dorama_vob",
            "anime",
            "anime_vob",
            "concurso",
            "concurso_vob",
            "western_animation",
            "western_animation_vob",
        }
        for session in self.all():
            for item in session.items:
                if enrichment_category(item) not in eligible:
                    continue
                key = (session.session_id, item.work_group_id or item.item_id)
                groups.setdefault(key, set()).add(item.enrichment_status)
        processed = sum(
            bool(statuses & {"enrichment_complete", "review_rejected", "needs_human_review"})
            for statuses in groups.values()
        )
        resolved = sum(
            bool(statuses & {"enrichment_complete", "review_rejected"})
            for statuses in groups.values()
        )
        review = sum(
            "needs_human_review" in statuses
            and not statuses & {"enrichment_complete", "review_rejected"}
            for statuses in groups.values()
        )
        return {
            "total": len(groups),
            "processed": processed,
            "resolved": resolved,
            "review": review,
        }

    @staticmethod
    def _consolidate_enrichment_rows(
        rows: list[dict[str, object]],
    ) -> list[dict[str, object]]:
        """Presenta una fila por categoria sin perder los destinos tecnicos."""
        categories = (
            ("movie", "Películas"),
            ("movie_vob", "Películas VOB"),
            ("series", "Series"),
            ("series_vob", "Series VOB"),
            ("novela", "Novelas"),
            ("novela_vob", "Novelas VOB"),
            ("dorama", "Doramas"),
            ("dorama_vob", "Doramas VOB"),
            ("anime", "Anime"),
            ("anime_vob", "Anime VOB"),
            ("concurso", "Concursos"),
            ("concurso_vob", "Concursos VOB"),
            ("western_animation", "Animados"),
            ("western_animation_vob", "Animados VOB"),
            ("pending_retry", "Pendientes"),
        )
        consolidated: list[dict[str, object]] = []
        for category, label in categories:
            matching = [row for row in rows if row.get("_categoría") == category]
            ready = sum(cast(int, row.get("Listos", 0)) for row in matching)
            completed = sum(cast(int, row.get("_enriquecidos", 0)) for row in matching)
            reviews = sum(cast(int, row.get("Inciertos", 0)) for row in matching)
            works = sum(cast(int, row.get("Obras", 0)) for row in matching)
            resolved = any(
                str(row.get("Estado", "")).casefold() == "completada" for row in matching
            )
            targets = tuple(
                {
                    "session_id": str(row.get("_sesión", "")),
                    "category": category,
                    "bank": str(row.get("_banco", "—")),
                    "status": str(row.get("_estado_sesión", "")),
                    "ready": cast(int, row.get("Listos", 0)),
                }
                for row in matching
            )
            banks = sorted({str(target["bank"]) for target in targets})
            consolidated.append(
                {
                    "Categoría": label,
                    "Obras": works,
                    "Archivos": sum(cast(int, row.get("Archivos", 0)) for row in matching),
                    "Listos": ready,
                    "Enriquecidos": completed,
                    "Pendientes": reviews,
                    "Consultas máximas": works,
                    "Preparación": (
                        f"Guardada · {len(targets)} sesión(es)" if targets else "No preparada"
                    ),
                    "TMDb": sum(cast(int, row.get("TMDb", 0)) for row in matching),
                    "AniList": sum(cast(int, row.get("AniList", 0)) for row in matching),
                    "TVMaze": sum(cast(int, row.get("TVMaze", 0)) for row in matching),
                    "Estado": (
                        "Lista para enriquecer"
                        if ready
                        else "Revisión pendiente"
                        if reviews
                        else "Completada"
                        if completed
                        else "completada"
                        if resolved
                        else "sin elementos elegibles"
                    ),
                    "Sesiones incluidas": len(targets),
                    "Bancos": ", ".join(banks) or "—",
                    "_categoría": category,
                    "_sesión": str(targets[0]["session_id"]) if targets else "",
                    "_banco": ", ".join(banks) or "—",
                    "_targets": targets,
                    "_enriquecidos": completed,
                }
            )
        return consolidated

    def resolve_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        approved: bool,
    ) -> ProcessingSession:
        """Cierra todos los archivos representados por una revisión agrupada."""
        session = self.sessions.get(session_id)
        if session is None:
            raise KeyError(session_id)
        targets = frozenset(item_ids)
        changed = tuple(
            replace(
                item,
                stage=ProcessingStage.CONSOLIDATED,
                status=SessionItemStatus.COMPLETED,
                warning=None if approved else "rechazado en revisión humana",
                enrichment_status=("enrichment_complete" if approved else "review_rejected"),
            )
            if item.item_id in targets
            else item
            for item in session.items
        )
        session = self.service.apply_review_resolution(session_id, changed)
        self.checkpoints.save(session)
        return session

    def annotate_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str | None = None,
        lock_title: bool = False,
    ) -> ProcessingSession:
        return self.service.apply_human_annotation(
            session_id,
            item_ids,
            corrected_title=corrected_title,
            lock_title=lock_title,
        )

    def requeue_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str,
    ) -> ProcessingSession:
        """Reabre solo el grupo corregido para una nueva identificacion."""
        session = self.service.requeue_review_items(
            session_id,
            item_ids,
            corrected_title=corrected_title,
        )
        self.checkpoints.save(session)
        return session

    def reprepare_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str,
    ) -> ProcessingSession:
        """Persiste la propuesta limpia sin sacarla de revision humana."""
        session = self.service.reprepare_review_items(
            session_id, item_ids, corrected_title=corrected_title
        )
        self.checkpoints.save(session)
        return session

    @staticmethod
    def suggest_review_title(value: str) -> str:
        """Obtiene la propuesta de limpieza local para revision humana."""
        return LocalPreparationService().suggest_review_title(value)

    def reprepare_review_items_bulk(
        self, session_id: str, corrected_titles: dict[str, str]
    ) -> ProcessingSession:
        return self.service.reprepare_review_items_bulk(session_id, corrected_titles)

    def revalidate_review_items_bulk(
        self,
        session_id: str,
        corrected_titles: dict[str, str],
        canonical_group_ids: dict[str, str] | None = None,
    ) -> ProcessingSession:
        return self.service.revalidate_review_items_bulk(
            session_id,
            corrected_titles,
            canonical_group_ids,
        )

    @staticmethod
    def suggest_review_title_from_evidence(
        value: str,
        *,
        original_name: str | None = None,
        original_path: str | None = None,
    ) -> str:
        return LocalPreparationService().suggest_review_title_from_evidence(
            value,
            original_name=original_name,
            original_path=original_path,
        )

    @staticmethod
    def row(session: ProcessingSession) -> dict[str, object]:
        stage_order = list(ProcessingStage)
        stage = (
            max(session.items, key=lambda item: stage_order.index(item.stage)).stage
            if session.items
            else ProcessingStage.IMPORTED
        )
        summary = session.summary
        return {
            "sesión": session.session_id,
            "estado": session.status.value,
            "progreso": f"{summary.percent:.1f} %",
            "etapa": stage.value,
            "elementos": len(session.items),
            "completados": summary.completed,
            "avisos": summary.warning,
            "errores": summary.failed,
            "importación": str(session.import_id),
            "banco": session.bank_name or "—",
        }


class _LazySessions(Sequence[ProcessingSession]):
    """Vista que evita materializar simultáneamente todos los inventarios."""

    def __init__(self, identifiers: tuple[str, ...], repository: Any) -> None:
        self._identifiers = identifiers
        self._repository = repository

    def __len__(self) -> int:
        return len(self._identifiers)

    @overload
    def __getitem__(self, index: int) -> ProcessingSession: ...

    @overload
    def __getitem__(self, index: slice) -> Sequence[ProcessingSession]: ...

    def __getitem__(self, index: int | slice) -> ProcessingSession | Sequence[ProcessingSession]:
        if isinstance(index, slice):
            return tuple(self[position] for position in range(*index.indices(len(self))))
        session = cast(ProcessingSession | None, self._repository.get(self._identifiers[index]))
        if session is None:
            raise IndexError(index)
        return session

    def __iter__(self) -> Iterator[ProcessingSession]:
        for identifier in self._identifiers:
            session = self._repository.get(identifier)
            if session is not None:
                yield session


class ReviewPresenter:
    """Traduce decisiones visuales a casos de uso de revisión auditables."""

    def __init__(self, service: Any) -> None:
        self.service = service

    def decide(self, review_id: str, action: str, value: str | None = None) -> Any:
        if action == "Aprobar":
            return self.service.approve_candidate(review_id, "desktop-user")
        if action == "Rechazar":
            return self.service.reject_candidate(review_id, "desktop-user")
        if action == "Corregir":
            item = self.service.get_review_details(review_id)
            return self.service.correct_metadata(
                review_id,
                "title",
                value,
                item.fields["title"].provenance,
                "desktop-user",
                "corrección visual",
            )
        if action == "Limpiar y reintentar":
            return self.service.get_review_details(review_id)
        if action == "Bloquear":
            return self.service.lock_field(review_id, "title", "desktop-user")
        raise ValueError(f"acción de revisión desconocida: {action}")

    def decide_many(self, review_ids: tuple[str, ...], action: str) -> tuple[Any, ...]:
        from mce.application.enrichment.models import ReviewItemStatus

        status = (
            ReviewItemStatus.APPROVED
            if action == "Aprobar"
            else ReviewItemStatus.REJECTED
            if action == "Rechazar"
            else None
        )
        if status is None:
            raise ValueError("la operación masiva solo admite aprobar o rechazar")
        return cast(
            tuple[Any, ...],
            self.service.decide_many(review_ids, status, "desktop-user"),
        )

    @staticmethod
    def catalog_row(item: Any) -> dict[str, object]:
        fields = item.fields
        return {
            "archivo": item.candidate_reference,
            "título": fields["title"].value,
            "título original": "—",
            "año": fields["year"].value if "year" in fields else None,
            "tipo": fields["type"].value,
            "banco": fields["bank"].value,
            "disponibilidad": "available",
            "ruta": fields["path"].value,
            "_file_id": item.candidate_reference,
            "_content_id": f"manual:{item.review_id}",
            "_source_id": fields["source_id"].value,
            "_installation_id": fields["installation_id"].value,
            "_original_name": fields["original_name"].value,
            "_size_bytes": fields["size_bytes"].value,
            "_file_hash": fields["file_hash"].value,
        }
