"""Catálogo PDF por categorías con carátulas HTTPS controladas."""

from __future__ import annotations

import hashlib
import ipaddress
import socket
from collections import defaultdict
from collections.abc import Callable, Iterable, Mapping
from pathlib import Path
from typing import ClassVar
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from PySide6.QtCore import QMarginsF, QRect, QRectF, Qt
from PySide6.QtGui import QFont, QImage, QPageLayout, QPageSize, QPainter, QPdfWriter

ArtworkLoader = Callable[[str], QImage | None]


class SafeArtworkCache:
    """Descarga imágenes públicas HTTPS acotadas y las reutiliza localmente."""

    def __init__(self, directory: Path, *, max_bytes: int = 5 * 1024 * 1024) -> None:
        self.directory = directory.resolve()
        self.max_bytes = max_bytes
        self.directory.mkdir(parents=True, exist_ok=True)

    def load(self, url: str) -> QImage | None:
        if not self._public_https(url):
            return None
        target = self.directory / f"{hashlib.sha256(url.encode()).hexdigest()}.img"
        if target.is_file() and not target.is_symlink():
            image = QImage.fromData(target.read_bytes())
            return image if not image.isNull() else None
        try:
            request = Request(url, headers={"User-Agent": "MCE-Desktop/0.12"})
            with urlopen(request, timeout=6) as response:
                final_url = response.geturl()
                if not self._public_https(final_url):
                    return None
                content_type = response.headers.get_content_type()
                if not content_type.startswith("image/"):
                    return None
                data = response.read(self.max_bytes + 1)
        except (OSError, ValueError):
            return None
        if len(data) > self.max_bytes:
            return None
        image = QImage.fromData(data)
        if image.isNull():
            return None
        temporary = target.with_suffix(".tmp")
        temporary.write_bytes(data)
        temporary.replace(target)
        return image

    @staticmethod
    def _public_https(url: str) -> bool:
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            return False
        try:
            addresses = socket.getaddrinfo(parsed.hostname, parsed.port or 443)
        except OSError:
            return False
        for address in addresses:
            ip = ipaddress.ip_address(address[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                return False
        return True


class PdfCatalogExporter:
    """Genera un PDF A4 legible sin modificar las filas del catálogo."""

    CATEGORY_ORDER = (
        "Anime",
        "Novelas",
        "Películas",
        "Series",
        "Temporadas",
        "Episodios",
        "Otros o sin clasificar",
    )
    CATEGORY_LABELS: ClassVar[dict[str, str]] = {
        "anime": "Anime",
        "novel": "Novelas",
        "novela": "Novelas",
        "movie": "Películas",
        "pelicula": "Películas",
        "series": "Series",
        "tv": "Series",
        "season": "Temporadas",
        "episode": "Episodios",
    }

    def __init__(self, artwork_loader: ArtworkLoader | None = None) -> None:
        self.artwork_loader = artwork_loader or (lambda _url: None)

    def export(self, rows: Iterable[Mapping[str, object]], destination: Path) -> int:
        if destination.is_symlink() or destination.suffix.casefold() != ".pdf":
            raise ValueError("PDF destination must be a regular .pdf path")
        target = destination.resolve()
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(".pdf.tmp")
        grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
        count = 0
        for row in rows:
            raw_type = str(row.get("tipo") or row.get("content_type") or "unknown").casefold()
            grouped[self.CATEGORY_LABELS.get(raw_type, "Otros o sin clasificar")].append(row)
            count += 1
        writer = QPdfWriter(str(temporary))
        writer.setResolution(96)
        writer.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        writer.setPageMargins(QMarginsF(14, 14, 14, 14), QPageLayout.Unit.Millimeter)
        writer.setTitle("Catálogo maestro MCE")
        painter = QPainter(writer)
        if not painter.isActive():
            raise OSError("No se pudo iniciar el generador PDF")
        try:
            page = writer.pageLayout().paintRectPixels(writer.resolution())
            page_number = 1
            y = self._header(painter, page, count, page_number=page_number)
            for category in self.CATEGORY_ORDER:
                category_rows = grouped.get(category, [])
                if not category_rows:
                    continue
                required = 48
                if y + required > page.bottom():
                    writer.newPage()
                    page_number += 1
                    y = self._header(painter, page, count, page_number=page_number, compact=True)
                painter.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
                painter.setPen(Qt.GlobalColor.darkBlue)
                painter.drawText(
                    page.left(), y, page.width(), 28, 0, f"{category} ({len(category_rows)})"
                )
                y += 34
                for row in category_rows:
                    card_height = 190
                    if y + card_height > page.bottom():
                        writer.newPage()
                        page_number += 1
                        y = self._header(
                            painter, page, count, page_number=page_number, compact=True
                        )
                    record_rect = QRectF(page.left(), y, page.width(), card_height)
                    self._draw_record(painter, record_rect, row)
                    y += card_height + 12
        finally:
            painter.end()
        temporary.replace(target)
        return count

    @staticmethod
    def _header(
        painter: QPainter,
        rect: QRect,
        count: int,
        *,
        page_number: int,
        compact: bool = False,
    ) -> int:
        painter.setPen(Qt.GlobalColor.black)
        painter.setFont(QFont("Segoe UI", 20 if not compact else 13, QFont.Weight.Bold))
        painter.drawText(rect.left(), rect.top(), rect.width(), 32, 0, "MCE · Catálogo multimedia")
        painter.setFont(QFont("Segoe UI", 9))
        painter.drawText(
            rect.left(),
            rect.top(),
            rect.width(),
            20,
            Qt.AlignmentFlag.AlignRight,
            f"Página {page_number}",
        )
        painter.drawText(
            rect.left(),
            rect.top() + 34,
            rect.width(),
            20,
            0,
            f"{count} contenidos · agrupados por categoría",
        )
        return rect.top() + (66 if not compact else 54)

    def _draw_record(self, painter: QPainter, rect: QRectF, row: Mapping[str, object]) -> None:
        painter.save()
        painter.setPen(Qt.GlobalColor.lightGray)
        painter.setBrush(Qt.GlobalColor.white)
        painter.drawRoundedRect(rect, 8, 8)
        cover_rect = QRectF(rect.left() + 10, rect.top() + 10, 112, rect.height() - 20)
        cover_url = str(row.get("carátula") or row.get("poster") or "")
        image = self.artwork_loader(cover_url) if cover_url else None
        if image is not None and not image.isNull():
            painter.drawImage(cover_rect, image)
        else:
            painter.setBrush(Qt.GlobalColor.lightGray)
            painter.drawRoundedRect(cover_rect, 5, 5)
            painter.setPen(Qt.GlobalColor.darkGray)
            painter.drawText(cover_rect, Qt.AlignmentFlag.AlignCenter, "Sin carátula")
        text_left = cover_rect.right() + 14
        text_width = rect.right() - text_left - 12
        title = str(row.get("título") or row.get("title") or "Sin título")
        painter.setPen(Qt.GlobalColor.black)
        painter.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        painter.drawText(QRectF(text_left, rect.top() + 12, text_width, 26), title)
        painter.setFont(QFont("Segoe UI", 9))
        details = (
            f"Año: {row.get('año') or '—'}    Tipo: {row.get('tipo') or '—'}\n"
            f"Géneros: {row.get('géneros') or '—'}\n"
            f"Director/creador: {row.get('director') or '—'}\n"
            f"Reparto: {row.get('reparto') or '—'}\n"
            f"Banco: {row.get('banco') or '—'}\n\n"
            f"{row.get('sinopsis') or 'Sin sinopsis disponible.'}"
        )
        painter.drawText(
            QRectF(text_left, rect.top() + 42, text_width, rect.height() - 52),
            Qt.TextFlag.TextWordWrap,
            details,
        )
        painter.restore()
