"""Adaptador visual para detección y resolución reversible de duplicados."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from mce.application.deduplication import (
    CatalogConsolidationService,
    FindDuplicateCandidates,
)
from mce.application.deduplication.models import (
    CatalogContent,
    CatalogFile,
    DuplicateCandidate,
    InMemoryCatalog,
)


class DuplicatePresenter:
    """Mantiene el catálogo operativo de Fase 9 fuera de los widgets Qt."""

    def __init__(self) -> None:
        self.catalog = InMemoryCatalog()
        self.service = CatalogConsolidationService(
            self.catalog, lambda: datetime.now(UTC), lambda: str(uuid4())
        )
        self._candidates: dict[str, DuplicateCandidate] = {}
        self._decisions: dict[str, tuple[str, str | None]] = {}

    def register_catalog_row(self, row: dict[str, object]) -> None:
        file_id = str(row.get("_file_id") or row.get("archivo") or uuid4())
        content_id = str(row.get("_content_id") or f"content:{file_id}")
        title = str(row.get("título") or row.get("titulo") or "Sin título")
        source_id = str(row.get("_source_id") or "unknown-source")
        path = str(row.get("ruta") or "")
        self.catalog.files[file_id] = CatalogFile(
            file_id=file_id,
            bank_id=str(row.get("banco") or "unknown-bank"),
            installation_id=str(row.get("_installation_id") or "unknown-installation"),
            source_id=source_id,
            path=path,
            normalized_path=path.replace("/", "\\").casefold(),
            name=str(row.get("_original_name") or path.rsplit("/", 1)[-1]),
            size_bytes=self._integer(row.get("_size_bytes")),
            file_hash=self._optional_text(row.get("_file_hash")),
            content_id=content_id,
        )
        current = self.catalog.contents.get(content_id)
        file_ids = () if current is None else current.file_ids
        self.catalog.contents[content_id] = CatalogContent(
            content_id,
            title,
            self._integer(row.get("año")),
            file_ids=tuple(dict.fromkeys((*file_ids, file_id))),
        )

    def rows(self) -> list[dict[str, object]]:
        candidates = FindDuplicateCandidates().execute(tuple(self.catalog.files.values()))
        self._candidates = {self._key(item): item for item in candidates}
        rows: list[dict[str, object]] = []
        for key, candidate in self._candidates.items():
            decision, merge_id = self._decisions.get(key, ("pendiente", None))
            rows.append(
                {
                    "id": key,
                    "archivo izquierdo": candidate.left_file_id,
                    "archivo derecho": candidate.right_file_id,
                    "tipo": candidate.duplicate_type.value,
                    "confianza": round(candidate.confidence, 1),
                    "estado": decision,
                    "evidencia": "; ".join(item.detail for item in candidate.evidence),
                    "_merge_id": merge_id or "",
                }
            )
        return rows

    def decide(self, candidate_id: str, action: str) -> None:
        candidate = self._candidates[candidate_id]
        if action == "Combinar":
            left = self.catalog.files[candidate.left_file_id]
            right = self.catalog.files[candidate.right_file_id]
            if left.content_id is None or right.content_id is None:
                raise ValueError("los archivos no tienen contenido asociado")
            if left.content_id == right.content_id:
                self.service.resolve_duplicate(candidate, "desktop-user", "mismo contenido")
                self._decisions[candidate_id] = ("combinado", None)
                return
            merge_id = self.service.merge_content(
                left.content_id, (right.content_id,), "desktop-user"
            )
            self._decisions[candidate_id] = ("combinado", merge_id)
        elif action == "Separar":
            decision, stored_merge_id = self._decisions.get(candidate_id, ("pendiente", None))
            if decision != "combinado" or stored_merge_id is None:
                raise ValueError("el duplicado seleccionado no tiene una fusión reversible")
            self.service.revert_merge(stored_merge_id, "desktop-user")
            self._decisions[candidate_id] = ("separado", None)
        elif action in {"Ignorar", "Posponer"}:
            resolution = "ignorado" if action == "Ignorar" else "pospuesto"
            self.service.resolve_duplicate(candidate, "desktop-user", resolution)
            self._decisions[candidate_id] = (resolution, None)
        elif action != "Evidencia":
            raise ValueError(f"acción de duplicado desconocida: {action}")

    @staticmethod
    def _key(candidate: DuplicateCandidate) -> str:
        return f"{candidate.left_file_id}|{candidate.right_file_id}"

    @staticmethod
    def _integer(value: object) -> int | None:
        return value if isinstance(value, int) and not isinstance(value, bool) else None

    @staticmethod
    def _optional_text(value: object) -> str | None:
        return str(value) if value not in {None, ""} else None
