"""Trabajo fuera del hilo visual con comunicación exclusiva por señales."""

import logging
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

logger = logging.getLogger(__name__)


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(str)
    progress = Signal(int)
    progress_detail = Signal(object)
    finished = Signal()


class TaskRunnable(QRunnable):
    def __init__(self, operation: Callable[[], Any], cancellation_token: Any | None = None) -> None:
        super().__init__()
        self.operation = operation
        self.token = cancellation_token
        self.signals = WorkerSignals()

    @Slot()
    def run(self) -> None:
        try:
            if self.token is not None and self.token.is_cancelled:
                return
            self.signals.progress.emit(5)
            value = self.operation()
            if self.token is None or not self.token.is_cancelled:
                self.signals.progress.emit(100)
                self.signals.result.emit(value)
        except Exception as exc:
            if self.token is not None and self.token.is_cancelled:
                logger.info("event=task_cancelled message=%s", exc)
            else:
                logger.exception("event=task_failed error_type=%s", type(exc).__name__)
            self.signals.error.emit(str(exc))
        finally:
            self.signals.finished.emit()
