"""Interfaz gráfica PySide6 de MCE Desktop."""
