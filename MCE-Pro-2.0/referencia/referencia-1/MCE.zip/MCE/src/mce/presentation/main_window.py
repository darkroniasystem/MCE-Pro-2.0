"""Ventana principal profesional y desacoplada de infraestructura."""

from __future__ import annotations

import hashlib
import logging
import os
import sys
from collections import Counter
from collections.abc import Callable, Iterable
from contextlib import suppress
from datetime import UTC, datetime
from math import ceil
from pathlib import Path
from time import monotonic
from typing import Any, cast
from uuid import uuid4

from PySide6.QtCore import QSettings, QSize, Qt, QThreadPool, QTimer, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QStyle,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)
from sqlalchemy.exc import SQLAlchemyError

from mce.application.dto import (
    ImportResult,
    ProcessingSession,
    ProcessingStage,
    SessionStatus,
    Workspace,
)
from mce.application.enrichment import InMemoryReviewRepository, ReviewService
from mce.application.enrichment.models import MetadataField, ReviewItem
from mce.application.identification import IdentificationService
from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.application.importers import ImportService
from mce.application.operations import ExportFormat, ExportRequest, ExportService
from mce.application.processing import (
    LocalPreparationService,
    ProcessingBatchResult,
    ProcessingProgress,
    SessionPipelineService,
    matches_enrichment_selection,
)
from mce.application.workspaces import CancellationToken, SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)
from mce.domain.value_objects import ConfidenceScore, FieldProvenance, FieldSourceType
from mce.infrastructure.ai_review import SqliteRateLimitStore, create_groq_client
from mce.infrastructure.checkpoints import JsonCheckpointStore
from mce.infrastructure.database.audit_persistence import AuditPersistenceService
from mce.infrastructure.database.diagnostics import (
    inspect_runtime_database_configuration,
    runtime_database_url,
)
from mce.infrastructure.database.metadata_persistence import MetadataPersistenceService
from mce.infrastructure.database.publication import (
    CatalogPublicationService,
    PublicationResult,
)
from mce.infrastructure.local_ai import OllamaQwenAnalyzer, UrllibOllamaTransport
from mce.infrastructure.metadata import MetadataRuntime, ProviderUsage, build_metadata_runtime
from mce.infrastructure.metadata.browser_playwright import (
    BrowserDiagnostic,
    PlaywrightBrowserAutomationBackend,
)
from mce.infrastructure.operations import (
    BackupResult,
    DiagnosticContext,
    DiagnosticPackageService,
    HealthService,
    PostgresBackupService,
    StartupReport,
)
from mce.infrastructure.runtime import RuntimePaths, resource_path
from mce.presentation.duplicate_presenter import DuplicatePresenter
from mce.presentation.pdf_catalog import PdfCatalogExporter, SafeArtworkCache
from mce.presentation.presenters import ImportPresenter, ReviewPresenter, SessionPresenter
from mce.presentation.viewmodels import TableViewModel
from mce.presentation.workers import TaskRunnable

logger = logging.getLogger(__name__)

WEB_PRIORITY_DEFAULTS = {"tavily": 30, "serper": 20, "exa": 10}
_LEGACY_WEB_PRIORITY_DEFAULTS = {"tavily": 10, "serper": 20, "exa": 30}
_WEB_PRIORITY_DEFAULTS_VERSION = 1


def migrate_web_priority_defaults(settings: QSettings) -> None:
    """Aplica una vez el orden medido de Fase P sin pisar valores personalizados."""

    version = cast(
        int,
        settings.value("web/priority_defaults_version", 0, type=int),
    )
    if version >= _WEB_PRIORITY_DEFAULTS_VERSION:
        return
    for provider, optimized in WEB_PRIORITY_DEFAULTS.items():
        key = f"web/{provider}_priority"
        current = (
            cast(int, settings.value(key, type=int))
            if settings.contains(key)
            else None
        )
        if current is None or current == _LEGACY_WEB_PRIORITY_DEFAULTS[provider]:
            settings.setValue(key, optimized)
    settings.setValue("web/priority_defaults_version", _WEB_PRIORITY_DEFAULTS_VERSION)

SECTIONS = (
    "Inicio",
    "Importaciones",
    "Sesiones",
    "Enriquecimiento",
    "Catálogo",
    "Finalización",
    "Pendientes de revisión",
    "Duplicados",
    "Bancos",
    "Fuentes",
    "Historial",
    "Configuración",
    "Diagnóstico",
)
SECTION_LABELS = {
    "Inicio": "Resumen",
    "Importaciones": "1  Importación",
    "Sesiones": "2  Clasificación y limpieza local",
    "Enriquecimiento": "3  Enriquecimiento selectivo",
    "Catálogo": "4  Revisión y vista previa",
    "Finalización": "5  Finalización",
    "Pendientes de revisión": "Revisión humana",
}


def provider_status_is_available(value: str) -> bool:
    """Reconoce estados disponibles aunque incluyan una descripción de función."""
    normalized = value.strip().casefold()
    return normalized == "configurada" or normalized.startswith("disponible sin credenciales")


LIGHT = """
QWidget { background: #f3f6fb; color: #172033; font-family: "Segoe UI"; font-size: 14px; }
QMainWindow, QStackedWidget { background: #f3f6fb; }
QListWidget#navigation { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #111827,stop:1 #172554); color: #cbd5e1; border: 0; padding: 16px 12px; outline: 0; }
QListWidget#navigation::item { height: 46px; padding: 0 16px; margin: 3px 0; border: 1px solid transparent; border-radius: 9px; }
QListWidget#navigation::item:hover { background: rgba(59,130,246,0.18); color: white; border-color: rgba(96,165,250,0.35); }
QListWidget#navigation::item:selected { background: #2563eb; color: white; border-left: 4px solid #93c5fd; font-weight: 700; }
QListWidget#navigation::item:disabled { color: #f8fafc; font-size: 15px; font-weight: 800; border-bottom: 1px solid #334155; border-radius: 0; margin-bottom: 12px; }
QLabel#pageTitle { font-size: 26px; font-weight: 700; color: #0f172a; }
QLabel#pageSubtitle { color: #64748b; font-size: 13px; }
QFrame[card="true"] { background: white; border: 1px solid #e2e8f0; border-radius: 12px; }
QFrame[card="true"] QLabel { background: transparent; }
QLabel#metricValue { background: transparent; color: #0f172a; font-size: 22px; font-weight: 700; }
QLabel#metricLabel { background: transparent; color: #64748b; }
QLabel#brand { background: transparent; color: white; font-size: 19px; font-weight: 800; padding: 8px 14px 18px 14px; }
QLabel#topTitle { background: transparent; color: #0f172a; font-size: 16px; font-weight: 700; }
QLabel[badge="true"] { border-radius: 9px; padding: 3px 9px; font-size: 12px; font-weight: 600; }
QLabel[state="neutral"] { background: #e2e8f0; color: #475569; }
QLabel[state="success"] { background: #dcfce7; color: #166534; }
QLabel[state="warning"] { background: #fef3c7; color: #92400e; }
QLabel[state="error"] { background: #fee2e2; color: #991b1b; }
QLabel#emptyTitle { font-size: 18px; font-weight: 700; color: #334155; }
QLabel#emptyText { color: #64748b; }
QFrame#topBar { background: white; border: 0; border-bottom: 1px solid #e2e8f0; }
QFrame#topBar QLabel { background: transparent; }
QFrame#workflowTabs { background: white; border: 0; border-bottom: 1px solid #e2e8f0; }
QPushButton[workflow="true"] { background: transparent; border: 0; border-radius: 0; padding: 12px 18px; color: #64748b; }
QPushButton[workflow="true"]:hover { background: #eff6ff; color: #1d4ed8; }
QPushButton[workflow="true"][active="true"] { color: #1d4ed8; border-bottom: 3px solid #2563eb; font-weight: 700; }
QFrame[actionGroup="true"] { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; }
QFrame[actionGroup="true"] QLabel { background: transparent; color: #64748b; font-size: 12px; font-weight: 700; }
QLineEdit { background: white; border: 1px solid #cbd5e1; border-radius: 8px; padding: 9px 12px; selection-background-color: #2563eb; }
QLineEdit:focus { border: 2px solid #2563eb; padding: 8px 11px; }
QPushButton { background: white; color: #334155; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 15px; font-weight: 600; }
QPushButton:hover { background: #f8fafc; border-color: #94a3b8; }
QPushButton:pressed { background: #e2e8f0; }
QPushButton:disabled { color: #94a3b8; background: #f1f5f9; border-color: #e2e8f0; }
QPushButton[variant="primary"] { background: #2563eb; color: white; border-color: #2563eb; }
QPushButton[variant="primary"]:hover { background: #1d4ed8; }
QPushButton[variant="danger"] { color: #b91c1c; border-color: #fecaca; background: #fff7f7; }
QTableWidget { background: white; alternate-background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; gridline-color: #edf2f7; selection-background-color: #dbeafe; selection-color: #1e3a8a; }
QHeaderView::section { background: #f8fafc; color: #475569; border: 0; border-bottom: 1px solid #e2e8f0; padding: 10px; font-weight: 600; }
QProgressBar { background: #e2e8f0; border: 0; border-radius: 5px; height: 10px; text-align: center; color: transparent; }
QProgressBar::chunk { background: #2563eb; border-radius: 5px; }
"""
DARK = """
QWidget { background: #0f172a; color: #e5e7eb; font-family: "Segoe UI"; font-size: 14px; }
QMainWindow, QStackedWidget { background: #0f172a; }
QListWidget#navigation { background: qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #080d19,stop:1 #172554); color: #cbd5e1; border: 0; padding: 16px 12px; outline: 0; }
QListWidget#navigation::item { height: 46px; padding: 0 16px; margin: 3px 0; border: 1px solid transparent; border-radius: 9px; }
QListWidget#navigation::item:hover { background: rgba(59,130,246,0.20); color: white; border-color: rgba(96,165,250,0.40); }
QListWidget#navigation::item:selected { background: #2563eb; color: white; border-left: 4px solid #93c5fd; font-weight: 700; }
QListWidget#navigation::item:disabled { color: white; font-size: 15px; font-weight: 800; border-bottom: 1px solid #334155; border-radius: 0; margin-bottom: 12px; }
QLabel#pageTitle { font-size: 26px; font-weight: 700; color: #f8fafc; }
QLabel#pageSubtitle { color: #94a3b8; font-size: 13px; }
QFrame[card="true"] { background: #182230; border: 1px solid #293548; border-radius: 12px; }
QFrame[card="true"] QLabel { background: transparent; }
QLabel#metricValue { background: transparent; color: #f8fafc; font-size: 22px; font-weight: 700; }
QLabel#metricLabel { background: transparent; color: #94a3b8; }
QLabel#brand { background: transparent; color: white; font-size: 19px; font-weight: 800; padding: 8px 14px 18px 14px; }
QLabel#topTitle { background: transparent; font-size: 16px; font-weight: 700; color: #f8fafc; }
QLabel[badge="true"] { border-radius: 9px; padding: 3px 9px; font-size: 12px; font-weight: 600; }
QLabel[state="neutral"] { background: #293548; color: #cbd5e1; }
QLabel[state="success"] { background: #143d2a; color: #86efac; }
QLabel[state="warning"] { background: #493515; color: #fde68a; }
QLabel[state="error"] { background: #481d24; color: #fecaca; }
QLabel#emptyTitle { font-size: 18px; font-weight: 700; color: #e2e8f0; }
QLabel#emptyText { color: #94a3b8; }
QFrame#topBar { background: #182230; border: 0; border-bottom: 1px solid #293548; }
QFrame#topBar QLabel { background: transparent; }
QFrame#workflowTabs { background: #182230; border: 0; border-bottom: 1px solid #293548; }
QPushButton[workflow="true"] { background: transparent; border: 0; border-radius: 0; padding: 12px 18px; color: #94a3b8; }
QPushButton[workflow="true"]:hover { background: #1e293b; color: #dbeafe; }
QPushButton[workflow="true"][active="true"] { color: #93c5fd; border-bottom: 3px solid #3b82f6; font-weight: 700; }
QFrame[actionGroup="true"] { background: #141d2b; border: 1px solid #293548; border-radius: 10px; }
QFrame[actionGroup="true"] QLabel { background: transparent; color: #94a3b8; font-size: 12px; font-weight: 700; }
QLineEdit { background: #182230; color: white; border: 1px solid #334155; border-radius: 8px; padding: 9px 12px; }
QLineEdit:focus { border: 2px solid #60a5fa; padding: 8px 11px; }
QPushButton { background: #1e293b; color: #e2e8f0; border: 1px solid #3b4a61; border-radius: 8px; padding: 8px 15px; font-weight: 600; }
QPushButton:hover { background: #293548; border-color: #64748b; }
QPushButton:disabled { color: #64748b; background: #172033; border-color: #293548; }
QPushButton[variant="primary"] { background: #2563eb; color: white; border-color: #2563eb; }
QPushButton[variant="primary"]:hover { background: #3b82f6; }
QPushButton[variant="danger"] { color: #fecaca; border-color: #7f1d1d; background: #32171b; }
QTableWidget { background: #182230; alternate-background-color: #141d2b; color: #e5e7eb; border: 1px solid #293548; border-radius: 10px; gridline-color: #293548; selection-background-color: #1d4ed8; selection-color: white; }
QHeaderView::section { background: #1e293b; color: #cbd5e1; border: 0; border-bottom: 1px solid #334155; padding: 10px; font-weight: 600; }
QProgressBar { background: #293548; border: 0; border-radius: 5px; height: 10px; color: transparent; }
QProgressBar::chunk { background: #3b82f6; border-radius: 5px; }
"""
DESTRUCTIVE_ACTIONS = frozenset(
    {
        "Cancelar",
        "Borrar sesión",
        "Rechazar",
        "Eliminar seleccionado",
        "Combinar",
        "Separar",
    }
)

def expand_grouped_review_rows(
    rows: tuple[dict[str, object], ...],
) -> tuple[dict[str, object], ...]:
    """Recupera los registros originales de una agrupación visual de revisión."""
    expanded: list[dict[str, object]] = []
    for row in rows:
        members = row.get("_grouped_review_rows")
        if isinstance(members, (tuple, list)):
            expanded.extend(dict(cast(dict[str, object], member)) for member in members)
        else:
            expanded.append(dict(row))
    return tuple(expanded)


def group_identical_review_rows(
    rows: tuple[dict[str, object], ...],
) -> tuple[dict[str, object], ...]:
    """Agrupa títulos candidatos idénticos del mismo tipo sin perder registros."""
    originals = expand_grouped_review_rows(rows)
    buckets: dict[tuple[str, str], list[dict[str, object]]] = {}
    order: list[tuple[str, str]] = []
    ungrouped: list[dict[str, object]] = []
    for row in originals:
        title = " ".join(str(row.get("título candidato") or "").split())
        category = str(row.get("tipo") or "").strip().casefold()
        if not title:
            ungrouped.append(dict(row))
            continue
        key = (category, title.casefold())
        if key not in buckets:
            buckets[key] = []
            order.append(key)
        buckets[key].append(dict(row))

    grouped: list[dict[str, object]] = []
    for key in order:
        members = buckets[key]
        leader = dict(members[0])
        if len(members) > 1:
            total_files = 0
            for member in members:
                with suppress(TypeError, ValueError):
                    total_files += int(cast(int | str, member.get("archivos agrupados") or 0))
            leader["archivos agrupados"] = total_files
            leader["obras agrupadas"] = len(members)
            leader["Coincidencia"] = f"{len(members)} registros con título idéntico"
            leader["_grouped_review_rows"] = tuple(members)
        grouped.append(leader)
    grouped.extend(ungrouped)
    return tuple(grouped)


def freeze_review_selection(
    selected_records: tuple[dict[str, object], ...],
) -> tuple[dict[str, object], ...]:
    """Congela una sola fila por obra lógica, conservando el orden visual."""
    unique: dict[str, dict[str, object]] = {}
    for row in selected_records:
        unique.setdefault(str(row.get("id")), dict(row))
    return tuple(unique.values())


def _candidate_identity_tokens(candidate: ProviderCandidate) -> frozenset[str]:
    """Devuelve identidades externas fuertes, nunca títulos aproximados."""
    tokens = {
        f"{candidate.provider.strip().casefold()}:{candidate.external_id.strip().casefold()}"
    }
    tokens.update(
        f"{provider.strip().casefold()}:{external_id.strip().casefold()}"
        for provider, external_id in candidate.external_ids
        if provider.strip() and external_id.strip()
    )
    return frozenset(token for token in tokens if not token.endswith(":"))


def safe_review_candidate(row: dict[str, object]) -> ProviderCandidate | None:
    """Elige candidato solo cuando toda la evidencia converge inequívocamente."""
    raw_candidates = row.get("_candidates")
    candidates = (
        tuple(value for value in raw_candidates if isinstance(value, ProviderCandidate))
        if isinstance(raw_candidates, tuple)
        else ()
    )
    if not candidates:
        existing = row.get("_candidate")
        if isinstance(existing, ProviderCandidate):
            return existing
        ai_state = str(row.get("_ai_review_state") or "")
        ai_score = float(cast(float | int | str, row.get("_ai_score") or 0))
        raw_sources = row.get("_ai_sources")
        ai_sources = tuple(raw_sources) if isinstance(raw_sources, tuple | list) else ()
        raw_contradictions = row.get("_ai_contradictions")
        ai_contradictions = (
            tuple(raw_contradictions)
            if isinstance(raw_contradictions, tuple | list)
            else ()
        )
        title = str(row.get("título candidato") or "").strip()
        if (
            ai_state == "approved_by_ai"
            and ai_score >= 80
            and len(ai_sources) >= 1
            and not ai_contradictions
            and title
        ):
            category = str(row.get("tipo") or "").casefold()
            kind = (
                SearchKind.ANIME
                if category == "anime"
                else SearchKind.SERIES
                if category in {"series", "novela", "dorama", "concurso", "tv_show"}
                else SearchKind.MOVIE
            )
            raw_year = row.get("año pista")
            year = int(raw_year) if isinstance(raw_year, int | float) else None
            external_id = hashlib.sha256(f"{category}|{title}|{year}".encode()).hexdigest()
            return ProviderCandidate(
                "mce-ai",
                external_id,
                kind,
                title,
                year=year,
                source_url=str(ai_sources[0]),
            )
        return None
    if len(candidates) == 1:
        return candidates[0]
    shared_identity = set(_candidate_identity_tokens(candidates[0]))
    for candidate in candidates[1:]:
        shared_identity.intersection_update(_candidate_identity_tokens(candidate))
    if not shared_identity:
        return None
    return max(
        candidates,
        key=lambda candidate: sum(
            bool(value)
            for value in (
                candidate.overview,
                candidate.cast_names or candidate.cast,
                candidate.director or candidate.creators,
                candidate.genres,
                candidate.images,
                candidate.year,
            )
        ),
    )


class ImportPage(QWidget):
    """Previsualiza un JSON MSL sin persistir ni bloquear el hilo visual."""

    validation_completed = Signal(object)
    session_creation_requested = Signal(object, str)

    def __init__(self, presenter: ImportPresenter | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.presenter = presenter or ImportPresenter(ImportService())
        self.pool = QThreadPool.globalInstance()
        self.token: CancellationToken | None = None
        self.worker: TaskRunnable | None = None
        self.last_result: ImportResult | None = None
        self.setAcceptDrops(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)
        title = QLabel("1  Importación y validación")
        title.setObjectName("pageTitle")
        subtitle = QLabel("Valida el archivo antes de crear una sesión de procesamiento.")
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        steps = QHBoxLayout()
        self.step_labels = []
        for index, text in enumerate(
            ("1  Seleccionar", "2  Validar", "3  Revisar", "4  Crear sesión")
        ):
            label = QLabel(text)
            label.setMinimumHeight(28)
            label.setProperty("badge", True)
            label.setProperty("state", "success" if index == 0 else "neutral")
            steps.addWidget(label)
            self.step_labels.append(label)
        steps.addStretch()
        layout.addLayout(steps)
        self.path = QLineEdit()
        self.path.setAccessibleName("Ruta JSON de MSL")
        choose = QPushButton("Seleccionar JSON")
        choose.setToolTip(
            "Abre el explorador para seleccionar un inventario JSON generado por MSL."
        )
        validate = QPushButton("Validar")
        validate.setToolTip(
            "Comprueba estructura, versión, registros e incidencias sin crear una sesión."
        )
        validate.setProperty("variant", "primary")
        self.cancel = QPushButton("Cancelar")
        self.cancel.setToolTip("Solicita detener de forma segura la operación que está en curso.")
        self.create_session = QPushButton("Crear sesión")
        self.create_session.setToolTip(
            "Crea una sesión local con los archivos validados y la muestra en la sección Sesiones."
        )
        self.cancel.setProperty("variant", "danger")
        self.create_session.setProperty("variant", "primary")
        self.cancel.setEnabled(False)
        self.create_session.setEnabled(False)
        self.progress = QProgressBar()
        self.summary = QLabel("Seleccione o arrastre un JSON de MSL")
        self.summary.setWordWrap(True)
        self.file_info = QLabel("Ningún archivo seleccionado")
        self.file_info.setObjectName("pageSubtitle")
        self.file_info.setWordWrap(True)
        bank_row = QHBoxLayout()
        bank_label = QLabel("Nombre del banco")
        bank_label.setMinimumWidth(140)
        self.bank_name = QLineEdit()
        self.bank_name.setAccessibleName("Nombre del banco para el catálogo")
        self.bank_name.setPlaceholderText("Ejemplo: Banco Trocadero 363")
        self.bank_name.setToolTip(
            "Nombre visible que identificará este banco en sesiones, catálogo y PostgreSQL."
        )
        bank_row.addWidget(bank_label)
        bank_row.addWidget(self.bank_name, 1)

        row = QHBoxLayout()
        row.addWidget(self.path)
        row.addWidget(choose)
        row.addWidget(validate)
        layout.addLayout(row)
        layout.addWidget(self.file_info)
        layout.addLayout(bank_row)
        layout.addWidget(self.progress)
        actions = QHBoxLayout()
        actions.addWidget(self.cancel)
        actions.addWidget(self.create_session)
        layout.addLayout(actions)
        summary_card = QFrame()
        summary_card.setProperty("card", True)
        summary_layout = QVBoxLayout(summary_card)
        summary_layout.setContentsMargins(18, 16, 18, 16)
        summary_layout.addWidget(self.summary)
        result_grid = QGridLayout()
        self.result_values = {}
        for index, name in enumerate(
            ("Estado", "Esquema", "Videos", "Subtítulos", "Avisos", "Errores")
        ):
            metric = QFrame()
            metric.setProperty("card", True)
            metric_layout = QVBoxLayout(metric)
            value = QLabel("—")
            value.setObjectName("metricValue")
            label = QLabel(name)
            label.setObjectName("metricLabel")
            label.setWordWrap(True)
            metric_layout.addWidget(value)
            metric_layout.addWidget(label)
            result_grid.addWidget(metric, index // 3, index % 3)
            self.result_values[name] = value
        summary_layout.addLayout(result_grid)
        layout.addWidget(summary_card)
        layout.addStretch()

        choose.clicked.connect(self.choose_file)
        validate.clicked.connect(self.validate_file)
        self.cancel.clicked.connect(self.cancel_work)
        self.create_session.clicked.connect(self.request_session_creation)

    def choose_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleccionar escaneo MSL", filter="JSON (*.json)"
        )
        if path:
            self.path.setText(path)

    def validate_file(self) -> None:
        self.last_result = None
        self.create_session.setEnabled(False)
        self.token = CancellationToken()
        self.cancel.setEnabled(True)
        self.summary.setText("Validando…")
        selected = Path(self.path.text())
        if selected.is_file():
            size_mib = selected.stat().st_size / (1024 * 1024)
            self.file_info.setText(f"{selected.name} · {size_mib:,.1f} MiB")
        self.set_step(1)
        self.worker = TaskRunnable(lambda: self.presenter.validate(self.path.text()), self.token)
        self.worker.signals.progress.connect(self.progress.setValue)
        self.worker.signals.result.connect(self.show_result)
        self.worker.signals.error.connect(self.show_error)
        self.worker.signals.finished.connect(self.finish_work)
        self.pool.start(self.worker)

    def finish_work(self) -> None:
        self.cancel.setEnabled(False)
        self.worker = None

    def show_result(self, result: ImportResult) -> None:
        self.last_result = result
        issues = len(result.issues)
        statistics = result.statistics
        files = statistics.video_files + statistics.subtitle_files
        package = result.package
        schema = package.detected_schema_version if package else "-"
        status = result.status.value
        self.summary.setText(
            f"Estado: {status} | Esquema: {schema} | Archivos: {files} | Incidencias: {issues}"
        )
        if result.issues:
            issue_counts = Counter(issue.code for issue in result.issues)
            first_by_code: dict[str, str] = {}
            for issue in result.issues:
                first_by_code.setdefault(issue.code, issue.message)
            issue_lines = [
                f"{count:,} x {code}: {first_by_code[code]}"
                for code, count in issue_counts.most_common(5)
            ]
            remaining = len(issue_counts) - len(issue_lines)
            if remaining > 0:
                issue_lines.append(f"… y {remaining} tipos de incidencia adicionales")
            self.summary.setText(
                self.summary.text() + "\n\nResumen de incidencias:\n" + "\n".join(issue_lines)
            )
        warnings = getattr(statistics, "warnings", 0)
        errors = getattr(statistics, "errors", 0) + getattr(statistics, "fatal_errors", 0)
        values = {
            "Estado": status.replace("_", " ").title(),
            "Esquema": str(schema),
            "Videos": str(statistics.video_files),
            "Subtítulos": str(statistics.subtitle_files),
            "Avisos": str(warnings),
            "Errores": str(errors),
        }
        for name, value in values.items():
            self.result_values[name].setText(value)
        self.set_step(2 if result.success else 1, error=not result.success)
        if package is not None:
            bank_data = dict(package.scan.bank_data)
            declared_name = str(bank_data.get("name") or bank_data.get("nombre") or "").strip()
            if declared_name:
                self.bank_name.setText(declared_name)
        self.create_session.setEnabled(bool(result.success and package))
        self.validation_completed.emit(result)

    def show_error(self, message: str) -> None:
        self.summary.setText(f"Error: {message}")
        self.set_step(1, error=True)

    def cancel_work(self) -> None:
        if self.token:
            self.token.cancel()
            self.summary.setText("Cancelación solicitada")

    def request_session_creation(self) -> None:
        if self.last_result is not None:
            bank_name = self.bank_name.text().strip()
            if not bank_name:
                self.summary.setText("Escriba el nombre del banco antes de crear la sesión.")
                self.bank_name.setFocus()
                return
            self.set_step(3)
            self.session_creation_requested.emit(self.last_result, bank_name)

    def set_step(self, active: int, error: bool = False) -> None:
        """Actualiza solo la representación del progreso del asistente."""
        for index, label in enumerate(self.step_labels):
            state = (
                "error"
                if error and index == active
                else "success"
                if index <= active
                else "neutral"
            )
            label.setProperty("state", state)
            label.style().unpolish(label)
            label.style().polish(label)

    def dragEnterEvent(self, event: Any) -> None:
        urls = event.mimeData().urls()
        if urls and urls[0].toLocalFile().lower().endswith(".json"):
            event.acceptProposedAction()

    def dropEvent(self, event: Any) -> None:
        self.path.setText(event.mimeData().urls()[0].toLocalFile())
        event.acceptProposedAction()


class SessionProgressPanel(QFrame):
    """Monitor compacto del pipeline con ETA calculada sin bloquear el proceso."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setProperty("card", True)
        self.setVisible(False)
        self.setMinimumHeight(178)
        self._started_at: float | None = None
        self._last: ProcessingProgress | None = None
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(7)
        header = QHBoxLayout()
        self.stage = QLabel("Preparando la sesión")
        self.stage.setObjectName("emptyTitle")
        self.percent = QLabel("0 %")
        self.percent.setObjectName("emptyTitle")
        header.addWidget(self.stage)
        header.addStretch()
        header.addWidget(self.percent)
        layout.addLayout(header)
        self.overall = QProgressBar()
        self.overall.setAccessibleName("Progreso general de la sesión")
        self.overall.setRange(0, 1000)
        self.overall.setFormat("Progreso general")
        layout.addWidget(self.overall)
        stage_row = QHBoxLayout()
        stage_caption = QLabel("Etapa actual")
        stage_caption.setObjectName("pageSubtitle")
        self.stage_progress = QProgressBar()
        self.stage_progress.setAccessibleName("Progreso de la etapa actual")
        self.stage_progress.setRange(0, 100)
        stage_row.addWidget(stage_caption)
        stage_row.addWidget(self.stage_progress, 1)
        layout.addLayout(stage_row)
        metrics = QGridLayout()
        self.processed = QLabel("Lote actual: 0 / 0 obras")
        self.speed = QLabel("Velocidad: calculando…")
        self.elapsed = QLabel("Transcurrido: 0 s")
        self.eta = QLabel("Restante estimado: calculando…")
        self.results = QLabel("Encontrados: 0 · Pendientes: 0 · Errores: 0")
        for label in (self.processed, self.speed, self.elapsed, self.eta, self.results):
            label.setObjectName("pageSubtitle")
        metrics.addWidget(self.processed, 0, 0)
        metrics.addWidget(self.speed, 0, 1)
        metrics.addWidget(self.elapsed, 1, 0)
        metrics.addWidget(self.eta, 1, 1)
        metrics.addWidget(self.results, 2, 0, 1, 2)
        layout.addLayout(metrics)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.refresh_time)

    def begin(self, total: int) -> None:
        self._started_at = monotonic()
        self._last = ProcessingProgress("preparing", "Preparando la sesión", 0, total, 0, 0)
        self.setVisible(True)
        self.timer.start()
        self.update_progress(self._last)

    def update_progress(self, snapshot: ProcessingProgress) -> None:
        self._last = snapshot
        self.stage.setText(snapshot.stage_label)
        self.percent.setText(f"{snapshot.overall_percent:g} %")
        self.overall.setValue(round(snapshot.overall_percent * 10))
        self.stage_progress.setValue(snapshot.stage_percent)
        self.processed.setText(f"Lote actual: {snapshot.processed:,} / {snapshot.total:,} obras")
        self.results.setText(
            f"Encontrados: {snapshot.identified:,} · Pendientes: "
            f"{snapshot.pending_review:,} · Errores: {snapshot.errors:,}"
        )
        self.refresh_time()
        if snapshot.stage in {"completed", "waiting_internet", "cancelled", "failed"}:
            self.timer.stop()

    def set_state(self, stage: str, label: str) -> None:
        current = self._last or ProcessingProgress(stage, label, 0, 0, 0, 0)
        stage_percent = 0 if stage in {"paused", "cancelled", "failed", "waiting_internet"} else 100
        self.update_progress(
            ProcessingProgress(
                stage,
                label,
                current.processed,
                current.total,
                current.overall_percent,
                stage_percent,
                current.identified,
                current.pending_review,
                current.errors,
            )
        )

    def clear(self) -> None:
        self.timer.stop()
        self._started_at = None
        self._last = None
        self.setVisible(False)

    def refresh_time(self) -> None:
        if self._started_at is None or self._last is None:
            return
        seconds = max(0.0, monotonic() - self._started_at)
        self.elapsed.setText(f"Transcurrido: {self._duration(seconds)}")
        speed = self._last.processed / seconds if seconds >= 0.5 else 0.0
        self.speed.setText(
            f"Velocidad: {speed:,.1f} registros/s" if speed else "Velocidad: calculando…"
        )
        if self._last.stage == "cancelled":
            self.eta.setText("Restante estimado: procesamiento cancelado")
        elif self._last.stage == "failed":
            self.eta.setText("Restante estimado: detenido por error")
        elif self._last.stage == "waiting_internet":
            self.eta.setText("Restante estimado: esperando proveedor")
        elif self._last.stage == "paused":
            self.eta.setText("Restante estimado: pausado")
        elif speed and self._last.total > self._last.processed:
            remaining = (self._last.total - self._last.processed) / speed
            self.eta.setText(f"Restante estimado: {self._duration(remaining)} aprox.")
        elif self._last.processed >= self._last.total and self._last.total:
            self.eta.setText("Restante estimado: terminado")
        else:
            self.eta.setText("Restante estimado: calculando…")

    @staticmethod
    def _duration(seconds: float) -> str:
        total = max(0, round(seconds))
        hours, remainder = divmod(total, 3600)
        minutes, secs = divmod(remainder, 60)
        if hours:
            return f"{hours} h {minutes:02d} min"
        if minutes:
            return f"{minutes} min {secs:02d} s"
        return f"{secs} s"


class ProviderUsagePanel(QFrame):
    """Muestra consumo real de APIs sin exponer credenciales ni datos privados."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setProperty("card", True)
        self.setVisible(False)
        self._started_at: float | None = None
        self._groq_available_at: float | None = None
        self._groq_cooldown_known = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        title = QLabel("Uso de proveedores y llamadas")
        title.setObjectName("emptyTitle")
        layout.addWidget(title)
        self.summary = QLabel("Las llamadas recuperadas desde caché no consumen cuota externa.")
        self.summary.setObjectName("pageSubtitle")
        layout.addWidget(self.summary)
        self.groq_status = QLabel("Groq: disponibilidad sin comprobar")
        self.groq_status.setObjectName("pageSubtitle")
        self.groq_status.setAccessibleName("Disponibilidad de Groq")
        layout.addWidget(self.groq_status)
        self.table = QTableWidget()
        self.table.setAccessibleName("Uso y límites de proveedores")
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels(
            [
                "Proveedor",
                "Llamadas",
                "Éxitos",
                "Errores",
                "429",
                "Caché",
                "Restantes",
                "Tokens",
                "Ritmo/min",
                "Detalle",
            ]
        )
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setMaximumHeight(245)
        self.table.setMinimumHeight(155)
        layout.addWidget(self.table)
        self._groq_timer = QTimer(self)
        self._groq_timer.setInterval(1000)
        self._groq_timer.timeout.connect(self._update_groq_countdown)
        self._groq_timer.start()

    def begin(self) -> None:
        self._started_at = monotonic()
        self.setVisible(True)

    def update_usage(self, values: tuple[ProviderUsage, ...]) -> None:
        if self._started_at is None:
            self.begin()
        elapsed_minutes = max((monotonic() - cast(float, self._started_at)) / 60, 1 / 60)
        self.table.setRowCount(len(values))
        total_calls = total_errors = total_cache = 0
        groq_usage: ProviderUsage | None = None
        for row, usage in enumerate(values):
            total_calls += usage.calls
            total_errors += usage.errors
            total_cache += usage.cache_hits
            if usage.name.casefold().startswith("groq"):
                groq_usage = usage
            cells = (
                usage.name,
                str(usage.calls),
                str(usage.successes),
                str(usage.errors),
                str(usage.rate_limited),
                str(usage.cache_hits),
                str(usage.remaining) if usage.remaining is not None else "—",
                (f"{usage.tokens_remaining:,}" if usage.tokens_remaining is not None else "—"),
                f"{usage.calls / elapsed_minutes:.1f}",
                usage.detail or "—",
            )
            for column, value in enumerate(cells):
                self.table.setItem(row, column, QTableWidgetItem(value))
        self.table.resizeColumnsToContents()
        self.summary.setText(
            f"Llamadas externas: {total_calls:,} · Evitadas por caché: "
            f"{total_cache:,} · Errores: {total_errors:,}"
        )
        self._capture_groq_availability(groq_usage)

    def _capture_groq_availability(self, usage: ProviderUsage | None) -> None:
        if usage is None:
            self._groq_available_at = None
            self._groq_cooldown_known = False
            self.groq_status.setText("Groq: no configurado")
            return
        if usage.cooldown_seconds is not None and usage.cooldown_seconds > 0:
            self._groq_available_at = monotonic() + usage.cooldown_seconds
            self._groq_cooldown_known = usage.cooldown_known
        else:
            self._groq_available_at = None
            self._groq_cooldown_known = True
        self._update_groq_countdown()

    def _update_groq_countdown(self) -> None:
        if self._groq_available_at is None:
            if self._groq_cooldown_known:
                self.groq_status.setText("Groq: disponible")
            return
        remaining = max(0, round(self._groq_available_at - monotonic()))
        if remaining <= 0:
            self._groq_available_at = None
            if self._groq_cooldown_known:
                self.groq_status.setText("Groq: disponible · ya puedes reanudar")
            else:
                self.groq_status.setText(
                    "Groq: espera de seguridad cumplida · disponibilidad por confirmar"
                )
            return
        if not self._groq_cooldown_known:
            self.groq_status.setText("Groq: límite desconocido · espera de seguridad activa")
            return
        minutes, seconds = divmod(remaining, 60)
        hours, minutes = divmod(minutes, 60)
        countdown = (
            f"{hours:02d}:{minutes:02d}:{seconds:02d}" if hours else f"{minutes:02d}:{seconds:02d}"
        )
        self.groq_status.setText(f"Groq: esperar {countdown}")


class CatalogCompletionPanel(QFrame):
    """Distingue cobertura de enriquecimiento y catalogo realmente completo."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setProperty("card", True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        header = QHBoxLayout()
        title = QLabel("Completitud real del catálogo")
        title.setObjectName("emptyTitle")
        self.percent = QLabel("0 %")
        self.percent.setObjectName("emptyTitle")
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.percent)
        layout.addLayout(header)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        self.progress.setAccessibleName("Porcentaje real de completitud del catálogo")
        layout.addWidget(self.progress)
        self.detail = QLabel("Esperando el resumen de obras únicas…")
        self.detail.setObjectName("pageSubtitle")
        self.detail.setWordWrap(True)
        layout.addWidget(self.detail)

    def update_summary(self, summary: dict[str, int]) -> None:
        total = max(0, int(summary.get("total", 0)))
        processed = min(total, max(0, int(summary.get("processed", 0))))
        resolved = min(total, max(0, int(summary.get("resolved", 0))))
        review = min(total, max(0, int(summary.get("review", 0))))
        percent = 0.0 if total == 0 else resolved * 100 / total
        coverage = 0.0 if total == 0 else processed * 100 / total
        self.percent.setText(f"{percent:.1f} %")
        self.progress.setValue(round(percent * 10))
        self.progress.setFormat(f"Listo para publicar · {resolved:,} / {total:,} obras")
        self.detail.setText(
            f"Cobertura de enriquecimiento: {coverage:.1f} % · "
            f"Resueltas: {resolved:,} · En revisión: {review:,} · "
            f"Sin procesar: {max(0, total - processed):,}"
        )


class DataPage(QWidget):
    """Tabla paginada reutilizable con búsqueda, detalle y acciones controladas."""

    action_requested = Signal(str, object)

    def __init__(
        self,
        title: str,
        actions: tuple[str, ...] = (),
        parent: QWidget | None = None,
        *,
        subtitle: str = "Consulta, filtra y administra los registros disponibles.",
        category_filters: tuple[tuple[str, str], ...] = (),
        action_groups: tuple[tuple[str, tuple[str, ...]], ...] = (),
        visible_columns: tuple[str, ...] | None = None,
    ):
        super().__init__(parent)
        self.model = TableViewModel()
        self.visible_columns = visible_columns
        self.action_buttons: list[QPushButton] = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)
        heading = QLabel(title)
        heading.setObjectName("pageTitle")
        layout.addWidget(heading)
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("pageSubtitle")
        subtitle_label.setWordWrap(True)
        layout.addWidget(subtitle_label)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar o filtrar")
        self.search.setAccessibleName(f"Buscar en {title}")
        layout.addWidget(self.search)
        if category_filters:
            filter_bar = QHBoxLayout()
            for label, term in category_filters:
                button = QPushButton(label)
                button.setToolTip(f"Muestra solamente la categoría {label}.")
                button.clicked.connect(lambda checked=False, value=term: self.search.setText(value))
                filter_bar.addWidget(button)
            filter_bar.addStretch()
            layout.addLayout(filter_bar)
        self.table = QTableWidget()
        self.table.setAccessibleName(f"Tabla de {title}")
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        content = QHBoxLayout()
        table_column = QVBoxLayout()
        self.empty_state = QFrame()
        self.empty_state.setProperty("card", True)
        self.empty_state.setMinimumHeight(170)
        self.empty_state.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        empty_layout = QVBoxLayout(self.empty_state)
        empty_layout.setContentsMargins(24, 24, 24, 24)
        empty_title = QLabel("Todavía no hay registros")
        empty_title.setObjectName("emptyTitle")
        empty_title.setWordWrap(True)
        empty_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_text = QLabel("Importa un escaneo MSL o ajusta los filtros para comenzar.")
        empty_text.setObjectName("emptyText")
        empty_text.setWordWrap(True)
        empty_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_text.setMinimumHeight(44)
        empty_text.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.MinimumExpanding)
        empty_layout.addWidget(empty_title, alignment=Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(empty_text, alignment=Qt.AlignmentFlag.AlignCenter)
        table_column.addWidget(self.empty_state)
        table_column.addWidget(self.table)
        content.addLayout(table_column, 3)
        detail_card = QFrame()
        detail_card.setProperty("card", True)
        detail_card.setMinimumWidth(235)
        detail_layout = QVBoxLayout(detail_card)
        detail_layout.setContentsMargins(18, 18, 18, 18)
        detail_title = QLabel("Detalles")
        detail_title.setObjectName("emptyTitle")
        detail_layout.addWidget(detail_title)
        self.details = QLabel("Selecciona una fila para consultar sus datos.")
        self.details.setObjectName("pageSubtitle")
        self.details.setWordWrap(True)
        detail_layout.addWidget(self.details)
        copy_details = QPushButton("Copiar detalles")
        copy_details.setToolTip("Copia toda la informacion visible de la fila.")
        copy_details.clicked.connect(lambda: QApplication.clipboard().setText(self.details.text()))
        detail_layout.addWidget(copy_details)
        detail_layout.addStretch()
        content.addWidget(detail_card, 1)
        layout.addLayout(content)
        pager = QHBoxLayout()
        self.previous = QPushButton("Anterior")
        self.previous.setToolTip("Muestra la página anterior de resultados.")
        self.page_label = QLabel("Página 1 de 1")
        self.next = QPushButton("Siguiente")
        self.next.setToolTip("Muestra la página siguiente de resultados.")
        pager.addWidget(self.previous)
        pager.addWidget(self.page_label)
        pager.addWidget(self.next)
        layout.addLayout(pager)
        if action_groups:
            grouped_actions = QHBoxLayout()
            grouped_actions.setSpacing(10)
            for group_name, names in action_groups:
                group = QFrame()
                group.setProperty("actionGroup", True)
                group_layout = QVBoxLayout(group)
                group_layout.setContentsMargins(10, 7, 10, 9)
                group_layout.setSpacing(6)
                group_layout.addWidget(QLabel(group_name))
                group_buttons = QHBoxLayout()
                group_buttons.setSpacing(6)
                for name in names:
                    group_buttons.addWidget(self.action_button(name))
                group_layout.addLayout(group_buttons)
                grouped_actions.addWidget(group)
            grouped_actions.addStretch()
            layout.insertLayout(3, grouped_actions)
        else:
            buttons = QHBoxLayout()
            for name in actions:
                buttons.addWidget(self.action_button(name))
            buttons.addStretch()
            layout.insertLayout(3, buttons)
        self.search.textChanged.connect(self.filter_rows)
        self.table.itemSelectionChanged.connect(self.show_details)
        self.previous.clicked.connect(lambda: self.change_page(-1))
        self.next.clicked.connect(lambda: self.change_page(1))
        self.table.horizontalHeader().sectionClicked.connect(self.sort_by_column)

    def action_button(self, name: str) -> QPushButton:
        button = QPushButton(name)
        self.action_buttons.append(button)
        button.setToolTip(self.action_tooltip(name))
        if name in DESTRUCTIVE_ACTIONS:
            button.setProperty("variant", "danger")
        elif name in {
            "Iniciar",
            "Reanudar",
            "Aprobar",
            "Aprobar todas",
            "Revalidar y completar",
            "Publicar catálogo",
            "Exportar JSON",
        }:
            button.setProperty("variant", "primary")
        button.clicked.connect(lambda checked=False, value=name: self.request_action(value))
        return button

    def set_actions_enabled(self, enabled: bool) -> None:
        """Bloquea las acciones mientras una operación masiva está activa."""
        for button in self.action_buttons:
            button.setEnabled(enabled)

    @staticmethod
    def action_tooltip(action: str) -> str:
        descriptions = {
            "Iniciar": "Inicia el procesamiento de la sesión seleccionada.",
            "Pausar": "Pausa la sesión seleccionada conservando su progreso.",
            "Reanudar": "Continúa una sesión previamente pausada.",
            "Cancelar": "Cancela la sesión seleccionada después de solicitar confirmación.",
            "Borrar sesión": (
                "Archiva lógicamente la sesión; conserva checkpoint, caché y catálogo."
            ),
            "Detalles": "Muestra la información completa de la selección.",
            "Repreparar todos": (
                "Reconstruye y limpia localmente los títulos de todo el filtro actual; "
                "las obras permanecen en revisión."
            ),
            "Revalidar y completar": (
                "Reprocesa solo las obras seleccionadas para completar identidad y metadatos. "
                "No publica el catálogo maestro."
            ),
            "Resolver coincidencias seguras": (
                "Resuelve en lote solo identidades externas inequívocas y omite los casos "
                "dudosos, sin nuevas llamadas."
            ),
            "Aprobar": "Acepta la propuesta seleccionada para continuar el procesamiento.",
            "Aprobar todas": (
                "Acepta en segundo plano todas las obras del filtro actual, no solo la página."
            ),
            "Rechazar": "Descarta la propuesta seleccionada después de confirmar.",
            "Corregir": "Permite registrar una corrección manual controlada.",
            "Bloquear": "Protege la decisión para impedir cambios automáticos posteriores.",
            "Combinar": "Fusiona los duplicados seleccionados después de confirmar.",
            "Separar": "Revierte o separa una agrupación de duplicados.",
            "Ignorar": "Marca la propuesta para no tratarla como duplicado.",
            "Posponer": "Deja la decisión pendiente para una revisión posterior.",
            "Evidencia": "Muestra las señales utilizadas para proponer el duplicado.",
            "Exportar JSON": "Exporta todos los registros visibles a JSON UTF-8 versionado.",
            "Exportar CSV": "Exporta todos los registros visibles a CSV compatible con Excel.",
            "Exportar PDF": ("Genera el catálogo visual por categorías con carátulas disponibles."),
            "Publicar catálogo": (
                "Valida y activa atómicamente una versión completa del catálogo."
            ),
            "Actualizar": "Vuelve a ejecutar las comprobaciones locales de diagnóstico.",
        }
        return descriptions.get(action, f"Ejecuta la acción {action} sobre la selección.")

    def set_rows(self, rows: Iterable[dict[str, Any]]) -> None:
        self.model.rows = list(rows)
        self.model.page = 1
        self.refresh()

    def filter_rows(self, text: str) -> None:
        self.model.query = text
        self.model.page = 1
        self.refresh()

    def change_page(self, offset: int) -> None:
        pages = max(1, ceil(self.model.total / self.model.page_size))
        self.model.page = min(pages, max(1, self.model.page + offset))
        self.refresh()

    def sort_by_column(self, index: int) -> None:
        item = self.table.horizontalHeaderItem(index)
        if item is None:
            return
        column = item.text()
        if self.model.sort_column == column:
            self.model.sort_descending = not self.model.sort_descending
        else:
            self.model.sort_column = column
            self.model.sort_descending = column == "archivos agrupados"
        self.model.page = 1
        self.refresh()

    def refresh(self) -> None:
        rows = self.model.filtered
        self.empty_state.setVisible(not rows)
        self.table.setVisible(bool(rows))
        available = (
            list(dict.fromkeys(key for row in rows for key in row if not key.startswith("_")))
            if rows
            else []
        )
        headers = (
            [key for key in self.visible_columns if key in available]
            if self.visible_columns is not None
            else available
        )
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            for column_index, key in enumerate(headers):
                value = str(row.get(key, ""))
                item = QTableWidgetItem(value)
                item.setToolTip(value)
                self.table.setItem(row_index, column_index, item)
        self.table.resizeColumnsToContents()
        minimum_widths = {
            "tipo": 110,
            "confianza": 115,
            "Coincidencia": 210,
            "archivos agrupados": 155,
            "Obras": 85,
            "Archivos": 90,
            "Listos": 85,
            "Enriquecidos": 120,
            "Pendientes": 105,
            "Consultas máximas": 150,
        }
        for header, minimum in minimum_widths.items():
            if header in headers:
                index = headers.index(header)
                self.table.setColumnWidth(index, max(self.table.columnWidth(index), minimum))
        self.table.horizontalHeader().setStretchLastSection(True)
        if "ubicación del JSON" in headers:
            self.table.setColumnWidth(headers.index("ubicación del JSON"), 360)
        pages = max(1, ceil(self.model.total / self.model.page_size))
        self.page_label.setText(f"Página {self.model.page} de {pages}")
        self.previous.setEnabled(self.model.page > 1)
        self.next.setEnabled(self.model.page < pages)

    def selected_rows(self) -> list[int]:
        return sorted({item.row() for item in self.table.selectedItems()})

    def show_details(self) -> None:
        rows = self.selected_rows()
        if not rows:
            self.details.setText("Selecciona una fila para consultar sus datos.")
            return
        visible = self.model.filtered
        records = [visible[index] for index in rows if index < len(visible)]
        if len(records) == 1:
            self.details.setText(
                "\n".join(
                    f"{key}: {value}"
                    for key, value in records[0].items()
                    if not key.startswith("_")
                )
            )
        else:
            self.details.setText(f"{len(records)} registros seleccionados")

    def request_action(self, action: str) -> None:
        rows = self.selected_rows()
        if action in DESTRUCTIVE_ACTIONS:
            answer = QMessageBox.question(
                self,
                "Confirmar acción",
                f"¿Confirma la acción «{action}» sobre {len(rows)} fila(s)?",
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        self.action_requested.emit(action, rows)


class SettingsPage(QWidget):
    """Preferencias visuales que no contienen decisiones de dominio."""

    theme_requested = Signal(bool)
    groq_test_requested = Signal()
    ollama_test_requested = Signal()
    browser_test_requested = Signal()

    def __init__(self, settings: QSettings, parent: QWidget | None = None):
        super().__init__(parent)
        self.settings = settings
        migrate_web_priority_defaults(settings)
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(14)
        title = QLabel("Configuración")
        title.setObjectName("pageTitle")
        layout.addWidget(title)
        subtitle = QLabel("Personaliza la apariencia de MCE Desktop.")
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        light = QPushButton("Tema claro")
        light.setToolTip("Utiliza colores claros y alto contraste para ambientes iluminados.")
        dark = QPushButton("Tema oscuro")
        dark.setToolTip("Utiliza colores oscuros para reducir el brillo de la pantalla.")
        dark.setProperty("variant", "primary")
        light.clicked.connect(lambda: self.theme_requested.emit(False))
        dark.clicked.connect(lambda: self.theme_requested.emit(True))
        layout.addWidget(light)
        layout.addWidget(dark)
        web_card = QFrame()
        web_card.setProperty("card", True)
        web_layout = QGridLayout(web_card)
        web_layout.addWidget(QLabel("Búsqueda web de último recurso"), 0, 0, 1, 3)
        web_layout.addWidget(QLabel("Proveedor"), 1, 0)
        web_layout.addWidget(QLabel("Activado"), 1, 1)
        web_layout.addWidget(QLabel("Prioridad"), 1, 2)
        self.web_enabled: dict[str, QCheckBox] = {}
        self.web_priority: dict[str, QSpinBox] = {}
        for row, (provider, default_priority) in enumerate(
            (("Tavily", 30), ("Serper", 20), ("Exa", 10)),
            start=2,
        ):
            key = provider.casefold()
            configured = bool(os.environ.get(f"{provider.upper()}_API_KEY", "").strip())
            label = QLabel(f"{provider} · {'clave guardada' if configured else 'sin clave'}")
            enabled = QCheckBox()
            enabled.setChecked(cast(bool, settings.value(f"web/{key}_enabled", True, type=bool)))
            enabled.toggled.connect(
                lambda value, name=key: settings.setValue(f"web/{name}_enabled", value)
            )
            priority = QSpinBox()
            priority.setRange(1, 100)
            priority.setValue(
                cast(
                    int,
                    settings.value(f"web/{key}_priority", default_priority, type=int),
                )
            )
            priority.valueChanged.connect(
                lambda value, name=key: settings.setValue(f"web/{name}_priority", value)
            )
            self.web_enabled[key] = enabled
            self.web_priority[key] = priority
            web_layout.addWidget(label, row, 0)
            web_layout.addWidget(enabled, row, 1)
            web_layout.addWidget(priority, row, 2)
        layout.addWidget(web_card)

        browser_card = QFrame()
        browser_card.setProperty("card", True)
        browser_layout = QGridLayout(browser_card)
        browser_layout.addWidget(QLabel("Navegador de último recurso"), 0, 0, 1, 4)
        self.browser_enabled = QCheckBox("Activar Browser web")
        self.browser_enabled.setChecked(
            cast(bool, settings.value("browser/enabled", False, type=bool))
        )
        self.browser_enabled.toggled.connect(
            lambda value: settings.setValue("browser/enabled", value)
        )
        browser_layout.addWidget(self.browser_enabled, 1, 0, 1, 2)
        self.browser_headless = QCheckBox("Modo Headless")
        self.browser_headless.setChecked(
            cast(bool, settings.value("browser/headless", True, type=bool))
        )
        self.browser_headless.toggled.connect(
            lambda value: settings.setValue("browser/headless", value)
        )
        browser_layout.addWidget(self.browser_headless, 1, 2, 1, 2)

        self.browser_timeout = QDoubleSpinBox()
        self.browser_timeout.setRange(0.1, 300.0)
        self.browser_timeout.setSuffix(" s")
        self.browser_timeout.setValue(
            cast(float, settings.value("browser/timeout", 20.0, type=float))
        )
        self.browser_timeout.valueChanged.connect(
            lambda value: settings.setValue("browser/timeout", value)
        )
        self.browser_concurrency = QSpinBox()
        self.browser_concurrency.setRange(1, 8)
        self.browser_concurrency.setValue(
            cast(int, settings.value("browser/max_concurrency", 1, type=int))
        )
        self.browser_concurrency.valueChanged.connect(
            lambda value: settings.setValue("browser/max_concurrency", value)
        )
        browser_layout.addWidget(QLabel("Tiempo máximo"), 2, 0)
        browser_layout.addWidget(self.browser_timeout, 2, 1)
        browser_layout.addWidget(QLabel("Concurrencia máxima"), 2, 2)
        browser_layout.addWidget(self.browser_concurrency, 2, 3)

        self.browser_delay_min = QSpinBox()
        self.browser_delay_min.setRange(0, 60_000)
        self.browser_delay_min.setSuffix(" ms")
        self.browser_delay_min.setValue(
            cast(int, settings.value("browser/delay_min_ms", 1_000, type=int))
        )
        self.browser_delay_min.valueChanged.connect(
            lambda value: settings.setValue("browser/delay_min_ms", value)
        )
        self.browser_delay_max = QSpinBox()
        self.browser_delay_max.setRange(0, 60_000)
        self.browser_delay_max.setSuffix(" ms")
        self.browser_delay_max.setValue(
            cast(int, settings.value("browser/delay_max_ms", 2_500, type=int))
        )
        self.browser_delay_max.valueChanged.connect(
            lambda value: settings.setValue("browser/delay_max_ms", value)
        )
        browser_layout.addWidget(QLabel("Espera mínima"), 3, 0)
        browser_layout.addWidget(self.browser_delay_min, 3, 1)
        browser_layout.addWidget(QLabel("Espera máxima"), 3, 2)
        browser_layout.addWidget(self.browser_delay_max, 3, 3)

        self.browser_max_results = QSpinBox()
        self.browser_max_results.setRange(1, 20)
        self.browser_max_results.setValue(
            cast(int, settings.value("browser/max_results", 5, type=int))
        )
        self.browser_max_results.valueChanged.connect(
            lambda value: settings.setValue("browser/max_results", value)
        )
        browser_layout.addWidget(QLabel("Resultados máximos"), 4, 0)
        browser_layout.addWidget(self.browser_max_results, 4, 1)
        self.browser_status = QLabel(self.browser_status_text())
        self.browser_status.setWordWrap(True)
        browser_layout.addWidget(self.browser_status, 5, 0, 1, 3)
        test_browser = QPushButton("Probar navegador")
        test_browser.clicked.connect(self.browser_test_requested.emit)
        browser_layout.addWidget(test_browser, 5, 3)
        self.browser_headless.toggled.connect(
            lambda _value: self.browser_status.setText(self.browser_status_text())
        )
        layout.addWidget(browser_card)

        local_card = QFrame()
        local_card.setProperty("card", True)
        local_layout = QVBoxLayout(local_card)
        local_layout.addWidget(QLabel("IA local mediante Ollama"))
        self.ollama_enabled = QCheckBox("Usar Qwen local antes de Groq")
        self.ollama_enabled.setChecked(
            cast(bool, settings.value("ollama/enabled", True, type=bool))
        )
        self.ollama_enabled.toggled.connect(
            lambda value: settings.setValue("ollama/enabled", value)
        )
        local_layout.addWidget(self.ollama_enabled)
        self.ollama_base_url = QLineEdit(
            str(settings.value("ollama/base_url", "http://localhost:11434"))
        )
        self.ollama_base_url.textChanged.connect(
            lambda value: settings.setValue("ollama/base_url", value)
        )
        local_layout.addWidget(QLabel("Dirección local de Ollama"))
        local_layout.addWidget(self.ollama_base_url)
        self.ollama_model = QLineEdit(str(settings.value("ollama/model", "qwen2.5:3b")))
        self.ollama_model.textChanged.connect(
            lambda value: settings.setValue("ollama/model", value)
        )
        local_layout.addWidget(QLabel("Modelo"))
        local_layout.addWidget(self.ollama_model)
        local_grid = QGridLayout()
        self.ollama_timeout = QDoubleSpinBox()
        self.ollama_timeout.setRange(1.0, 600.0)
        self.ollama_timeout.setSuffix(" s")
        self.ollama_timeout.setValue(
            cast(float, settings.value("ollama/timeout", 120.0, type=float))
        )
        self.ollama_timeout.valueChanged.connect(
            lambda value: settings.setValue("ollama/timeout", value)
        )
        self.ollama_concurrency = QSpinBox()
        self.ollama_concurrency.setRange(1, 8)
        self.ollama_concurrency.setValue(
            cast(int, settings.value("ollama/max_concurrency", 1, type=int))
        )
        self.ollama_concurrency.valueChanged.connect(
            lambda value: settings.setValue("ollama/max_concurrency", value)
        )
        local_grid.addWidget(QLabel("Tiempo máximo"), 0, 0)
        local_grid.addWidget(self.ollama_timeout, 0, 1)
        local_grid.addWidget(QLabel("Concurrencia máxima"), 0, 2)
        local_grid.addWidget(self.ollama_concurrency, 0, 3)
        local_layout.addLayout(local_grid)
        self.ollama_status = QLabel(
            f"Servidor: sin comprobar\nModelo: {self.ollama_model.text()}\nEstado: pendiente"
        )
        self.ollama_status.setWordWrap(True)
        local_layout.addWidget(self.ollama_status)
        test_ollama = QPushButton("Probar Ollama y Qwen")
        test_ollama.clicked.connect(self.ollama_test_requested.emit)
        local_layout.addWidget(test_ollama)
        layout.addWidget(local_card)
        ai_card = QFrame()
        ai_card.setProperty("card", True)
        ai_layout = QVBoxLayout(ai_card)
        ai_layout.addWidget(QLabel("Revisión automática mediante Groq"))
        self.groq_enabled = QCheckBox("Activar Groq después de proveedores insuficientes")
        self.groq_enabled.setChecked(cast(bool, settings.value("groq/enabled", True, type=bool)))
        self.groq_enabled.toggled.connect(lambda value: settings.setValue("groq/enabled", value))
        ai_layout.addWidget(self.groq_enabled)
        configured = bool(os.environ.get("GROQ_API_KEY", "").strip())
        self.groq_status = QLabel(
            "GROQ_API_KEY: configurada" if configured else "GROQ_API_KEY: no configurada"
        )
        ai_layout.addWidget(self.groq_status)
        self.groq_primary = QComboBox()
        self.groq_primary.addItems(
            ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.6-27b"]
        )
        self.groq_primary.setCurrentText(
            str(settings.value("groq/primary_model", "openai/gpt-oss-120b"))
        )
        self.groq_primary.currentTextChanged.connect(
            lambda value: settings.setValue("groq/primary_model", value)
        )
        ai_layout.addWidget(QLabel("Modelo principal"))
        ai_layout.addWidget(self.groq_primary)
        self.groq_fallback = QCheckBox("Activar modelo de respaldo")
        self.groq_fallback.setChecked(cast(bool, settings.value("groq/fallback", True, type=bool)))
        self.groq_fallback.toggled.connect(lambda value: settings.setValue("groq/fallback", value))
        ai_layout.addWidget(self.groq_fallback)
        self.groq_test_mode = QCheckBox("Modo de prueba: nunca aprobar automáticamente")
        self.groq_test_mode.setChecked(
            cast(bool, settings.value("groq/test_mode", False, type=bool))
        )
        self.groq_test_mode.toggled.connect(
            lambda value: settings.setValue("groq/test_mode", value)
        )
        ai_layout.addWidget(self.groq_test_mode)
        self.groq_daily_limit = QSpinBox()
        self.groq_daily_limit.setRange(1, 1000)
        self.groq_daily_limit.setValue(
            cast(int, settings.value("groq/daily_limit", 1000, type=int))
        )
        self.groq_daily_limit.valueChanged.connect(
            lambda value: settings.setValue("groq/daily_limit", value)
        )
        ai_layout.addWidget(QLabel("Máximo diario de obras"))
        ai_layout.addWidget(self.groq_daily_limit)
        test_groq = QPushButton("Probar conexión Groq")
        test_groq.clicked.connect(self.groq_test_requested.emit)
        ai_layout.addWidget(test_groq)
        ai_layout.addWidget(QLabel("Gemini: desactivado por incompatibilidad regional"))
        layout.addWidget(ai_card)
        layout.addStretch()
        scroll.setWidget(body)
        outer_layout.addWidget(scroll)

    def browser_status_text(self, diagnostic: BrowserDiagnostic | None = None) -> str:
        mode = "Headless" if self.browser_headless.isChecked() else "Visible"
        if diagnostic is None:
            return (
                f"Playwright: sin comprobar · Chromium: sin comprobar\n"
                f"Modo: {mode} · Estado: pendiente"
            )
        playwright = "OK" if diagnostic.playwright_available else "NO DISPONIBLE"
        chromium = "OK" if diagnostic.chromium_available else "NO DISPONIBLE"
        state = "Disponible" if diagnostic.chromium_available else diagnostic.message
        return (
            f"Playwright: {playwright} · Chromium: {chromium}\n"
            f"Modo: {mode} · Estado: {state}"
        )


class MainWindow(QMainWindow):
    """Shell navegable; todas las operaciones reales se delegan a presentadores."""

    def __init__(
        self,
        settings: QSettings | None = None,
        session_presenter: SessionPresenter | None = None,
        import_presenter: ImportPresenter | None = None,
        metadata_runtime_builder: (
            Callable[[Path, Callable[[], bool]], MetadataRuntime] | None
        ) = None,
        runtime_paths: RuntimePaths | None = None,
        publication_service: CatalogPublicationService | None = None,
        startup_report: StartupReport | None = None,
    ):
        super().__init__()
        self.runtime_paths = runtime_paths or RuntimePaths.discover()
        self._preload_persisted_enrichment = metadata_runtime_builder is None
        self.settings = settings or QSettings("MCE", "Desktop")
        self.session_presenter = session_presenter or self.build_session_presenter()
        self.import_presenter = import_presenter
        self.metadata_cache_path = self.runtime_paths.cache / "metadata_cache.sqlite3"
        self.metadata_runtime_builder = metadata_runtime_builder or (
            lambda path, cancelled: build_metadata_runtime(path, cancelled=cancelled)
        )
        self.metadata_runtime = self.metadata_runtime_builder(
            self.metadata_cache_path, lambda: False
        )
        self.metadata_persistence = (
            None
            if metadata_runtime_builder is not None
            else MetadataPersistenceService.from_runtime_environment()
        )
        self.audit_persistence = (
            None
            if metadata_runtime_builder is not None
            else AuditPersistenceService.from_runtime_environment()
        )
        self.publication_service = (
            publication_service
            if publication_service is not None
            else None
            if metadata_runtime_builder is not None
            else CatalogPublicationService.from_runtime_environment()
        )
        self.export_service = ExportService()
        self.pdf_exporter = PdfCatalogExporter(
            SafeArtworkCache(self.runtime_paths.cache / "artwork").load
        )
        self.health_service = HealthService()
        self.backup_service = PostgresBackupService()
        self.diagnostic_service = DiagnosticPackageService()
        self.startup_report = startup_report
        self.safe_mode = bool(startup_report and startup_report.safe_mode)
        self.session_worker: TaskRunnable | None = None
        self.enrichment_worker: TaskRunnable | None = None
        self.enrichment_rows_loaded = False
        self.last_enrichment_rows: list[dict[str, object]] = []
        self.enrichment_refresh_pending = False
        self.processing_worker: TaskRunnable | None = None
        self.processing_had_error = False
        self.groq_test_worker: TaskRunnable | None = None
        self.ollama_test_worker: TaskRunnable | None = None
        self.browser_test_worker: TaskRunnable | None = None
        self.pending_enrichment_targets: list[tuple[str, frozenset[str]]] = []
        self.pending_local_preparation_sessions: list[str] = []
        self.local_preparation_total = 0
        self.local_preparation_completed = 0
        self.review_worker: TaskRunnable | None = None
        self.publication_worker: TaskRunnable | None = None
        self.operational_worker: TaskRunnable | None = None
        self.processing_token: CancellationToken | None = None
        self.processing_session_id: str | None = None
        self.review_repository = InMemoryReviewRepository()
        self.review_presenter = ReviewPresenter(
            ReviewService(self.review_repository, lambda: datetime.now(UTC))
        )
        self.duplicate_presenter = DuplicatePresenter()
        self.review_rows: list[dict[str, object]] = []
        self.catalog_rows: list[dict[str, object]] = []
        self.review_sessions: dict[str, str] = {}
        self.dashboard_values: dict[str, QLabel] = {}
        self.session_rows: list[dict[str, object]] = []
        self.history_rows: list[dict[str, object]] = []
        self.bank_rows: dict[str, dict[str, object]] = {}
        self.source_rows: dict[str, dict[str, object]] = {}
        self.catalog_completion_summary = {
            "total": 0,
            "processed": 0,
            "resolved": 0,
            "review": 0,
        }
        self.setWindowTitle("MCE Desktop — Media Cleaner & Enrichment")
        self.resize(1600, 900)
        self.setMinimumSize(1280, 720)
        root = QWidget()
        root.setObjectName("applicationRoot")
        self.setCentralWidget(root)
        shell = QVBoxLayout(root)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)
        top_bar = QFrame()
        top_bar.setObjectName("topBar")
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(24, 10, 20, 10)
        self.current_section = QLabel("Inicio")
        self.current_section.setObjectName("topTitle")
        self.current_section.setMinimumWidth(160)
        self.database_badge = QLabel("PostgreSQL · sin comprobar")
        self.database_badge.setToolTip(
            "Estado de PostgreSQL. En esta vista todavía no se ha ejecutado el diagnóstico."
        )
        self.database_badge.setProperty("badge", True)
        self.database_badge.setProperty("state", "warning")
        database_status = inspect_runtime_database_configuration()
        self.database_status = database_status
        postgres_check = next(
            (
                check
                for check in (startup_report.checks if startup_report else ())
                if check.name == "postgresql"
            ),
            None,
        )
        connected = bool(postgres_check and postgres_check.status == "ok")
        if connected:
            self.database_badge.setText("PostgreSQL · catálogo maestro conectado")
        elif database_status.configured:
            self.database_badge.setText("PostgreSQL · configurado, sin conexión")
        else:
            self.database_badge.setText("PostgreSQL · sin configurar")
        self.database_badge.setProperty("state", "success" if connected else "error")
        self.metadata_badge = QLabel()
        self.metadata_badge.setProperty("badge", True)
        self.refresh_metadata_badge()
        self.activity_badge = QLabel("Sin tareas activas")
        self.activity_badge.setToolTip("Muestra la operación que MCE está ejecutando actualmente.")
        self.activity_badge.setProperty("badge", True)
        self.activity_badge.setProperty("state", "neutral")
        self.theme_button = QPushButton("◐")
        self.theme_button.setFixedSize(38, 34)
        self.theme_button.setToolTip("Alterna inmediatamente entre el tema claro y el oscuro.")
        self.settings_button = QPushButton()
        self.settings_button.setIcon(
            self.style().standardIcon(QStyle.StandardPixmap.SP_FileDialogContentsView)
        )
        self.settings_button.setFixedSize(38, 34)
        self.settings_button.setAccessibleName("Configuración")
        self.settings_button.setToolTip("Abre la configuración de MCE Desktop.")
        top_layout.addWidget(self.current_section)
        top_layout.addStretch()
        top_layout.addWidget(self.activity_badge)
        top_layout.addWidget(self.metadata_badge)
        top_layout.addWidget(self.database_badge)
        top_layout.addWidget(self.theme_button)
        top_layout.addWidget(self.settings_button)
        shell.addWidget(top_bar)
        workflow_bar = QFrame()
        workflow_bar.setObjectName("workflowTabs")
        workflow_layout = QHBoxLayout(workflow_bar)
        workflow_layout.setContentsMargins(18, 0, 18, 0)
        workflow_layout.setSpacing(2)
        self.workflow_buttons: dict[str, QPushButton] = {}
        for section in (
            "Importaciones",
            "Sesiones",
            "Enriquecimiento",
            "Catálogo",
            "Finalización",
        ):
            button = QPushButton(SECTION_LABELS[section])
            button.setProperty("workflow", True)
            button.setProperty("active", False)
            button.setToolTip(self.section_tooltip(section))
            button.clicked.connect(lambda checked=False, value=section: self.navigate_to(value))
            workflow_layout.addWidget(button)
            self.workflow_buttons[section] = button
        workflow_layout.addStretch()
        shell.addWidget(workflow_bar)
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        self.navigation = QListWidget()
        self.navigation.setObjectName("navigation")
        self.navigation.setAccessibleName("Navegación principal")
        self.navigation.setFixedWidth(210)
        self.navigation.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.navigation.setIconSize(QSize(22, 22))
        brand = QListWidgetItem("MCE DESKTOP")
        brand.setFlags(Qt.ItemFlag.NoItemFlags)
        self.navigation.addItem(brand)
        icon_map = (
            QStyle.StandardPixmap.SP_DesktopIcon,
            QStyle.StandardPixmap.SP_DialogOpenButton,
            QStyle.StandardPixmap.SP_MediaPlay,
            QStyle.StandardPixmap.SP_BrowserReload,
            QStyle.StandardPixmap.SP_DirHomeIcon,
            QStyle.StandardPixmap.SP_DialogApplyButton,
            QStyle.StandardPixmap.SP_MessageBoxWarning,
            QStyle.StandardPixmap.SP_FileDialogDetailedView,
            QStyle.StandardPixmap.SP_DriveHDIcon,
            QStyle.StandardPixmap.SP_DirIcon,
            QStyle.StandardPixmap.SP_FileDialogInfoView,
            QStyle.StandardPixmap.SP_FileDialogContentsView,
            QStyle.StandardPixmap.SP_ComputerIcon,
        )
        for section, standard_icon in zip(SECTIONS, icon_map, strict=True):
            item = QListWidgetItem(
                self.style().standardIcon(standard_icon), SECTION_LABELS.get(section, section)
            )
            item.setToolTip(self.section_tooltip(section))
            self.navigation.addItem(item)
            item.setHidden(
                section
                in {
                    "Importaciones",
                    "Sesiones",
                    "Enriquecimiento",
                    "Catálogo",
                    "Finalización",
                    "Configuración",
                }
            )
        self.stack = QStackedWidget()
        body.addWidget(self.navigation)
        body.addWidget(self.stack, 1)
        shell.addLayout(body, 1)

        self.pages: dict[str, QWidget] = {}
        self._add("Inicio", self.dashboard())
        import_page = ImportPage(self.import_presenter)
        import_page.session_creation_requested.connect(self.create_session)
        import_page.validation_completed.connect(self.import_validated)
        self._add("Importaciones", import_page)
        actions = {
            "Sesiones": (
                "Preparar local",
                "Preparar todas",
                "Pausar",
                "Reanudar",
                "Cancelar",
                "Borrar sesión",
                "Detalles",
            ),
            "Enriquecimiento": ("Enriquecer online", "Pausar", "Reanudar", "Detalles"),
            "Pendientes de revisión": (
                "Eliminar seleccionado",
                "Agrupar obras idénticas",
                "Repreparar todos",
                "Revalidar y completar",
                "Resolver coincidencias seguras",
            ),
            "Duplicados": ("Combinar", "Separar", "Ignorar", "Posponer", "Evidencia"),
            "Catálogo": ("Exportar PDF", "Exportar JSON", "Exportar CSV"),
            "Finalización": (
                "Publicar catálogo",
                "Exportar PDF",
                "Exportar JSON",
                "Exportar CSV",
            ),
            "Bancos": ("Exportar JSON", "Exportar CSV"),
            "Fuentes": ("Exportar JSON", "Exportar CSV"),
            "Historial": ("Exportar JSON", "Exportar CSV"),
            "Diagnóstico": (
                "Actualizar",
                "Crear backup",
                "Restaurar backup",
                "Generar paquete",
                "Exportar JSON",
            ),
        }
        for section in SECTIONS[2:]:
            if section == "Configuración":
                settings_page = SettingsPage(self.settings)
                settings_page.theme_requested.connect(self.set_theme)
                settings_page.groq_test_requested.connect(self.test_groq_connection)
                settings_page.ollama_test_requested.connect(self.test_ollama_connection)
                settings_page.browser_test_requested.connect(self.test_browser_connection)
                self._add(section, settings_page)
            else:
                subtitles = {
                    "Sesiones": (
                        "Clasifica y limpia primero sin Internet. El enriquecimiento online "
                        "se inicia después y solo para elementos preparados."
                    ),
                    "Enriquecimiento": (
                        "Consulta proveedores solo para las categorías ya clasificadas y "
                        "limpias que decidas enriquecer."
                    ),
                    "Catálogo": (
                        "Comprueba cómo quedará el catálogo antes de exportarlo o publicarlo."
                    ),
                    "Finalización": (
                        "Revisa cantidades por categoría y genera las salidas finales aprobadas."
                    ),
                }
                filters = (
                    (
                        ("Todos", ""),
                        ("Anime", "anime"),
                        ("Animados", "western_animation"),
                        ("Concursos", "concurso"),
                        ("Doramas", "dorama"),
                        ("Novelas", "novela"),
                        ("Películas", "movie"),
                        ("Series", "series"),
                    )
                    if section == "Catálogo"
                    else ()
                )
                self._add(
                    section,
                    DataPage(
                        SECTION_LABELS.get(section, section),
                        actions.get(section, ()),
                        subtitle=subtitles.get(
                            section, "Consulta, filtra y administra los registros disponibles."
                        ),
                        category_filters=filters,
                        visible_columns=(
                            (
                                "banco",
                                "estado",
                                "progreso",
                                "elementos",
                                "completados",
                                "avisos",
                                "errores",
                            )
                            if section == "Sesiones"
                            else (
                                "Categoría",
                                "Obras",
                                "Archivos",
                                "Listos",
                                "Enriquecidos",
                                "Pendientes",
                                "Consultas máximas",
                                "Preparación",
                                "Estado",
                            )
                            if section == "Enriquecimiento"
                            else (
                                "grupo",
                                "título candidato",
                                "archivos agrupados",
                                "ruta",
                                "tipo",
                                "confianza",
                                "Coincidencia",
                            )
                            if section == "Pendientes de revisión"
                            else None
                        ),
                        action_groups=(
                            (
                                (
                                    "Preparación",
                                    ("Preparar local",),
                                ),
                                ("Control", ("Pausar", "Reanudar")),
                                ("Consulta", ("Detalles",)),
                                ("Sesión", ("Cancelar", "Borrar sesión")),
                            )
                            if section == "Sesiones"
                            else (
                                (
                                    "Enriquecimiento",
                                    ("Enriquecer online", "Pausar", "Reanudar"),
                                ),
                                ("Consulta", ("Detalles",)),
                            )
                            if section == "Enriquecimiento"
                            else ()
                        ),
                    ),
                )
        sessions_page = self.pages["Sesiones"]
        self.session_progress_panel = SessionProgressPanel()
        cast(QVBoxLayout, sessions_page.layout()).insertWidget(2, self.session_progress_panel)
        enrichment_page = self.pages["Enriquecimiento"]
        self.enrichment_progress_panel = SessionProgressPanel()
        self.enrichment_progress_panel.overall.setFormat("Progreso de la selección")
        self.enrichment_progress_panel.overall.setAccessibleName(
            "Progreso de las categorías seleccionadas"
        )
        cast(QVBoxLayout, enrichment_page.layout()).insertWidget(2, self.enrichment_progress_panel)
        self.provider_usage_panel = ProviderUsagePanel()
        cast(QVBoxLayout, enrichment_page.layout()).insertWidget(3, self.provider_usage_panel)
        self.catalog_completion_panel = CatalogCompletionPanel()
        finalization_page = self.pages["Finalización"]
        cast(QVBoxLayout, finalization_page.layout()).insertWidget(2, self.catalog_completion_panel)
        sessions_page.action_requested.connect(self.handle_session_action)  # type: ignore[attr-defined]
        self.pages["Enriquecimiento"].action_requested.connect(  # type: ignore[attr-defined]
            self.handle_session_action
        )
        self.pages["Pendientes de revisión"].action_requested.connect(  # type: ignore[attr-defined]
            self.handle_review_action
        )
        self.pages["Duplicados"].action_requested.connect(  # type: ignore[attr-defined]
            self.handle_duplicate_action
        )
        for section in (
            "Catálogo",
            "Finalización",
            "Bancos",
            "Fuentes",
            "Historial",
            "Diagnóstico",
        ):
            self.pages[section].action_requested.connect(  # type: ignore[attr-defined]
                lambda action, rows, value=section: self.handle_operational_action(value, action)
            )
        self.session_rows = self.session_presenter.rows()
        sessions_page.set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.restore_pending_reviews()
        self.invalidate_enrichment_rows()
        self.refresh_finalization()
        if "Sesiones pendientes" in self.dashboard_values:
            self.dashboard_values["Sesiones pendientes"].setText(
                str(sum(row["estado"] != "completed" for row in self.session_rows))
            )
        self.navigation.currentRowChanged.connect(self.navigate)
        self.theme_button.clicked.connect(self.toggle_theme)
        self.settings_button.clicked.connect(lambda: self.navigate_to("Configuración"))
        self.reprepare_all_shortcut = QShortcut(QKeySequence("F9"), self)
        self.reprepare_all_shortcut.setContext(Qt.ShortcutContext.ApplicationShortcut)
        self.reprepare_all_shortcut.activated.connect(
            lambda: self.handle_review_action("Repreparar todos", [])
        )
        self.navigation.setCurrentRow(1)
        self.restore_preferences()
        # Precarga los agregados persistidos para que la etapa 3 no dependa de
        # ejecutar otra preparación local durante la sesión actual.
        if self._preload_persisted_enrichment:
            QTimer.singleShot(0, self.refresh_enrichment_rows)
        self.refresh_diagnostics(database_status)
        if self.startup_report is not None:
            self.show_startup_report(self.startup_report)

    @staticmethod
    def section_tooltip(section: str) -> str:
        descriptions = {
            "Inicio": "Resumen del estado general, actividad y métricas de MCE.",
            "Importaciones": "Selecciona y valida inventarios JSON creados por MediaScan Local.",
            "Sesiones": "Consulta y controla los trabajos creados desde importaciones válidas.",
            "Enriquecimiento": (
                "Consulta metadatos online para sesiones preparadas y categorías elegidas."
            ),
            "Pendientes de revisión": "Resuelve decisiones que requieren confirmación humana.",
            "Catálogo": "Consulta contenidos, versiones, archivos y disponibilidades consolidadas.",
            "Finalización": "Revisa el resumen final y genera las salidas aprobadas del catálogo.",
            "Duplicados": "Revisa coincidencias y decide si deben combinarse o separarse.",
            "Bancos": "Consulta los bancos de copia registrados en el catálogo.",
            "Fuentes": "Consulta discos, carpetas y ubicaciones incluidas en los escaneos.",
            "Historial": "Revisa cambios y decisiones auditables realizadas en MCE.",
            "Configuración": "Personaliza preferencias locales de la aplicación.",
            "Diagnóstico": "Consulta el estado técnico de servicios y dependencias.",
        }
        return descriptions[section]

    @staticmethod
    def build_session_presenter(
        checkpoint_dir: Path | None = None,
        originals_dir: Path | None = None,
        *,
        use_postgresql: bool = False,
    ) -> SessionPresenter:
        """Compone casos de uso locales sin introducir infraestructura en widgets."""
        workspaces = InMemoryWorkspaceRepository()
        sessions: Any = InMemorySessionRepository()
        workspace = Workspace(str(uuid4()), "Espacio de trabajo de MCE Desktop")
        workspaces.save(workspace)
        checkpoints = (
            JsonCheckpointStore(checkpoint_dir)
            if checkpoint_dir is not None
            else InMemoryCheckpointStore()
        )
        if isinstance(checkpoints, JsonCheckpointStore):
            from mce.infrastructure.checkpoints.json_checkpoint_store import (
                CheckpointSessionRepository,
            )

            sessions = CheckpointSessionRepository(checkpoints)
            from mce.infrastructure.database.session_ledger import (
                PostgresSessionRepository,
            )

            if use_postgresql:
                sessions = (
                    PostgresSessionRepository.from_runtime_environment(originals_dir) or sessions
                )
        service = SessionService(
            workspaces,
            sessions,
            checkpoints,
            SystemClock(),
            UuidGenerator(),
        )
        presenter = SessionPresenter(service, workspace.workspace_id, sessions, checkpoints)
        if hasattr(sessions, "list_ids"):
            identifiers = sessions.list_ids()
            first = sessions.get(identifiers[0]) if identifiers else None
            if first is not None:
                workspace = Workspace(
                    first.workspace_id,
                    "Espacio de trabajo recuperado desde PostgreSQL",
                    identifiers,
                )
                workspaces.save(workspace)
                presenter.workspace_id = first.workspace_id
                for identifier in identifiers:
                    presenter.register_persisted(identifier)
        elif checkpoint_dir is not None:
            restored = []
            for path in sorted(checkpoint_dir.glob("*.json")):
                try:
                    # Los checkpoints masivos se conservan para recuperación explícita,
                    # pero nunca se materializan durante el arranque en modo seguro.
                    if path.stat().st_size > 8 * 1024 * 1024:
                        continue
                    candidate = checkpoints.load(path.stem)
                    if candidate.status is not SessionStatus.ARCHIVED:
                        restored.append(candidate)
                except (OSError, ValueError):
                    continue
            if restored:
                workspace_id = restored[0].workspace_id
                workspace = Workspace(
                    workspace_id,
                    "Espacio de trabajo recuperado",
                    tuple(session.session_id for session in restored),
                )
                workspaces.save(workspace)
                presenter.workspace_id = workspace_id
                for session in restored:
                    presenter.register_restored(session)
        return presenter

    def _add(self, name: str, page: QWidget) -> None:
        self.pages[name] = page
        self.stack.addWidget(page)

    def dashboard(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)
        title = QLabel("Panel general")
        title.setObjectName("pageTitle")
        subtitle = QLabel("Estado operativo y actividad reciente de tu catálogo multimedia.")
        subtitle.setObjectName("pageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)
        metrics = (
            ("PostgreSQL", "Pendiente de diagnóstico"),
            ("Última importación", "Sin actividad"),
            ("Sesiones pendientes", "0"),
            ("Revisiones pendientes", "0"),
            ("Errores recientes", "0"),
            ("Catálogo", "Sin datos"),
            ("Completitud catálogo", "0.0 %"),
        )
        grid = QGridLayout()
        grid.setSpacing(14)
        for index, (label, value) in enumerate(metrics):
            card = QFrame()
            card.setProperty("card", True)
            card_layout = QVBoxLayout(card)
            card_layout.setContentsMargins(20, 15, 20, 15)
            value_label = QLabel(value)
            value_label.setObjectName("metricValue")
            value_label.setWordWrap(True)
            value_label.setMinimumHeight(30)
            self.dashboard_values[label] = value_label
            name_label = QLabel(label)
            name_label.setObjectName("metricLabel")
            name_label.setWordWrap(True)
            card_layout.addWidget(value_label)
            card_layout.addWidget(name_label)
            grid.addWidget(card, index // 2, index % 2)
        layout.addLayout(grid)
        layout.addStretch()
        return page

    def navigate(self, row: int) -> None:
        """Sincroniza navegación, página y título de la cabecera."""
        if row <= 0:
            return
        index = row - 1
        self.stack.setCurrentIndex(index)
        section = SECTIONS[index]
        self.current_section.setText(SECTION_LABELS.get(section, section))
        for name, button in self.workflow_buttons.items():
            button.setProperty("active", name == section)
            button.style().unpolish(button)
            button.style().polish(button)
        if section == "Enriquecimiento" and not self.enrichment_rows_loaded:
            self.refresh_enrichment_rows()

    def invalidate_enrichment_rows(self) -> None:
        """Marca los agregados como obsoletos sin bloquear el hilo visual."""
        self.enrichment_rows_loaded = False
        if self.enrichment_worker is not None:
            self.enrichment_refresh_pending = True
            return
        if self.stack.currentWidget() is self.pages["Enriquecimiento"]:
            self.refresh_enrichment_rows()

    def refresh_enrichment_rows(self) -> None:
        """Carga agregados PostgreSQL en segundo plano al abrir la etapa 3."""
        if self.enrichment_worker is not None:
            self.enrichment_refresh_pending = True
            return
        self.enrichment_refresh_pending = False
        self.activity_badge.setText("Cargando sesiones preparadas…")
        worker = TaskRunnable(self.load_enrichment_snapshot)
        self.enrichment_worker = worker
        worker.signals.result.connect(self.enrichment_rows_ready)
        worker.signals.error.connect(self.enrichment_rows_failed)
        worker.signals.finished.connect(self.enrichment_rows_finished)
        QThreadPool.globalInstance().start(worker)

    def load_enrichment_snapshot(self) -> tuple[list[dict[str, object]], dict[str, int]]:
        """Recupera lecturas tras una desconexión sin alterar sesiones ni catálogo."""
        try:
            rows = self.session_presenter.enrichment_rows()
        except SQLAlchemyError as first_error:
            logger.warning(
                "event=enrichment_rows_read_retry error_type=%s",
                type(first_error).__name__,
            )
            try:
                rows = self.session_presenter.enrichment_rows()
            except SQLAlchemyError as second_error:
                logger.warning(
                    "event=enrichment_rows_degraded error_type=%s",
                    type(second_error).__name__,
                )
                rows = list(self.last_enrichment_rows)
        return rows, self.safe_catalog_completion()

    def safe_catalog_completion(self) -> dict[str, int]:
        """Una métrica informativa no debe ocultar las secciones preparadas."""
        try:
            return self.session_presenter.catalog_completion()
        except (SQLAlchemyError, OSError, RuntimeError) as exc:
            logger.warning(
                "event=catalog_completion_degraded error_type=%s",
                type(exc).__name__,
            )
            return dict(self.catalog_completion_summary)

    def groq_resume_block(self) -> str | None:
        """Impide gastar llamadas mientras persiste un enfriamiento conocido."""
        state = SqliteRateLimitStore(self.metadata_cache_path).load("groq")
        if state is None:
            return None
        seconds, authoritative, quota_kind = state
        if seconds <= 0:
            return None
        minutes, remaining = divmod(round(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        countdown = (
            f"{hours:02d}:{minutes:02d}:{remaining:02d}"
            if hours
            else f"{minutes:02d}:{remaining:02d}"
        )
        source = "indicado por Groq" if authoritative else "de seguridad creciente"
        return f"Groq bloqueado por {quota_kind} · {countdown} · plazo {source}"

    def enrichment_rows_ready(self, payload: object) -> None:
        rows, completion = cast(tuple[list[dict[str, object]], dict[str, int]], payload)
        self.pages["Enriquecimiento"].set_rows(rows)  # type: ignore[attr-defined]
        self.last_enrichment_rows = list(rows)
        self.catalog_completion_summary = completion
        self.catalog_completion_panel.update_summary(completion)
        self.refresh_dashboard()
        self.enrichment_rows_loaded = True
        self.activity_badge.setText(f"Enriquecimiento · {len(rows)} categoría(s) preparada(s)")

    def enrichment_rows_failed(self, message: str) -> None:
        self.activity_badge.setText(f"No se pudo cargar Enriquecimiento: {message}")

    def enrichment_rows_finished(self) -> None:
        self.enrichment_worker = None
        if self.enrichment_refresh_pending:
            self.enrichment_refresh_pending = False
            self.refresh_enrichment_rows()

    def navigate_to(self, section: str) -> None:
        """Abre una sección por identidad sin depender de posiciones visuales."""
        self.navigation.setCurrentRow(SECTIONS.index(section) + 1)

    def toggle_theme(self) -> None:
        current = self.settings.value("dark_mode", False, type=bool)
        self.set_theme(not current)

    def test_groq_connection(self) -> None:
        if self.groq_test_worker is not None:
            return
        key = os.environ.get("GROQ_API_KEY", "").strip()
        page = cast(SettingsPage, self.pages["Configuración"])
        if not key:
            page.groq_status.setText("GROQ_API_KEY: no configurada")
            return
        page.groq_status.setText("Groq: comprobando conexión…")
        worker = TaskRunnable(
            lambda: tuple(model.id for model in create_groq_client(key).models.list())
        )
        self.groq_test_worker = worker
        worker.signals.result.connect(self.groq_connection_ok)
        worker.signals.error.connect(self.groq_connection_failed)
        worker.signals.finished.connect(lambda: setattr(self, "groq_test_worker", None))
        QThreadPool.globalInstance().start(worker)

    def groq_connection_ok(self, payload: object) -> None:
        models = tuple(str(value) for value in cast(tuple[object, ...], payload))
        primary = "openai/gpt-oss-120b"
        state = "disponible" if primary in models else "conectado · modelo principal no disponible"
        cast(SettingsPage, self.pages["Configuración"]).groq_status.setText(f"Groq: {state}")

    def groq_connection_failed(self, message: str) -> None:
        safe = message.replace("GROQ_API_KEY", "credencial")[:300]
        cast(SettingsPage, self.pages["Configuración"]).groq_status.setText(f"Groq: error · {safe}")

    def test_ollama_connection(self) -> None:
        if self.ollama_test_worker is not None:
            return
        page = cast(SettingsPage, self.pages["Configuración"])
        model = page.ollama_model.text().strip() or "qwen2.5:3b"
        page.ollama_status.setText(
            f"Servidor: comprobando\nModelo: {model}\nEstado: probando inferencia"
        )
        try:
            analyzer = OllamaQwenAnalyzer(
                UrllibOllamaTransport(page.ollama_base_url.text().strip()),
                model=model,
                timeout=page.ollama_timeout.value(),
                max_concurrency=page.ollama_concurrency.value(),
            )
        except ValueError as exc:
            page.ollama_status.setText(
                f"Servidor: NO DISPONIBLE\nModelo: {model}\n"
                f"Estado: configuración inválida · {exc}"
            )
            return
        worker = TaskRunnable(analyzer.diagnose)
        self.ollama_test_worker = worker
        worker.signals.result.connect(self.ollama_connection_checked)
        worker.signals.error.connect(
            lambda message: page.ollama_status.setText(
                f"Servidor: NO DISPONIBLE\nModelo: {model}\n"
                f"Estado: error · {message[:300]}"
            )
        )
        worker.signals.finished.connect(lambda: setattr(self, "ollama_test_worker", None))
        QThreadPool.globalInstance().start(worker)

    def ollama_connection_checked(self, payload: object) -> None:
        diagnostic = cast(Any, payload)
        page = cast(SettingsPage, self.pages["Configuración"])
        server = "OK" if diagnostic.connected else "NO DISPONIBLE"
        model = page.ollama_model.text().strip() or "qwen2.5:3b"
        state = "Disponible" if diagnostic.inference_ok else diagnostic.message
        page.ollama_status.setText(
            f"Servidor: {server}\nModelo: {model}\nEstado: {state}"
        )

    def test_browser_connection(self) -> None:
        if self.browser_test_worker is not None:
            return
        page = cast(SettingsPage, self.pages["Configuración"])
        page.browser_status.setText(
            "Playwright: comprobando · Chromium: comprobando\n"
            f"Modo: {'Headless' if page.browser_headless.isChecked() else 'Visible'} · "
            "Estado: iniciando navegador"
        )
        backend = PlaywrightBrowserAutomationBackend(
            channel=os.environ.get("MCE_BROWSER_CHANNEL", "chrome")
        )
        headless = page.browser_headless.isChecked()
        worker = TaskRunnable(lambda: backend.diagnose(headless=headless))
        self.browser_test_worker = worker
        worker.signals.result.connect(self.browser_connection_checked)
        worker.signals.error.connect(self.browser_connection_failed)
        worker.signals.finished.connect(
            lambda: setattr(self, "browser_test_worker", None)
        )
        QThreadPool.globalInstance().start(worker)

    def browser_connection_checked(self, payload: object) -> None:
        page = cast(SettingsPage, self.pages["Configuración"])
        page.browser_status.setText(page.browser_status_text(cast(BrowserDiagnostic, payload)))

    def browser_connection_failed(self, message: str) -> None:
        page = cast(SettingsPage, self.pages["Configuración"])
        diagnostic = BrowserDiagnostic(False, False, message.replace("\n", " ")[:300])
        page.browser_status.setText(page.browser_status_text(diagnostic))

    def create_session(self, import_result: ImportResult, bank_name: str = "") -> None:
        """Crea la sesión fuera del hilo visual y refleja el resultado."""
        if self.safe_mode:
            self.activity_badge.setText("Modo seguro: creación de sesiones bloqueada")
            return
        import_page = self.pages["Importaciones"]
        import_page.create_session.setEnabled(False)  # type: ignore[attr-defined]
        import_page.summary.setText("Creando sesión…")  # type: ignore[attr-defined]
        self.activity_badge.setText("Creando sesión")
        self.activity_badge.setProperty("state", "warning")
        self._refresh_badge(self.activity_badge)
        self.session_worker = TaskRunnable(
            lambda: self.session_presenter.create(import_result, bank_name or None)
        )
        self.session_worker.signals.result.connect(self.session_created)
        self.session_worker.signals.error.connect(self.session_creation_failed)
        self.session_worker.signals.finished.connect(self.session_creation_finished)
        QThreadPool.globalInstance().start(self.session_worker)

    def session_created(self, session: ProcessingSession) -> None:
        row = self.session_presenter.row(session)
        self.session_rows.append(row)
        sessions_page = self.pages["Sesiones"]
        sessions_page.set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        import_page = self.pages["Importaciones"]
        import_page.summary.setText(  # type: ignore[attr-defined]
            f"Sesión creada correctamente · {row['elementos']} elementos · estado {row['estado']}"
        )
        self.navigate_to("Sesiones")
        self.add_history("sesión creada", session.session_id, session.status.value)
        self.refresh_dashboard()

    def import_validated(self, result: ImportResult) -> None:
        """Actualiza métricas visuales sin reinterpretar el resultado."""
        self.dashboard_values["Última importación"].setText(
            result.status.value.replace("_", " ").title()
        )
        self.dashboard_values["Errores recientes"].setText(
            str(result.statistics.errors + result.statistics.fatal_errors)
        )
        self.add_history("importación validada", result.source_file, result.status.value)
        if result.package is None:
            return
        bank_data = dict(result.package.scan.bank_data)
        bank_row: dict[str, object] = {
            "id": str(result.package.domain_import.bank_id),
            "nombre": bank_data.get("name") or bank_data.get("nombre") or "Banco MSL",
            "estado": "importado",
            "archivo": result.package.original_filename,
        }
        self.bank_rows[str(bank_row["id"])] = bank_row
        self.pages["Bancos"].set_rows(self.bank_rows.values())  # type: ignore[attr-defined]
        source_rows: list[dict[str, object]] = [
            {
                "id": str(source.temporary_id),
                "nombre": source.display_name,
                "tipo": source.source_type.value,
                "ruta": source.original_root_path,
            }
            for source in result.package.sources
        ]
        for source_row in source_rows:
            self.source_rows[str(source_row["id"])] = source_row
        self.pages["Fuentes"].set_rows(self.source_rows.values())  # type: ignore[attr-defined]

    def handle_session_action(self, action: str, selected_rows: list[int]) -> None:
        """Traduce controles visuales a transiciones del caso de uso."""
        if self.safe_mode and action != "Detalles":
            self.activity_badge.setText("Modo seguro: escrituras bloqueadas")
            return
        if action == "Preparar todas":
            self.prepare_all_sessions_local()
            return
        if not selected_rows:
            self.activity_badge.setText("Selecciona una sesión")
            return
        source_page = (
            self.pages["Enriquecimiento"]
            if self.stack.currentWidget() is self.pages["Enriquecimiento"]
            else self.pages["Sesiones"]
        )
        visible = source_page.model.filtered  # type: ignore[attr-defined]
        row = visible[selected_rows[0]]
        enrichment_selection = source_page is self.pages["Enriquecimiento"]
        session_id = str(row["_sesión"] if enrichment_selection else row["sesión"])
        selected_categories = (
            frozenset(str(visible[index]["_categoría"]) for index in selected_rows)
            if enrichment_selection
            else None
        )
        queued_targets: list[tuple[str, frozenset[str]]] = []
        selected_ready_total: int | None = None
        selected_bank_name: str | None = None
        if enrichment_selection:
            categories_by_session: dict[str, set[str]] = {}
            session_statuses: dict[str, str] = {}
            session_banks: dict[str, str] = {}
            for index in selected_rows:
                record = visible[index]
                record_targets = cast(tuple[dict[str, object], ...], record.get("_targets", ()))
                for target in record_targets:
                    target_session = str(target.get("session_id", ""))
                    category = str(target.get("category", ""))
                    ready = cast(int, target.get("ready", 0))
                    if not target_session or not category or ready <= 0:
                        continue
                    categories_by_session.setdefault(target_session, set()).add(category)
                    session_statuses[target_session] = str(target.get("status", ""))
                    session_banks[target_session] = str(target.get("bank", ""))
            queued_targets = [
                (target_session, frozenset(categories))
                for target_session, categories in categories_by_session.items()
            ]
            if action == "Reanudar":
                resumable = {
                    SessionStatus.PAUSED.value,
                    SessionStatus.WAITING_INTERNET.value,
                }
                queued_targets.sort(
                    key=lambda target: (session_statuses.get(target[0], "") not in resumable,)
                )
            if not queued_targets:
                self.activity_badge.setText("No quedan obras listas en esta selección")
                return
            session_id, selected_categories = queued_targets[0]
            # El total exacto por obra se emite desde el trabajador después de
            # agrupar. Usar el número de archivos aquí inflaba el lote visual.
            selected_ready_total = 0
            selected_bank_name = session_banks.get(session_id) or None
        if (
            enrichment_selection
            and not queued_targets
            and any(str(visible[index]["_sesión"]) != session_id for index in selected_rows)
        ):
            self.activity_badge.setText("Selecciona categorías de una sola sesión")
            return
        if action == "Borrar sesión":
            if session_id == self.processing_session_id:
                self.activity_badge.setText("Detén el procesamiento antes de borrar la sesión")
                return
            try:
                self.session_presenter.delete(session_id)
            except (KeyError, OSError, ValueError) as exc:
                self.activity_badge.setText(f"No se pudo borrar la sesión: {exc}")
                return
            review_ids = {
                review_id
                for review_id, related_session_id in self.review_sessions.items()
                if related_session_id == session_id
            }
            self.review_rows = [
                item for item in self.review_rows if str(item.get("id")) not in review_ids
            ]
            for review_id in review_ids:
                self.review_sessions.pop(review_id, None)
            self.session_rows = [
                item for item in self.session_rows if str(item["sesión"]) != session_id
            ]
            self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
            self.invalidate_enrichment_rows()
            self.pages["Pendientes de revisión"].set_rows(  # type: ignore[attr-defined]
                self.review_rows
            )
            self.activity_badge.setText("Sesión archivada")
            self.session_progress_panel.clear()
            self.enrichment_progress_panel.clear()
            self.add_history("sesión archivada", session_id, "checkpoint conservado")
            self.refresh_dashboard()
            return
        if action == "Preparar local":
            self.prepare_session_local(session_id)
            return
        if action == "Enriquecer online":
            blocked = self.groq_resume_block()
            if blocked is not None:
                self.activity_badge.setText(blocked)
                return
            if enrichment_selection:
                records = [visible[index] for index in selected_rows]
                files = sum(int(record["Listos"]) for record in records)
                works = sum(int(record["Obras"]) for record in records)
                tmdb = sum(int(record["TMDb"]) for record in records)
                anilist = sum(int(record["AniList"]) for record in records)
                tvmaze = sum(int(record["TVMaze"]) for record in records)
                answer = QMessageBox.question(
                    self,
                    "Confirmar presupuesto de enriquecimiento",
                    (
                        f"Archivos seleccionados: {files:,}\n"
                        f"Obras únicas: {works:,}\n"
                        f"TMDb: hasta {tmdb:,} consultas\n"
                        f"AniList: hasta {anilist:,} consultas\n"
                        f"TVMaze: hasta {tvmaze:,} consultas\n\n"
                        "La estimación no modifica datos. ¿Iniciar este lote?"
                    ),
                )
                if answer != QMessageBox.StandardButton.Yes:
                    self.activity_badge.setText("Enriquecimiento cancelado antes de usar APIs")
                    return
            self.pending_enrichment_targets = queued_targets[1:] if enrichment_selection else []
            self.start_session_processing(
                session_id,
                selected_categories,
                prepared_total=selected_ready_total,
                bank_name=selected_bank_name,
            )
            return
        targets = {
            "Pausar": SessionStatus.PAUSED,
            "Reanudar": SessionStatus.RUNNING,
            "Cancelar": SessionStatus.CANCELLED,
        }
        if action not in targets:
            return
        if action == "Reanudar" and enrichment_selection and self.processing_worker is None:
            blocked = self.groq_resume_block()
            if blocked is not None:
                self.activity_badge.setText(blocked)
                return
            # No persistas aquí la transición de una sesión grande. Esa escritura
            # bloqueaba la ventana antes de que el trabajador pudiera arrancar.
            self.pending_enrichment_targets = queued_targets[1:]
            self.activity_badge.setText("Reanudando lote guardado…")
            self.start_session_processing(
                session_id,
                selected_categories,
                prepared_total=selected_ready_total,
                bank_name=selected_bank_name,
            )
            return
        if session_id == self.processing_session_id and self.processing_token is not None:
            if action == "Pausar":
                self.processing_token.pause()
                self.session_progress_panel.set_state("paused", "Procesamiento pausado")
                self.enrichment_progress_panel.set_state("paused", "Selección pausada")
                self.activity_badge.setText("Procesamiento pausado · checkpoint conservado")
                # No serializar una sesión grande en el hilo visual. El trabajo
                # permanece vivo y el token cooperativo conserva su posición.
                return
            elif action == "Reanudar":
                self.processing_token.resume()
                self.session_progress_panel.set_state("running", "Reanudando procesamiento")
                self.enrichment_progress_panel.set_state("running", "Reanudando selección")
                self.activity_badge.setText("Reanudando procesamiento")
                return
            elif action == "Cancelar":
                self.processing_token.cancel()
                self.session_progress_panel.set_state("cancelled", "Procesamiento cancelado")
                self.enrichment_progress_panel.set_state("cancelled", "Selección cancelada")
        try:
            changed = self.session_presenter.transition(session_id, targets[action])
        except (KeyError, ValueError) as exc:
            self.activity_badge.setText(f"Acción no válida: {exc}")
            return
        changed_row = self.session_presenter.row(changed)
        self.session_rows = [
            changed_row if item["sesión"] == session_id else item for item in self.session_rows
        ]
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        self.activity_badge.setText(f"Sesión {changed.status.value}")
        self.refresh_dashboard()
        if action == "Reanudar" and self.processing_worker is None:
            local_stages = {
                ProcessingStage.IMPORTED,
                ProcessingStage.NORMALIZED,
                ProcessingStage.CLASSIFIED,
                ProcessingStage.CLEANED,
                ProcessingStage.GROUPED,
            }
            if any(item.stage in local_stages for item in changed.items):
                self.prepare_session_local(session_id)
            else:
                # Al reanudar desde la etapa 3 se debe conservar la categoría
                # elegida. Pasar None reiniciaba accidentalmente toda la sesión.
                self.start_session_processing(session_id, selected_categories)

    @staticmethod
    def _needs_local_preparation(session: ProcessingSession) -> bool:
        local_stages = {
            ProcessingStage.IMPORTED,
            ProcessingStage.NORMALIZED,
            ProcessingStage.CLASSIFIED,
            ProcessingStage.CLEANED,
            ProcessingStage.GROUPED,
        }
        return any(
            item.stage in local_stages
            or item.classification_status == "classification_pending"
            or item.cleaning_status == "cleaning_pending"
            or (
                item.stage is not ProcessingStage.CONSOLIDATED
                and item.detected_category != "subtitle"
                and item.grouping_version != LocalPreparationService.GROUPING_VERSION
            )
            for item in session.items
        )

    def prepare_all_sessions_local(self) -> None:
        """Reprepara en serie todas las sesiones que usan reglas locales antiguas."""
        if self.processing_worker is not None:
            self.activity_badge.setText("Ya existe una tarea activa")
            return
        candidates: list[str] = []
        for row in self.session_rows:
            session_id = str(row["sesión"])
            session = self.session_presenter.sessions.get(session_id)
            if session is not None and self._needs_local_preparation(session):
                candidates.append(session_id)
        if not candidates:
            self.restore_pending_reviews()
            self.invalidate_enrichment_rows()
            self.activity_badge.setText("Todas las sesiones ya tienen la preparación vigente")
            return
        self.local_preparation_total = len(candidates)
        self.local_preparation_completed = 0
        self.pending_local_preparation_sessions = candidates[1:]
        self.activity_badge.setText(
            f"Preparación masiva local · 1/{self.local_preparation_total} sesiones"
        )
        self.prepare_session_local(candidates[0])

    def prepare_session_local(self, session_id: str) -> None:
        """Ejecuta clasificación y limpieza offline antes de cualquier proveedor."""
        if self.processing_worker is not None:
            self.activity_badge.setText("Ya existe una tarea activa")
            return
        current = self.session_presenter.sessions.get(session_id)
        if current is None:
            self.activity_badge.setText("La sesión seleccionada ya no existe")
            return
        needs_local_preparation = self._needs_local_preparation(current)
        if not needs_local_preparation:
            ready = sum(
                item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in current.items
            )
            self.invalidate_enrichment_rows()
            self.activity_badge.setText(f"Preparación ya guardada · {ready:,} archivos listos")
            return
        if current.status is SessionStatus.READY:
            current = self.session_presenter.transition(session_id, SessionStatus.RUNNING)
            changed_row = self.session_presenter.row(current)
            self.session_rows = [
                changed_row if item["sesión"] == session_id else item for item in self.session_rows
            ]
            self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        token = CancellationToken()
        worker: TaskRunnable
        worker = TaskRunnable(
            lambda: self.session_presenter.prepare_local(
                session_id,
                progress_detail=worker.signals.progress_detail.emit,
                token=token,
            ),
            token,
        )
        self.processing_worker = worker
        self.processing_had_error = False
        self.processing_session_id = session_id
        self.processing_token = token
        worker.signals.progress_detail.connect(self.show_processing_detail)
        worker.signals.result.connect(self.session_preparation_completed)
        worker.signals.error.connect(self.session_processing_failed)
        worker.signals.finished.connect(self.session_processing_finished)
        self.activity_badge.setText("Clasificando localmente · 0 %")
        QThreadPool.globalInstance().start(worker)

    def session_preparation_completed(self, payload: object) -> None:
        session, summary = cast(tuple[ProcessingSession, object], payload)
        changed_row = self.session_presenter.row(session)
        self.session_rows = [
            changed_row if item["sesión"] == session.session_id else item
            for item in self.session_rows
        ]
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        ready = getattr(summary, "ready_for_enrichment", 0)
        uncertain = getattr(summary, "uncertain", 0)
        self.activity_badge.setText(
            f"Preparación local terminada · {ready:,} listos · {uncertain:,} inciertos"
        )
        self.add_history(
            "preparación local",
            session.session_id,
            f"{ready} listos para enriquecer; {uncertain} inciertos",
        )

    def start_session_processing(
        self,
        session_id: str,
        selected_categories: frozenset[str] | None = None,
        *,
        prepared_total: int | None = None,
        bank_name: str | None = None,
    ) -> None:
        """Ejecuta el pipeline 5 a 9 en segundo plano con progreso cooperativo."""
        if getattr(sys, "frozen", False) and not self.database_status.safe:
            self.activity_badge.setText("Configura el catálogo maestro PostgreSQL mce")
            QMessageBox.warning(
                self,
                "Catálogo maestro no disponible",
                "El procesamiento se bloqueó porque el ejecutable no encuentra la base "
                "PostgreSQL exacta mce. La base mce_test nunca se usa para el catálogo real.",
            )
            return
        if self.processing_worker is not None:
            self.activity_badge.setText("Ya existe una sesión procesándose")
            return
        session: ProcessingSession | None = None
        if prepared_total is None:
            session = self.session_presenter.sessions.get(session_id)
            if session is None:
                self.activity_badge.setText("La sesión seleccionada ya no existe")
                return
            bank_name = session.bank_name
            if session.status is SessionStatus.FAILED:
                session = self.session_presenter.retry(session_id)
                self.activity_badge.setText(
                    f"Reintento controlado #{session.retry_count} preparado"
                )
                self.session_rows = [
                    self.session_presenter.row(current) for current in self.session_presenter.all()
                ]
                self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
                self.invalidate_enrichment_rows()
            if session.status not in {
                SessionStatus.READY,
                SessionStatus.PAUSED,
                SessionStatus.RUNNING,
                SessionStatus.WAITING_REVIEW,
                SessionStatus.WAITING_INTERNET,
            }:
                self.activity_badge.setText(
                    f"No se puede iniciar una sesión en estado {session.status.value}"
                )
                return
            if any(
                item.stage is ProcessingStage.IMPORTED
                or item.classification_status == "classification_pending"
                or item.cleaning_status == "cleaning_pending"
                for item in session.items
            ):
                self.activity_badge.setText(
                    "Primero ejecuta «Preparar local»; todavía no se consultó ningún proveedor"
                )
                return
        token = CancellationToken()
        self.processing_token = token
        self.processing_session_id = session_id
        self._apply_groq_settings_to_process()
        self.metadata_runtime = self.metadata_runtime_builder(
            self.metadata_cache_path, lambda: token.is_cancelled
        )
        self.provider_usage_panel.begin()
        if self.metadata_runtime.usage_snapshot is not None:
            self.provider_usage_panel.update_usage(self.metadata_runtime.usage_snapshot())
        self.refresh_metadata_badge()
        persistence = self.metadata_persistence
        pipeline = SessionPipelineService(
            IdentificationService(
                self.metadata_runtime.provider,
                web_fallback=self.metadata_runtime.web_fallback,
            ),
            self.review_repository,
            persist_candidate=(
                (
                    lambda candidate, bank_id, raw_title, alias, confidence: persistence.save(
                        candidate,
                        bank_id,
                        alias,
                        confidence,
                        raw_bank_title=raw_title,
                        bank_name=bank_name,
                    )
                )
                if persistence is not None
                else None
            ),
            resolve_known_identity=(
                persistence.find_known_candidate if persistence is not None else None
            ),
            ai_reviewer=cast(Any, self.metadata_runtime.ai_reviewer),
        )
        worker: TaskRunnable
        worker = TaskRunnable(
            lambda: self.session_presenter.process(
                session_id,
                pipeline,
                token,
                worker.signals.progress.emit,
                worker.signals.progress_detail.emit,
                selected_categories,
            ),
            token,
        )
        self.processing_worker = worker
        self.processing_had_error = False
        selected_total = prepared_total
        if selected_total is None and session is not None:
            selected_total = len(
                {
                    item.work_group_id or item.item_id
                    for item in session.items
                    if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
                    and matches_enrichment_selection(item, selected_categories)
                }
            )
        selected_total = selected_total or 0
        self.session_progress_panel.begin(selected_total)
        self.enrichment_progress_panel.begin(selected_total)
        worker.signals.progress.connect(self.show_processing_progress)
        worker.signals.progress_detail.connect(self.show_processing_detail)
        worker.signals.result.connect(self.session_processing_completed)
        worker.signals.error.connect(self.session_processing_failed)
        worker.signals.finished.connect(self.session_processing_finished)
        self.activity_badge.setText("Procesando sesión · 0 %")
        QThreadPool.globalInstance().start(worker)

    def _apply_groq_settings_to_process(self) -> None:
        migrate_web_priority_defaults(self.settings)
        for provider in ("tavily", "serper", "exa"):
            os.environ[f"MCE_{provider.upper()}_ENABLED"] = (
                "true"
                if cast(
                    bool,
                    self.settings.value(f"web/{provider}_enabled", True, type=bool),
                )
                else "false"
            )
            os.environ[f"MCE_{provider.upper()}_PRIORITY"] = str(
                cast(
                    int,
                    self.settings.value(
                        f"web/{provider}_priority",
                        WEB_PRIORITY_DEFAULTS[provider],
                        type=int,
                    ),
                )
            )
        os.environ["BROWSER_SEARCH_ENABLED"] = (
            "true"
            if cast(bool, self.settings.value("browser/enabled", False, type=bool))
            else "false"
        )
        os.environ["BROWSER_HEADLESS"] = (
            "true"
            if cast(bool, self.settings.value("browser/headless", True, type=bool))
            else "false"
        )
        os.environ["BROWSER_TIMEOUT"] = str(
            cast(float, self.settings.value("browser/timeout", 20.0, type=float))
        )
        os.environ["BROWSER_MAX_CONCURRENCY"] = str(
            cast(int, self.settings.value("browser/max_concurrency", 1, type=int))
        )
        delay_min = cast(
            int, self.settings.value("browser/delay_min_ms", 1_000, type=int)
        )
        delay_max = cast(
            int, self.settings.value("browser/delay_max_ms", 2_500, type=int)
        )
        os.environ["BROWSER_DELAY_MIN_MS"] = str(delay_min)
        os.environ["BROWSER_DELAY_MAX_MS"] = str(max(delay_min, delay_max))
        os.environ["BROWSER_MAX_RESULTS"] = str(
            cast(int, self.settings.value("browser/max_results", 5, type=int))
        )
        os.environ["OLLAMA_ENABLED"] = (
            "true"
            if cast(bool, self.settings.value("ollama/enabled", True, type=bool))
            else "false"
        )
        os.environ["OLLAMA_BASE_URL"] = str(
            self.settings.value("ollama/base_url", "http://localhost:11434")
        )
        os.environ["OLLAMA_MODEL"] = str(self.settings.value("ollama/model", "qwen2.5:3b"))
        os.environ["OLLAMA_TIMEOUT"] = str(
            cast(float, self.settings.value("ollama/timeout", 120.0, type=float))
        )
        os.environ["LOCAL_LLM_MAX_CONCURRENCY"] = str(
            cast(int, self.settings.value("ollama/max_concurrency", 1, type=int))
        )
        os.environ["MCE_GROQ_ENABLED"] = (
            "true" if cast(bool, self.settings.value("groq/enabled", True, type=bool)) else "false"
        )
        os.environ["MCE_GROQ_FALLBACK_ENABLED"] = (
            "true" if cast(bool, self.settings.value("groq/fallback", True, type=bool)) else "false"
        )
        os.environ["MCE_GROQ_PRIMARY_MODEL"] = str(
            self.settings.value("groq/primary_model", "openai/gpt-oss-120b")
        )
        os.environ["MCE_AI_DAILY_WORK_LIMIT"] = str(
            cast(int, self.settings.value("groq/daily_limit", 1000, type=int))
        )
        os.environ["MCE_AI_TEST_MODE"] = (
            "true"
            if cast(bool, self.settings.value("groq/test_mode", False, type=bool))
            else "false"
        )
        os.environ["MCE_GROQ_QWEN_FALLBACK"] = "false"

    def show_processing_progress(self, value: int) -> None:
        self.activity_badge.setText(f"Procesando sesión · {value} %")

    def show_processing_detail(self, snapshot: object) -> None:
        detail = cast(ProcessingProgress, snapshot)
        self.session_progress_panel.update_progress(detail)
        self.enrichment_progress_panel.update_progress(detail)
        if self.metadata_runtime.usage_snapshot is not None:
            self.provider_usage_panel.update_usage(self.metadata_runtime.usage_snapshot())
        self.activity_badge.setText(f"{detail.stage_label} · {detail.overall_percent:g} %")

    def session_processing_completed(self, payload: object) -> None:
        result, session = cast(tuple[ProcessingBatchResult, ProcessingSession], payload)
        changed_row = self.session_presenter.row(session)
        self.session_rows = [
            changed_row if item["sesión"] == session.session_id else item
            for item in self.session_rows
        ]
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        incoming_ids = {str(row["id"]) for row in result.review_rows}
        self.review_rows = [row for row in self.review_rows if str(row["id"]) not in incoming_ids]
        self.review_rows.extend(result.review_rows)
        self.review_sessions.update(
            {str(row["id"]): session.session_id for row in result.review_rows}
        )
        self.catalog_rows.extend(result.catalog_rows)
        for catalog_row in result.catalog_rows:
            self.duplicate_presenter.register_catalog_row(catalog_row)
        self.pages["Pendientes de revisión"].set_rows(self.review_rows)  # type: ignore[attr-defined]
        self.pages["Catálogo"].set_rows(self.catalog_rows)  # type: ignore[attr-defined]
        self.refresh_finalization()
        self.refresh_duplicates()
        if result.summary is not None:
            summary = result.summary
            self.add_history(
                "resumen de lote",
                session.session_id,
                (
                    f"{summary.get('completed_works', 0)}/{summary.get('total_works', 0)} obras · "
                    f"restantes {summary.get('remaining_works', 0)} · "
                    f"llamadas {sum(cast(dict[str, int], summary.get('provider_calls', {})).values())} · "
                    f"caché {summary.get('provider_cache_hits', 0)}"
                ),
            )
        if result.deferred_reason:
            self.activity_badge.setText(f"En espera del proveedor: {result.deferred_reason}")
            self.add_history("proveedor en espera", session.session_id, result.deferred_reason)
        elif session.status is SessionStatus.COMPLETED:
            self.session_progress_panel.set_state("completed", "Procesamiento terminado")
            self.enrichment_progress_panel.set_state("completed", "Selección terminada")
        destination = (
            "Sesiones"
            if result.deferred_reason
            else "Pendientes de revisión"
            if result.review_rows
            else "Catálogo"
        )
        if not self.pending_enrichment_targets:
            self.navigate_to(destination)

    def session_processing_failed(self, message: str) -> None:
        self.processing_had_error = True
        self.pending_local_preparation_sessions.clear()
        logger.error(
            "event=session_processing_failed session_id=%s message=%s",
            self.processing_session_id,
            message,
        )
        if self.processing_token is not None and self.processing_token.is_cancelled:
            self.activity_badge.setText("Procesamiento cancelado")
            self.session_progress_panel.set_state("cancelled", "Procesamiento cancelado")
            self.enrichment_progress_panel.set_state("cancelled", "Selección cancelada")
        elif (
            self.processing_session_id is not None
            and (current := self.session_presenter.sessions.get(self.processing_session_id))
            is not None
            and current.status is SessionStatus.WAITING_INTERNET
        ):
            self.activity_badge.setText(f"En espera del proveedor: {message}")
            self.navigate_to("Sesiones")
        else:
            self.activity_badge.setText(f"Error de procesamiento: {message}")
            self.session_progress_panel.set_state("failed", "Error durante el procesamiento")
            self.enrichment_progress_panel.set_state("failed", "Error en la selección")
        # No tapes la excepción ni congeles la ventana recargando todas las
        # sesiones. Los resúmenes se actualizarán de forma asíncrona después.
        self.invalidate_enrichment_rows()

    def session_processing_finished(self) -> None:
        if self.processing_had_error:
            self.processing_worker = None
            self.processing_token = None
            self.processing_session_id = None
            self.pending_enrichment_targets.clear()
            self.pending_local_preparation_sessions.clear()
            return
        session = (
            self.session_presenter.sessions.get(self.processing_session_id)
            if self.processing_session_id is not None
            else None
        )
        if session is not None and session.status in {
            SessionStatus.COMPLETED,
            SessionStatus.WAITING_REVIEW,
        }:
            self.activity_badge.setText("Sin tareas activas")
            self.activity_badge.setProperty("state", "neutral")
            self._refresh_badge(self.activity_badge)
        next_target = (
            self.pending_enrichment_targets.pop(0)
            if session is not None
            and session.status in {SessionStatus.COMPLETED, SessionStatus.WAITING_REVIEW}
            and self.pending_enrichment_targets
            else None
        )
        if (
            next_target is None
            and session is not None
            and session.status
            not in {
                SessionStatus.COMPLETED,
                SessionStatus.WAITING_REVIEW,
            }
        ):
            self.pending_enrichment_targets.clear()
        self.processing_worker = None
        self.processing_token = None
        self.processing_session_id = None
        if self.local_preparation_total:
            self.local_preparation_completed += 1
            if self.pending_local_preparation_sessions:
                next_session = self.pending_local_preparation_sessions.pop(0)
                position = self.local_preparation_completed + 1
                self.activity_badge.setText(
                    f"Preparación masiva local · {position}/{self.local_preparation_total} sesiones"
                )
                QTimer.singleShot(
                    0,
                    lambda session_id=next_session: self.prepare_session_local(session_id),
                )
                return
            total = self.local_preparation_total
            self.local_preparation_total = 0
            self.local_preparation_completed = 0
            self.restore_pending_reviews()
            self.invalidate_enrichment_rows()
            self.activity_badge.setText(
                f"Preparación masiva terminada · {total} sesión(es) actualizada(s)"
            )
        if next_target is not None:
            target_session, categories = next_target
            remaining = len(self.pending_enrichment_targets)
            self.activity_badge.setText(f"Continuando siguiente sesión · {remaining} después")
            QTimer.singleShot(
                0,
                lambda session_id=target_session, selected=categories: (
                    self.start_session_processing(session_id, selected)
                ),
            )

    def handle_review_action(self, action: str, selected_rows: list[int]) -> None:
        """Aplica una decisión humana y actualiza revisión y catálogo."""
        if self.safe_mode:
            self.activity_badge.setText("Modo seguro: revisiones bloqueadas")
            return
        review_page = self.pages["Pendientes de revisión"]
        delete_selected = action == "Eliminar seleccionado"
        if delete_selected:
            action = "Rechazar"
        if action == "Agrupar obras idénticas":
            before = len(self.review_rows)
            self.review_rows = list(group_identical_review_rows(tuple(self.review_rows)))
            after = len(self.review_rows)
            grouped = before - after
            review_page.set_rows(self.review_rows)  # type: ignore[attr-defined]
            self.activity_badge.setText(
                f"Agrupación terminada · {grouped:,} registro(s) repetido(s) reunido(s) · "
                f"{after:,} obra(s) visibles"
            )
            self.add_history(
                "revisión",
                "agrupar obras idénticas",
                f"{before} registros convertidos en {after} obras visibles; sin llamadas externas",
            )
            return
        if action == "Repreparar todos":
            selected_records = list(
                expand_grouped_review_rows(tuple(review_page.model.matching))  # type: ignore[attr-defined]
            )
            self.start_review_repair(tuple(selected_records), revalidate=False)
            return
        if action == "Revalidar y completar":
            visible = review_page.model.filtered  # type: ignore[attr-defined]
            selected_records = [visible[index] for index in selected_rows if index < len(visible)]
            if not selected_records:
                self.activity_badge.setText("Selecciona las obras que deseas revalidar")
                return
            answer = QMessageBox.question(
                self,
                "Revalidar y completar metadatos",
                (
                    f"Obras seleccionadas: {len(selected_records):,}\n\n"
                    "MCE reparará sus títulos y volverá a consultar caché y proveedores. "
                    "Las obras identificadas pasarán a la vista previa del catálogo; "
                    "las incompletas volverán a revisión humana.\n\n"
                    "Esto no publica todavía el catálogo maestro. ¿Continuar?"
                ),
            )
            if answer == QMessageBox.StandardButton.Yes:
                self.start_review_repair(tuple(selected_records), revalidate=True)
            return
        if action == "Resolver coincidencias seguras":
            selected_records = list(
                expand_grouped_review_rows(tuple(review_page.model.matching))  # type: ignore[attr-defined]
            )
            if not selected_records:
                self.activity_badge.setText("No hay obras en el filtro actual")
                return
            resolvable: list[dict[str, object]] = []
            for selected in selected_records:
                safe_candidate = safe_review_candidate(selected)
                if safe_candidate is None:
                    continue
                prepared = dict(selected)
                prepared["_candidate"] = safe_candidate
                prepared["_candidate_approvable"] = True
                resolvable.append(prepared)
            omitted = len(selected_records) - len(resolvable)
            if not resolvable:
                self.activity_badge.setText(
                    "Ninguna selección tiene una identidad externa inequívoca"
                )
                return
            answer = QMessageBox.question(
                self,
                "Resolver coincidencias seguras",
                (
                    f"Seleccionadas: {len(selected_records):,}\n"
                    f"Identidades inequívocas: {len(resolvable):,}\n"
                    f"Casos dudosos que permanecerán en revisión: {omitted:,}\n\n"
                    "Las identidades repetidas se consolidarán mediante sus IDs externos. "
                    "No se harán nuevas llamadas ni se publicará el catálogo. ¿Continuar?"
                ),
            )
            if answer == QMessageBox.StandardButton.Yes:
                self.start_bulk_review("Aprobar", tuple(resolvable))
            return
        if action == "Aprobar todas":
            action = "Aprobar"
            selected_records = list(
                expand_grouped_review_rows(tuple(review_page.model.matching))  # type: ignore[attr-defined]
            )
        else:
            visible = review_page.model.filtered  # type: ignore[attr-defined]
            selected_records = [visible[index] for index in selected_rows if index < len(visible)]
            selected_records = list(expand_grouped_review_rows(tuple(selected_records)))
        if not selected_records:
            self.activity_badge.setText("Selecciona un pendiente de revisión")
            return
        if delete_selected:
            answer = QMessageBox.question(
                self,
                "Eliminar de Revisión humana",
                (
                    f"Se retirarán de Revisión humana {len(selected_records):,} "
                    "registro(s) de la obra seleccionada.\n\n"
                    "No se borrarán archivos físicos ni se modificará el catálogo "
                    "maestro PostgreSQL. ¿Continuar?"
                ),
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        if action in {"Aprobar", "Rechazar"} and len(selected_records) > 1:
            self.start_bulk_review(action, tuple(selected_records))
            return
        if (
            action in {"Corregir", "Limpiar y reintentar", "Bloquear"}
            and len(selected_records) != 1
        ):
            self.activity_badge.setText(f"{action} requiere seleccionar una sola fila")
            return
        correction = None
        if action in {"Corregir", "Limpiar y reintentar"}:
            current_title = str(selected_records[0].get("título candidato") or "")
            proposed_title = (
                self.session_presenter.suggest_review_title(current_title)
                if action == "Limpiar y reintentar"
                else current_title
            )
            correction, accepted = QInputDialog.getText(
                self,
                "Limpiar título" if action == "Limpiar y reintentar" else "Corregir título",
                "Propuesta local (puedes editarla):"
                if action == "Limpiar y reintentar"
                else "Título corregido:",
                text=proposed_title,
            )
            if not accepted or not correction.strip():
                return
        affected_sessions: set[str] = set()
        for selected in selected_records:
            review_id = str(selected["id"])
            persisted_id: str | None = None
            candidate = cast(ProviderCandidate | None, selected.get("_candidate"))
            approved_candidate = candidate if bool(selected.get("_candidate_approvable")) else None
            session_id = self.review_sessions.get(review_id)
            raw_item_ids = selected.get("_item_ids")
            item_ids = (
                tuple(str(value) for value in raw_item_ids)
                if isinstance(raw_item_ids, list)
                else (review_id,)
            )
            if action == "Repreparar localmente":
                if session_id is None:
                    self.activity_badge.setText("La revisión no está vinculada a una sesión")
                    return
                original_title = str(selected.get("título candidato") or "")
                prepared_title = self.session_presenter.suggest_review_title_from_evidence(
                    original_title,
                    original_name=str(selected.get("archivo") or ""),
                    original_path=str(selected.get("ruta") or ""),
                )
                if not prepared_title:
                    self.activity_badge.setText("La limpieza no produjo un título utilizable")
                    return
                self.session_presenter.reprepare_review_items(
                    session_id, item_ids, corrected_title=prepared_title
                )
                selected["título candidato"] = prepared_title
                selected["estado de identidad"] = "repreparado localmente; aún en revisión"
                selected["consulta usada"] = prepared_title
                selected["_candidate"] = None
                selected["_candidate_approvable"] = False
                affected_sessions.add(session_id)
                continue
            if action == "Aprobar" and self.metadata_persistence:
                try:
                    if session_id is None:
                        raise RuntimeError("la revisión no está vinculada a una sesión")
                    processing_session = self.session_presenter.sessions.get(session_id)
                    if processing_session is None:
                        raise RuntimeError("la sesión de la revisión ya no existe")
                    selected_ids = frozenset(item_ids)
                    group_items = tuple(
                        item for item in processing_session.items if item.item_id in selected_ids
                    )
                    persisted_id = self.metadata_persistence.save_approved_group(
                        approved_candidate,
                        processing_session,
                        group_items,
                        alias=str(selected.get("grupo") or selected.get("título candidato") or ""),
                        confidence=float(cast(float | str, selected.get("puntuación externa") or 0)),
                    )
                except (SQLAlchemyError, RuntimeError, ValueError) as exc:
                    self.activity_badge.setText(
                        f"No se pudo persistir la revisión: {type(exc).__name__}"
                    )
                    return
            try:
                decided = self.review_presenter.decide(review_id, action, correction)
            except (KeyError, ValueError) as exc:
                self.activity_badge.setText(f"No se pudo aplicar la revisión: {exc}")
                return
            if action == "Aprobar":
                catalog_row = self.review_presenter.catalog_row(decided)
                catalog_row["estado catálogo"] = "aprobado"
                catalog_row["_catalog_stage"] = "approved"
                catalog_row["archivos agrupados"] = int(
                    cast(int | str, selected.get("archivos agrupados") or 1)
                )
                if approved_candidate is not None:
                    catalog_row.update(
                        {
                            "título": approved_candidate.title,
                            "título original": approved_candidate.original_title or "—",
                            "año": approved_candidate.year,
                            "tipo": approved_candidate.kind.value,
                            "géneros": ", ".join(approved_candidate.genres),
                            "sinopsis": approved_candidate.overview or "",
                            "reparto": ", ".join(
                                approved_candidate.cast_names or approved_candidate.cast
                            ),
                            "director": approved_candidate.director or "",
                            "carátula": next(
                                (
                                    url
                                    for kind, url in approved_candidate.images
                                    if kind in {"poster", "movieposter", "tvposter", "artwork"}
                                ),
                                "",
                            ),
                        }
                    )
                if persisted_id is not None:
                    catalog_row["_content_id"] = persisted_id
                self.catalog_rows.append(catalog_row)
                self.duplicate_presenter.register_catalog_row(catalog_row)
            if action in {"Aprobar", "Rechazar"}:
                session_id = self.review_sessions.pop(review_id, None)
                if session_id is not None:
                    affected_sessions.add(session_id)
                    self.session_presenter.resolve_review_items(
                        session_id,
                        item_ids,
                        approved=action == "Aprobar",
                    )
                self.review_rows = [row for row in self.review_rows if str(row["id"]) != review_id]
            elif action == "Corregir":
                selected["título candidato"] = correction
                selected["_candidate"] = None
                selected["_candidate_approvable"] = False
                if session_id is not None:
                    self.session_presenter.annotate_review_items(
                        session_id, item_ids, corrected_title=correction
                    )
            elif action == "Bloquear":
                selected["bloqueado"] = "sí"
                if session_id is not None:
                    self.session_presenter.annotate_review_items(
                        session_id, item_ids, lock_title=True
                    )
            elif action == "Limpiar y reintentar":
                if session_id is None:
                    self.activity_badge.setText("La revision no esta vinculada a una sesion")
                    return
                self.session_presenter.requeue_review_items(
                    session_id,
                    item_ids,
                    corrected_title=correction or "",
                )
                self.review_sessions.pop(review_id, None)
                self.review_rows = [row for row in self.review_rows if str(row["id"]) != review_id]
                affected_sessions.add(session_id)
                self.invalidate_enrichment_rows()
                self.activity_badge.setText(
                    "Título limpio enviado a Enriquecimiento selectivo · Pendientes"
                )
        self.pages["Pendientes de revisión"].set_rows(self.review_rows)  # type: ignore[attr-defined]
        self.pages["Catálogo"].set_rows(self.catalog_rows)  # type: ignore[attr-defined]
        self.refresh_finalization()
        self.refresh_duplicates()
        for session_id in affected_sessions:
            current = self.session_presenter.sessions.get(session_id)
            has_open_reviews = session_id in self.review_sessions.values()
            has_ready_items = bool(
                current
                and any(
                    item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in current.items
                )
            )
            if (
                current is not None
                and current.status is SessionStatus.WAITING_REVIEW
                and not has_open_reviews
                and not has_ready_items
            ):
                completed = self.session_presenter.transition(session_id, SessionStatus.COMPLETED)
            else:
                completed = current
            if completed is not None:
                completed_row = self.session_presenter.row(completed)
                self.session_rows = [
                    completed_row if row["sesión"] == completed.session_id else row
                    for row in self.session_rows
                ]
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        self.activity_badge.setText(f"Revisión: {action.lower()}")
        self.add_history("revisión", action.lower(), f"{len(selected_records)} registro(s)")
        self.refresh_dashboard()

    def start_review_repair(
        self, selected_records: tuple[dict[str, object], ...], *, revalidate: bool
    ) -> None:
        """Repara títulos en segundo plano y opcionalmente los reabre para enriquecer."""
        if self.review_worker is not None:
            self.activity_badge.setText("Ya existe una operación de revisión en curso")
            return
        frozen = freeze_review_selection(selected_records)
        if not frozen:
            self.activity_badge.setText("No hay obras en el filtro actual")
            return
        worker: TaskRunnable
        worker = TaskRunnable(
            lambda: self._run_review_repair(frozen, revalidate, worker.signals.progress.emit)
        )
        self.review_worker = worker
        self.pages["Pendientes de revisión"].set_actions_enabled(False)  # type: ignore[attr-defined]
        label = "Revalidando" if revalidate else "Repreparando"
        worker.signals.progress.connect(
            lambda value: self.activity_badge.setText(f"{label} obras · {value} %")
        )
        worker.signals.result.connect(self._review_repair_completed)
        worker.signals.error.connect(self._bulk_review_failed)
        worker.signals.finished.connect(self._bulk_review_finished)
        self.activity_badge.setText(f"{label} obras · 0 %")
        QThreadPool.globalInstance().start(worker)

    def _run_review_repair(
        self,
        selected_records: tuple[dict[str, object], ...],
        revalidate: bool,
        report_progress: Callable[[int], None] | None = None,
    ) -> dict[str, object]:
        corrections: dict[str, dict[str, str]] = {}
        canonical_groups: dict[str, dict[str, str]] = {}
        updated: dict[str, str] = {}
        changed_titles: list[str] = []
        unchanged_titles: list[str] = []
        unresolved: list[str] = []
        stale: list[str] = []
        session_item_ids: dict[str, frozenset[str]] = {}
        total = len(selected_records)
        processed_logical = 0
        for index, selected in enumerate(selected_records, start=1):
            logical_review_id = str(selected["id"])
            title = self.session_presenter.suggest_review_title_from_evidence(
                str(selected.get("título candidato") or ""),
                original_name=str(selected.get("archivo") or ""),
                original_path=str(selected.get("ruta") or ""),
            )
            if not title:
                unresolved.append(logical_review_id)
                continue
            members = expand_grouped_review_rows((selected,))
            canonical_group_id = (
                "review-canonical-"
                + hashlib.sha256(
                    (
                        f"{str(selected.get('tipo') or '').strip().casefold()}|"
                        f"{title.strip().casefold()}"
                    ).encode()
                ).hexdigest()[:32]
            )
            logical_updated = False
            logical_stale = True
            for member in members:
                review_id = str(member["id"])
                session_id = self.review_sessions.get(review_id)
                if session_id is None:
                    continue
                raw_ids = member.get("_item_ids")
                item_ids = (
                    tuple(str(value) for value in raw_ids)
                    if isinstance(raw_ids, list)
                    else (review_id,)
                )
                if session_id not in session_item_ids:
                    current = self.session_presenter.sessions.get(session_id)
                    session_item_ids[session_id] = (
                        frozenset(item.item_id for item in current.items)
                        if current is not None
                        else frozenset()
                    )
                item_ids = tuple(
                    item_id for item_id in item_ids if item_id in session_item_ids[session_id]
                )
                if not item_ids:
                    continue
                logical_stale = False
                corrections.setdefault(session_id, {}).update(
                    {item_id: title for item_id in item_ids}
                )
                canonical_groups.setdefault(session_id, {}).update(
                    {item_id: canonical_group_id for item_id in item_ids}
                )
                updated[review_id] = title
                logical_updated = True
            if logical_stale:
                stale.append(logical_review_id)
                continue
            if not logical_updated:
                unresolved.append(logical_review_id)
                continue
            processed_logical += 1
            previous_title = str(selected.get("título candidato") or "").strip()
            if title.casefold() == previous_title.casefold():
                unchanged_titles.append(logical_review_id)
            else:
                changed_titles.append(logical_review_id)
            if report_progress is not None:
                report_progress(round(index * 45 / total))
        sessions = tuple(corrections)
        for index, (session_id, titles) in enumerate(corrections.items(), start=1):
            if revalidate:
                self.session_presenter.revalidate_review_items_bulk(
                    session_id,
                    titles,
                    canonical_groups.get(session_id),
                )
            else:
                self.session_presenter.reprepare_review_items_bulk(session_id, titles)
            if report_progress is not None:
                report_progress(45 + round(index * 55 / max(1, len(corrections))))
        result = {
            "revalidate": revalidate,
            "updated": updated,
            "changed": tuple(changed_titles),
            "unchanged": tuple(unchanged_titles),
            "unresolved": tuple(unresolved),
            "stale": tuple(stale),
            "sessions": sessions,
        }
        logger.info(
            "event=review_repair_summary mode=%s total=%d processed=%d changed=%d unchanged=%d unresolved=%d stale=%d external_calls=0",
            "revalidate" if revalidate else "local_only",
            total,
            processed_logical,
            len(changed_titles),
            len(unchanged_titles),
            len(unresolved),
            len(stale),
        )
        return result

    def _review_repair_completed(self, payload: object) -> None:
        data = cast(dict[str, object], payload)
        updated = cast(dict[str, str], data["updated"])
        unresolved = cast(tuple[str, ...], data["unresolved"])
        stale = cast(tuple[str, ...], data["stale"])
        changed = cast(tuple[str, ...], data["changed"])
        unchanged = cast(tuple[str, ...], data["unchanged"])
        revalidate = bool(data["revalidate"])
        was_grouped = any("_grouped_review_rows" in row for row in self.review_rows)
        review_rows = list(expand_grouped_review_rows(tuple(self.review_rows)))
        for row in review_rows:
            review_id = str(row["id"])
            if review_id in updated:
                row["título candidato"] = updated[review_id]
                row["consulta usada"] = updated[review_id]
                row["estado de identidad"] = (
                    "enviado a revalidación"
                    if revalidate
                    else "repreparado; pendiente de revalidación"
                )
        if revalidate:
            moved = set(updated)
            for review_id in moved:
                self.review_sessions.pop(review_id, None)
            review_rows = [row for row in review_rows if str(row["id"]) not in moved]
        self.review_rows = (
            list(group_identical_review_rows(tuple(review_rows))) if was_grouped else review_rows
        )
        self.pages["Pendientes de revisión"].set_rows(self.review_rows)  # type: ignore[attr-defined]
        self.session_rows = self.session_presenter.rows()
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        if revalidate and updated:
            sessions = cast(tuple[str, ...], data["sessions"])
            targets = [(session_id, frozenset({"pending_retry"})) for session_id in sessions]
            self.pending_enrichment_targets = targets[1:]
            self.activity_badge.setText(
                f"Revalidación preparada · {len(updated)} obra(s); iniciando enriquecimiento"
            )
            QTimer.singleShot(
                0,
                lambda: self.start_session_processing(targets[0][0], targets[0][1]),
            )
        else:
            self.activity_badge.setText(
                f"Repreparación terminada · {len(updated)} procesada(s) · "
                f"{len(changed)} modificada(s) · {len(unchanged)} sin cambios · "
                f"{len(unresolved)} sin título recuperable"
                f" · {len(stale)} referencia(s) histórica(s) omitida(s)"
            )
        self.add_history(
            "revisión",
            "revalidar y completar" if revalidate else "repreparar todos",
            f"{len(updated)} procesadas; {len(changed)} modificadas; {len(unchanged)} sin cambios; "
            f"{len(unresolved)} sin título; {len(stale)} históricas omitidas",
        )

    def restore_pending_reviews(self) -> None:
        """Reconstruye revisiones persistidas sin cargar inventarios completos."""
        loader = getattr(self.session_presenter.sessions, "list_pending_review_rows", None)
        if not callable(loader):
            return
        rows = list(loader())
        reviews: list[ReviewItem] = []
        for row in rows:
            if self.metadata_persistence is not None:
                category = str(row.get("tipo") or "").casefold()
                kind = (
                    SearchKind.ANIME
                    if category == "anime"
                    else SearchKind.SERIES
                    if category
                    in {"series", "season", "episode", "novela", "dorama", "concurso", "tv_show"}
                    else SearchKind.MOVIE
                )
                known = self.metadata_persistence.find_known_candidate(
                    str(row.get("título candidato") or ""),
                    kind,
                    str(row.get("banco") or "") or None,
                )
                if known is not None:
                    row["_candidate"] = known
                    row["_candidates"] = (known,)
                    row["_candidate_approvable"] = True
            confidence = int(max(0, min(100, round(float(row.get("confianza") or 0)))))
            row_provenance = FieldProvenance(
                FieldSourceType.IMPORTED,
                "postgresql",
                "restored-review",
                datetime.now(UTC),
                ConfidenceScore(confidence),
            )
            fields = {
                "title": MetadataField(str(row.get("título candidato") or ""), row_provenance),
                "type": MetadataField(str(row.get("tipo") or "unclassified"), row_provenance),
                "path": MetadataField(str(row.get("ruta") or ""), row_provenance),
                "bank": MetadataField(str(row.get("banco") or "—"), row_provenance),
                "source_id": MetadataField(str(row.get("_source_id") or ""), row_provenance),
                "installation_id": MetadataField(
                    str(row.get("_installation_id") or ""), row_provenance
                ),
                "original_name": MetadataField(
                    str(row.get("_original_name") or ""), row_provenance
                ),
                "size_bytes": MetadataField(row.get("_size_bytes"), row_provenance),
                "file_hash": MetadataField(str(row.get("_file_hash") or ""), row_provenance),
            }
            if row.get("año pista") is not None:
                fields["year"] = MetadataField(row["año pista"], row_provenance)
            reviews.append(
                ReviewItem(
                    str(row["id"]),
                    str(row.get("_physical_file_id") or row["id"]),
                    fields,
                )
            )
        self.review_rows = rows
        self.review_sessions = {str(row["id"]): str(row["_session_id"]) for row in rows}
        self.review_repository.save_many(tuple(reviews))
        self.pages["Pendientes de revisión"].set_rows(self.review_rows)  # type: ignore[attr-defined]

    def start_bulk_review(
        self, action: str, selected_records: tuple[dict[str, object], ...]
    ) -> None:
        """Ejecuta persistencia y resolución agrupada fuera del hilo visual."""
        if self.review_worker is not None:
            self.activity_badge.setText("Ya existe una aprobación masiva en curso")
            return
        # Una obra lógica solo puede entrar una vez al lote aunque una vista defectuosa
        # entregue la misma fila repetida.
        frozen = freeze_review_selection(selected_records)
        if not frozen:
            self.activity_badge.setText("No hay obras pendientes en la selección")
            return
        worker: TaskRunnable
        worker = TaskRunnable(
            lambda: self._run_bulk_review(action, frozen, worker.signals.progress.emit)
        )
        self.review_worker = worker
        self.pages["Pendientes de revisión"].set_actions_enabled(False)  # type: ignore[attr-defined]
        worker.signals.progress.connect(
            lambda value: self.activity_badge.setText(f"{action} seleccionados · {value} %")
        )
        worker.signals.result.connect(self._bulk_review_completed)
        worker.signals.error.connect(self._bulk_review_failed)
        worker.signals.finished.connect(self._bulk_review_finished)
        self.activity_badge.setText(f"{action} seleccionados · 0 %")
        QThreadPool.globalInstance().start(worker)

    def _run_bulk_review(
        self,
        action: str,
        selected_records: tuple[dict[str, object], ...],
        report_progress: Callable[[int], None] | None = None,
    ) -> dict[str, object]:
        results: list[dict[str, object]] = []
        review_ids: list[str] = []
        session_items: dict[str, list[str]] = {}
        total = len(selected_records)
        for index, selected in enumerate(selected_records, start=1):
            review_id = str(selected["id"])
            session_id = self.review_sessions.get(review_id)
            raw_item_ids = selected.get("_item_ids")
            item_ids = (
                tuple(str(value) for value in raw_item_ids)
                if isinstance(raw_item_ids, list)
                else (review_id,)
            )
            persisted_id: str | None = None
            candidate = selected.get("_candidate")
            approved_candidate = candidate if bool(selected.get("_candidate_approvable")) else None
            if action == "Aprobar" and self.metadata_persistence is not None:
                if session_id is None:
                    raise RuntimeError("la revisión no está vinculada a una sesión")
                processing_session = self.session_presenter.sessions.get(session_id)
                if processing_session is None:
                    raise RuntimeError("la sesión de la revisión ya no existe")
                selected_ids = frozenset(item_ids)
                group_items = tuple(
                    item for item in processing_session.items if item.item_id in selected_ids
                )
                persisted_id = self.metadata_persistence.save_approved_group(
                    cast(ProviderCandidate | None, approved_candidate),
                    processing_session,
                    group_items,
                    alias=str(selected.get("grupo") or selected.get("título candidato") or ""),
                    confidence=float(
                        cast(float | int | str, selected.get("puntuación externa") or 0)
                    ),
                )
            review_ids.append(review_id)
            results.append(
                {
                    "selected": selected,
                    "persisted_id": persisted_id,
                    "candidate": approved_candidate,
                    "session_id": session_id,
                    "item_ids": item_ids,
                }
            )
            if session_id is not None:
                session_items.setdefault(session_id, []).extend(item_ids)
            if report_progress is not None and total:
                report_progress(round(index * 90 / total))
        decisions = self.review_presenter.decide_many(tuple(review_ids), action)
        for result, decided in zip(results, decisions, strict=True):
            result["decided"] = decided
        for session_id, session_item_ids in session_items.items():
            self.session_presenter.resolve_review_items(
                session_id,
                tuple(dict.fromkeys(session_item_ids)),
                approved=action == "Aprobar",
            )
        if report_progress is not None:
            report_progress(100)
        return {"action": action, "results": results, "sessions": tuple(session_items)}

    def _bulk_review_completed(self, payload: object) -> None:
        data = cast(dict[str, object], payload)
        action = str(data["action"])
        results = cast(list[dict[str, object]], data["results"])
        removed_ids: set[str] = set()
        for result in results:
            selected = cast(dict[str, object], result["selected"])
            review_id = str(selected["id"])
            removed_ids.add(review_id)
            self.review_sessions.pop(review_id, None)
            if action == "Aprobar":
                catalog_row = self.review_presenter.catalog_row(result["decided"])
                catalog_row["estado catálogo"] = "aprobado"
                catalog_row["_catalog_stage"] = "approved"
                catalog_row["archivos agrupados"] = int(
                    cast(int | str, selected.get("archivos agrupados") or 1)
                )
                candidate = cast(ProviderCandidate | None, result["candidate"])
                if candidate is not None:
                    catalog_row.update(
                        {
                            "título": candidate.title,
                            "título original": candidate.original_title or "—",
                            "año": candidate.year,
                            "tipo": candidate.kind.value,
                        }
                    )
                if result["persisted_id"] is not None:
                    catalog_row["_content_id"] = result["persisted_id"]
                self.catalog_rows.append(catalog_row)
                self.duplicate_presenter.register_catalog_row(catalog_row)
        was_grouped = any("_grouped_review_rows" in row for row in self.review_rows)
        review_rows = list(expand_grouped_review_rows(tuple(self.review_rows)))
        review_rows = [row for row in review_rows if str(row["id"]) not in removed_ids]
        self.review_rows = (
            list(group_identical_review_rows(tuple(review_rows))) if was_grouped else review_rows
        )
        for session_id in cast(tuple[str, ...], data["sessions"]):
            current = self.session_presenter.sessions.get(session_id)
            has_open_reviews = session_id in self.review_sessions.values()
            has_ready_items = bool(
                current
                and any(
                    item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in current.items
                )
            )
            if (
                current is not None
                and current.status is SessionStatus.WAITING_REVIEW
                and not has_open_reviews
                and not has_ready_items
            ):
                self.session_presenter.transition(session_id, SessionStatus.COMPLETED)
        self.pages["Pendientes de revisión"].set_rows(self.review_rows)  # type: ignore[attr-defined]
        self.pages["Catálogo"].set_rows(self.catalog_rows)  # type: ignore[attr-defined]
        self.session_rows = self.session_presenter.rows()
        self.pages["Sesiones"].set_rows(self.session_rows)  # type: ignore[attr-defined]
        self.invalidate_enrichment_rows()
        self.refresh_finalization()
        self.refresh_duplicates()
        self.refresh_dashboard()
        self.activity_badge.setText(f"{action}: {len(results)} seleccionado(s) procesados")

    def _bulk_review_failed(self, message: str) -> None:
        self.activity_badge.setText(f"No se pudo completar la revisión masiva: {message}")

    def _bulk_review_finished(self) -> None:
        self.review_worker = None
        self.pages["Pendientes de revisión"].set_actions_enabled(True)  # type: ignore[attr-defined]

    def refresh_duplicates(self) -> None:
        """Recalcula candidatos con el detector conservador de la Fase 9."""
        self.pages["Duplicados"].set_rows(self.duplicate_presenter.rows())  # type: ignore[attr-defined]

    def handle_duplicate_action(self, action: str, selected_rows: list[int]) -> None:
        """Delega decisiones de duplicados al servicio reversible del catálogo."""
        if self.safe_mode and action != "Evidencia":
            self.activity_badge.setText("Modo seguro: decisiones bloqueadas")
            return
        if not selected_rows:
            self.activity_badge.setText("Selecciona un candidato duplicado")
            return
        visible = self.pages["Duplicados"].model.filtered  # type: ignore[attr-defined]
        candidate_id = str(visible[selected_rows[0]]["id"])
        try:
            self.duplicate_presenter.decide(candidate_id, action)
        except (KeyError, ValueError) as exc:
            self.activity_badge.setText(f"No se pudo resolver el duplicado: {exc}")
            return
        self.refresh_duplicates()
        self.activity_badge.setText(f"Duplicado: {action.lower()}")
        self.add_history("duplicado", candidate_id, action.lower())

    def add_history(self, action: str, target: str, result: str) -> None:
        self.history_rows.insert(
            0,
            {
                "fecha UTC": datetime.now(UTC).isoformat(timespec="seconds"),
                "acción": action,
                "objetivo": target,
                "resultado": result,
            },
        )
        self.pages["Historial"].set_rows(self.history_rows)  # type: ignore[attr-defined]
        if self.audit_persistence is not None:
            try:
                self.audit_persistence.record(
                    action,
                    "desktop_action",
                    target,
                    new_value={"result": result},
                )
            except (SQLAlchemyError, RuntimeError, TypeError, ValueError):
                self.activity_badge.setText("Acción completada; auditoría PostgreSQL pendiente")

    def show_startup_report(self, report: StartupReport) -> None:
        """Presenta el preflight real y anuncia el modo seguro sin revelar secretos."""
        rows = [
            {"componente": item.name, "estado": item.status, "detalle": item.message}
            for item in report.checks
        ]
        self.pages["Diagnóstico"].set_rows(rows)  # type: ignore[attr-defined]
        if report.safe_mode:
            self.activity_badge.setText("MODO SEGURO · base incompatible; escrituras bloqueadas")
            self.activity_badge.setProperty("state", "error")
            self.pages["Importaciones"].create_session.setEnabled(False)  # type: ignore[attr-defined]
        else:
            interrupted = next(
                (item.message for item in report.checks if item.name == "checkpoints"), ""
            )
            self.activity_badge.setText(f"Integridad inicial correcta · {interrupted}")
            self.activity_badge.setProperty("state", "success")
        self._refresh_badge(self.activity_badge)

    def start_backup(self) -> None:
        raw = runtime_database_url()
        if raw is None:
            self.activity_badge.setText("Backup no disponible: PostgreSQL no configurado")
            return
        stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
        default = self.runtime_paths.backups / f"mce-{stamp}.dump"
        selected, _ = QFileDialog.getSaveFileName(
            self, "Crear backup PostgreSQL", str(default), "PostgreSQL dump (*.dump)"
        )
        if selected:
            self._run_operational(
                lambda: self.backup_service.create(raw, Path(selected)), "Creando backup…"
            )

    def start_restore(self) -> None:
        raw = runtime_database_url()
        if raw is None:
            self.activity_badge.setText("Restauración no disponible: PostgreSQL no configurado")
            return
        selected, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar backup PostgreSQL",
            str(self.runtime_paths.backups),
            "PostgreSQL dump (*.dump)",
        )
        if not selected:
            return
        answer = QMessageBox.warning(
            self,
            "Restaurar PostgreSQL",
            "MCE creará primero un punto de restauración válido. ¿Continuar?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
        restore_point = self.runtime_paths.backups / f"mce-before-restore-{stamp}.dump"
        self._run_operational(
            lambda: self.backup_service.restore_safely(
                raw, Path(selected), restore_point, allow_master=True
            ),
            "Creando punto de restauración y restaurando…",
        )

    def start_diagnostic_package(self) -> None:
        default = self.runtime_paths.exports / "mce-diagnostic.zip"
        selected = self._select_diagnostic_destination(default)
        if selected is None:
            logger.info("event=diagnostic_package_cancelled")
            return
        checks = tuple(
            {"name": item.name, "status": item.status, "message": item.message}
            for item in (self.startup_report.checks if self.startup_report else ())
        )
        current_page = self.stack.currentWidget()
        stage = next(
            (name for name, page in self.pages.items() if page is current_page),
            "Inicio",
        )
        context = DiagnosticContext(
            active_stage=stage,
            statistics={
                "sessions": len(self.session_rows),
                "review_rows": len(self.review_rows),
                "catalog_rows": len(self.catalog_rows),
            },
        )
        self._run_operational(
            lambda: self.diagnostic_service.create(
                selected, context, logs_directory=self.runtime_paths.logs, health_checks=checks
            ),
            "Generando paquete de diagnóstico…",
        )

    def _select_diagnostic_destination(self, default: Path) -> Path | None:
        dialog = QFileDialog(self, "Guardar paquete de diagnóstico")
        dialog.setOption(QFileDialog.Option.DontUseNativeDialog, True)
        dialog.setAcceptMode(QFileDialog.AcceptMode.AcceptSave)
        dialog.setFileMode(QFileDialog.FileMode.AnyFile)
        dialog.setNameFilter("ZIP (*.zip)")
        dialog.setDefaultSuffix("zip")
        dialog.setDirectory(str(default.parent))
        dialog.selectFile(default.name)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return None
        selected = dialog.selectedFiles()
        return Path(selected[0]) if selected else None

    def _run_operational(self, operation: Callable[[], object], message: str) -> None:
        if self.operational_worker is not None:
            self.activity_badge.setText("Ya existe una operación de diagnóstico activa")
            return
        worker = TaskRunnable(operation)
        self.operational_worker = worker
        self.pages["Diagnóstico"].set_actions_enabled(False)  # type: ignore[attr-defined]
        worker.signals.result.connect(self._operational_completed)
        worker.signals.error.connect(self._operational_failed)
        worker.signals.finished.connect(self._operational_finished)
        self.activity_badge.setText(message)
        QThreadPool.globalInstance().start(worker)

    def _operational_completed(self, payload: object) -> None:
        if isinstance(payload, BackupResult):
            self.activity_badge.setText(payload.message)
            if payload.success:
                self.add_history(payload.operation, payload.database, str(payload.path))
        elif isinstance(payload, Path):
            logger.info(
                "event=diagnostic_package_created filename=%s bytes=%s",
                payload.name,
                payload.stat().st_size,
            )
            self.activity_badge.setText(f"Paquete diagnóstico creado · {payload.name}")
            self.add_history("diagnóstico", "paquete", str(payload))

    def _operational_failed(self, message: str) -> None:
        logger.error("event=operational_action_failed error=%s", message)
        self.activity_badge.setText(f"Operación fallida: {message}")

    def _operational_finished(self) -> None:
        self.operational_worker = None
        self.pages["Diagnóstico"].set_actions_enabled(True)  # type: ignore[attr-defined]

    def handle_operational_action(self, section: str, action: str) -> None:
        """Ejecuta exportación y diagnóstico sin introducirlos en los widgets."""
        if self.safe_mode and section != "Diagnóstico" and not action.startswith("Exportar"):
            self.activity_badge.setText("Modo seguro: escrituras bloqueadas")
            return
        if section == "Diagnóstico" and action == "Crear backup":
            self.start_backup()
            return
        if section == "Diagnóstico" and action == "Restaurar backup":
            self.start_restore()
            return
        if section == "Diagnóstico" and action == "Generar paquete":
            self.start_diagnostic_package()
            return
        if section == "Finalización" and action == "Publicar catálogo":
            self.start_catalog_publication()
            return
        if section == "Diagnóstico" and action == "Actualizar":
            report = self.health_service.inspect(
                resource_path("alembic.ini").parent, self.metadata_cache_path
            )
            rows = [
                {"componente": item.name, "estado": item.status, "detalle": item.message}
                for item in report.checks
            ]
            self.pages["Diagnóstico"].set_rows(rows)  # type: ignore[attr-defined]
            self.activity_badge.setText(
                "Diagnóstico correcto" if report.healthy else "Diagnóstico con incidencias"
            )
            return
        if action == "Exportar PDF" and section in {"Catálogo", "Finalización"}:
            default = self.runtime_paths.exports / "catalogo_mce.pdf"
            selected, _ = QFileDialog.getSaveFileName(
                self, "Exportar catálogo PDF", str(default.resolve()), "PDF (*.pdf)"
            )
            if not selected:
                return
            try:
                count = self.pdf_exporter.export(self.catalog_rows, Path(selected))
            except (OSError, TypeError, ValueError) as exc:
                self.activity_badge.setText(f"No se pudo exportar PDF: {exc}")
                return
            self.activity_badge.setText(f"PDF generado · {count} contenidos")
            self.add_history("exportación PDF", "Catálogo", selected)
            return
        if action not in {"Exportar JSON", "Exportar CSV"}:
            return
        export_format = ExportFormat.JSON if action.endswith("JSON") else ExportFormat.CSV
        default = self.runtime_paths.exports / (
            f"{section.casefold().replace(' ', '_')}.{export_format}"
        )
        selected, _ = QFileDialog.getSaveFileName(
            self,
            f"Exportar {section}",
            str(default.resolve()),
            "JSON (*.json)" if export_format is ExportFormat.JSON else "CSV (*.csv)",
        )
        if not selected:
            return
        page = self.pages[section]
        export_rows = (
            tuple(self.catalog_rows) if section == "Finalización" else tuple(page.model.rows)  # type: ignore[attr-defined]
        )
        try:
            result = self.export_service.export(
                ExportRequest(section, Path(selected), export_format, export_rows)
            )
        except (OSError, TypeError, ValueError) as exc:
            self.activity_badge.setText(f"No se pudo exportar: {exc}")
            return
        self.activity_badge.setText(f"Exportados {result.row_count} registros")
        if section != "Historial":
            self.add_history("exportación", section, str(result.destination))

    def start_catalog_publication(self) -> None:
        """Construye y activa el snapshot fuera del hilo visual."""
        if self.publication_service is None:
            self.activity_badge.setText("Publicación no disponible: PostgreSQL no configurado")
            return
        if self.publication_worker is not None:
            self.activity_badge.setText("Ya existe una publicación en curso")
            return
        answer = QMessageBox.question(
            self,
            "Publicar catálogo",
            "¿Validar y activar una nueva versión completa del catálogo?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        worker = TaskRunnable(self.publication_service.publish)
        self.publication_worker = worker
        self.pages["Finalización"].set_actions_enabled(False)  # type: ignore[attr-defined]
        worker.signals.result.connect(self._publication_completed)
        worker.signals.error.connect(self._publication_failed)
        worker.signals.finished.connect(self._publication_finished)
        self.activity_badge.setText("Validando versión completa del catálogo…")
        QThreadPool.globalInstance().start(worker)

    def _publication_completed(self, payload: object) -> None:
        result = cast(PublicationResult, payload)
        if result.status == "active":
            self.activity_badge.setText(
                f"Catálogo publicado · versión {result.catalog_version} · "
                f"{result.entry_count} disponibilidades"
            )
            self.add_history(
                "publicación",
                f"catálogo v{result.catalog_version}",
                f"activo · {result.entry_count} disponibilidades",
            )
        else:
            errors = len(cast(list[object], result.validation_report.get("errors", [])))
            self.activity_badge.setText(
                f"Publicación rechazada · {errors} incidencia(s); versión anterior intacta"
            )
            self.add_history(
                "publicación rechazada",
                f"catálogo v{result.catalog_version}",
                f"{errors} incidencia(s)",
            )

    def _publication_failed(self, message: str) -> None:
        self.activity_badge.setText(f"Publicación revertida; versión anterior intacta: {message}")

    def _publication_finished(self) -> None:
        self.publication_worker = None
        self.pages["Finalización"].set_actions_enabled(True)  # type: ignore[attr-defined]

    def refresh_diagnostics(self, database_status: object) -> None:
        """Expone diagnósticos seguros sin filtrar credenciales."""
        status = cast(Any, database_status)
        rows = [
            {
                "componente": "PostgreSQL de pruebas",
                "estado": "seguro" if status.safe else "pendiente",
                "detalle": status.message,
            },
            {
                "componente": "Checkpoints de sesiones",
                "estado": "activo",
                "detalle": "JSON local atómico",
            },
            {
                "componente": "Caché de metadatos",
                "estado": "acotada",
                "detalle": "SQLite separada · TTL y máximo configurables",
            },
        ]
        rows.extend(
            {
                "componente": f"Proveedor {name}",
                "estado": value,
                "detalle": "credencial oculta" if value == "configurada" else value,
            }
            for name, value in self.metadata_runtime.provider_statuses
        )
        self.pages["Diagnóstico"].set_rows(rows)  # type: ignore[attr-defined]

    def refresh_metadata_badge(self) -> None:
        """Muestra configuración del proveedor sin revelar credenciales."""
        if not self.metadata_runtime.configured:
            text, state = "Proveedores · configurar", "warning"
        elif self.metadata_runtime.offline:
            text, state = "Proveedores · caché offline", "warning"
        else:
            configured = sum(
                provider_status_is_available(value)
                for _, value in self.metadata_runtime.provider_statuses
            )
            total = len(self.metadata_runtime.provider_statuses)
            text, state = f"Proveedores · {configured}/{total}", "success"
        self.metadata_badge.setText(text)
        self.metadata_badge.setToolTip(self.metadata_runtime.message)
        self.metadata_badge.setProperty("state", state)
        self._refresh_badge(self.metadata_badge)

    def refresh_dashboard(self) -> None:
        """Sincroniza contadores derivados de los modelos visibles."""
        self.dashboard_values["Sesiones pendientes"].setText(
            str(sum(row["estado"] != "completed" for row in self.session_rows))
        )
        self.dashboard_values["Revisiones pendientes"].setText(str(len(self.review_rows)))
        self.dashboard_values["Catálogo"].setText(f"{len(self.catalog_rows)} contenidos")
        completion = self.catalog_completion_summary
        total = int(completion.get("total", 0))
        resolved = min(total, int(completion.get("resolved", 0)))
        percent = 0.0 if total == 0 else resolved * 100 / total
        self.dashboard_values["Completitud catálogo"].setText(f"{percent:.1f} %")

    def refresh_finalization(self) -> None:
        """Resume por categoría lo que se exportará desde la etapa final."""
        labels = {
            "anime": "Anime",
            "novel": "Novelas",
            "novela": "Novelas",
            "movie": "Películas",
            "pelicula": "Películas",
            "series": "Series",
            "tv": "Series",
            "season": "Temporadas",
            "episode": "Episodios",
        }
        counts: Counter[str] = Counter()
        for row in self.catalog_rows:
            raw = str(row.get("tipo") or row.get("content_type") or "unknown").casefold()
            counts[labels.get(raw, "Otros o sin clasificar")] += 1
        state = (
            "aprobado · pendiente de publicación" if not self.review_rows else "revisión pendiente"
        )
        rows = [
            {"categoría": category, "elementos": count, "estado": state}
            for category, count in sorted(counts.items())
        ]
        if not rows:
            rows = [{"categoría": "Catálogo", "elementos": 0, "estado": "sin datos"}]
        self.pages["Finalización"].set_rows(rows)  # type: ignore[attr-defined]

    def session_creation_failed(self, message: str) -> None:
        import_page = self.pages["Importaciones"]
        import_page.summary.setText(f"No se pudo crear la sesión: {message}")  # type: ignore[attr-defined]

    def session_creation_finished(self) -> None:
        self.activity_badge.setText("Sin tareas activas")
        self.activity_badge.setProperty("state", "neutral")
        self._refresh_badge(self.activity_badge)
        self.session_worker = None

    @staticmethod
    def _refresh_badge(label: QLabel) -> None:
        label.style().unpolish(label)
        label.style().polish(label)

    def set_theme(self, dark: bool) -> None:
        app = QApplication.instance()
        if app is not None:
            cast(QApplication, app).setStyleSheet(DARK if dark else LIGHT)
        self.settings.setValue("dark_mode", dark)

    def restore_preferences(self) -> None:
        geometry = self.settings.value("geometry")
        if geometry is not None:
            self.restoreGeometry(geometry)
        self.set_theme(bool(self.settings.value("dark_mode", False, type=bool)))

    def closeEvent(self, event: Any) -> None:
        if self.processing_worker is not None:
            answer = QMessageBox.question(
                self,
                "Procesamiento activo",
                "Hay una sesión procesándose. ¿Desea cancelarla y cerrar MCE?",
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            if self.processing_token is not None:
                self.processing_token.cancel()
            if self.processing_session_id is not None:
                with suppress(KeyError, ValueError):
                    self.session_presenter.transition(
                        self.processing_session_id, SessionStatus.CANCELLED
                    )
            QThreadPool.globalInstance().waitForDone(5000)
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.sync()
        super().closeEvent(event)
