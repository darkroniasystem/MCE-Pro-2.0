"""Adaptadores explícitos de contratos MSL hacia el normalizador canónico."""

from dataclasses import dataclass

from mce.application.importers.field_aliases import SchemaFieldAliases
from mce.application.importers.schema_detector import (
    SchemaCompatibility,
    SchemaDetectionResult,
)


class UnsupportedMslSchemaError(ValueError):
    """Impide adaptar silenciosamente un contrato desconocido."""


@dataclass(frozen=True, slots=True)
class MslSchemaAdapter:
    """Política versionada consumida por la normalización común y segura."""

    schema_version: str | None
    include_embedded_subtitles: bool = False

    @property
    def aliases(self) -> SchemaFieldAliases:
        """Devuelve únicamente los alias controlados para este contrato."""
        return SchemaFieldAliases(self.schema_version)


class MslSchema10Adapter(MslSchemaAdapter):
    """Contrato MSL 1.0."""

    def __init__(self) -> None:
        super().__init__("1.0")


class MslSchema22Adapter(MslSchemaAdapter):
    """Contrato real MSL 2.2, incluidos subtítulos anidados por video."""

    def __init__(self) -> None:
        super().__init__("2.2", include_embedded_subtitles=True)


class LegacyMslSchemaAdapter(MslSchemaAdapter):
    """Compatibilidad explícita para documentos sin versión declarada."""

    def __init__(self) -> None:
        super().__init__(None)


class MslSchemaAdapterRegistry:
    """Resuelve un adaptador solo después de una detección compatible."""

    def __init__(self) -> None:
        self._supported = {
            "1.0": MslSchema10Adapter(),
            "2.2": MslSchema22Adapter(),
        }
        self._legacy = LegacyMslSchemaAdapter()

    def resolve(self, detection: SchemaDetectionResult) -> MslSchemaAdapter:
        """Devuelve la política exacta o rechaza el esquema no registrado."""
        if detection.compatibility is SchemaCompatibility.SUPPORTED:
            adapter = self._supported.get(detection.version or "")
            if adapter is not None:
                return adapter
        if detection.compatibility in {
            SchemaCompatibility.MISSING,
            SchemaCompatibility.LEGACY_VERSION,
        }:
            return self._legacy
        raise UnsupportedMslSchemaError(
            f"No existe adaptador MSL para schema_version={detection.version!r}"
        )
