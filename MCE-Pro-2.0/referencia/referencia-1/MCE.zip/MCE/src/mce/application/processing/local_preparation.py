"""Clasificación y limpieza locales, completamente separadas de proveedores."""

from __future__ import annotations

import re
from collections import Counter
from collections.abc import Callable
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import PureWindowsPath
from typing import ClassVar
from uuid import NAMESPACE_URL, uuid5

from mce.application.classification import MediaClassifier
from mce.application.classification.models import MediaKind
from mce.application.dto import ProcessingSession, ProcessingStage
from mce.application.dto.session_models import SessionItem, SessionItemStatus
from mce.application.normalization import FilenameNormalizationPipeline
from mce.application.normalization.models import FilenameAnalysis, TokenKind
from mce.application.processing.models import ProcessingProgress
from mce.application.processing.selection import enrichment_category, matches_enrichment_selection

ProgressCallback = Callable[[ProcessingProgress], None]


@dataclass(frozen=True, slots=True)
class LocalPreparationSummary:
    total: int
    categories: dict[str, int]
    classified: int
    uncertain: int
    unclassified: int
    cleaned: int
    ready_for_enrichment: int
    errors: int
    unique_works: int = 0


@dataclass(frozen=True, slots=True)
class EnrichmentEstimate:
    selected_files: int
    unique_works: int
    individual_episodes: int
    cached_works: int
    excluded_completed: int
    estimated_queries_by_provider: dict[str, int]


class LocalPreparationService:
    """Ejecuta etapas puras y offline conservando cada entrada original."""

    CLASSIFICATION_VERSION = "mce-local-classification-v6"
    CLEANING_VERSION = "mce-local-cleaning-v3"
    GROUPING_VERSION = "mce-work-grouping-v8"
    AUDIO_SUFFIXES: ClassVar[frozenset[str]] = frozenset(
        {".aac", ".flac", ".m4a", ".mp3", ".ogg", ".wav"}
    )
    EPISODIC_CATEGORIES: ClassVar[frozenset[str]] = frozenset(
        {
            "series",
            "novela",
            "dorama",
            "anime",
            "concurso",
            "western_animation",
        }
    )
    CONTENT_CATEGORIES: ClassVar[frozenset[str]] = frozenset(
        {"movie", "series", "novela", "dorama", "anime", "concurso", "western_animation"}
    )
    SEASON_FOLDER = re.compile(
        r"^(?:(?:season|temporada|temp|s)\s*[._ -]*\d{1,3}"
        r"|\d{1,3}(?:ra|da|ta|er|a)?\s*(?:temporada|temp))"
        r"(?:\s*[\[(].*)?$",
        re.I,
    )
    GENERIC_WORK_FOLDER = re.compile(
        r"^(?:anime\s+online|donghuas?)(?:\s|$)",
        re.I,
    )
    TRAILING_EPISODE = re.compile(
        r"(?:[\s._-]+(?:episodio|episode|cap[ií]tulo|cap|ep)\s*)?\d{1,4}$",
        re.I,
    )
    SUBTITLE_SUFFIXES: ClassVar[frozenset[str]] = frozenset(
        {".srt", ".ass", ".ssa", ".sub", ".vtt", ".idx", ".smi", ".sup"}
    )
    VOB_SUFFIXES: ClassVar[frozenset[str]] = frozenset({".vob"})
    DISC_FOLDER = re.compile(r"^(?:video[ _-]*ts|bdmv|disc|disk|dvd)(?:[ _-]*\d+)?$", re.I)
    PATH_RULES: ClassVar[tuple[tuple[str, tuple[str, ...]], ...]] = (
        ("anime", ("anime", "animes", "manga", "mangas", "donghua", "donghuas")),
        ("novela", ("novela", "novelas", "telenovela", "telenovelas")),
        ("dorama", ("dorama", "doramas", "kdrama", "k-drama", "jdrama", "cdrama")),
        (
            "concurso",
            ("concurso", "concursos", "reality", "talent show", "game show"),
        ),
        (
            "western_animation",
            ("animados", "animadas", "cartoon", "cartoons", "animacion", "animación"),
        ),
        ("series", ("series", "tv show", "tv shows", "programas")),
        (
            "movie",
            (
                "pelicula",
                "películas",
                "peliculas",
                "movies",
                "movie",
                "filmes",
                "films",
                "cine",
                "documental",
                "documentales",
                "documentary",
                "documentaries",
            ),
        ),
    )
    REVIEW_ONLY_KEYWORDS: ClassVar[tuple[str, ...]] = (
        "concierto",
        "concert",
        "curso",
        "course",
        "tutorial",
        "karaoke",
    )
    REVIEW_COLLECTION_SUFFIXES: ClassVar[tuple[str, ...]] = (
        "animados manga lat",
        "animados manga",
        "manga ghibli",
        "manga lat",
        "mangas",
    )
    REVIEW_WEB_NOISE = re.compile(
        r"(?:[\s._,-]+(?:wiki|fandom|drama\s+fandom|files?|folder|carpeta))+$",
        re.I,
    )
    REVIEW_EPISODE_NOISE = re.compile(
        r"(?:[\s,._-]+(?:cap[ií]tulo|cap|episodio|episode|ep)\s*[-._ ]*\d{1,4})",
        re.I,
    )
    REVIEW_SEASON_EPISODE_NOISE = re.compile(
        r"(?:[\s,._-]+(?:temporada|temp|season)\s*[-._ ]*"
        r"(?:\d{1,3})?\s*(?:cap[ií]tulo|cap|episodio|episode|ep)?\s*[-._ ]*\d{0,4})$",
        re.I,
    )
    REVIEW_STANDALONE_EPISODE = re.compile(
        r"^(?:s\d{1,3}e\d{1,4}|\d{1,3}x\d{1,4}|"
        r"(?:cap[ií]tulo|cap|episodio|episode|ep)\s*\d{1,4})$",
        re.I,
    )

    def __init__(self) -> None:
        self.normalizer = FilenameNormalizationPipeline()
        self.classifier = MediaClassifier()

    def suggest_review_title(self, value: str) -> str:
        """Propone una limpieza local reversible para una revision humana."""
        source = value.strip()
        if not source:
            return ""
        analysis = self.normalizer.analyze(source)
        candidate = analysis.candidates[0].value if analysis.candidates else source
        candidate = self._clean_bank_noise(candidate)
        folded = candidate.casefold()
        for suffix in self.REVIEW_COLLECTION_SUFFIXES:
            if not folded.endswith(suffix):
                continue
            prefix = candidate[: -len(suffix)]
            if prefix and (prefix[-1].isspace() or prefix[-1] in "-_.:"):
                return " ".join(prefix.strip(" ._-").split()) or candidate
        candidate = self.REVIEW_WEB_NOISE.sub("", candidate).strip(" .,_-")
        candidate = self.REVIEW_EPISODE_NOISE.sub(" ", candidate)
        candidate = self.REVIEW_SEASON_EPISODE_NOISE.sub("", candidate)
        candidate = re.sub(r"\b(?:dorama|sub(?:titulos?)?)\b", " ", candidate, flags=re.I)
        candidate = re.sub(r"\s*[,;:]\s*", " ", candidate)
        candidate = " ".join(candidate.strip(" .,_-").split())
        words = candidate.split()
        for size in range(1, len(words) // 2 + 1):
            left = " ".join(words[:size]).casefold()
            right = " ".join(words[size : size * 2]).casefold()
            if left == right:
                candidate = " ".join(words[:size] + words[size * 2 :]).strip()
                break
        return candidate

    def suggest_review_title_from_evidence(
        self,
        value: str,
        *,
        original_name: str | None = None,
        original_path: str | None = None,
    ) -> str:
        """Reconstruye un titulo usando solo evidencia local reversible del grupo."""
        candidates = [value, original_name or ""]
        if original_path:
            path = PureWindowsPath(original_path)
            candidates.extend(reversed(path.parts[:-1]))
        for raw in candidates:
            proposed = self.suggest_review_title(raw)
            if not proposed or self.REVIEW_STANDALONE_EPISODE.fullmatch(proposed):
                continue
            if self.SEASON_FOLDER.fullmatch(proposed):
                continue
            folded = proposed.casefold()
            if folded in {"doramas", "dorama", "series", "serie", "subtitulos"}:
                continue
            return proposed
        return ""

    def classify(
        self,
        session: ProcessingSession,
        *,
        cancelled: Callable[[], bool] = lambda: False,
        wait_if_paused: Callable[[], None] = lambda: None,
        progress: ProgressCallback = lambda value: None,
    ) -> tuple[ProcessingSession, LocalPreparationSummary]:
        changed: list[SessionItem] = []
        total = len(session.items)
        for index, item in enumerate(session.items, start=1):
            wait_if_paused()
            if cancelled():
                raise RuntimeError("clasificación cancelada por el usuario")
            if (
                item.classification_version == self.CLASSIFICATION_VERSION
                and item.classification_status
                not in {"classification_pending", "classification_error"}
            ):
                changed.append(item)
                continue
            name = item.original_name or PureWindowsPath(item.original_path).name
            suffix = PureWindowsPath(name).suffix.casefold()
            if suffix in self.AUDIO_SUFFIXES:
                changed.append(
                    replace(
                        item,
                        stage=ProcessingStage.CLASSIFIED,
                        status=SessionItemStatus.SKIPPED,
                        detected_category="unsupported_media",
                        category_confidence=100.0,
                        classification_reason="formato de audio fuera del catálogo de video",
                        matched_rules=(f"audio_extension:{suffix}",),
                        classification_version=self.CLASSIFICATION_VERSION,
                        classified_at=datetime.now(UTC),
                        classification_status="unsupported_media",
                        enrichment_status="enrichment_complete",
                    )
                )
                self._report(progress, "classifying", "Excluyendo audio no soportado", index, total)
                continue
            if suffix in self.SUBTITLE_SUFFIXES:
                changed.append(
                    replace(
                        item,
                        stage=ProcessingStage.CLASSIFIED,
                        detected_category="subtitle",
                        category_confidence=100.0,
                        classification_reason="extensión reconocida de subtítulo",
                        matched_rules=(f"subtitle_extension:{suffix}",),
                        classification_version=self.CLASSIFICATION_VERSION,
                        classified_at=datetime.now(UTC),
                        classification_status="classified",
                    )
                )
                self._report(progress, "classifying", "Separando subtítulos", index, total)
                continue
            analysis = self.normalizer.analyze(name, original_path=item.original_path)
            category, confidence, reason, rules = self._category(analysis)
            status = (
                "unclassified"
                if category == "unclassified"
                else "classification_uncertain"
                if confidence < 75
                else "classified"
            )
            changed.append(
                replace(
                    item,
                    stage=ProcessingStage.CLASSIFIED,
                    detected_category=category,
                    category_confidence=confidence,
                    classification_reason=reason,
                    matched_rules=rules,
                    classification_version=self.CLASSIFICATION_VERSION,
                    classified_at=datetime.now(UTC),
                    classification_status=status,
                )
            )
            self._report(progress, "classifying", "Clasificando localmente", index, total)
        changed_items = tuple(changed)
        result = (
            session
            if changed_items == session.items
            else replace(session, items=changed_items, updated_at=datetime.now(UTC))
        )
        return result, self.summary(result)

    def clean(
        self,
        session: ProcessingSession,
        *,
        cancelled: Callable[[], bool] = lambda: False,
        wait_if_paused: Callable[[], None] = lambda: None,
        progress: ProgressCallback = lambda value: None,
    ) -> tuple[ProcessingSession, LocalPreparationSummary]:
        changed: list[SessionItem] = []
        total = len(session.items)
        for index, item in enumerate(session.items, start=1):
            wait_if_paused()
            if cancelled():
                raise RuntimeError("limpieza cancelada por el usuario")
            if item.classification_status == "classification_pending":
                raise ValueError("la limpieza requiere clasificación local previa")
            if item.classification_status == "unsupported_media":
                changed.append(
                    replace(
                        item,
                        stage=ProcessingStage.CONSOLIDATED,
                        status=SessionItemStatus.SKIPPED,
                        cleaning_status="not_applicable",
                        grouping_status="not_applicable",
                        enrichment_status="enrichment_complete",
                    )
                )
                continue
            if item.cleaning_status == "cleaned" and item.detected_category != "subtitle":
                changed.append(item)
                continue
            name = item.original_name or PureWindowsPath(item.original_path).name
            analysis = self.normalizer.analyze(name, original_path=item.original_path)
            title = analysis.candidates[0].value if analysis.candidates else ""
            title = self._clean_bank_noise(title)
            subtitle = PureWindowsPath(name).suffix.casefold() in self.SUBTITLE_SUFFIXES
            cleaning_status = "cleaned" if title else "cleaning_uncertain"
            stage = (
                ProcessingStage.CONSOLIDATED if subtitle else ProcessingStage.READY_FOR_ENRICHMENT
            )
            item_status = SessionItemStatus.COMPLETED if subtitle else SessionItemStatus.PENDING
            changed.append(
                replace(
                    item,
                    stage=stage,
                    status=item_status,
                    clean_title=title or None,
                    order_prefix=analysis.order_prefix.value if analysis.order_prefix else None,
                    detected_year=analysis.year.value if analysis.year else None,
                    season_number=analysis.season.value if analysis.season else None,
                    episode_number=(analysis.episode.episode_start if analysis.episode else None),
                    technical_tags=tuple(
                        token.value
                        for token in analysis.tokens
                        if token.removed
                        and token.kind not in {TokenKind.TITLE, TokenKind.YEAR, TokenKind.EPISODE}
                    ),
                    language_hints=tuple(language.value for language in analysis.languages),
                    normalization_trace=tuple(
                        f"{entry.token}|{entry.classification.value}|{entry.action}"
                        for entry in analysis.trace
                    ),
                    normalization_version=analysis.normalizer_version,
                    possible_extra=analysis.possible_extra,
                    cleaning_reason=(
                        "normalización técnica explicable"
                        if title
                        else "no se pudo obtener un título limpio"
                    ),
                    cleaning_version=self.CLEANING_VERSION,
                    cleaned_at=datetime.now(UTC),
                    cleaning_status=cleaning_status,
                    enrichment_status=("enrichment_complete" if subtitle else "pending_enrichment"),
                )
            )
            self._report(progress, "cleaning", "Limpiando nombres localmente", index, total)
        changed_items = tuple(changed)
        result = (
            session
            if changed_items == session.items
            else replace(session, items=changed_items, updated_at=datetime.now(UTC))
        )
        return result, self.summary(result)

    def group(
        self,
        session: ProcessingSession,
        *,
        cancelled: Callable[[], bool] = lambda: False,
        wait_if_paused: Callable[[], None] = lambda: None,
        progress: ProgressCallback = lambda value: None,
    ) -> tuple[ProcessingSession, LocalPreparationSummary]:
        """Consolida archivos en obras estables sin consultar proveedores."""
        changed: list[SessionItem] = []
        total = len(session.items)
        for index, item in enumerate(session.items, start=1):
            wait_if_paused()
            if cancelled():
                raise RuntimeError("agrupación cancelada por el usuario")
            if item.stage is ProcessingStage.CONSOLIDATED:
                changed.append(item)
                continue
            if item.grouping_status == "grouped" and item.grouping_version == self.GROUPING_VERSION:
                changed.append(item)
                continue
            if item.cleaning_status not in {"cleaned", "cleaning_uncertain"}:
                raise ValueError("la agrupación requiere limpieza local previa")
            category = item.detected_category or "unclassified"
            work_title, confidence, reason = self._work_identity(item, category)
            work_title = self._display_work_title(work_title)
            bank_key = item.bank_id or session.bank_name or "sin-banco"
            # Una nueva versión de agrupamiento representa una preparación fresca:
            # no debe heredar la cola virtual ``pending_retry`` de una revisión
            # anterior. La categoría VOB se deriva solo del tipo y del archivo.
            workflow_category = enrichment_category(replace(item, review_reason=None))
            group_id = str(
                uuid5(
                    NAMESPACE_URL,
                    f"mce:{bank_key}:{workflow_category}:{work_title.casefold()}",
                )
            )
            original_group_title = self._original_group_title(item, category)
            group_analysis = self.normalizer.analyze(original_group_title)
            changed.append(
                replace(
                    item,
                    stage=ProcessingStage.READY_FOR_ENRICHMENT,
                    status=SessionItemStatus.PENDING,
                    work_group_id=group_id,
                    work_title=work_title,
                    original_group_title=original_group_title,
                    order_prefix=(
                        item.order_prefix
                        or (
                            group_analysis.order_prefix.value
                            if group_analysis.order_prefix is not None
                            else None
                        )
                    ),
                    grouping_confidence=confidence,
                    grouping_reason=reason,
                    grouping_version=self.GROUPING_VERSION,
                    grouping_status="grouped",
                    warning=None,
                    error=None,
                    enrichment_status="pending_enrichment",
                    identification_confidence=None,
                    metadata_confidence=None,
                    final_confidence=None,
                    final_category=None,
                    classification_resolution_status=None,
                    classification_resolution_explanation=None,
                    classification_conflicts=(),
                    human_title_correction=None,
                    human_title_locked=False,
                    human_decision_at=None,
                    review_reason=None,
                    providers_completed=(),
                    providers_pending=(),
                    providers_failed=(),
                    identification_query_fingerprints=(),
                    metadata_from_cache=False,
                    web_search_used=False,
                    web_search_reason=None,
                    web_search_decision=None,
                    web_search_query=None,
                    web_search_evidence=(),
                    web_search_from_cache=False,
                    ai_review_state=None,
                    ai_provider=None,
                    ai_model=None,
                    ai_prompt_version=None,
                    ai_schema_version=None,
                    ai_query_fingerprint=None,
                    ai_sources=(),
                    ai_contradictions=(),
                    ai_model_confidence=None,
                    ai_mce_score=None,
                    ai_from_cache=False,
                    ai_reason=None,
                    next_retry_at=None,
                )
            )
            self._report(progress, "grouping", "Agrupando archivos en obras", index, total)
        changed_items = tuple(changed)
        result = (
            session
            if changed_items == session.items
            else replace(session, items=changed_items, updated_at=datetime.now(UTC))
        )
        return result, self.summary(result)

    def estimate(
        self,
        session: ProcessingSession,
        selected_categories: frozenset[str] | None = None,
        providers: tuple[str, ...] = ("tmdb", "anilist", "tvmaze"),
    ) -> EnrichmentEstimate:
        selected = [
            item
            for item in session.items
            if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
            and matches_enrichment_selection(item, selected_categories)
        ]
        groups = {item.work_group_id or item.item_id for item in selected}
        completed = sum(item.enrichment_status == "enrichment_complete" for item in session.items)
        return EnrichmentEstimate(
            selected_files=len(selected),
            unique_works=len(groups),
            individual_episodes=0,
            cached_works=0,
            excluded_completed=completed,
            estimated_queries_by_provider={provider: len(groups) for provider in providers},
        )

    def summary(self, session: ProcessingSession) -> LocalPreparationSummary:
        categories = Counter(item.detected_category or "unclassified" for item in session.items)
        return LocalPreparationSummary(
            total=len(session.items),
            categories=dict(sorted(categories.items())),
            classified=sum(item.classification_status == "classified" for item in session.items),
            uncertain=sum(
                item.classification_status == "classification_uncertain" for item in session.items
            ),
            unclassified=sum(
                item.classification_status == "unclassified" for item in session.items
            ),
            cleaned=sum(item.cleaning_status == "cleaned" for item in session.items),
            ready_for_enrichment=sum(
                item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in session.items
            ),
            errors=sum(
                item.classification_status == "classification_error"
                or item.cleaning_status == "cleaning_error"
                for item in session.items
            ),
            unique_works=len(
                {item.work_group_id for item in session.items if item.work_group_id is not None}
            ),
        )

    def _work_identity(self, item: SessionItem, category: str) -> tuple[str, float, str]:
        path = PureWindowsPath(item.original_path)
        parent = path.parent
        if path.suffix.casefold() in self.VOB_SUFFIXES and category in self.CONTENT_CATEGORIES:
            while self.DISC_FOLDER.fullmatch(parent.name.strip()):
                parent = parent.parent
            if self.SEASON_FOLDER.fullmatch(parent.name.strip()):
                parent = parent.parent
            folder_title = parent.name.strip()
            if folder_title:
                cleaned = self.normalizer.analyze(folder_title, original_path=str(parent))
                title = cleaned.candidates[0].value if cleaned.candidates else folder_title
                return (
                    self._clean_bank_noise(title),
                    98.0,
                    "fragmentos VOB agrupados por la carpeta de obra",
                )
        if category in self.EPISODIC_CATEGORIES and (
            item.season_number is not None or item.episode_number is not None
        ):
            file_title = item.clean_title or path.stem
            if file_title:
                return (
                    file_title,
                    96.0,
                    "t?tulo base epis?dico independiente de la ruta f?sica",
                )
        if self.SEASON_FOLDER.fullmatch(parent.name.strip()):
            parent = parent.parent
        folder_title = parent.name.strip()
        if category in self.EPISODIC_CATEGORIES and self.GENERIC_WORK_FOLDER.match(folder_title):
            file_title = item.clean_title or PureWindowsPath(item.original_path).stem
            work_title = self.TRAILING_EPISODE.sub("", file_title).strip(" ._-")
            return (
                work_title or file_title,
                90.0,
                "título base del archivo dentro de carpeta contenedora",
            )
        if category in self.EPISODIC_CATEGORIES and folder_title:
            cleaned = self.normalizer.analyze(folder_title, original_path=str(parent))
            title = cleaned.candidates[0].value if cleaned.candidates else folder_title
            return title, 95.0, "carpeta de obra compartida y categoría episódica"
        title = item.clean_title or item.original_name or path.stem
        return title, 90.0, "título limpio y categoría"

    @staticmethod
    def _display_work_title(value: str) -> str:
        collapsed = re.sub(r"\s+", " ", value).strip()
        return collapsed.title() if collapsed.isupper() else collapsed

    def _original_group_title(self, item: SessionItem, category: str) -> str:
        path = PureWindowsPath(item.original_path)
        parent = path.parent
        while self.DISC_FOLDER.fullmatch(parent.name.strip()):
            parent = parent.parent
        if self.SEASON_FOLDER.fullmatch(parent.name.strip()):
            parent = parent.parent
        if category in self.EPISODIC_CATEGORIES and parent.name.strip():
            return parent.name.strip()
        return item.original_name or path.stem

    def _category(self, analysis: FilenameAnalysis) -> tuple[str, float, str, tuple[str, ...]]:
        text = f"{analysis.original_path or ''} {analysis.original_name}".casefold()
        path_context = str(
            PureWindowsPath(analysis.original_path).parent if analysis.original_path else ""
        ).casefold()
        local = self.classifier.classify(analysis)
        episodic = local.kind in {MediaKind.EPISODE, MediaKind.SEASON}
        path_match = self._path_category(
            path_context,
            allowed=self.EPISODIC_CATEGORIES if episodic else None,
        )
        if episodic and path_match is not None:
            category, matched = path_match
            return (
                category,
                max(local.confidence, 95.0),
                "obra seriada inferida por estructura y carpeta padre",
                tuple(evidence.signal for evidence in local.evidence) + matched,
            )
        if episodic:
            return (
                "series",
                local.confidence,
                "estructura episódica agrupada como serie",
                tuple(evidence.signal for evidence in local.evidence),
            )
        if path_match is not None:
            category, matched = path_match
            return category, 95.0, "contexto de ruta o carpeta", matched
        review_matches = tuple(
            keyword for keyword in self.REVIEW_ONLY_KEYWORDS if self._contains_word(text, keyword)
        )
        if review_matches:
            return (
                "unclassified",
                50.0,
                "tipo pendiente de proveedor o revisión humana",
                review_matches,
            )
        if local.kind is MediaKind.UNKNOWN:
            return "unclassified", 0.0, "evidencia local insuficiente", ()
        final_category = {
            MediaKind.DOCUMENTARY: "movie",
            MediaKind.DVD_DISC: "movie",
            MediaKind.SPECIAL: "movie",
            MediaKind.SEASON: "series",
            MediaKind.EPISODE: "series",
        }.get(local.kind, local.kind.value)
        return (
            final_category,
            local.confidence,
            "patrones técnicos del nombre",
            tuple(evidence.signal for evidence in local.evidence),
        )

    @staticmethod
    def _clean_bank_noise(value: str) -> str:
        """Retira numeración frontal y marcas operativas sin tocar el original."""
        cleaned = re.sub(
            r"^\s*(?:cap(?:ítulo|itulo)?|ep(?:isodio)?|episode)?\s*\d{1,4}"
            r"\s*[-_.:]\s*",
            "",
            value,
            flags=re.I,
        )
        cleaned = re.sub(
            r"\b(?:trocadero|banco)[\s_-]*\d+[a-zªº]*\b",
            "",
            cleaned,
            flags=re.I,
        )
        return re.sub(r"\s+", " ", cleaned).strip(" ._-") or value.strip()

    def _path_category(
        self,
        text: str,
        *,
        allowed: frozenset[str] | None = None,
    ) -> tuple[str, tuple[str, ...]] | None:
        candidates: list[tuple[int, str, str]] = []
        for category, keywords in self.PATH_RULES:
            if allowed is not None and category not in allowed:
                continue
            for keyword in keywords:
                matches = tuple(
                    re.finditer(
                        rf"(?<![\w]){re.escape(keyword.casefold())}(?![\w])",
                        text,
                    )
                )
                if matches:
                    candidates.append((matches[-1].start(), category, keyword))
        if not candidates:
            return None
        deepest = max(position for position, _, _ in candidates)
        selected = tuple(
            (category, keyword) for position, category, keyword in candidates if position == deepest
        )
        category = selected[0][0]
        return category, tuple(keyword for _, keyword in selected)

    @staticmethod
    def _contains_word(text: str, keyword: str) -> bool:
        return bool(
            re.search(
                rf"(?<![\w]){re.escape(keyword.casefold())}(?![\w])",
                text,
            )
        )

    @staticmethod
    def _report(
        callback: ProgressCallback, stage: str, label: str, processed: int, total: int
    ) -> None:
        if processed == total or processed == 1 or processed % 250 == 0:
            callback(
                ProcessingProgress(
                    stage,
                    label,
                    processed,
                    total,
                    round(processed * 100 / total, 1) if total else 100.0,
                    round(processed * 100 / total) if total else 100,
                )
            )
