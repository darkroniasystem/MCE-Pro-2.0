"""Clasificación técnica por extensión y patrones DVD."""

import re

from mce.application.dto import DetectedMediaType

VIDEO_EXTENSIONS = frozenset(
    {
        ".mp4",
        ".mkv",
        ".avi",
        ".mov",
        ".mpg",
        ".mpeg",
        ".m4v",
        ".wmv",
        ".flv",
        ".webm",
        ".ts",
        ".m2ts",
        ".vob",
        ".3gp",
        ".ogv",
    }
)
SUBTITLE_EXTENSIONS = frozenset({".srt", ".ass", ".ssa", ".vtt", ".sub", ".smi"})
_DVD_VOB = re.compile(r"^VTS_\d{2}_\d\.VOB$", re.IGNORECASE)


def classify_media(name: str, extension: str) -> DetectedMediaType:
    """Clasifica sin abrir ni analizar el archivo multimedia."""
    upper_name = name.upper()
    normalized_extension = extension.lower()
    if upper_name in {"VIDEO_TS", "VIDEO_TS.IFO"} or _DVD_VOB.match(name):
        return DetectedMediaType.DVD
    if normalized_extension == ".txt":
        return DetectedMediaType.SUBTITLE_PROBABLE
    if normalized_extension in SUBTITLE_EXTENSIONS:
        return DetectedMediaType.SUBTITLE
    if normalized_extension in VIDEO_EXTENSIONS:
        return DetectedMediaType.VIDEO
    return DetectedMediaType.UNKNOWN
