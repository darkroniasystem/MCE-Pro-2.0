"""Validación de la forma general del contrato canónico."""

from typing import Any

from mce.application.dto import ImportIssue, ImportIssueSeverity, ImportLimits


def _issue(
    code: str,
    message: str,
    *,
    severity: ImportIssueSeverity = ImportIssueSeverity.WARNING,
    location: str | None = None,
    record_index: int | None = None,
    field_name: str | None = None,
    raw_value: Any = None,
) -> ImportIssue:
    return ImportIssue(
        code,
        severity,
        message,
        location,
        record_index,
        field_name,
        raw_value,
    )


class StructuralValidator:
    """Comprueba contenedores y campos mínimos sin interpretar relaciones."""

    def validate(self, document: dict[str, Any], limits: ImportLimits) -> tuple[ImportIssue, ...]:
        """Devuelve todas las incidencias estructurales detectables en una pasada."""
        issues: list[ImportIssue] = []
        sources = document.get("sources")
        files = document.get("files")
        if not document.get("_sources_container_valid", isinstance(sources, list)):
            issues.append(
                _issue(
                    "INVALID_SOURCES_LIST",
                    "sources debe ser una lista.",
                    severity=ImportIssueSeverity.ERROR,
                    location="sources",
                )
            )
            sources = []
        if not document.get("_files_container_valid", isinstance(files, list)):
            issues.append(
                _issue(
                    "INVALID_FILES_LIST",
                    "files debe ser una lista.",
                    severity=ImportIssueSeverity.ERROR,
                    location="files",
                )
            )
            files = []
        assert isinstance(sources, list)
        assert isinstance(files, list)
        if len(sources) > limits.max_sources:
            issues.append(
                _issue(
                    "SOURCE_LIMIT_EXCEEDED",
                    "La cantidad de fuentes supera el límite configurado.",
                    severity=ImportIssueSeverity.FATAL,
                    location="sources",
                )
            )
        if len(sources) + len(files) > limits.max_total_records:
            issues.append(
                _issue(
                    "RECORD_LIMIT_EXCEEDED",
                    "La cantidad total de registros supera el límite configurado.",
                    severity=ImportIssueSeverity.FATAL,
                )
            )
        for index, source in enumerate(sources):
            if not isinstance(source, dict):
                issues.append(
                    _issue(
                        "INVALID_SOURCE_RECORD",
                        "La entrada de fuente no es un objeto.",
                        record_index=index,
                        location="sources",
                    )
                )
        for index, file_record in enumerate(files):
            if not isinstance(file_record, dict):
                issues.append(
                    _issue(
                        "INVALID_FILE_RECORD",
                        "La entrada de archivo no es un objeto.",
                        record_index=index,
                        location="files",
                    )
                )
                continue
            name = file_record.get("name")
            if not isinstance(name, str) or not name.strip():
                issues.append(
                    _issue(
                        "FILE_NAME_MISSING",
                        "El archivo no tiene un nombre válido.",
                        record_index=index,
                        location="files",
                        field_name="name",
                        raw_value=name,
                    )
                )
            relative = file_record.get("relative_path")
            full = file_record.get("full_path")
            if not self._usable_text(relative) and not self._usable_text(full):
                issues.append(
                    _issue(
                        "PATH_MISSING",
                        "El archivo no tiene ruta relativa ni completa.",
                        record_index=index,
                        location="files",
                        field_name="path",
                    )
                )
        return tuple(issues)

    @staticmethod
    def _usable_text(value: Any) -> bool:
        return isinstance(value, str) and bool(value.strip())
