"""Contrato del lector de documentos JSON."""

from pathlib import Path
from typing import Any, Protocol

from mce.application.dto import ImportLimits


class FileReader(Protocol):
    """Lee un único documento externo sin modificarlo."""

    def read(self, path: Path, limits: ImportLimits) -> dict[str, Any]:
        """Devuelve un objeto JSON raíz validado de forma segura."""
        ...
