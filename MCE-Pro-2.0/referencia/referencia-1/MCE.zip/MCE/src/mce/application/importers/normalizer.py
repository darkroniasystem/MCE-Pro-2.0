"""Normalización técnica hacia un contrato canónico único."""

from typing import Any

from mce.application.dto import ImportIssue, ImportIssueSeverity
from mce.application.importers.field_aliases import SchemaFieldAliases
from mce.application.importers.schema_adapters import MslSchemaAdapterRegistry
from mce.application.importers.schema_detector import SchemaDetectionResult
from mce.application.importers.streaming_json import CombinedStreamingList, StreamingJsonList

_SCOPE_TYPES = {
    "full": "full",
    "complete": "full",
    "completo": "full",
    "completa": "full",
    "partial": "partial",
    "parcial": "partial",
    "selected_sources": "selected_sources",
    "selected_paths": "selected_paths",
}

_SOURCE_TYPES = {
    "local_volume": "local_volume",
    "local_directory": "local_directory",
    "ruta_local": "local_directory",
    "network_share": "network_share",
    "network_directory": "network_directory",
    "unc_manual": "network_share",
    "unknown": "unknown",
}


class MslNormalizer:
    """Adapta 1.0, 2.2 y legado a nombres internos sin limpiar títulos."""

    def __init__(self, adapters: MslSchemaAdapterRegistry | None = None) -> None:
        self._adapters = adapters or MslSchemaAdapterRegistry()

    def normalize(
        self,
        document: dict[str, Any],
        detection: SchemaDetectionResult,
    ) -> tuple[dict[str, Any], tuple[ImportIssue, ...]]:
        """Devuelve el documento canónico y avisos de compatibilidad."""
        adapter = self._adapters.resolve(detection)
        aliases = adapter.aliases
        issues: list[ImportIssue] = []
        if detection.version is None:
            issues.append(
                ImportIssue(
                    "SCHEMA_VERSION_MISSING",
                    ImportIssueSeverity.WARNING,
                    "Falta schema_version; se tratará como formato legado.",
                    "schema_version",
                )
            )
            issues.append(
                ImportIssue(
                    "LEGACY_FIELD_ALIAS",
                    ImportIssueSeverity.WARNING,
                    "Se habilitaron alias controlados para el formato legado.",
                )
            )

        raw_scan = document.get("scan")
        scan = raw_scan if isinstance(raw_scan, dict) else {}
        raw_scope = scan.get("scope")
        if not isinstance(raw_scope, dict):
            raw_scope = document.get("alcance_escaneo")
        scope = raw_scope if isinstance(raw_scope, dict) else {}

        raw_sources = aliases.root(document, "sources")
        raw_files = aliases.root(document, "files")
        raw_subtitles = aliases.root(document, "subtitles")
        canonical_sources = self._normalize_sources(raw_sources, aliases)
        canonical_files = self._normalize_files(raw_files, aliases, "video")
        normalized_subtitles = self._normalize_files(raw_subtitles, aliases, "subtitle")
        if isinstance(canonical_files, StreamingJsonList):
            canonical_files = CombinedStreamingList(canonical_files, normalized_subtitles)
        else:
            canonical_files.extend(normalized_subtitles)
        if adapter.include_embedded_subtitles:
            canonical_files.extend(self._embedded_subtitles(canonical_files, aliases))

        bank = aliases.root(document, "bank")
        installation = aliases.root(document, "installation")
        generator = document.get("generator")
        if not isinstance(generator, dict):
            generator = {"name": "MSL", "version": document.get("app_version")}
        summary = aliases.root(document, "summary")

        canonical = {
            "schema_version": adapter.schema_version,
            "generator": generator,
            "scan": {
                "scan_id": SchemaFieldAliases.first(scan, ("scan_id",), document.get("scan_id")),
                "started_at": SchemaFieldAliases.first(
                    scan, ("started_at",), document.get("fecha_inicio")
                ),
                "finished_at": SchemaFieldAliases.first(
                    scan, ("finished_at",), document.get("fecha_fin")
                ),
                "status": SchemaFieldAliases.first(scan, ("status",), document.get("estado")),
                "scope": {
                    "type": _SCOPE_TYPES.get(
                        str(SchemaFieldAliases.first(scope, ("type", "tipo"), "partial")).lower(),
                        "partial",
                    ),
                    "source_ids": SchemaFieldAliases.first(
                        scope, ("source_ids", "sources", "fuentes"), []
                    ),
                    "included_paths": SchemaFieldAliases.first(
                        scope, ("included_paths", "paths", "rutas"), []
                    ),
                },
            },
            "bank": self._normalize_bank(bank),
            "installation": self._normalize_installation(installation),
            "sources": canonical_sources,
            "files": canonical_files,
            "summary": summary if isinstance(summary, dict) else None,
            "_sources_container_valid": raw_sources is None or isinstance(raw_sources, list),
            "_files_container_valid": (
                (raw_files is None or isinstance(raw_files, list))
                and (raw_subtitles is None or isinstance(raw_subtitles, list))
            ),
        }
        return canonical, tuple(issues)

    @staticmethod
    def _normalize_bank(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            return {}
        return {
            "bank_id": SchemaFieldAliases.first(value, ("bank_id", "id")),
            "name": SchemaFieldAliases.first(value, ("name", "nombre")),
        }

    @staticmethod
    def _normalize_installation(value: Any) -> dict[str, Any]:
        if not isinstance(value, dict):
            return {}
        return {
            "installation_id": SchemaFieldAliases.first(value, ("installation_id", "id")),
            "name": SchemaFieldAliases.first(value, ("name", "nombre", "nombre_equipo")),
            "machine_identifier": SchemaFieldAliases.first(
                value, ("machine_identifier", "machine_id")
            ),
        }

    @staticmethod
    def _normalize_sources(value: Any, aliases: SchemaFieldAliases) -> Any:
        if not isinstance(value, list):
            return value
        if isinstance(value, StreamingJsonList):
            return value.transformed(
                lambda record: MslNormalizer._normalized_source(record, aliases)
            )
        for index, record in enumerate(value):
            value[index] = MslNormalizer._normalized_source(record, aliases)
        return value

    @staticmethod
    def _normalized_source(record: Any, aliases: SchemaFieldAliases) -> Any:
        if not isinstance(record, dict):
            return record
        raw_type = str(aliases.first(record, ("type", "tipo"), "unknown")).lower()
        return {
            "source_id": aliases.first(record, ("source_id", "id")),
            "type": _SOURCE_TYPES.get(raw_type, "unknown"),
            "display_name": aliases.first(record, ("display_name", "name", "nombre")),
            "root_path": aliases.first(record, ("root_path", "path", "ruta")),
            "raw_type": raw_type,
        }

    @staticmethod
    def _normalize_files(value: Any, aliases: SchemaFieldAliases, default_type: str) -> list[Any]:
        if value is None:
            return []
        if not isinstance(value, list):
            return []
        if isinstance(value, StreamingJsonList):
            return value.transformed(
                lambda record: MslNormalizer._normalized_file(record, aliases, default_type)
            )
        for index, record in enumerate(value):
            value[index] = MslNormalizer._normalized_file(record, aliases, default_type)
        return value

    @staticmethod
    def _normalized_file(record: Any, aliases: SchemaFieldAliases, default_type: str) -> Any:
        if not isinstance(record, dict):
            return record
        name = aliases.first(record, ("name", "file_name", "filename", "nombre"))
        return {
            "file_id": aliases.first(record, ("file_id", "media_id", "id")),
            "source_id": aliases.first(record, ("source_id", "source")),
            "name": name,
            "relative_path": aliases.first(record, ("relative_path", "ruta_relativa")),
            "full_path": aliases.first(record, ("full_path", "path", "ruta", "ruta_completa")),
            "extension": aliases.first(record, ("extension", "ext")),
            "media_type": aliases.first(record, ("media_type",), default_type),
            "size": aliases.first(record, ("size", "size_bytes", "tamano")),
            "hash": aliases.first(record, ("hash", "sha256")),
            "embedded_subtitles": record.get("subtitulos", []),
        }

    @classmethod
    def _embedded_subtitles(cls, files: list[Any], aliases: SchemaFieldAliases) -> list[Any]:
        subtitles: list[Any] = []
        for video in files:
            if not isinstance(video, dict):
                continue
            raw = video.get("embedded_subtitles")
            if not isinstance(raw, list):
                continue
            for item in cls._normalize_files(raw, aliases, "subtitle"):
                if isinstance(item, dict) and not item.get("source_id"):
                    item["source_id"] = video.get("source_id")
                subtitles.append(item)
        return subtitles
