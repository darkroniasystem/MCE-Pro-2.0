"""Validador determinista: el modelo nunca se autoaprueba a si mismo."""

from __future__ import annotations

import re
import unicodedata
from urllib.parse import urlparse

from mce.application.ai_review.decision_engine import AIDecisionEngine
from mce.application.ai_review.models import (
    SCHEMA_VERSION,
    AIReviewDecision,
    AIReviewInput,
    AIReviewResult,
    AIReviewState,
)


class EvidenceValidator:
    def __init__(
        self,
        decision_engine: AIDecisionEngine | None = None,
        *,
        min_model_confidence: float = 80,
    ) -> None:
        self.decision_engine = decision_engine or AIDecisionEngine()
        self.min_model_confidence = min_model_confidence

    def validate(self, item: AIReviewInput, proposal: AIReviewResult) -> AIReviewResult:
        sources = tuple(source for source in proposal.sources if self._public_http(source.url))
        domains = {
            urlparse(source.url).netloc.casefold().removeprefix("www.") for source in sources
        }
        canonical_domains = {
            urlparse(source.url).netloc.casefold().removeprefix("www.")
            for source in sources
            if self._same_title(proposal.canonical_title, source.title)
        }
        score = self.decision_engine.score(item, proposal)
        contradictions = tuple(value for value in proposal.contradictions if value.strip())
        if proposal.hallucinated_source:
            contradictions = tuple(
                dict.fromkeys((*contradictions, "el analizador citó una fuente no suministrada"))
            )
        confidence_ok = (
            proposal.model_confidence is None
            or proposal.model_confidence >= self.min_model_confidence
        )
        analyzer_allows_accept = self._analyzer_allows_accept(proposal)
        strong = (
            score >= 80
            and len(domains) >= 1
            and len(canonical_domains) >= 1
            and not contradictions
            and not proposal.hallucinated_source
            and bool(proposal.canonical_title)
            and bool(proposal.media_type)
            and confidence_ok
            and analyzer_allows_accept
        )
        if strong:
            state = AIReviewState.APPROVED
            decision = AIReviewDecision.APPROVE
        elif sources or proposal.canonical_title:
            state = AIReviewState.HUMAN
            decision = AIReviewDecision.HUMAN_REVIEW
        else:
            state = AIReviewState.NOT_FOUND
            decision = AIReviewDecision.NOT_FOUND
        return AIReviewResult(
            schema_version=SCHEMA_VERSION,
            state=state,
            decision=decision,
            canonical_title=proposal.canonical_title,
            media_type=proposal.media_type,
            year=proposal.year,
            seasons=proposal.seasons,
            deterministic_score=score,
            sources=sources,
            contradictions=contradictions,
            reason=proposal.reason,
            model=proposal.model,
            cached=proposal.cached,
            provider=proposal.provider,
            model_confidence=proposal.model_confidence,
            prompt_version=proposal.prompt_version,
            query_fingerprint=proposal.query_fingerprint,
            latency_ms=proposal.latency_ms,
            input_tokens=proposal.input_tokens,
            output_tokens=proposal.output_tokens,
            hallucinated_source=proposal.hallucinated_source,
            field_evidence=proposal.field_evidence,
            analysis_status=proposal.analysis_status,
            recommended_action=proposal.recommended_action,
        )

    @staticmethod
    def _analyzer_allows_accept(proposal: AIReviewResult) -> bool:
        if proposal.provider == "ollama":
            return (
                proposal.analysis_status == "matched"
                and proposal.recommended_action == "accept"
            )
        if proposal.provider == "groq":
            return proposal.decision is AIReviewDecision.APPROVE
        return True

    @staticmethod
    def _public_http(url: str) -> bool:
        parsed = urlparse(url)
        host = parsed.hostname or ""
        return (
            parsed.scheme in {"http", "https"}
            and bool(host)
            and host
            not in {
                "localhost",
                "127.0.0.1",
                "::1",
            }
        )

    @staticmethod
    def _same_title(left: str | None, right: str | None) -> bool:
        def normalized(value: str | None) -> str:
            folded = unicodedata.normalize("NFKD", value or "")
            ascii_text = "".join(
                character for character in folded if not unicodedata.combining(character)
            )
            return " ".join(re.findall(r"[a-z0-9]+", ascii_text.casefold()))

        canonical = normalized(left)
        source = normalized(right)
        if not canonical:
            return False
        if canonical == source:
            return True
        canonical_tokens = canonical.split()
        source_tokens = source.split()
        if source_tokens[: len(canonical_tokens)] != canonical_tokens:
            return False
        suffix = source_tokens[len(canonical_tokens) :]
        harmless = {
            "tv",
            "series",
            "movie",
            "film",
            "anime",
            "drama",
            "dorama",
            "imdb",
            "tmdb",
            "wikipedia",
        }
        return bool(suffix) and all(token in harmless or token.isdigit() for token in suffix)
