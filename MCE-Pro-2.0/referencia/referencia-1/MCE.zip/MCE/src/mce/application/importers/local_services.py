"""Implementaciones locales sin persistencia para hash y duplicados."""

import hashlib
from pathlib import Path

from mce.application.exceptions import ImportFileAccessError


class LocalSha256Calculator:
    """Calcula SHA-256 por bloques sin conservar contenido en memoria."""

    def __init__(self, chunk_size: int = 1024 * 1024) -> None:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        self._chunk_size = chunk_size

    def calculate(self, path: Path) -> str:
        """Devuelve la huella hexadecimal del archivo original."""
        digest = hashlib.sha256()
        try:
            with path.open("rb") as stream:
                while chunk := stream.read(self._chunk_size):
                    digest.update(chunk)
        except OSError as exc:
            raise ImportFileAccessError("No se pudo calcular la huella del archivo.") from exc
        return digest.hexdigest()


class InMemoryImportRegistry:
    """Registro efímero para pruebas y una única ejecución de escritorio."""

    def __init__(self, hashes: set[str] | None = None) -> None:
        self._hashes = set(hashes or ())

    def contains_hash(self, file_hash: str) -> bool:
        """Consulta una huella sin modificar el registro."""
        return file_hash in self._hashes

    def add_hash(self, file_hash: str) -> None:
        """Registra una huella completada."""
        self._hashes.add(file_hash)
