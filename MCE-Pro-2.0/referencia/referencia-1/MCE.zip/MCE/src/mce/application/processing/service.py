"""Coordinador de casos de uso existentes para una sesión."""

import hashlib
import json
import logging
import re
from collections.abc import Callable
from dataclasses import asdict, replace
from datetime import UTC, datetime
from pathlib import PureWindowsPath
from time import monotonic
from typing import cast

from mce.application.ai_review import (
    AIReviewDecision,
    AIReviewInput,
    AIReviewResult,
    AIReviewState,
)
from mce.application.classification import (
    ClassificationResolutionStatus,
    ClassificationResolver,
    ClassificationSignal,
    ClassificationSignalSource,
)
from mce.application.dto import ProcessingSession, ProcessingStage, SessionItem
from mce.application.enrichment.models import MetadataField, ReviewItem
from mce.application.enrichment.service import InMemoryReviewRepository
from mce.application.identification import IdentificationService
from mce.application.identification.models import (
    ContentCandidate,
    IdentificationQuery,
    IdentificationResult,
    IdentificationStatus,
    MatchScore,
    ProviderAttemptStatus,
    ProviderCandidate,
    ScoreEvidence,
    SearchKind,
)
from mce.application.processing.models import (
    ProcessedMedia,
    ProcessingBatchResult,
    ProcessingProgress,
)
from mce.application.processing.selection import matches_enrichment_selection
from mce.domain.value_objects import ConfidenceScore, FieldProvenance, FieldSourceType

logger = logging.getLogger(__name__)


class SessionPipelineService:
    """Ejecuta fases 5 a 9 sin inventar una identificación cuando falta evidencia."""

    def __init__(
        self,
        identifier: IdentificationService,
        review_repository: InMemoryReviewRepository | None = None,
        persist_candidate: (
            Callable[[ProviderCandidate, str | None, str, str, float], str] | None
        ) = None,
        classification_resolver: ClassificationResolver | None = None,
        resolve_known_identity: (
            Callable[[str, SearchKind, str | None], ProviderCandidate | None] | None
        ) = None,
        ai_reviewer: Callable[[AIReviewInput], AIReviewResult] | None = None,
    ) -> None:
        self.identifier = identifier
        self.review_repository = review_repository
        self.persist_candidate = persist_candidate
        self.classification_resolver = classification_resolver or ClassificationResolver()
        self.resolve_known_identity = resolve_known_identity
        self.ai_reviewer = ai_reviewer

    def process(
        self,
        session: ProcessingSession,
        *,
        cancelled: Callable[[], bool] = lambda: False,
        wait_if_paused: Callable[[], None] = lambda: None,
        progress: Callable[[int], None] = lambda value: None,
        progress_detail: Callable[[ProcessingProgress], None] = lambda value: None,
        selected_categories: frozenset[str] | None = None,
        persist_completed: Callable[[tuple[SessionItem, ...]], None] = lambda value: None,
    ) -> ProcessingBatchResult:
        processed: list[ProcessedMedia] = []
        reviews: list[dict[str, object]] = []
        catalog: list[dict[str, object]] = []
        audit_rows: list[dict[str, object]] = []
        deferred_reason: str | None = None
        target_items = tuple(
            item
            for item in session.items
            if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
            and matches_enrichment_selection(item, selected_categories)
        )
        grouped_items: dict[str, list[SessionItem]] = {}
        for item in target_items:
            group_key = item.work_group_id or item.item_id
            grouped_items.setdefault(group_key, []).append(item)
        target_groups = tuple(tuple(items) for items in grouped_items.values())
        total = len(target_groups)
        logger.info(
            "event=enrichment_batch_started session_id=%s batch_total=%d categories=%s",
            session.session_id,
            total,
            ",".join(sorted(selected_categories or ())) or "all",
        )
        identification_cache: dict[IdentificationQuery, IdentificationResult] = {}
        persisted_content: dict[tuple[str, str, str | None], str] = {}
        identified_queries: set[IdentificationQuery] = set()
        review_rows_by_query: dict[IdentificationQuery, dict[str, object]] = {}
        identified_count = 0
        review_count = 0
        error_count = 0
        completed_groups = 0
        last_detail_at = 0.0

        def report_detail(
            stage: str,
            label: str,
            index: int,
            stage_percent: int,
            *,
            force: bool = False,
        ) -> None:
            nonlocal last_detail_at
            now = monotonic()
            if not force and now - last_detail_at < 0.2:
                return
            completed = max(0, index - 1)
            fractional = stage_percent / 100
            overall = 100.0 if total == 0 else round((completed + fractional) * 100 / total, 1)
            progress_detail(
                ProcessingProgress(
                    stage,
                    label,
                    min(completed, total),
                    total,
                    min(100.0, overall),
                    stage_percent,
                    identified_count,
                    review_count,
                    error_count,
                )
            )
            last_detail_at = now

        report_detail("preparing", "Preparando la sesión", 1, 0, force=True)
        for index, group_items in enumerate(target_groups, start=1):
            work_started = monotonic()
            wait_if_paused()
            if cancelled():
                raise RuntimeError("procesamiento cancelado por el usuario")
            item = min(
                group_items,
                key=lambda candidate: (
                    candidate.possible_extra,
                    candidate.original_path.casefold(),
                    candidate.item_id,
                ),
            )
            name = item.original_name or PureWindowsPath(item.original_path).name
            title = item.work_title or item.clean_title or name
            category = item.detected_category or "unclassified"
            kind = (
                SearchKind.ANIME
                if category == "anime"
                else SearchKind.SERIES
                if category
                in {"series", "season", "episode", "novela", "dorama", "concurso", "tv_show"}
                else SearchKind.MOVIE
            )
            aliases = _safe_title_aliases(item, title)
            queries = _staged_queries(item, title, kind, aliases)
            query = queries[0]
            unsafe_external_title = _title_requires_local_review(title)
            attempted_fingerprints = {
                fingerprint
                for member in group_items
                for fingerprint in member.identification_query_fingerprints
            }
            query_fingerprints: list[str] = []
            identification = identification_cache.get(query)
            if unsafe_external_title:
                identification = IdentificationResult(
                    IdentificationStatus.NOT_FOUND_CONFIRMED,
                    (),
                    None,
                    message="título local genérico o colección; proveedores omitidos",
                    from_cache=True,
                )
                identification_cache[query] = identification
            if identification is None and self.resolve_known_identity is not None:
                known = None
                for identity_title in (title, *aliases):
                    known = self.resolve_known_identity(identity_title, kind, item.bank_id)
                    if known is not None:
                        break
                if known is not None:
                    selected_known = ContentCandidate(
                        known,
                        MatchScore(
                            100.0,
                            (
                                ScoreEvidence(
                                    "known_canonical_identity",
                                    100.0,
                                    "identidad y alias confirmados reutilizados localmente",
                                ),
                            ),
                        ),
                    )
                    identification = IdentificationResult(
                        IdentificationStatus.IDENTIFIED,
                        (selected_known,),
                        selected_known,
                        message="identidad canonica reutilizada localmente",
                        from_cache=True,
                    )
                    identification_cache[query] = identification
            if identification is None:
                fingerprint = _identification_query_fingerprint(query)
                query_fingerprints.append(fingerprint)
                if fingerprint in attempted_fingerprints:
                    identification = IdentificationResult(
                        IdentificationStatus.NOT_FOUND_CONFIRMED,
                        (),
                        None,
                        message="consulta idéntica ya agotada; proveedores omitidos",
                        from_cache=True,
                    )
                else:
                    report_detail(
                        "enriching",
                        "Buscando y enriqueciendo metadatos online",
                        index,
                        70,
                        force=index == 1,
                    )
                    identification = self.identifier.identify(query)
                identification_cache[query] = identification
            for staged_query in queries[1:]:
                eligible = (
                    identification.status
                    in {IdentificationStatus.NOT_FOUND, IdentificationStatus.NOT_FOUND_CONFIRMED}
                    if staged_query.query_variant == "local_alias"
                    else identification.status
                    in {
                        IdentificationStatus.PROBABLE,
                        IdentificationStatus.AMBIGUOUS,
                        IdentificationStatus.NOT_FOUND,
                        IdentificationStatus.NOT_FOUND_CONFIRMED,
                    }
                )
                if not eligible:
                    if identification.status is IdentificationStatus.IDENTIFIED:
                        break
                    continue
                query = staged_query
                retry = identification_cache.get(query)
                if retry is None:
                    fingerprint = _identification_query_fingerprint(query)
                    query_fingerprints.append(fingerprint)
                    if fingerprint in attempted_fingerprints:
                        retry = IdentificationResult(
                            IdentificationStatus.NOT_FOUND_CONFIRMED,
                            (),
                            None,
                            message="consulta idéntica con año ya agotada; proveedores omitidos",
                            from_cache=True,
                        )
                    else:
                        retry = self.identifier.identify(query)
                    identification_cache[query] = retry
                identification = retry
            if cancelled():
                raise RuntimeError("procesamiento cancelado por el usuario")
            if identification.status in {
                IdentificationStatus.OFFLINE,
                IdentificationStatus.PROVIDER_ERROR,
                IdentificationStatus.WAITING_RATE_LIMIT,
                IdentificationStatus.WAITING_RETRY,
                IdentificationStatus.PROVIDER_UNAVAILABLE,
                IdentificationStatus.PROVIDER_PARTIAL,
            }:
                deferred_reason = identification.message or "proveedor de metadatos no disponible"
                error_count += 1
                audit_rows.append(
                    _work_audit_row(
                        item,
                        title,
                        category,
                        query_fingerprints,
                        identification,
                        None,
                        "deferred_provider",
                        work_started,
                        len(group_items),
                    )
                )
                break
            ai_review: AIReviewResult | None = None
            identical_queries_exhausted = bool(query_fingerprints) and all(
                value in attempted_fingerprints for value in query_fingerprints
            )
            if (
                self.ai_reviewer is not None
                and not unsafe_external_title
                and not identical_queries_exhausted
                and identification.status
                in {
                    IdentificationStatus.PROBABLE,
                    IdentificationStatus.AMBIGUOUS,
                    IdentificationStatus.NOT_FOUND,
                    IdentificationStatus.NOT_FOUND_CONFIRMED,
                }
            ):
                report_detail("ai_review", "Revisando evidencia con IA", index, 82)
                ai_review = self.ai_reviewer(
                    AIReviewInput(
                        item.work_group_id or item.item_id,
                        title,
                        category,
                        item.detected_year,
                        item.season_number,
                        item.episode_number,
                        alternative_titles=aliases,
                    )
                )
                if ai_review.state is AIReviewState.WAITING_RATE_LIMIT:
                    deferred_reason = ai_review.reason or "Groq temporalmente limitado"
                    error_count += 1
                    audit_rows.append(
                        _work_audit_row(
                            item,
                            title,
                            category,
                            query_fingerprints,
                            identification,
                            ai_review,
                            "deferred_ai_rate_limit",
                            work_started,
                            len(group_items),
                        )
                    )
                    break
                if ai_review.decision is AIReviewDecision.APPROVE:
                    ai_kind = (
                        SearchKind.ANIME
                        if category == "anime"
                        else SearchKind.SERIES
                        if category in {"series", "novela", "dorama", "concurso"}
                        else SearchKind.MOVIE
                    )
                    ai_metadata = _ai_review_metadata(ai_review)
                    ai_candidate = ProviderCandidate(
                        provider="mce-ai",
                        external_id=hashlib.sha256(
                            f"{category}|{ai_review.canonical_title}|{ai_review.year}".encode()
                        ).hexdigest(),
                        kind=ai_kind,
                        title=ai_review.canonical_title or title,
                        year=ai_review.year,
                        overview=cast(str | None, ai_metadata["overview"]),
                        genres=cast(tuple[str, ...], ai_metadata["genres"]),
                        cast_names=cast(tuple[str, ...], ai_metadata["cast_names"]),
                        director=cast(str | None, ai_metadata["director"]),
                        season_count=cast(int | None, ai_metadata["season_count"]),
                        ratings=cast(tuple[tuple[str, str], ...], ai_metadata["ratings"]),
                        source_url=ai_review.sources[0].url if ai_review.sources else None,
                    )
                    selected_ai = ContentCandidate(
                        ai_candidate,
                        MatchScore(
                            ai_review.deterministic_score,
                            (
                                ScoreEvidence(
                                    "mce_ai_evidence",
                                    ai_review.deterministic_score,
                                    ai_review.reason or "evidencia IA validada por MCE",
                                ),
                            ),
                        ),
                    )
                    identification = IdentificationResult(
                        IdentificationStatus.IDENTIFIED,
                        (selected_ai,),
                        selected_ai,
                        message="aprobado por IA y validador determinista de MCE",
                    )
            selected = identification.selected
            completed_providers = tuple(
                dict.fromkeys(
                    _provider_name(attempt.provider)
                    for attempt in identification.attempts
                    if attempt.status
                    in {
                        ProviderAttemptStatus.SUCCESS_WITH_RESULTS,
                        ProviderAttemptStatus.SUCCESS_NO_RESULTS,
                    }
                )
            )
            if ai_review is not None and ai_review.decision is AIReviewDecision.APPROVE:
                completed_providers = (*completed_providers, "mce-ai")
            pending_providers = tuple(
                dict.fromkeys(
                    _provider_name(attempt.provider)
                    for attempt in identification.attempts
                    if attempt.status
                    in {
                        ProviderAttemptStatus.RATE_LIMITED,
                        ProviderAttemptStatus.TIMEOUT,
                    }
                )
            )
            failed_providers = tuple(
                dict.fromkeys(
                    _provider_name(attempt.provider)
                    for attempt in identification.attempts
                    if attempt.status
                    in {
                        ProviderAttemptStatus.UNAVAILABLE,
                        ProviderAttemptStatus.AUTHENTICATION_ERROR,
                        ProviderAttemptStatus.INVALID_RESPONSE,
                        ProviderAttemptStatus.TERMINAL_ERROR,
                    }
                )
            )
            web = identification.web_fallback
            web_used = bool(web is not None and getattr(web, "used", False))
            web_evidence = tuple(
                f"{entry.provider}|{entry.source}|{entry.title}|{entry.media_type or ''}|"
                f"{entry.year or ''}|{entry.score:.1f}|{entry.source_url}|"
                f"{entry.collected_at.isoformat()}"
                for entry in (getattr(web, "evidence", ()) if web is not None else ())
            )
            if web_used:
                completed_providers = tuple(dict.fromkeys((*completed_providers, "web")))
            resolution_signals = [
                ClassificationSignal(
                    ClassificationSignalSource.LOCAL,
                    category,
                    item.category_confidence or 0,
                    "mce-local",
                    item.classification_reason or "clasificación local",
                )
            ]
            resolution_signals.extend(
                ClassificationSignal(
                    ClassificationSignalSource.PROVIDER,
                    candidate.metadata.kind.value,
                    candidate.score.total,
                    candidate.metadata.provider,
                    f"{candidate.metadata.title} ({candidate.score.total:.1f})",
                )
                for candidate in identification.candidates
            )
            resolution_signals.extend(
                ClassificationSignal(
                    ClassificationSignalSource.WEB,
                    entry.media_type,
                    entry.score,
                    f"tavily:{entry.source}",
                    entry.source_url,
                )
                for entry in (getattr(web, "evidence", ()) if web is not None else ())
                if entry.media_type
            )
            classification_resolution = self.classification_resolver.resolve(
                tuple(resolution_signals)
            )
            resolution_allows_identification = (
                classification_resolution.status is ClassificationResolutionStatus.RESOLVED
                and _categories_compatible(classification_resolution.final_category, category)
            )
            requires_complete_metadata = any(
                member.review_reason == "pending_normalization_retry" for member in group_items
            )
            missing_metadata = (
                _missing_catalog_metadata(selected.metadata, category)
                if selected is not None and requires_complete_metadata
                else ()
            )
            metadata_level = (
                _catalog_metadata_level(selected.metadata, category)
                if selected is not None
                else "incompletos"
            )
            if (
                identification.status is IdentificationStatus.IDENTIFIED
                and selected
                and resolution_allows_identification
                and not missing_metadata
            ):
                if query not in identified_queries:
                    identified_count += 1
                    identified_queries.add(query)
                stage = ProcessingStage.CONSOLIDATED
                warning = None
                content_key = (
                    selected.metadata.provider,
                    selected.metadata.external_id,
                    item.bank_id,
                )
                persisted_id = persisted_content.get(content_key)
                if persisted_id is None:
                    persisted_id = (
                        self.persist_candidate(
                            selected.metadata,
                            item.bank_id,
                            name,
                            title,
                            selected.score.total,
                        )
                        if self.persist_candidate is not None
                        else f"{selected.metadata.provider}:{selected.metadata.external_id}"
                    )
                    persisted_content[content_key] = persisted_id
                for physical_item in group_items:
                    physical_name = (
                        physical_item.original_name
                        or PureWindowsPath(physical_item.original_path).name
                    )
                    catalog.append(
                        {
                            "archivo": str(physical_item.physical_file_id),
                            "título": selected.metadata.title,
                            "título original": selected.metadata.original_title or "—",
                            "año": selected.metadata.year,
                            "tipo": category,
                            "banco": session.bank_name or item.bank_id or "—",
                            "disponibilidad": "available",
                            "ruta": physical_item.original_path,
                            "géneros": ", ".join(selected.metadata.genres),
                            "sinopsis": selected.metadata.overview or "",
                            "reparto": ", ".join(
                                selected.metadata.cast_names or selected.metadata.cast
                            ),
                            "director": selected.metadata.director or "",
                            "temporadas": selected.metadata.season_count,
                            "valoración": next(
                                (value for _, value in selected.metadata.ratings), ""
                            ),
                            "carátula": next(
                                (
                                    url
                                    for kind, url in selected.metadata.images
                                    if kind in {"poster", "movieposter", "tvposter", "artwork"}
                                ),
                                "",
                            ),
                            "_file_id": str(physical_item.physical_file_id),
                            "_content_id": persisted_id,
                            "_source_id": str(physical_item.source_id),
                            "_installation_id": physical_item.installation_id or "",
                            "_original_name": physical_name,
                            "_size_bytes": physical_item.size_bytes,
                            "_file_hash": physical_item.file_hash or "",
                            "_bank_id": physical_item.bank_id or "",
                            # La completitud se conserva para automatización y auditoría,
                            # pero las categorías flexibles no exponen al usuario que
                            # sus metadatos complementarios son parciales.
                            "_metadata_completeness": metadata_level,
                            "estado catálogo": _public_catalog_status(
                                category, metadata_level
                            ),
                            "_catalog_stage": (
                                "metadata_partial"
                                if metadata_level == "metadatos parciales"
                                else "approved"
                            ),
                        }
                    )
            else:
                stage = ProcessingStage.REVIEWED
                warning = (
                    f"metadatos incompletos: {', '.join(missing_metadata)}"
                    if missing_metadata
                    else "requiere revisión humana"
                )
                best = identification.candidates[0] if identification.candidates else None
                grouped_review = review_rows_by_query.get(query)
                if grouped_review is None:
                    review_count += 1
                    grouped_review = {
                        "id": item.item_id,
                        "archivo": name,
                        "grupo": title,
                        "archivos agrupados": len(group_items),
                        "ruta": item.original_path,
                        "título candidato": title,
                        "tipo": category,
                        "confianza": round(item.category_confidence or 0, 1),
                        "Coincidencia": (
                            f"{best.metadata.provider} - {best.score.total:.0f} %"
                            if best is not None
                            else "Evidencia web disponible"
                            if web_evidence
                            else "Sin coincidencias"
                        ),
                        "estado IA": ai_review.state.value if ai_review else "no ejecutada",
                        "modelo IA": ai_review.model if ai_review else "—",
                        "confianza MCE IA": (ai_review.deterministic_score if ai_review else None),
                        "fuentes IA": (
                            " | ".join(source.url for source in ai_review.sources)
                            if ai_review
                            else "—"
                        ),
                        "contradicciones IA": (
                            (" | ".join(ai_review.contradictions) or "—") if ai_review else "—"
                        ),
                        "identificación": identification.status.value,
                        "estado de identidad": (
                            "revalidación agotada; cambia el título o resuelve la coincidencia"
                            if identical_queries_exhausted
                            else "candidato estructurado disponible"
                            if best is not None
                            else "evidencia web encontrada; identificaci\u00f3n pendiente"
                            if web_evidence
                            else "sin identificaci\u00f3n externa"
                        ),
                        "aprobaci\u00f3n resultante": (
                            "identidad estructurada"
                            if best is not None
                            else "identificaci\u00f3n manual incompleta"
                        ),
                        "consulta usada": query.title,
                        "a\u00f1o pista": item.detected_year,
                        "evidencia web": " | ".join(web_evidence) or "\u2014",
                        "candidatos externos": " | ".join(
                            f"{candidate.metadata.title} ({candidate.score.total:.1f})"
                            for candidate in identification.candidates[:3]
                        )
                        or "sin coincidencias",
                        "título original candidato": (
                            best.metadata.original_title if best else None
                        )
                        or "—",
                        "título inglés candidato": (best.metadata.english_title if best else None)
                        or "—",
                        "proveedor candidato": best.metadata.provider if best else "—",
                        "puntuación externa": best.score.total if best else None,
                        "evidencia": ", ".join(
                            (
                                *item.matched_rules,
                                *(
                                    evidence.rule
                                    for evidence in (best.score.evidence if best else ())
                                ),
                            )
                        )
                        or "local",
                        "conflicto": (
                            "; ".join(classification_resolution.conflicts)
                            or (
                                "varios candidatos con puntuación cercana"
                                if identification.status is IdentificationStatus.AMBIGUOUS
                                else "—"
                            )
                        ),
                        "decisión de clasificación": classification_resolution.explanation,
                        "_candidate": best.metadata if best else None,
                        "_candidates": tuple(
                            candidate.metadata for candidate in identification.candidates[:8]
                        ),
                        "_candidate_approvable": (
                            identification.status is IdentificationStatus.PROBABLE
                            and best is not None
                        ),
                        "banco": session.bank_name or item.bank_id or "—",
                        "_bank_id": item.bank_id or "",
                        "_size_bytes": item.size_bytes,
                        "_file_hash": item.file_hash or "",
                        "_item_ids": [member.item_id for member in group_items],
                    }
                    reviews.append(grouped_review)
                    review_rows_by_query[query] = grouped_review
                if self.review_repository is not None and grouped_review["id"] == item.item_id:
                    provenance = FieldProvenance(
                        FieldSourceType.IMPORTED,
                        "msl",
                        str(item.import_id),
                        datetime.now(UTC),
                        ConfidenceScore(min(100, max(0, round(item.category_confidence or 0)))),
                    )
                    fields = {
                        "title": MetadataField(title, provenance),
                        "type": MetadataField(category, provenance),
                        "path": MetadataField(item.original_path, provenance),
                        "bank": MetadataField(session.bank_name or item.bank_id or "—", provenance),
                        "source_id": MetadataField(str(item.source_id), provenance),
                        "installation_id": MetadataField(item.installation_id or "", provenance),
                        "original_name": MetadataField(name, provenance),
                        "size_bytes": MetadataField(item.size_bytes, provenance),
                        "file_hash": MetadataField(item.file_hash or "", provenance),
                    }
                    if item.detected_year:
                        fields["year"] = MetadataField(item.detected_year, provenance)
                    self.review_repository.save(
                        ReviewItem(item.item_id, str(item.physical_file_id), fields)
                    )
            for member in group_items:
                changed = replace(
                    member.processed(stage, warning=warning),
                    identification_confidence=(
                        selected.score.total if selected is not None else None
                    ),
                    metadata_confidence=(
                        selected.score.total
                        if selected is not None
                        and identification.status is IdentificationStatus.IDENTIFIED
                        else None
                    ),
                    enrichment_status=(
                        "enrichment_complete"
                        if stage is ProcessingStage.CONSOLIDATED
                        else "needs_human_review"
                    ),
                    providers_completed=completed_providers,
                    providers_pending=pending_providers,
                    providers_failed=failed_providers,
                    identification_query_fingerprints=tuple(
                        dict.fromkeys(
                            (
                                *member.identification_query_fingerprints,
                                *query_fingerprints,
                            )
                        )
                    ),
                    metadata_from_cache=identification.from_cache,
                    final_category=classification_resolution.final_category,
                    classification_resolution_status=classification_resolution.status.value,
                    classification_resolution_explanation=classification_resolution.explanation,
                    classification_conflicts=classification_resolution.conflicts,
                    web_search_used=web_used,
                    web_search_reason=(getattr(web, "reason", None) if web else None),
                    web_search_decision=(
                        "evidence_collected_review_required"
                        if web_used and web_evidence
                        else "no_relevant_evidence_review_required"
                        if web_used
                        else None
                    ),
                    web_search_query=(getattr(web, "query", None) if web else None),
                    web_search_evidence=web_evidence,
                    web_search_from_cache=bool(getattr(web, "from_cache", False) if web else False),
                    ai_review_state=ai_review.state.value if ai_review else None,
                    ai_provider=ai_review.provider if ai_review else None,
                    ai_model=ai_review.model if ai_review else None,
                    ai_prompt_version=ai_review.prompt_version if ai_review else None,
                    ai_schema_version=ai_review.schema_version if ai_review else None,
                    ai_query_fingerprint=ai_review.query_fingerprint if ai_review else None,
                    ai_sources=(
                        tuple(source.url for source in ai_review.sources) if ai_review else ()
                    ),
                    ai_contradictions=ai_review.contradictions if ai_review else (),
                    ai_model_confidence=ai_review.model_confidence if ai_review else None,
                    ai_mce_score=ai_review.deterministic_score if ai_review else None,
                    ai_from_cache=bool(ai_review.cached if ai_review else False),
                    ai_reason=ai_review.reason if ai_review else None,
                )
                processed.append(
                    ProcessedMedia(
                        changed,
                        title,
                        member.detected_year,
                        category,
                        member.category_confidence or 0,
                        identification.status.value,
                        stage,
                        warning,
                    )
                )
            persist_completed(tuple(value.item for value in processed[-len(group_items) :]))
            outcome = (
                "identified_partial"
                if (
                    stage is ProcessingStage.CONSOLIDATED
                    and metadata_level == "metadatos parciales"
                    and _strict_metadata_category(category)
                )
                else "identified"
                if stage is ProcessingStage.CONSOLIDATED
                else "human_review"
            )
            audit_row = _work_audit_row(
                item,
                title,
                category,
                query_fingerprints,
                identification,
                ai_review,
                outcome,
                work_started,
                len(group_items),
            )
            audit_rows.append(audit_row)
            logger.info(
                "event=enrichment_work_audit payload=%s",
                json.dumps(audit_row, ensure_ascii=False, sort_keys=True),
            )
            completed_groups = index
            report_detail(
                "saving", "Guardando resultados y procedencia", index, 95, force=index == 1
            )
            if index == total or index % 250 == 0:
                progress(100 if total == 0 else round(index * 100 / total))
        final_processed = total if not deferred_reason else completed_groups
        progress_detail(
            ProcessingProgress(
                "waiting_internet" if deferred_reason else "completed",
                "Esperando conexión o proveedor" if deferred_reason else "Procesamiento terminado",
                final_processed,
                total,
                round(final_processed * 100 / total, 1) if total else 100.0,
                100 if not deferred_reason else 0,
                identified_count,
                review_count,
                error_count,
            )
        )
        summary = _batch_summary(
            session.session_id,
            total,
            completed_groups,
            audit_rows,
            deferred_reason,
        )
        logger.info(
            "event=enrichment_batch_summary payload=%s",
            json.dumps(summary, ensure_ascii=False, sort_keys=True),
        )
        return ProcessingBatchResult(
            session.session_id,
            tuple(processed),
            tuple(reviews),
            tuple(catalog),
            deferred_reason,
            tuple(audit_rows),
            summary,
        )


def _missing_catalog_metadata(candidate: ProviderCandidate, category: str) -> tuple[str, ...]:
    """La identidad segura se cataloga aunque sus metadatos sean parciales."""
    del category
    if not candidate.title.strip() or not candidate.external_id.strip():
        return ("identidad externa",)
    return ()


def _ai_review_metadata(ai_review: AIReviewResult) -> dict[str, object]:
    """Materializa únicamente campos presentes en la evidencia web validada."""
    fields = {field.field_name.casefold(): field.value for field in ai_review.field_evidence}

    def strings(value: object) -> tuple[str, ...]:
        if isinstance(value, str):
            return (value.strip(),) if value.strip() else ()
        if isinstance(value, (tuple, list)):
            return tuple(str(item).strip() for item in value if str(item).strip())
        return ()

    sources = ai_review.sources
    cast_names = strings(fields.get("cast") or fields.get("reparto")) or tuple(
        dict.fromkeys(name for source in sources for name in source.cast if name.strip())
    )
    genres = strings(fields.get("genres") or fields.get("géneros")) or tuple(
        dict.fromkeys(name for source in sources for name in source.genres if name.strip())
    )
    director_values = strings(fields.get("director") or fields.get("dirección"))
    overview_values = strings(fields.get("overview") or fields.get("sinopsis"))
    overview = overview_values[0] if overview_values else next(
        (source.snippet.strip() for source in sources if source.snippet.strip()), None
    )
    raw_seasons = fields.get("season_count") or fields.get("temporadas")
    season_count = raw_seasons if isinstance(raw_seasons, int) else None
    if season_count is None:
        values = tuple(value for source in sources for value in source.seasons)
        season_count = max(values) if values else None
    raw_rating = fields.get("rating") or fields.get("valoración")
    rating = float(raw_rating) if isinstance(raw_rating, (int, float)) else next(
        (source.rating for source in sources if source.rating is not None), None
    )
    return {
        "overview": overview,
        "genres": genres,
        "cast_names": cast_names,
        "director": director_values[0] if director_values else None,
        "season_count": season_count,
        "ratings": (("web", f"{rating:g}"),) if rating is not None else (),
    }


def _strict_metadata_category(category: str) -> bool:
    return category.casefold() in {
        "pelicula",
        "peliculas",
        "película",
        "películas",
        "movie",
        "serie",
        "series",
        "novela",
        "novelas",
    }


def _useful_metadata(candidate: ProviderCandidate) -> tuple[str, ...]:
    values = {
        "año": candidate.year is not None,
        "sinopsis": bool((candidate.overview or "").strip()),
        "reparto": bool(candidate.cast_names or candidate.cast),
        "dirección": bool(candidate.director or candidate.creators),
        "temporadas": candidate.season_count is not None,
        "valoración": bool(candidate.ratings),
        "géneros": bool(candidate.genres),
        "carátula": any(
            kind in {"poster", "movieposter", "tvposter", "artwork"} for kind, _ in candidate.images
        ),
    }
    return tuple(name for name, present in values.items() if present)


def _catalog_metadata_level(candidate: ProviderCandidate, category: str) -> str:
    present = set(_useful_metadata(candidate))
    required = {"año", "sinopsis", "reparto", "dirección", "valoración"}
    if category.casefold() in {"series", "serie", "dorama"}:
        required.add("temporadas")
    return "completo" if required <= present else "metadatos parciales"


_GENERIC_EXTERNAL_TITLE = re.compile(
    r"^(?:(?:part|parte|vts|video[ _-]*ts|title|titulo|disc|disk|dvd|cd)"
    r"[\s._-]*\d+(?:[\s._-]+\d+)*)$",
    re.I,
)
_COLLECTION_EXTERNAL_TITLE = re.compile(
    r"\b(?:trilog[ií]a|colecci[oó]n|collection|combo|pack|saga completa)\b",
    re.I,
)


def _title_requires_local_review(title: str) -> bool:
    """Evita gastar proveedores e IA en fragmentos o contenedores sin identidad única."""
    normalized = " ".join(title.strip().split())
    return not normalized or bool(
        _GENERIC_EXTERNAL_TITLE.fullmatch(normalized)
        or _COLLECTION_EXTERNAL_TITLE.search(normalized)
    )


def _categories_compatible(resolved: str | None, local: str) -> bool:
    """Compara familias semánticas sin rechazar subcategorías televisivas."""
    aliases = {
        "tv": "series",
        "tv_show": "series",
        "episode": "series",
        "season": "series",
        "dorama": "series",
        "novela": "series",
        "concurso": "series",
        "pelicula": "movie",
        "películas": "movie",
        "peliculas": "movie",
    }
    resolved_key = (resolved or "").strip().casefold()
    local_key = local.strip().casefold()
    left = aliases.get(resolved_key, resolved_key)
    right = aliases.get(local_key, local_key)
    return bool(left) and left == right


def _public_catalog_status(category: str, metadata_level: str) -> str:
    """Estado visible; la completitud real queda en el campo interno del catálogo."""
    if _strict_metadata_category(category):
        return metadata_level
    return "catalogado"


def _identification_query_fingerprint(query: IdentificationQuery) -> str:
    payload = json.dumps(
        asdict(query),
        sort_keys=True,
        ensure_ascii=False,
        default=str,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _provider_name(value: str) -> str:
    """Quita decoradores técnicos y conserva el nombre estable del proveedor."""
    return value.rsplit(":", 1)[-1].casefold()


def _safe_title_aliases(item: SessionItem, title: str) -> tuple[str, ...]:
    """Recupera solo titulos derivados localmente; nunca rutas ni nombres completos."""
    candidates = (
        item.human_title_correction,
        item.original_group_title,
        item.clean_title,
        item.work_title,
    )
    return tuple(
        dict.fromkeys(
            value.strip()
            for value in candidates
            if value and value.strip() and value.casefold().strip() != title.casefold().strip()
        )
    )[:4]


def _staged_queries(
    item: SessionItem,
    title: str,
    kind: SearchKind,
    aliases: tuple[str, ...],
) -> tuple[IdentificationQuery, ...]:
    """Genera consultas baratas primero y reserva web/ano para el ultimo intento."""
    normalizer = item.normalization_version or "mce-filename-normalizer-v3"
    queries = [
        IdentificationQuery(
            title,
            kind,
            aliases=aliases,
            query_variant="clean_title",
            normalizer_version=normalizer,
            allow_web_fallback=False,
        )
    ]
    if item.detected_year is not None:
        queries.append(
            IdentificationQuery(
                title,
                kind,
                item.detected_year,
                aliases=aliases,
                season=item.season_number,
                episode=item.episode_number,
                query_variant="structured_year_hint",
                normalizer_version=normalizer,
                allow_web_fallback=True,
            )
        )
    else:
        queries[0] = replace(queries[0], allow_web_fallback=True)
    return tuple(dict.fromkeys(queries))


def _batch_summary(
    session_id: str,
    total: int,
    completed: int,
    rows: list[dict[str, object]],
    deferred_reason: str | None,
) -> dict[str, object]:
    outcomes: dict[str, int] = {}
    provider_calls: dict[str, int] = {}
    provider_cache = 0
    ai_routes: dict[str, int] = {}
    ambiguous = 0
    without_identity = 0
    exhausted = 0
    elapsed_ms = 0
    for row in rows:
        outcome = str(row.get("outcome") or "unknown")
        outcomes[outcome] = outcomes.get(outcome, 0) + 1
        identity_status = str(row.get("identification_status") or "")
        if identity_status == IdentificationStatus.AMBIGUOUS.value:
            ambiguous += 1
        elif identity_status in {
            IdentificationStatus.NOT_FOUND.value,
            IdentificationStatus.NOT_FOUND_CONFIRMED.value,
        }:
            without_identity += 1
        fingerprints = row.get("query_fingerprints")
        if bool(row.get("identification_from_cache")) and fingerprints:
            exhausted += 1
        elapsed = row.get("elapsed_ms")
        elapsed_ms += elapsed if isinstance(elapsed, int) else 0
        attempts = row.get("provider_attempts")
        for attempt in attempts if isinstance(attempts, (tuple, list)) else ():
            if not isinstance(attempt, dict):
                continue
            provider = str(attempt.get("provider") or "unknown")
            if bool(attempt.get("from_cache")):
                provider_cache += 1
            else:
                provider_calls[provider] = provider_calls.get(provider, 0) + 1
        ai_provider = str(row.get("ai_provider") or "none")
        ai_state = str(row.get("ai_state") or "not_used")
        route = f"{ai_provider}:{ai_state}"
        ai_routes[route] = ai_routes.get(route, 0) + 1
    return {
        "session_id": session_id,
        "total_works": total,
        "completed_works": completed,
        "remaining_works": max(0, total - completed),
        "outcomes": outcomes,
        "approved_complete": outcomes.get("identified", 0),
        "approved_partial": outcomes.get("identified_partial", 0),
        "returned_to_review": outcomes.get("human_review", 0),
        "ambiguous": ambiguous,
        "without_identity": without_identity,
        "revalidation_exhausted": exhausted,
        "provider_calls": provider_calls,
        "provider_cache_hits": provider_cache,
        "ai_routes": ai_routes,
        "active_elapsed_ms": elapsed_ms,
        "deferred": deferred_reason is not None,
        "deferred_reason": deferred_reason,
    }


def _work_audit_row(
    item: SessionItem,
    title: str,
    category: str,
    query_fingerprints: list[str],
    identification: IdentificationResult,
    ai_review: AIReviewResult | None,
    outcome: str,
    started: float,
    grouped_files: int,
) -> dict[str, object]:
    """Resumen sin rutas privadas, suficiente para auditar coste y decisiones."""
    return {
        "work_group_id": item.work_group_id or item.item_id,
        "title": title,
        "category": category,
        "grouped_files": grouped_files,
        "query_fingerprints": tuple(dict.fromkeys(query_fingerprints)),
        "provider_attempts": tuple(
            {
                "provider": attempt.provider,
                "status": attempt.status.value,
                "from_cache": bool(getattr(attempt, "from_cache", False)),
            }
            for attempt in identification.attempts
        ),
        "identification_status": identification.status.value,
        "identification_from_cache": identification.from_cache,
        "ai_state": ai_review.state.value if ai_review else None,
        "ai_provider": ai_review.provider if ai_review else None,
        "ai_model": ai_review.model if ai_review else None,
        "ai_from_cache": bool(ai_review.cached) if ai_review else False,
        "ai_score": ai_review.deterministic_score if ai_review else None,
        "source_count": len(ai_review.sources) if ai_review else 0,
        "contradiction_count": len(ai_review.contradictions) if ai_review else 0,
        "outcome": outcome,
        "elapsed_ms": round((monotonic() - started) * 1000),
    }
