"""Exportación segura y estable de conjuntos operativos."""

from __future__ import annotations

import csv
import json
from collections.abc import Iterable, Mapping
from dataclasses import asdict, dataclass
from enum import StrEnum
from itertools import chain
from pathlib import Path
from typing import Any


class ExportFormat(StrEnum):
    JSON = "json"
    CSV = "csv"


@dataclass(frozen=True, slots=True)
class BotCatalogRecord:
    """Contrato v1 independiente del futuro bot y de la interfaz."""

    content_id: str
    title: str
    spanish_title: str | None = None
    original_title: str | None = None
    aliases: tuple[str, ...] = ()
    content_type: str = "unknown"
    year: int | None = None
    genres: tuple[str, ...] = ()
    cast: tuple[str, ...] = ()
    director: str | None = None
    synopsis: str | None = None
    bank: str | None = None
    availability: tuple[str, ...] = ()
    versions: tuple[str, ...] = ()
    seasons: tuple[Mapping[str, Any], ...] = ()
    episodes: tuple[Mapping[str, Any], ...] = ()

    def to_contract(self) -> dict[str, Any]:
        return {"contract_version": "mce.bot.catalog.v1", **asdict(self)}


@dataclass(frozen=True, slots=True)
class ExportRequest:
    dataset: str
    destination: Path
    format: ExportFormat
    rows: Iterable[Mapping[str, Any]]


@dataclass(frozen=True, slots=True)
class ExportResult:
    destination: Path
    format: ExportFormat
    row_count: int
    byte_count: int


class ExportService:
    """Escribe JSON o CSV mediante reemplazo atómico y sin secretos."""

    _forbidden_fragments = ("password", "passwd", "secret", "token", "api_key", "database_url")

    def export(self, request: ExportRequest) -> ExportResult:
        if request.destination.is_symlink():
            raise ValueError("export destination must not be a symbolic link")
        destination = request.destination.resolve()
        if destination.suffix.casefold() != f".{request.format.value}":
            raise ValueError(f"destination must end with .{request.format.value}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        count = 0
        try:
            if request.format is ExportFormat.JSON:
                count = self._write_json(temporary, request.dataset, request.rows)
            else:
                count = self._write_csv(temporary, request.rows)
            temporary.replace(destination)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return ExportResult(destination, request.format, count, destination.stat().st_size)

    def _write_json(
        self, destination: Path, dataset: str, rows: Iterable[Mapping[str, Any]]
    ) -> int:
        count = 0
        with destination.open("w", encoding="utf-8", newline="\n") as stream:
            stream.write('{"contract_version":"mce.export.v1","dataset":')
            json.dump(dataset, stream, ensure_ascii=False)
            stream.write(',"rows":[')
            for raw in rows:
                if count:
                    stream.write(",")
                json.dump(self._safe_row(raw), stream, ensure_ascii=False, default=str)
                count += 1
            stream.write("]}\n")
        return count

    def _write_csv(self, destination: Path, rows: Iterable[Mapping[str, Any]]) -> int:
        iterator = iter(rows)
        first = next(iterator, None)
        if first is None:
            destination.write_text("", encoding="utf-8")
            return 0
        safe_first = self._safe_row(first)
        columns = tuple(safe_first)
        count = 0
        with destination.open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
            writer.writeheader()
            for row in chain((safe_first,), (self._safe_row(value) for value in iterator)):
                writer.writerow({key: self._csv_value(row.get(key)) for key in columns})
                count += 1
        return count

    def _safe_row(self, row: Mapping[str, Any]) -> dict[str, Any]:
        return {
            str(key): value
            for key, value in row.items()
            if not any(fragment in str(key).casefold() for fragment in self._forbidden_fragments)
        }

    @staticmethod
    def _csv_value(value: Any) -> Any:
        if isinstance(value, (dict, list, tuple)):
            return json.dumps(value, ensure_ascii=False, default=str)
        if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
            return "'" + value
        return value
