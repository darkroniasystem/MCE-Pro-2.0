"""Construye el unico payload permitido para buscadores y modelos."""

from __future__ import annotations

import re
from dataclasses import asdict

from mce.application.ai_review.models import AIReviewInput

_PATH = re.compile(r"(?i)(?:[a-z]:\\|\\\\)[^\s]+")
_SECRET = re.compile(r"(?i)(?:api[_ -]?key|token|secret)\s*[:=]\s*\S+")


def sanitized_payload(item: AIReviewInput) -> dict[str, object]:
    payload = asdict(item)
    payload.pop("work_group_id", None)
    for key in ("title",):
        payload[key] = _clean(str(payload[key]))
    payload["alternative_titles"] = tuple(
        value for raw in item.alternative_titles if (value := _clean(raw))
    )
    return payload


def _clean(value: str) -> str:
    value = _PATH.sub("", value)
    value = _SECRET.sub("", value)
    return " ".join(value.split())[:500]
