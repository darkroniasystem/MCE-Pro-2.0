"""Pipeline puro y explicable de nombres multimedia."""

from __future__ import annotations

import re
import unicodedata
from pathlib import PureWindowsPath

from mce.application.normalization.models import (
    EditionHint,
    EpisodeHint,
    ExtractedToken,
    FilenameAnalysis,
    LanguageHint,
    NormalizationTrace,
    OrderPrefixHint,
    ResolutionHint,
    SeasonHint,
    TitleCandidate,
    TokenKind,
    YearHint,
)
from mce.application.normalization.token_dictionary import TokenDictionary

EPISODE_PATTERNS = (
    re.compile(r"(?i)\bS(\d{1,2})E(\d{1,3})(?:-?E(\d{1,3}))?\b"),
    re.compile(r"(?i)\b(\d{1,2})x(\d{1,3})(?:-(\d{1,3}))?\b"),
    re.compile(r"(?i)\bT(?:emporada)?\s*(\d{1,2})\s*(?:E|Cap(?:itulo|\u00edtulo)?)\s*(\d{1,3})\b"),
)
YEAR = re.compile(r"^(18[7-9]\d|19\d{2}|20\d{2}|2100)$")
GROUP = re.compile(r"^\[([^\]]+)\]$")
VOLUME = re.compile(r"(?i)^(?:vol(?:ume)?)[ ._-]?(\d+)$")
PART = re.compile(r"(?i)^(?:part|parte|pt)[ ._-]?(\d+)$")
ABSOLUTE_EPISODE = re.compile(
    r"(?i)\b(?:episodio|episode|cap(?:itulo|ítulo)?|ep)\s*(\d{1,3})(?:-(\d{1,3}))?\b"
)
EPISODE_LABEL = re.compile(r"(?i)^(?:episodio|episode|cap(?:itulo|ítulo)?|ep)$")
EPISODE_NUMBER = re.compile(r"^(\d{1,3})(?:-(\d{1,3}))?$")
SEASON_TOKEN = re.compile(r"(?i)^T(?:emporada)?(\d{1,2})$")
EPISODE_TOKEN = re.compile(r"(?i)^(?:E|Cap(?:itulo|ítulo)?)(\d{1,3})$")
SEASON_ONLY = re.compile(r"(?i)^(?:season|temporada|temp|t|s)[ ._-]?(\d{1,3})$")
SEASON_LABEL = re.compile(r"(?i)^(?:season|temporada|temp)$")
ORDER_PREFIX = re.compile(
    r"^\s*((?:\d{3,6}\s*[-_.]\s*)|(?:0\d{2,5}\s+))(?=[^\W\d_])",
    re.UNICODE,
)
MEDIA_EXTENSIONS = frozenset(
    {".mkv", ".mp4", ".avi", ".mov", ".wmv", ".ts", ".m2ts", ".vob", ".ifo", ".srt", ".ass"}
)
EXTRA_PHRASES = ("behind the scenes", "frame book", "music video")
EXTRA_WORDS = frozenset(
    {"cover", "trailer", "teaser", "sample", "preview", "intro", "opening", "ending", "theme"}
)


class FilenameTokenizer:
    """Separa extensión, camel case y delimitadores conservando Unicode."""

    def tokenize(self, name: str) -> tuple[str, tuple[str, ...]]:
        path = PureWindowsPath(name)
        stem = path.stem if path.suffix.casefold() in MEDIA_EXTENSIONS else name
        normalized = unicodedata.normalize("NFKC", stem)
        normalized = re.sub(r"(?i)bluray", "bluray", normalized)
        normalized = re.sub(r"(?i)dvdrip", "dvdrip", normalized)
        normalized = re.sub(r"(?<=[a-záéíóúñ])(?=[A-ZÁÉÍÓÚÑ])", " ", normalized)
        normalized = re.sub(r"[._]+", " ", normalized)
        normalized = re.sub(r"[()]", " ", normalized)
        normalized = re.sub(r"\s+", " ", normalized).strip()
        return normalized, tuple(re.findall(r"\[[^\]]+\]|[^\s]+", normalized))


class NoiseClassifier:
    """Clasifica una señal mediante reglas y diccionario centralizados."""

    def __init__(self, dictionary: TokenDictionary):
        self._dictionary = dictionary

    def classify(self, token: str, *, protect_year: bool = False) -> TokenKind | None:
        kind = self._dictionary.classify(token)
        if kind is None and any(pattern.fullmatch(token) for pattern in EPISODE_PATTERNS):
            return TokenKind.EPISODE
        if kind is None and (group := GROUP.match(token)):
            if YEAR.fullmatch(group.group(1)) and not protect_year:
                return TokenKind.YEAR
            return TokenKind.RELEASE_GROUP
        if kind is None and VOLUME.match(token):
            return TokenKind.VOLUME
        if kind is None and PART.match(token):
            return TokenKind.PART
        if kind is None and YEAR.match(token) and not protect_year:
            return TokenKind.YEAR
        return kind


class TitleCandidateBuilder:
    """Construye candidatos sin inventar, traducir ni cambiar el original."""

    def build(
        self,
        title_tokens: list[str],
        normalized: str,
        trace_count: int,
        year: YearHint | None,
    ) -> tuple[TitleCandidate, ...]:
        candidate = re.sub(r"\s+", " ", " ".join(title_tokens)).strip(" -") or normalized
        confidence = max(35.0, 95.0 - 2.0 * trace_count)
        values = [TitleCandidate(candidate, confidence)]
        if year and candidate.casefold() != normalized.casefold():
            values.append(TitleCandidate(normalized, 55.0))
        return tuple(values)


class FilenameNormalizationPipeline:
    """Produce candidatos y señales sin renombrar ni identificar obras."""

    def __init__(self, dictionary: TokenDictionary | None = None):
        self._dictionary = dictionary or TokenDictionary.default()
        self._tokenizer = FilenameTokenizer()
        self._classifier = NoiseClassifier(self._dictionary)
        self._builder = TitleCandidateBuilder()

    def analyze(self, name: str, *, original_path: str | None = None) -> FilenameAnalysis:
        if not isinstance(name, str) or not name.strip():
            raise ValueError("filename must not be empty")
        if "\x00" in name or (original_path is not None and "\x00" in original_path):
            raise ValueError("filename and path must not contain null characters")
        path = PureWindowsPath(name)
        stem = path.stem if path.suffix.casefold() in MEDIA_EXTENSIONS else name
        normalized_stem = unicodedata.normalize("NFKC", stem)
        prefix_match = ORDER_PREFIX.match(normalized_stem)
        order_prefix = (
            OrderPrefixHint(re.sub(r"\D", "", prefix_match.group(1)), 95.0)
            if prefix_match is not None
            else None
        )
        working_name = normalized_stem[prefix_match.end() :] if prefix_match is not None else name
        normalized, raw_tokens = self._tokenizer.tokenize(working_name)
        episode = None
        for pattern in EPISODE_PATTERNS:
            match = pattern.search(normalized)
            if match:
                episode_end = (
                    int(match.group(3))
                    if match.lastindex and match.lastindex >= 3 and match.group(3)
                    else None
                )
                episode = EpisodeHint(int(match.group(1)), int(match.group(2)), episode_end)
                break
        if episode is None and (absolute := ABSOLUTE_EPISODE.search(normalized)):
            episode = EpisodeHint(
                None,
                int(absolute.group(1)),
                int(absolute.group(2)) if absolute.group(2) else None,
            )
        classified = []
        trace = []
        title = []
        year = None
        resolution = None
        languages = []
        editions = []
        protect_year = len(raw_tokens) == 1
        dvd_control_name = [token.casefold() for token in raw_tokens] == ["video", "ts"]
        episode_token_indexes = self._episode_token_indexes(raw_tokens)
        for index, token in enumerate(raw_tokens):
            protect_this_year = protect_year or (
                YEAR.fullmatch(token) is not None
                and not self._year_is_contextual_hint(name, raw_tokens, index)
            )
            kind = (
                TokenKind.EPISODE
                if index in episode_token_indexes
                else self._classifier.classify(token, protect_year=protect_this_year)
            )
            if dvd_control_name and token.casefold() == "ts":
                kind = None
            if kind is None:
                classified.append(ExtractedToken(token, TokenKind.TITLE, False))
                title.append(token)
                continue
            classified.append(ExtractedToken(token, kind, True))
            trace.append(NormalizationTrace(token, kind, "removed_from_title_candidate"))
            if kind is TokenKind.YEAR and year is None:
                year = YearHint(int(token.strip("[]()")), 90.0)
            elif kind is TokenKind.RESOLUTION and resolution is None:
                resolution = ResolutionHint(token.lower())
            elif kind is TokenKind.LANGUAGE:
                languages.append(LanguageHint(token))
            elif kind is TokenKind.EDITION:
                editions.append(EditionHint(token))
        season = self._season_hint(raw_tokens, episode)
        possible_extra = self._is_possible_extra(normalized)
        candidates = self._builder.build(title, normalized, len(trace), year)
        return FilenameAnalysis(
            name,
            original_path,
            normalized,
            candidates,
            tuple(classified),
            tuple(trace),
            year,
            resolution,
            tuple(languages),
            tuple(editions),
            episode,
            season,
            order_prefix,
            possible_extra,
        )

    @staticmethod
    def _episode_token_indexes(tokens: tuple[str, ...]) -> frozenset[int]:
        """Localiza la señal episódica completa sin clasificar la obra."""
        selected: set[int] = set()
        for index, token in enumerate(tokens):
            if any(pattern.fullmatch(token) for pattern in EPISODE_PATTERNS):
                selected.add(index)
            if (
                EPISODE_LABEL.fullmatch(token)
                and index + 1 < len(tokens)
                and EPISODE_NUMBER.fullmatch(tokens[index + 1])
            ):
                selected.update((index, index + 1))
            if (
                SEASON_TOKEN.fullmatch(token)
                and index + 1 < len(tokens)
                and EPISODE_TOKEN.fullmatch(tokens[index + 1])
            ):
                selected.update((index, index + 1))
            if SEASON_ONLY.fullmatch(token):
                selected.add(index)
            if (
                SEASON_LABEL.fullmatch(token)
                and index + 1 < len(tokens)
                and tokens[index + 1].isdigit()
            ):
                selected.update((index, index + 1))
        return frozenset(selected)

    @staticmethod
    def _season_hint(tokens: tuple[str, ...], episode: EpisodeHint | None) -> SeasonHint | None:
        if episode is not None and episode.season is not None:
            return SeasonHint(episode.season)
        for index, token in enumerate(tokens):
            if match := SEASON_ONLY.fullmatch(token):
                return SeasonHint(int(match.group(1)))
            if (
                SEASON_LABEL.fullmatch(token)
                and index + 1 < len(tokens)
                and tokens[index + 1].isdigit()
            ):
                return SeasonHint(int(tokens[index + 1]))
        return None

    def _year_is_contextual_hint(
        self, original_name: str, tokens: tuple[str, ...], index: int
    ) -> bool:
        token = tokens[index]
        stem = PureWindowsPath(original_name).stem
        if re.search(rf"[\[(]\s*{re.escape(token)}\s*[\])]", stem):
            return True
        if re.search(rf"[-??]\s*{re.escape(token)}(?:\s|$)", stem):
            return True
        return any(
            self._classifier.classify(candidate, protect_year=True) is not None
            for candidate in tokens[index + 1 :]
        )

    @staticmethod
    def _is_possible_extra(normalized: str) -> bool:
        folded = normalized.casefold().replace("_", " ").replace("-", " ")
        words = set(re.findall(r"[\w]+", folded, flags=re.UNICODE))
        return bool(words & EXTRA_WORDS) or any(phrase in folded for phrase in EXTRA_PHRASES)
