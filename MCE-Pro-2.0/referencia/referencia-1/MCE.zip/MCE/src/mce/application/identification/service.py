"""Caso de uso de identificación sin acoplarse a una API."""

from dataclasses import replace
from typing import TYPE_CHECKING

from mce.application.identification.models import (
    ContentCandidate,
    IdentificationQuery,
    IdentificationResult,
    IdentificationStatus,
    ProviderAttempt,
    ProviderAttemptStatus,
    SearchKind,
)
from mce.application.identification.scoring import MatchPolicy, MatchScorer
from mce.application.ports.metadata_provider import MetadataProvider

if TYPE_CHECKING:
    from mce.application.web_search import WebSearchFallbackService


class ProviderError(RuntimeError):
    pass


class ProviderOfflineError(ProviderError):
    pass


class ProviderTimeoutError(ProviderError):
    pass


class ProviderRateLimitError(ProviderError):
    pass


class ProviderResponseError(ProviderError):
    pass


class ProviderClientError(ProviderError):
    pass


class ProviderServerError(ProviderError):
    pass


class ProviderConfigurationError(ProviderError):
    pass


class ProviderAuthenticationError(ProviderError):
    pass


class ProviderConnectionError(ProviderServerError):
    pass


class ProviderNotFoundError(ProviderError):
    pass


class ProviderCancelledError(ProviderError):
    pass


class IdentificationService:
    def __init__(
        self,
        provider: MetadataProvider,
        policy: MatchPolicy | None = None,
        scorer: MatchScorer | None = None,
        web_fallback: "WebSearchFallbackService | None" = None,
    ):
        self.provider = provider
        self.policy = policy or MatchPolicy()
        self.scorer = scorer or MatchScorer()
        self.web_fallback = web_fallback

    def identify(self, query: IdentificationQuery) -> IdentificationResult:
        try:
            found = (
                self.provider.search_movie(query)
                if query.kind is SearchKind.MOVIE
                else self.provider.search_series(query)
            )
        except ProviderOfflineError as exc:
            return IdentificationResult(IdentificationStatus.OFFLINE, (), message=str(exc))
        except ProviderError as exc:
            return IdentificationResult(IdentificationStatus.PROVIDER_ERROR, (), message=str(exc))
        ranked = tuple(
            sorted(
                (ContentCandidate(item, self.scorer.score(query, item)) for item in found),
                key=lambda item: item.score.total,
                reverse=True,
            )
        )
        attempts = tuple(getattr(self.provider, "last_attempts", ()))
        cached = bool(getattr(self.provider, "last_from_cache", False))
        if not ranked:
            statuses = {attempt.status for attempt in attempts}
            if ProviderAttemptStatus.RATE_LIMITED in statuses:
                return self._with_web(
                    query,
                    IdentificationResult(
                        IdentificationStatus.WAITING_RATE_LIMIT,
                        (),
                        message=_attempt_messages(attempts, {ProviderAttemptStatus.RATE_LIMITED}),
                        from_cache=cached,
                        attempts=attempts,
                    ),
                )
            if ProviderAttemptStatus.TIMEOUT in statuses:
                return self._with_web(
                    query,
                    IdentificationResult(
                        IdentificationStatus.WAITING_RETRY,
                        (),
                        message=_attempt_messages(attempts, {ProviderAttemptStatus.TIMEOUT}),
                        from_cache=cached,
                        attempts=attempts,
                    ),
                )
            unavailable = {
                ProviderAttemptStatus.UNAVAILABLE,
                ProviderAttemptStatus.AUTHENTICATION_ERROR,
                ProviderAttemptStatus.INVALID_RESPONSE,
                ProviderAttemptStatus.TERMINAL_ERROR,
            }
            if statuses & unavailable:
                return self._with_web(
                    query,
                    IdentificationResult(
                        IdentificationStatus.PROVIDER_UNAVAILABLE,
                        (),
                        message=_attempt_messages(attempts, unavailable),
                        from_cache=cached,
                        attempts=attempts,
                    ),
                )
            return self._with_web(
                query,
                IdentificationResult(
                    IdentificationStatus.NOT_FOUND_CONFIRMED,
                    (),
                    from_cache=cached,
                    attempts=attempts,
                ),
            )
        best = ranked[0]
        if bool(getattr(self.provider, "last_primary_incomplete", False)):
            return self._with_web(
                query,
                IdentificationResult(
                    IdentificationStatus.PROVIDER_PARTIAL,
                    ranked,
                    best,
                    message="proveedor principal pendiente; resultado complementario no definitivo",
                    from_cache=bool(getattr(self.provider, "last_from_cache", False)),
                    attempts=attempts,
                ),
            )
        ambiguous = (
            len(ranked) > 1
            and best.score.total - ranked[1].score.total <= self.policy.ambiguity_distance
        )
        if ambiguous:
            return self._with_web(
                query,
                IdentificationResult(
                    IdentificationStatus.AMBIGUOUS,
                    ranked,
                    from_cache=cached,
                    attempts=attempts,
                ),
            )
        if best.score.total >= self.policy.automatic_acceptance:
            detail_loader = getattr(self.provider, "get_candidate_details", None)
            if callable(detail_loader):
                try:
                    detailed = detail_loader(best.metadata)
                except ProviderError:
                    # La búsqueda válida conserva su resultado; el detalle podrá reintentarse.
                    detailed = None
                if detailed is not None:
                    best = ContentCandidate(detailed, best.score)
            return self._with_web(
                query,
                IdentificationResult(
                    IdentificationStatus.IDENTIFIED,
                    ranked,
                    best,
                    from_cache=cached,
                    attempts=attempts,
                ),
            )
        if best.score.total >= self.policy.manual_review:
            return self._with_web(
                query,
                IdentificationResult(
                    IdentificationStatus.PROBABLE,
                    ranked,
                    best,
                    from_cache=cached,
                    attempts=attempts,
                ),
            )
        return self._with_web(
            query,
            IdentificationResult(
                IdentificationStatus.NOT_FOUND_CONFIRMED,
                ranked,
                from_cache=cached,
                attempts=attempts,
            ),
        )

    def _with_web(
        self, query: IdentificationQuery, result: IdentificationResult
    ) -> IdentificationResult:
        if self.web_fallback is None or not query.allow_web_fallback:
            return result
        try:
            decision = self.web_fallback.collect(query, result)
        except ProviderError as exc:
            return replace(result, message=result.message or f"respaldo web: {exc}")
        return replace(result, web_fallback=decision)


def _attempt_messages(
    attempts: tuple[ProviderAttempt, ...],
    statuses: set[ProviderAttemptStatus],
) -> str | None:
    messages = tuple(
        attempt.message for attempt in attempts if attempt.status in statuses and attempt.message
    )
    return " · ".join(dict.fromkeys(messages)) or None
