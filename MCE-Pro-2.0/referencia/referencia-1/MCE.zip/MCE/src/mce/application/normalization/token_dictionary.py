"""Diccionario central e inmutable de señales técnicas."""

from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType

from mce.application.normalization.models import TokenKind


@dataclass(frozen=True, slots=True)
class TokenDictionary:
    """Clasifica tokens conocidos sin expresiones regulares dispersas."""

    mapping: Mapping[str, TokenKind]

    def __post_init__(self) -> None:
        normalized = {
            str(token).casefold(): TokenKind(kind) for token, kind in self.mapping.items()
        }
        object.__setattr__(self, "mapping", MappingProxyType(normalized))

    @classmethod
    def default(cls) -> "TokenDictionary":
        groups = {
            TokenKind.RESOLUTION: "hd 360p 480p 576p 720p 1080p 1080i 2160p 4k uhd",
            TokenKind.VIDEO_CODEC: "x264 x265 h264 h265 hevc av1 divx xvid",
            TokenKind.AUDIO_CODEC: "aac ac3 eac3 dts atmos truehd mp3 flac",
            TokenKind.SOURCE: "bluray bdrip brrip web webdl web-dl webrip hdtv dvdrip remux",
            TokenKind.LANGUAGE: (
                "latino castellano spanish español eng english dual doblada subtitulada esp-latino"
            ),
            TokenKind.EDITION: (
                "extended remastered remaster director's cut directorscut unrated special edition"
            ),
            TokenKind.HDR: "hdr hdr10 hdr10+ dolbyvision dv",
            TokenKind.THREE_D: "3d sbs half-sbs",
            TokenKind.QUALITY: "cam ts telesync screener",
            TokenKind.REGION: "ntsc pal region1 region2",
            TokenKind.NOISE: (
                "proper repack internal sample trailer peliculas nuevas películas nuevas"
            ),
        }
        mapping = {token: kind for kind, text in groups.items() for token in text.split()}
        return cls(mapping)

    def classify(self, token: str) -> TokenKind | None:
        """Devuelve la categoría conocida ignorando mayúsculas."""
        return self.mapping.get(token.casefold())
