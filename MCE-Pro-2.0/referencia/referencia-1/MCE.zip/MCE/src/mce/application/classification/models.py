"""Resultados preliminares y explicables de clasificación multimedia."""

from dataclasses import dataclass
from enum import StrEnum


class MediaKind(StrEnum):
    MOVIE = "movie"
    SERIES = "series"
    SEASON = "season"
    EPISODE = "episode"
    NOVELA = "novela"
    ANIME = "anime"
    DORAMA = "dorama"
    DOCUMENTARY = "documentary"
    WESTERN_ANIMATION = "western_animation"
    DVD_DISC = "dvd_disc"
    SPECIAL = "special"
    UNKNOWN = "unknown"


class SubtitleMatchStatus(StrEnum):
    MATCHED = "matched"
    PROBABLE = "probable"
    AMBIGUOUS = "ambiguous"
    UNMATCHED = "unmatched"


@dataclass(frozen=True, slots=True)
class ClassificationEvidence:
    signal: str
    value: str
    weight: float


@dataclass(frozen=True, slots=True)
class ClassificationCandidate:
    kind: MediaKind
    confidence: float
    evidence: tuple[ClassificationEvidence, ...]


@dataclass(frozen=True, slots=True)
class ClassificationConflict:
    candidates: tuple[ClassificationCandidate, ...]
    reason: str


@dataclass(frozen=True, slots=True)
class ContentClassification:
    kind: MediaKind
    confidence: float
    evidence: tuple[ClassificationEvidence, ...]
    warnings: tuple[str, ...] = ()
    alternatives: tuple[ClassificationCandidate, ...] = ()
    conflict: ClassificationConflict | None = None


@dataclass(frozen=True, slots=True)
class PathEvidenceResult:
    """Recorrido auditable de carpetas, desde la más cercana hacia la raíz."""

    original_path: str
    traversed_segments: tuple[str, ...]
    candidates: tuple[ClassificationCandidate, ...]


@dataclass(frozen=True, slots=True)
class SubtitleInput:
    identifier: str
    path: str
    name: str
    language: str | None = None


@dataclass(frozen=True, slots=True)
class VideoInput:
    identifier: str
    path: str
    name: str


@dataclass(frozen=True, slots=True)
class SubtitleMatch:
    subtitle_id: str
    video_id: str | None
    status: SubtitleMatchStatus
    confidence: float
    evidence: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DiscFileGroup:
    root_path: str
    file_paths: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class DiscCandidate:
    root_path: str
    groups: tuple[DiscFileGroup, ...]
    confidence: float


@dataclass(frozen=True, slots=True)
class GroupingCandidate:
    kind: MediaKind
    key: str
    member_ids: tuple[str, ...]
    confidence: float
    provisional: bool = True


@dataclass(frozen=True, slots=True)
class HierarchyMediaInput:
    """Archivo preparado para agrupación sin convertirlo en entidad editorial."""

    identifier: str
    bank_id: str
    path: str
    name: str
    kind: MediaKind
    clean_title: str | None = None
    season_number: int | None = None
    episode_number: int | None = None
    language: str | None = None
    is_subtitle: bool = False


@dataclass(frozen=True, slots=True)
class EpisodeGroupingCandidate:
    season_number: int
    episode_number: int
    video_ids: tuple[str, ...]
    subtitle_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SeasonGroupingCandidate:
    number: int
    episodes: tuple[EpisodeGroupingCandidate, ...]


@dataclass(frozen=True, slots=True)
class WorkHierarchyCandidate:
    key: str
    bank_id: str
    title: str
    kind: MediaKind
    seasons: tuple[SeasonGroupingCandidate, ...]
    standalone_video_ids: tuple[str, ...]
    confidence: float
    provisional: bool = True


@dataclass(frozen=True, slots=True)
class HierarchyGroupingResult:
    works: tuple[WorkHierarchyCandidate, ...]
    discs: tuple[DiscCandidate, ...]
    subtitle_matches: tuple[SubtitleMatch, ...]
    unresolved_subtitle_ids: tuple[str, ...]
