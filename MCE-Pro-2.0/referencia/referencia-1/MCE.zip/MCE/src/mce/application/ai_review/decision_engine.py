"""Puntuacion visible calculada por MCE, independiente del modelo."""

from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import urlparse

from mce.application.ai_review.models import AIReviewInput, AIReviewResult


class AIDecisionEngine:
    def score(self, item: AIReviewInput, proposal: AIReviewResult) -> float:
        title_score = self._title_similarity(item.title, proposal.canonical_title or "")
        score = title_score * 45
        if self._compatible_type(item.category, proposal.media_type):
            score += 20
        if (
            item.year_hint is None
            or proposal.year is None
            or abs(item.year_hint - proposal.year) <= 1
        ):
            score += 10
        if item.season_hint is None or not proposal.seasons or item.season_hint in proposal.seasons:
            score += 10
        domains = {
            urlparse(source.url).netloc.casefold().removeprefix("www.")
            for source in proposal.sources
        }
        score += min(15, len(domains) * 7.5)
        if proposal.contradictions:
            score -= min(40, len(proposal.contradictions) * 20)
        return round(max(0.0, min(100.0, score)), 1)

    @staticmethod
    def _title_similarity(left: str, right: str) -> float:
        normalized_left = _normalize(left)
        normalized_right = _normalize(right)
        if not normalized_left or not normalized_right:
            return 0.0
        if normalized_left == normalized_right:
            return 1.0
        return SequenceMatcher(None, normalized_left, normalized_right).ratio()

    @staticmethod
    def _compatible_type(local: str, proposed: str | None) -> bool:
        aliases = {
            "movie": "movie",
            "pelicula": "movie",
            "series": "series",
            "serie": "series",
            "novela": "novela",
            "dorama": "dorama",
            "anime": "anime",
            "animado": "western_animation",
            "western_animation": "western_animation",
            "concurso": "concurso",
        }
        return aliases.get(local.casefold()) == aliases.get((proposed or "").casefold())


def _normalize(value: str) -> str:
    folded = unicodedata.normalize("NFKD", value.casefold())
    ascii_value = "".join(char for char in folded if not unicodedata.combining(char))
    return " ".join(re.findall(r"[a-z0-9]+", ascii_value))
