"""Casos de uso para crear y controlar sesiones de procesamiento."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from threading import Event

from mce.application.dto import ImportResult, ImportResultStatus
from mce.application.dto.session_models import (
    JobProgress,
    ProcessingSession,
    ProcessingStage,
    SessionItem,
    SessionItemStatus,
    SessionStatus,
)
from mce.application.exceptions import DuplicateSessionError, InvalidSessionPackageError
from mce.application.ports.session_ports import (
    CheckpointStore,
    Clock,
    IdGenerator,
    ProgressReporter,
    SessionRepository,
    WorkspaceRepository,
)


class CancellationToken:
    """Señal cooperativa y segura entre hilos; no cancela trabajo por fuerza."""

    def __init__(self) -> None:
        self._event = Event()
        self._paused = Event()

    def cancel(self) -> None:
        """Solicita la cancelación."""
        self._event.set()
        self._paused.clear()

    def pause(self) -> None:
        """Solicita una pausa cooperativa."""
        self._paused.set()

    def resume(self) -> None:
        """Libera una pausa cooperativa."""
        self._paused.clear()

    def wait_if_paused(self) -> None:
        """Espera en intervalos cortos y permite cancelar durante la pausa."""
        while self._paused.is_set() and not self._event.wait(0.1):
            pass

    @property
    def is_cancelled(self) -> bool:
        """Indica si se solicitó cancelar."""
        return self._event.is_set()


class SessionService:
    """Orquesta sesiones sin limpiar ni modificar el catálogo."""

    def __init__(
        self,
        workspaces: WorkspaceRepository,
        sessions: SessionRepository,
        checkpoints: CheckpointStore,
        clock: Clock,
        ids: IdGenerator,
        reporter: ProgressReporter | None = None,
    ) -> None:
        self._workspaces = workspaces
        self._sessions = sessions
        self._checkpoints = checkpoints
        self._clock = clock
        self._ids = ids
        self._reporter = reporter

    def create(
        self, workspace_id: str, result: ImportResult, bank_name: str | None = None
    ) -> ProcessingSession:
        """Crea una sesión ready desde un resultado importado y no duplicado."""
        if result.status is ImportResultStatus.DUPLICATE:
            raise InvalidSessionPackageError("a duplicate import cannot create a session")
        if not result.success or result.package is None:
            raise InvalidSessionPackageError("a session requires a successful import package")
        existing = self._sessions.find_by_package_hash(result.package.original_file_hash)
        if existing is not None:
            raise DuplicateSessionError("the import package already has a session")
        workspace = self._workspaces.get(workspace_id)
        if workspace is None:
            raise KeyError(workspace_id)
        now = self._clock.now()
        package = result.package
        declared_bank = dict(package.scan.bank_data)
        resolved_bank_name = (
            (bank_name or "").strip()
            or str(declared_bank.get("name") or declared_bank.get("nombre") or "").strip()
            or f"Banco {package.domain_import.bank_id}"
        )
        items = tuple(
            SessionItem(
                item_id=self._ids.new_id(),
                import_id=package.domain_import.import_id,
                source_id=file.source_id,
                physical_file_id=file.file_id,
                original_path=file.normalized_path.original,
                original_name=file.original_name,
                bank_id=str(package.domain_import.bank_id),
                installation_id=str(package.domain_scan.installation_id),
                size_bytes=file.size_bytes,
                file_hash=file.cryptographic_hash,
            )
            for file in package.domain_files
        )
        session = ProcessingSession(
            session_id=self._ids.new_id(),
            workspace_id=workspace_id,
            import_id=package.domain_import.import_id,
            package_hash=package.original_file_hash,
            scan_scope=package.domain_scan.scope,
            items=items,
            created_at=now,
            updated_at=now,
            bank_name=resolved_bank_name,
        ).transition(SessionStatus.READY, at=now)
        self._sessions.save(session)
        self._workspaces.save(workspace.add_session(session.session_id))
        self._report(session)
        return session

    def transition(self, session_id: str, target: SessionStatus) -> ProcessingSession:
        """Aplica y persiste una transición normal."""
        session = self._required(session_id).transition(target, at=self._clock.now())
        self._sessions.save(session)
        self._report(session)
        return session

    def delete(self, session_id: str) -> None:
        """Archiva lógicamente una sesión terminal y conserva su checkpoint."""
        session = self._required(session_id)
        if session.status is SessionStatus.RUNNING:
            raise ValueError("a running session cannot be archived")
        if session.status is SessionStatus.ARCHIVED:
            raise ValueError("session is already archived")
        workspace = self._workspaces.get(session.workspace_id)
        if workspace is None:
            raise KeyError(session.workspace_id)
        archived = session.transition(SessionStatus.ARCHIVED, at=self._clock.now())
        self._sessions.save(archived)
        self._checkpoints.save(archived)
        self._workspaces.save(workspace.remove_session(session_id))

    def restore_archived(self, session_id: str) -> ProcessingSession:
        """Restaura una sesión archivada conservando resultados y checkpoint."""
        session = self._required(session_id).restore_archived(at=self._clock.now())
        workspace = self._workspaces.get(session.workspace_id)
        if workspace is None:
            raise KeyError(session.workspace_id)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._workspaces.save(workspace.add_session(session_id))
        self._report(session)
        return session

    def save_item(self, session_id: str, item: SessionItem) -> ProcessingSession:
        """Persiste el resultado aislado de un elemento."""
        session = self._required(session_id).replace_item(item, at=self._clock.now())
        self._sessions.save(session)
        self._report(session)
        return session

    def save_processed_items(
        self, session_id: str, items: tuple[SessionItem, ...]
    ) -> ProcessingSession:
        """Guarda un lote completo para evitar estados parciales en memoria."""
        session = self._required(session_id).replace_all_items(items, at=self._clock.now())
        self._sessions.save(session)
        self._report(session)
        return session

    def apply_review_resolution(
        self, session_id: str, items: tuple[SessionItem, ...]
    ) -> ProcessingSession:
        """Persiste de forma atómica una aprobación o rechazo humano."""
        session = self._required(session_id).apply_review_resolution(items, at=self._clock.now())
        self._sessions.save(session)
        self._report(session)
        return session

    def apply_human_annotation(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str | None = None,
        lock_title: bool = False,
    ) -> ProcessingSession:
        """Persiste una corrección o bloqueo antes de cerrar la revisión."""
        targets = frozenset(item_ids)
        now = self._clock.now()
        session = self._required(session_id)
        changed = tuple(
            replace(
                item,
                human_title_correction=(
                    corrected_title.strip()
                    if corrected_title is not None
                    else item.human_title_correction
                ),
                human_title_locked=item.human_title_locked or lock_title,
                human_decision_at=now,
            )
            if item.item_id in targets
            else item
            for item in session.items
        )
        session = session.apply_review_resolution(changed, at=now)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._report(session)
        return session

    def requeue_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str,
    ) -> ProcessingSession:
        """Devuelve un grupo revisado al enriquecimiento sin perder trazabilidad."""
        title = corrected_title.strip()
        if not title:
            raise ValueError("corrected_title must not be empty")
        targets = frozenset(item_ids)
        if not targets:
            raise ValueError("at least one review item is required")
        now = self._clock.now()
        session = self._required(session_id)
        if not targets <= {item.item_id for item in session.items}:
            raise KeyError("review item does not belong to the session")
        changed = tuple(
            replace(
                item,
                clean_title=title,
                work_title=title,
                stage=ProcessingStage.READY_FOR_ENRICHMENT,
                status=SessionItemStatus.PENDING,
                warning=None,
                error=None,
                cleaning_reason="titulo corregido en revision humana para reintento",
                cleaning_status="cleaned",
                grouping_status="grouped",
                enrichment_status="pending_enrichment",
                identification_confidence=None,
                metadata_confidence=None,
                final_confidence=None,
                final_category=None,
                classification_resolution_status=None,
                classification_resolution_explanation=None,
                classification_conflicts=(),
                human_title_correction=title,
                human_title_locked=True,
                human_decision_at=now,
                review_reason="pending_normalization_retry",
                providers_completed=(),
                providers_pending=(),
                providers_failed=(),
                metadata_from_cache=False,
                web_search_used=False,
                web_search_reason=None,
                web_search_decision=None,
                web_search_query=None,
                web_search_evidence=(),
                web_search_from_cache=False,
                next_retry_at=None,
            )
            if item.item_id in targets
            else item
            for item in session.items
        )
        session = session.apply_review_resolution(changed, at=now)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._report(session)
        return session

    def reprepare_review_items(
        self,
        session_id: str,
        item_ids: tuple[str, ...],
        *,
        corrected_title: str,
    ) -> ProcessingSession:
        """Guarda una limpieza local, pero conserva el grupo dentro de revision."""
        title = corrected_title.strip()
        if not title:
            raise ValueError("corrected_title must not be empty")
        targets = frozenset(item_ids)
        if not targets:
            raise ValueError("at least one review item is required")
        now = self._clock.now()
        session = self._required(session_id)
        if not targets <= {item.item_id for item in session.items}:
            raise KeyError("review item does not belong to the session")
        changed = tuple(
            replace(
                item,
                clean_title=title,
                work_title=title,
                stage=ProcessingStage.REVIEWED,
                status=SessionItemStatus.WARNING,
                warning="repreparado localmente; pendiente de revision humana",
                cleaning_reason="titulo repreparado localmente en revision humana",
                cleaning_status="cleaned",
                normalization_trace=tuple(
                    dict.fromkeys(
                        (
                            *item.normalization_trace,
                            "human_review_reprepare_confirmed",
                        )
                    )
                ),
                enrichment_status="needs_human_review",
                human_title_correction=title,
                human_decision_at=now,
                review_reason="locally_reprepared_in_review",
            )
            if item.item_id in targets
            else item
            for item in session.items
        )
        session = session.apply_local_review_repreparation(changed, at=now)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._report(session)
        return session

    def fail(self, session_id: str, reason: str) -> ProcessingSession:
        """Registra un error fatal de sesión."""
        session = self._required(session_id).mark_failed(reason, at=self._clock.now())
        self._sessions.save(session)
        return session

    def reprepare_review_items_bulk(
        self, session_id: str, corrected_titles: dict[str, str]
    ) -> ProcessingSession:
        """Reprepara muchos elementos cargando y guardando la sesion una sola vez."""
        titles = {key: value.strip() for key, value in corrected_titles.items() if value.strip()}
        if not titles:
            raise ValueError("at least one usable review title is required")
        now = self._clock.now()
        session = self._required(session_id)
        current_ids = {item.item_id for item in session.items}
        titles = {key: value for key, value in titles.items() if key in current_ids}
        if not titles:
            return session
        changed = tuple(
            replace(
                item,
                clean_title=titles[item.item_id],
                work_title=titles[item.item_id],
                stage=ProcessingStage.REVIEWED,
                status=SessionItemStatus.WARNING,
                warning="repreparado localmente; pendiente de revalidacion",
                cleaning_reason="titulo repreparado localmente en revision humana",
                cleaning_status="cleaned",
                normalization_trace=tuple(
                    dict.fromkeys((*item.normalization_trace, "human_review_reprepare_confirmed"))
                ),
                enrichment_status="needs_human_review",
                human_title_correction=titles[item.item_id],
                human_decision_at=now,
                review_reason="locally_reprepared_in_review",
            )
            if item.item_id in titles
            else item
            for item in session.items
        )
        session = session.apply_local_review_repreparation(changed, at=now)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._report(session)
        return session

    def revalidate_review_items_bulk(
        self,
        session_id: str,
        corrected_titles: dict[str, str],
        canonical_group_ids: dict[str, str] | None = None,
    ) -> ProcessingSession:
        """Devuelve obras reparadas al enriquecimiento para completar sus metadatos."""
        titles = {key: value.strip() for key, value in corrected_titles.items() if value.strip()}
        if not titles:
            raise ValueError("at least one usable review title is required")
        now = self._clock.now()
        session = self._required(session_id)
        if session.status is SessionStatus.FAILED:
            session = session.prepare_retry(at=now)
        current_ids = {item.item_id for item in session.items}
        titles = {key: value for key, value in titles.items() if key in current_ids}
        if not titles:
            return session
        canonical_groups = {
            key: value.strip()
            for key, value in (canonical_group_ids or {}).items()
            if key in titles and value.strip()
        }
        retry_marker = "explicit_human_revalidation"
        changed = tuple(
            replace(
                item,
                clean_title=titles[item.item_id],
                work_title=titles[item.item_id],
                stage=ProcessingStage.READY_FOR_ENRICHMENT,
                status=SessionItemStatus.PENDING,
                warning=None,
                error=None,
                cleaning_reason="titulo reparado para revalidar y completar metadatos",
                cleaning_status="cleaned",
                work_group_id=canonical_groups.get(item.item_id, item.work_group_id),
                normalization_trace=tuple(
                    dict.fromkeys((*item.normalization_trace, retry_marker))
                ),
                grouping_status="grouped",
                enrichment_status="pending_enrichment",
                identification_confidence=None,
                metadata_confidence=None,
                final_confidence=None,
                final_category=None,
                classification_resolution_status=None,
                classification_resolution_explanation=None,
                classification_conflicts=(),
                human_title_correction=titles[item.item_id],
                human_title_locked=True,
                human_decision_at=now,
                review_reason="pending_normalization_retry",
                providers_completed=(),
                providers_pending=(),
                providers_failed=(),
                identification_query_fingerprints=(
                    ()
                    if (
                        titles[item.item_id].casefold()
                        != (item.work_title or item.clean_title or "").strip().casefold()
                        or retry_marker not in item.normalization_trace
                    )
                    else item.identification_query_fingerprints
                ),
                metadata_from_cache=False,
                web_search_used=False,
                web_search_reason=None,
                web_search_decision=None,
                web_search_query=None,
                web_search_evidence=(),
                web_search_from_cache=False,
                next_retry_at=None,
            )
            if item.item_id in titles
            else item
            for item in session.items
        )
        session = session.apply_review_resolution(changed, at=now)
        self._sessions.save(session)
        self._checkpoints.save(session)
        self._report(session)
        return session

    def retry(self, session_id: str) -> ProcessingSession:
        """Prepara explícitamente un reintento de sesión fallida."""
        session = self._required(session_id).prepare_retry(at=self._clock.now())
        self._sessions.save(session)
        return session

    def reactivate_after_local_preparation(self, session_id: str) -> ProcessingSession:
        """Reactiva una sesión cancelada cuyo contenido local ya fue recalculado."""
        session = self._required(session_id).reactivate_after_local_preparation(
            at=self._clock.now()
        )
        self._sessions.save(session)
        self._report(session)
        return session

    def checkpoint(self, session_id: str) -> Path:
        """Guarda un checkpoint del estado actual."""
        return self._checkpoints.save(self._required(session_id))

    def configure_enrichment_job(
        self, session_id: str, selected_categories: frozenset[str] | None
    ) -> None:
        """Congela en el ledger el alcance de obras únicas del lote."""
        session = self._required(session_id)
        configure = getattr(self._sessions, "configure_enrichment_job", None)
        if callable(configure):
            configure(session, selected_categories)

    def restore(self, session_id: str) -> ProcessingSession:
        """Reconstruye y registra una sesión desde su checkpoint."""
        session = self._checkpoints.load(session_id)
        self._sessions.save(session)
        return session

    def _required(self, session_id: str) -> ProcessingSession:
        session = self._sessions.get(session_id)
        if session is None:
            raise KeyError(session_id)
        return session

    def _report(self, session: ProcessingSession) -> None:
        if self._reporter is not None:
            summary = session.summary
            self._reporter.report(
                JobProgress(session.session_id, summary.processed, summary.total, summary.percent)
            )
