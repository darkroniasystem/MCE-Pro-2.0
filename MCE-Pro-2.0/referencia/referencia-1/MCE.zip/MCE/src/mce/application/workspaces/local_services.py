"""Adaptadores locales temporales para ejecutar la Fase 3 sin base de datos."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from mce.application.dto.session_models import ProcessingSession, Workspace


class SystemClock:
    """Reloj UTC del sistema."""

    def now(self) -> datetime:
        """Obtiene el instante actual con zona UTC."""
        return datetime.now(UTC)


class UuidGenerator:
    """Generador UUID4 para identidades de aplicación."""

    def new_id(self) -> str:
        """Genera un UUID canónico."""
        return str(uuid4())


class InMemoryWorkspaceRepository:
    """Repositorio temporal sin persistencia entre procesos."""

    def __init__(self) -> None:
        self._items: dict[str, Workspace] = {}

    def get(self, workspace_id: str) -> Workspace | None:
        """Busca un espacio por identidad."""
        return self._items.get(workspace_id)

    def save(self, workspace: Workspace) -> None:
        """Inserta o reemplaza el espacio."""
        self._items[workspace.workspace_id] = workspace


class InMemorySessionRepository:
    """Repositorio temporal con unicidad por hash de paquete."""

    def __init__(self) -> None:
        self._items: dict[str, ProcessingSession] = {}

    def get(self, session_id: str) -> ProcessingSession | None:
        """Busca una sesión por identidad."""
        return self._items.get(session_id)

    def find_by_package_hash(self, package_hash: str) -> ProcessingSession | None:
        """Busca la sesión ya asociada a un paquete."""
        return next(
            (item for item in self._items.values() if item.package_hash == package_hash), None
        )

    def save(self, session: ProcessingSession) -> None:
        """Inserta o reemplaza una sesión."""
        self._items[session.session_id] = session

    def delete(self, session_id: str) -> None:
        """Puerto heredado; el servicio conserva aquí las sesiones archivadas."""
        if session_id not in self._items:
            raise FileNotFoundError(session_id)


class InMemoryCheckpointStore:
    """Checkpoints volátiles para una ejecución local sin escribir en disco."""

    def __init__(self) -> None:
        self._items: dict[str, ProcessingSession] = {}

    def save(self, session: ProcessingSession) -> Path:
        self._items[session.session_id] = session
        return Path(session.session_id)

    def load(self, session_id: str) -> ProcessingSession:
        try:
            return self._items[session_id]
        except KeyError as exc:
            raise FileNotFoundError(session_id) from exc

    def delete(self, session_id: str) -> None:
        try:
            del self._items[session_id]
        except KeyError as exc:
            raise FileNotFoundError(session_id) from exc
