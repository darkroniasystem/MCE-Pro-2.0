"""Política central de campos canónicos y alias conocidos."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class SchemaFieldAliases:
    """Resuelve nombres por contrato sin traducción arbitraria."""

    version: str | None

    def root(self, document: dict[str, Any], canonical: str) -> Any:
        """Obtiene una colección raíz mediante alias controlados."""
        aliases = {
            "sources": ("sources", "fuentes"),
            "files": ("files", "archivos", "videos"),
            "subtitles": ("subtitles", "subtitulos"),
            "bank": ("bank", "banco"),
            "installation": ("installation", "instalacion"),
            "summary": ("summary", "resumen"),
        }[canonical]
        return self.first(document, aliases)

    @staticmethod
    def first(record: dict[str, Any], aliases: tuple[str, ...], default: Any = None) -> Any:
        """Devuelve el primer alias presente, incluso si su valor es nulo."""
        for alias in aliases:
            if alias in record:
                return record[alias]
        return default
