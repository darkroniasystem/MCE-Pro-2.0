"""Resolución explicable de clasificación entre evidencias heterogéneas."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import ClassVar


class ClassificationSignalSource(StrEnum):
    LOCAL = "local"
    PROVIDER = "provider"
    WEB = "web"
    HUMAN = "human"


class ClassificationResolutionStatus(StrEnum):
    RESOLVED = "resolved"
    REQUIRES_REVIEW = "requires_review"
    HUMAN_PROTECTED = "human_protected"


@dataclass(frozen=True, slots=True)
class ClassificationSignal:
    source: ClassificationSignalSource
    category: str
    confidence: float
    origin: str
    detail: str
    locked: bool = False

    def __post_init__(self) -> None:
        if not self.category.strip() or not self.origin.strip() or not self.detail.strip():
            raise ValueError("classification signal fields must not be empty")
        if not 0 <= self.confidence <= 100:
            raise ValueError("classification confidence must be between 0 and 100")


@dataclass(frozen=True, slots=True)
class ClassificationResolution:
    status: ClassificationResolutionStatus
    final_category: str | None
    confidence: float
    explanation: str
    signals: tuple[ClassificationSignal, ...]
    conflicts: tuple[str, ...] = ()


class ClassificationResolver:
    """Combina señales sin permitir que web o proveedores oculten contradicciones."""

    _ALIASES: ClassVar[dict[str, str]] = {
        "tv": "series",
        "tv_show": "series",
        "episode": "series",
        "season": "series",
        "dorama": "series",
        "novela": "series",
        "concurso": "series",
        "pelicula": "movie",
        "peliculas": "movie",
    }

    def resolve(
        self, signals: tuple[ClassificationSignal, ...]
    ) -> ClassificationResolution:
        if not signals:
            return ClassificationResolution(
                ClassificationResolutionStatus.REQUIRES_REVIEW,
                None,
                0,
                "Sin evidencias de clasificación; se requiere revisión humana.",
                (),
                ("missing_evidence",),
            )
        normalized = tuple(self._normalize(signal) for signal in signals)
        human = tuple(
            signal for signal in normalized if signal.source is ClassificationSignalSource.HUMAN
        )
        if human:
            categories = {signal.category for signal in human}
            if len(categories) > 1:
                return self._review(normalized, ("conflicting_human_decisions",))
            chosen_signal = max(human, key=lambda signal: (signal.locked, signal.confidence))
            suffix = " y está bloqueada" if chosen_signal.locked else ""
            return ClassificationResolution(
                ClassificationResolutionStatus.HUMAN_PROTECTED,
                chosen_signal.category,
                chosen_signal.confidence,
                f"La corrección humana de {chosen_signal.origin} prevalece{suffix}; "
                "las automatizaciones posteriores no pueden sobrescribirla.",
                normalized,
            )

        local = tuple(
            signal for signal in normalized if signal.source is ClassificationSignalSource.LOCAL
        )
        providers = tuple(
            signal
            for signal in normalized
            if signal.source is ClassificationSignalSource.PROVIDER
        )
        web = tuple(
            signal for signal in normalized if signal.source is ClassificationSignalSource.WEB
        )
        strong_local = max(local, key=lambda signal: signal.confidence, default=None)
        provider_categories = {signal.category for signal in providers if signal.confidence >= 75}
        conflicts: list[str] = []
        if len(provider_categories) > 1:
            conflicts.append("providers_disagree")
        if (
            strong_local
            and provider_categories
            and strong_local.category not in provider_categories
        ):
            conflicts.append("local_provider_contradiction")
        if conflicts:
            return self._review(normalized, tuple(conflicts))

        scores: dict[str, float] = {}
        reliable: dict[str, set[str]] = {}
        weights = {
            ClassificationSignalSource.LOCAL: 1.0,
            ClassificationSignalSource.PROVIDER: 1.0,
            ClassificationSignalSource.WEB: 0.35,
        }
        for signal in normalized:
            scores[signal.category] = scores.get(signal.category, 0) + signal.confidence * weights[
                signal.source
            ]
            if signal.source is not ClassificationSignalSource.WEB and signal.confidence >= 75:
                reliable.setdefault(signal.category, set()).add(signal.origin)
        chosen_category = max(scores, key=lambda category: scores[category])
        chosen_signals = tuple(
            signal for signal in normalized if signal.category == chosen_category
        )
        confidence = min(100.0, max(signal.confidence for signal in chosen_signals))
        reliable_count = len(reliable.get(chosen_category, set()))
        if reliable_count < 2:
            return self._review(normalized, ("insufficient_reliable_consensus",))
        explanation = (
            f"Resultado {chosen_category}: coinciden {reliable_count} señales fiables "
            "independientes; "
            f"se conservaron {len(web)} evidencias web solo como respaldo."
        )
        return ClassificationResolution(
            ClassificationResolutionStatus.RESOLVED,
            chosen_category,
            confidence,
            explanation,
            normalized,
        )

    def _review(
        self, signals: tuple[ClassificationSignal, ...], conflicts: tuple[str, ...]
    ) -> ClassificationResolution:
        detail = ", ".join(conflicts)
        return ClassificationResolution(
            ClassificationResolutionStatus.REQUIRES_REVIEW,
            None,
            0,
            f"No se sobrescribió la clasificación: {detail}; requiere revisión humana.",
            signals,
            conflicts,
        )

    def _normalize(self, signal: ClassificationSignal) -> ClassificationSignal:
        category = signal.category.strip().casefold()
        return ClassificationSignal(
            signal.source,
            self._ALIASES.get(category, category),
            signal.confidence,
            signal.origin,
            signal.detail,
            signal.locked,
        )
