"""Contratos estables para identificación explicable."""

from dataclasses import dataclass
from enum import StrEnum


class IdentificationStatus(StrEnum):
    IDENTIFIED = "identified"
    PROBABLE = "probable"
    AMBIGUOUS = "ambiguous"
    NOT_FOUND = "not_found_confirmed"
    PROVIDER_ERROR = "provider_error"
    OFFLINE = "offline"
    WAITING_RATE_LIMIT = "waiting_rate_limit"
    WAITING_RETRY = "waiting_retry"
    PROVIDER_UNAVAILABLE = "provider_unavailable"
    PROVIDER_PARTIAL = "provider_partial"
    NOT_FOUND_CONFIRMED = "not_found_confirmed"


class ProviderAttemptStatus(StrEnum):
    SUCCESS_WITH_RESULTS = "success_with_results"
    SUCCESS_NO_RESULTS = "success_no_results"
    RATE_LIMITED = "rate_limited"
    TIMEOUT = "timeout"
    UNAVAILABLE = "unavailable"
    AUTHENTICATION_ERROR = "authentication_error"
    INVALID_RESPONSE = "invalid_response"
    TERMINAL_ERROR = "terminal_error"


@dataclass(frozen=True, slots=True)
class ProviderAttempt:
    provider: str
    status: ProviderAttemptStatus
    result_count: int = 0
    message: str | None = None


class SearchKind(StrEnum):
    MOVIE = "movie"
    SERIES = "series"
    ANIME = "anime"


@dataclass(frozen=True, slots=True)
class IdentificationQuery:
    title: str
    kind: SearchKind
    year: int | None = None
    original_title: str | None = None
    aliases: tuple[str, ...] = ()
    season: int | None = None
    episode: int | None = None
    country: str | None = None
    cast: tuple[str, ...] = ()
    director: str | None = None
    duration_minutes: int | None = None
    language: str = "es"
    region: str | None = None
    query_variant: str = "clean_title"
    normalizer_version: str = "mce-filename-normalizer-v3"
    allow_web_fallback: bool = True


@dataclass(frozen=True, slots=True)
class ProviderTitleAlias:
    title: str
    language: str | None = None
    country: str | None = None
    alias_type: str = "alternative"
    provenance: str | None = None


@dataclass(frozen=True, slots=True)
class ProviderCandidate:
    provider: str
    external_id: str
    kind: SearchKind
    title: str
    original_title: str | None = None
    translated_titles: tuple[str, ...] = ()
    aliases: tuple[str, ...] = ()
    year: int | None = None
    country: str | None = None
    cast: tuple[str, ...] = ()
    director: str | None = None
    duration_minutes: int | None = None
    overview: str | None = None
    genres: tuple[str, ...] = ()
    languages: tuple[str, ...] = ()
    cast_names: tuple[str, ...] = ()
    creators: tuple[str, ...] = ()
    studios: tuple[str, ...] = ()
    networks: tuple[str, ...] = ()
    status: str | None = None
    episode_count: int | None = None
    season_count: int | None = None
    external_ids: tuple[tuple[str, str], ...] = ()
    images: tuple[tuple[str, str], ...] = ()
    ratings: tuple[tuple[str, str], ...] = ()
    source_url: str | None = None
    spanish_title: str | None = None
    english_title: str | None = None
    title_aliases: tuple[ProviderTitleAlias, ...] = ()


@dataclass(frozen=True, slots=True)
class ScoreEvidence:
    rule: str
    points: float
    detail: str


@dataclass(frozen=True, slots=True)
class MatchScore:
    total: float
    evidence: tuple[ScoreEvidence, ...]


@dataclass(frozen=True, slots=True)
class ContentCandidate:
    metadata: ProviderCandidate
    score: MatchScore


@dataclass(frozen=True, slots=True)
class IdentificationResult:
    status: IdentificationStatus
    candidates: tuple[ContentCandidate, ...]
    selected: ContentCandidate | None = None
    message: str | None = None
    from_cache: bool = False
    attempts: tuple[ProviderAttempt, ...] = ()
    web_fallback: object | None = None
