"""Resultados explicables de normalización de nombres."""

from dataclasses import dataclass
from enum import StrEnum


class TokenKind(StrEnum):
    """Clases de señales extraídas."""

    TITLE = "title"
    YEAR = "year"
    RESOLUTION = "resolution"
    VIDEO_CODEC = "video_codec"
    AUDIO_CODEC = "audio_codec"
    SOURCE = "source"
    LANGUAGE = "language"
    EDITION = "edition"
    EPISODE = "episode"
    HDR = "hdr"
    THREE_D = "3d"
    RELEASE_GROUP = "release_group"
    NOISE = "noise"
    QUALITY = "quality"
    REGION = "region"
    VOLUME = "volume"
    PART = "part"
    SEASON = "season"
    ORDER_PREFIX = "order_prefix"
    EXTRA = "extra"


@dataclass(frozen=True, slots=True)
class ExtractedToken:
    """Token clasificado sin perder su forma original."""

    value: str
    kind: TokenKind
    removed: bool


@dataclass(frozen=True, slots=True)
class NormalizationTrace:
    """Explicación de una transformación."""

    token: str
    classification: TokenKind
    action: str


@dataclass(frozen=True, slots=True)
class YearHint:
    """Año probable extraído."""

    value: int
    confidence: float


@dataclass(frozen=True, slots=True)
class ResolutionHint:
    """Resolución técnica extraída."""

    value: str


@dataclass(frozen=True, slots=True)
class LanguageHint:
    """Idioma o variante declarada en el nombre."""

    value: str


@dataclass(frozen=True, slots=True)
class EditionHint:
    """Edición editorial declarada."""

    value: str


@dataclass(frozen=True, slots=True)
class EpisodeHint:
    """Temporada, episodio o rango detectado sin clasificar contenido."""

    season: int | None
    episode_start: int
    episode_end: int | None = None


@dataclass(frozen=True, slots=True)
class SeasonHint:
    """Temporada detectada sin convertirla en parte del t?tulo."""

    value: int


@dataclass(frozen=True, slots=True)
class OrderPrefixHint:
    """?ndice de organizaci?n local conservado solo para trazabilidad."""

    value: str
    confidence: float


@dataclass(frozen=True, slots=True)
class TitleCandidate:
    """Título derivado con confianza porcentual."""

    value: str
    confidence: float


@dataclass(frozen=True, slots=True)
class FilenameAnalysis:
    """Análisis completo que conserva la entrada byte por byte como texto."""

    original_name: str
    original_path: str | None
    normalized_text: str
    candidates: tuple[TitleCandidate, ...]
    tokens: tuple[ExtractedToken, ...]
    trace: tuple[NormalizationTrace, ...]
    year: YearHint | None = None
    resolution: ResolutionHint | None = None
    languages: tuple[LanguageHint, ...] = ()
    editions: tuple[EditionHint, ...] = ()
    episode: EpisodeHint | None = None
    season: SeasonHint | None = None
    order_prefix: OrderPrefixHint | None = None
    possible_extra: bool = False
    normalizer_version: str = "mce-filename-normalizer-v3"
