"""Contratos versionados de revision IA; no contienen rutas privadas."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum

SCHEMA_VERSION = "mce.ai-review.v1"
PROMPT_VERSION = "mce.ai-review.prompt.v4"


class AIRateLimitDeferred(RuntimeError):
    """Proveedor IA temporalmente limitado; el trabajo debe reanudarse despues."""

    def __init__(
        self,
        provider: str,
        retry_after_seconds: float,
        *,
        authoritative: bool = False,
        quota_kind: str = "unknown",
    ) -> None:
        self.provider = provider
        self.retry_after_seconds = max(1.0, retry_after_seconds)
        self.authoritative = authoritative
        self.quota_kind = quota_kind
        self.available_at = datetime.now(UTC) + timedelta(seconds=self.retry_after_seconds)
        super().__init__(
            f"{provider} limitado ({quota_kind}); reintentar en "
            f"{self.retry_after_seconds:.0f} segundos"
        )


class AIReviewState(StrEnum):
    PENDING = "pending_ai_review"
    APPROVED = "approved_by_ai"
    HUMAN = "pending_human_review"
    NOT_FOUND = "ai_not_found"
    ERROR = "ai_error"
    WAITING_RATE_LIMIT = "ai_waiting_rate_limit"
    QUOTA_EXHAUSTED = "ai_quota_exhausted"
    CANCELLED = "ai_cancelled"


class AIReviewDecision(StrEnum):
    APPROVE = "approve"
    HUMAN_REVIEW = "human_review"
    NOT_FOUND = "not_found"


@dataclass(frozen=True, slots=True)
class AIReviewInput:
    work_group_id: str
    title: str
    category: str
    year_hint: int | None = None
    season_hint: int | None = None
    episode_hint: int | None = None
    alternative_titles: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class EvidenceSource:
    url: str
    title: str
    snippet: str
    provider: str
    year: int | None = None
    media_type: str | None = None
    seasons: tuple[int, ...] = ()
    genres: tuple[str, ...] = ()
    cast: tuple[str, ...] = ()
    rating: float | None = None
    platforms: tuple[str, ...] = ()
    alternative_titles: tuple[str, ...] = ()
    origin: str | None = None


@dataclass(frozen=True, slots=True)
class AIFieldEvidence:
    field_name: str
    value: object
    confidence: float
    source_urls: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class AIReviewResult:
    schema_version: str
    state: AIReviewState
    decision: AIReviewDecision
    canonical_title: str | None
    media_type: str | None
    year: int | None
    seasons: tuple[int, ...]
    deterministic_score: float
    sources: tuple[EvidenceSource, ...]
    contradictions: tuple[str, ...] = ()
    reason: str = ""
    model: str | None = None
    cached: bool = False
    provider: str | None = None
    model_confidence: float | None = None
    prompt_version: str = PROMPT_VERSION
    query_fingerprint: str | None = None
    latency_ms: int | None = None
    input_tokens: int | None = None
    output_tokens: int | None = None
    hallucinated_source: bool = False
    field_evidence: tuple[AIFieldEvidence, ...] = ()
    analysis_status: str | None = None
    recommended_action: str | None = None
