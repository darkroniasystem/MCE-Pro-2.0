"""Pipeline seguro de importación de archivos MSL."""

from mce.application.importers.import_service import ImportService

__all__ = ["ImportService"]
