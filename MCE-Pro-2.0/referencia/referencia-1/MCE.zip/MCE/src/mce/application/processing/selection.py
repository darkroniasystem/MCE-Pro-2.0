"""Selección virtual de lotes para el enriquecimiento."""

from pathlib import PureWindowsPath

from mce.application.dto.session_models import SessionItem

PENDING_RETRY_CATEGORY = "pending_retry"
PENDING_RETRY_REASON = "pending_normalization_retry"
VOB_CATEGORIES = {
    "movie": "movie_vob",
    "series": "series_vob",
    "novela": "novela_vob",
    "dorama": "dorama_vob",
    "anime": "anime_vob",
    "concurso": "concurso_vob",
    "western_animation": "western_animation_vob",
}


def enrichment_category(item: SessionItem) -> str:
    """Separa colas operativas sin cambiar el tipo canónico del contenido."""
    if item.review_reason == PENDING_RETRY_REASON:
        return PENDING_RETRY_CATEGORY
    category = item.detected_category or "unclassified"
    name = item.original_name or PureWindowsPath(item.original_path).name
    if PureWindowsPath(name).suffix.casefold() == ".vob":
        return VOB_CATEGORIES.get(category, category)
    return category


def matches_enrichment_selection(
    item: SessionItem,
    selected_categories: frozenset[str] | tuple[str, ...] | None,
) -> bool:
    """Decide si un elemento pertenece al lote selectivo solicitado."""
    return not selected_categories or enrichment_category(item) in selected_categories
