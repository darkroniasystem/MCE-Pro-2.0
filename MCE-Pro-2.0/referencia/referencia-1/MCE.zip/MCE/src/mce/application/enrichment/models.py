"""Metadatos revisables, conflictos y auditoría de Fase 8."""

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from typing import Any

from mce.domain.value_objects import FieldProvenance


class FieldLockState(StrEnum):
    UNLOCKED = "unlocked"
    SYSTEM_LOCKED = "system_locked"
    MANUAL_LOCKED = "manual_locked"


class ReviewItemStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


@dataclass(frozen=True, slots=True)
class MetadataField:
    value: Any
    provenance: FieldProvenance
    lock_state: FieldLockState = FieldLockState.UNLOCKED


@dataclass(frozen=True, slots=True)
class ConflictOption:
    value: Any
    provenance: FieldProvenance


@dataclass(frozen=True, slots=True)
class ConflictResolution:
    selected_value: Any
    actor: str
    resolved_at: datetime
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class MetadataConflict:
    field_name: str
    options: tuple[ConflictOption, ...]
    resolution: ConflictResolution | None = None


@dataclass(frozen=True, slots=True)
class AuditRecord:
    action: str
    actor: str
    timestamp: datetime
    target_id: str
    field_name: str | None = None
    old_value: Any = None
    new_value: Any = None
    reason: str | None = None
    origin: str | None = None


@dataclass(frozen=True, slots=True)
class ReviewItem:
    review_id: str
    candidate_reference: str
    fields: dict[str, MetadataField]
    conflicts: tuple[MetadataConflict, ...] = ()
    status: ReviewItemStatus = ReviewItemStatus.PENDING
    audit: tuple[AuditRecord, ...] = ()
    corrections: tuple[AuditRecord, ...] = ()


@dataclass(frozen=True, slots=True)
class LanguageModelSuggestion:
    task: str
    value: str
    explanation: str
