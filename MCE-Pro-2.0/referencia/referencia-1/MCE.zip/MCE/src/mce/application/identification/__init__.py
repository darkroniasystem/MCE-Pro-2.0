"""Identificación explicable de contenido."""

from mce.application.identification.scoring import MatchPolicy, MatchScorer
from mce.application.identification.service import IdentificationService

__all__ = ["IdentificationService", "MatchPolicy", "MatchScorer"]
