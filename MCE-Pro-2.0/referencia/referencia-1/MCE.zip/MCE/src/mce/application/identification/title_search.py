"""Normalización estable de títulos para catálogo, alias y bots."""

from __future__ import annotations

import re
import unicodedata

_ROMAN = {
    "i": "1",
    "ii": "2",
    "iii": "3",
    "iv": "4",
    "v": "5",
    "vi": "6",
    "vii": "7",
    "viii": "8",
    "ix": "9",
    "x": "10",
    "xi": "11",
    "xii": "12",
    "xiii": "13",
    "xiv": "14",
    "xv": "15",
    "xvi": "16",
    "xvii": "17",
    "xviii": "18",
    "xix": "19",
    "xx": "20",
}


def normalize_search_title(value: str) -> str:
    """Ignora caja, diacríticos, puntuación y números romanos básicos."""
    folded = unicodedata.normalize("NFKD", value).casefold()
    without_marks = "".join(
        character for character in folded if not unicodedata.combining(character)
    )
    words = re.findall(r"[a-z0-9]+", without_marks)
    return " ".join(_ROMAN.get(word, word) for word in words)
