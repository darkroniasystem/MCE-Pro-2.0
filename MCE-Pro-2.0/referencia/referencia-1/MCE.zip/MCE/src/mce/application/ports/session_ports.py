"""Puertos del subsistema de sesiones."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Protocol

from mce.application.dto.session_models import JobProgress, ProcessingSession, Workspace


class Clock(Protocol):
    """Fuente inyectable de tiempo UTC."""

    def now(self) -> datetime: ...


class IdGenerator(Protocol):
    """Generador inyectable de identificadores opacos."""

    def new_id(self) -> str: ...


class ProgressReporter(Protocol):
    """Destino opcional para progreso de sesiones."""

    def report(self, progress: JobProgress) -> None: ...


class WorkspaceRepository(Protocol):
    """Contrato de almacenamiento de espacios de trabajo."""

    def get(self, workspace_id: str) -> Workspace | None: ...
    def save(self, workspace: Workspace) -> None: ...


class SessionRepository(Protocol):
    """Contrato de almacenamiento de sesiones."""

    def get(self, session_id: str) -> ProcessingSession | None: ...
    def find_by_package_hash(self, package_hash: str) -> ProcessingSession | None: ...
    def save(self, session: ProcessingSession) -> None: ...
    def delete(self, session_id: str) -> None: ...


class CheckpointStore(Protocol):
    """Contrato para checkpoints JSON explícitos."""

    def save(self, session: ProcessingSession) -> Path: ...
    def load(self, session_id: str) -> ProcessingSession: ...
    def delete(self, session_id: str) -> None: ...
