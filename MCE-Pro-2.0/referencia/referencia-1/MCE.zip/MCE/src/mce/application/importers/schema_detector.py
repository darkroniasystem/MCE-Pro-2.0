"""Detección aislada de versión y compatibilidad."""

from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class SchemaCompatibility(StrEnum):
    """Clasificación estable de una versión encontrada."""

    SUPPORTED = "supported"
    UNSUPPORTED = "unsupported"
    MISSING = "missing"
    MALFORMED = "malformed"
    FUTURE_VERSION = "future_version"
    LEGACY_VERSION = "legacy_version"


@dataclass(frozen=True, slots=True)
class SchemaDetectionResult:
    """Versión declarada y decisión del detector."""

    raw_version: Any
    version: str | None
    compatibility: SchemaCompatibility


class SchemaDetector:
    """Reconoce exclusivamente contratos conocidos por MCE."""

    supported_versions = frozenset({"1.0", "2.2"})

    def detect(self, document: dict[str, Any]) -> SchemaDetectionResult:
        """Clasifica `schema_version` sin validar el resto del documento."""
        raw = document.get("schema_version")
        if raw is None:
            return SchemaDetectionResult(raw, None, SchemaCompatibility.MISSING)
        if not isinstance(raw, str) or not raw.strip():
            return SchemaDetectionResult(raw, None, SchemaCompatibility.MALFORMED)
        version = raw.strip()
        parts = version.split(".")
        if len(parts) != 2 or not all(part.isdigit() for part in parts):
            return SchemaDetectionResult(raw, version, SchemaCompatibility.MALFORMED)
        if version in self.supported_versions:
            return SchemaDetectionResult(raw, version, SchemaCompatibility.SUPPORTED)
        major = int(parts[0])
        if major > 2:
            compatibility = SchemaCompatibility.FUTURE_VERSION
        elif major < 1:
            compatibility = SchemaCompatibility.LEGACY_VERSION
        else:
            compatibility = SchemaCompatibility.UNSUPPORTED
        return SchemaDetectionResult(raw, version, compatibility)
