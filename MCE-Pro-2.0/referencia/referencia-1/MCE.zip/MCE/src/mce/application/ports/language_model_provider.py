"""Puerto opcional y no autoritativo para sugerencias de IA."""

from typing import Protocol

from mce.application.enrichment.models import LanguageModelSuggestion


class LanguageModelProvider(Protocol):
    def suggest(self, task: str, payload: dict[str, object]) -> LanguageModelSuggestion: ...
