"""Orquestación atómica del pipeline de importación MSL."""

import logging
import os
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from time import perf_counter

from mce.application.dto import (
    ImportIssue,
    ImportIssueSeverity,
    ImportPackage,
    ImportRequest,
    ImportResult,
    ImportResultStatus,
    ImportStatistics,
)
from mce.application.exceptions import (
    ImportErrorBase,
    ImportFileAccessError,
    ImportFileNotFoundError,
    ImportFileTooLargeError,
    InvalidJsonError,
)
from mce.application.importers.duplicate_import_checker import DuplicateImportChecker
from mce.application.importers.import_mapper import ImportMapper
from mce.application.importers.json_reader import SafeJsonReader
from mce.application.importers.local_services import InMemoryImportRegistry, LocalSha256Calculator
from mce.application.importers.normalizer import MslNormalizer
from mce.application.importers.schema_detector import SchemaCompatibility, SchemaDetector
from mce.application.importers.schema_validator import StructuralValidator
from mce.application.importers.semantic_validator import SemanticValidator
from mce.application.ports import FileReader, HashCalculator, ImportRegistry
from mce.infrastructure.runtime.logging_config import correlation_scope

logger = logging.getLogger(__name__)
ProgressCallback = Callable[[str], None]


class ImportService:
    """Coordina lectura, validación, mapeo y registro sin persistencia."""

    def __init__(
        self,
        *,
        reader: FileReader | None = None,
        hash_calculator: HashCalculator | None = None,
        registry: ImportRegistry | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._reader = reader or SafeJsonReader()
        self._hash_calculator = hash_calculator or LocalSha256Calculator()
        self._registry = registry or InMemoryImportRegistry()
        self._duplicates = DuplicateImportChecker(self._registry)
        self._clock = clock or (lambda: datetime.now(UTC))
        self._schema_detector = SchemaDetector()
        self._normalizer = MslNormalizer()
        self._structural_validator = StructuralValidator()
        self._semantic_validator = SemanticValidator()
        self._mapper = ImportMapper()

    def import_file(
        self,
        request: ImportRequest,
        progress_callback: ProgressCallback | None = None,
    ) -> ImportResult:
        before = _resident_memory_bytes()
        started = perf_counter()
        with correlation_scope():
            result = self._import_file_correlated(request, progress_callback)
            logger.info(
                "event=import_finished file=%s status=%s success=%s "
                "json_hash=%s duration_ms=%d rss_before=%s rss_after=%s "
                "records=%d warnings=%d errors=%d",
                Path(request.file_path).name,
                result.status.value,
                result.success,
                result.file_hash,
                round((perf_counter() - started) * 1000),
                before,
                _resident_memory_bytes(),
                result.statistics.total_records,
                result.statistics.warnings,
                result.statistics.errors + result.statistics.fatal_errors,
            )
            return result

    def _import_file_correlated(
        self,
        request: ImportRequest,
        progress_callback: ProgressCallback | None = None,
    ) -> ImportResult:
        """Ejecuta el pipeline y convierte fallos esperados en `ImportResult`."""
        started = perf_counter()
        path = Path(request.file_path)
        logger.info(
            "event=import_started file=%s size_bytes=%s",
            path.name,
            path.stat().st_size if path.is_file() else None,
        )
        file_hash: str | None = None
        canonical: dict[str, object] | None = None
        issues: tuple[ImportIssue, ...] = ()
        stage_started = started
        previous_stage = "starting"

        def progress(stage: str) -> None:
            nonlocal previous_stage, stage_started
            now = perf_counter()
            logger.info(
                "event=import_stage stage=%s duration_ms=%d rss=%s",
                previous_stage,
                round((now - stage_started) * 1000),
                _resident_memory_bytes(),
            )
            previous_stage = stage
            stage_started = now
            self._progress(progress_callback, stage)

        try:
            progress("reading")
            document = self._reader.read(path, request.limits)
            progress("hashing")
            file_hash = self._hash_calculator.calculate(path)
            if self._duplicates.is_duplicate(file_hash) and not request.force_duplicate:
                duplicate_issue = ImportIssue(
                    "DUPLICATE_IMPORT",
                    ImportIssueSeverity.WARNING,
                    "El mismo archivo ya fue importado.",
                )
                return self._result(
                    started,
                    path,
                    file_hash,
                    ImportResultStatus.DUPLICATE,
                    False,
                    None,
                    (duplicate_issue,),
                    ImportStatistics(warnings=1),
                )
            progress("detecting_schema")
            detection = self._schema_detector.detect(document)
            if not self._schema_allowed(detection.compatibility, request.allow_legacy):
                code = (
                    "SCHEMA_VERSION_MALFORMED"
                    if detection.compatibility is SchemaCompatibility.MALFORMED
                    else "SCHEMA_VERSION_UNSUPPORTED"
                )
                schema_issue = ImportIssue(
                    code,
                    ImportIssueSeverity.FATAL,
                    "La versión del esquema no es compatible.",
                    "schema_version",
                    raw_value=detection.raw_version,
                )
                status = (
                    ImportResultStatus.UNSUPPORTED_SCHEMA
                    if detection.compatibility
                    in {SchemaCompatibility.FUTURE_VERSION, SchemaCompatibility.UNSUPPORTED}
                    else ImportResultStatus.INCOMPATIBLE
                )
                return self._result(
                    started,
                    path,
                    file_hash,
                    status,
                    False,
                    None,
                    (schema_issue,),
                    ImportStatistics(fatal_errors=1),
                )
            canonical, normalization_issues = self._normalizer.normalize(document, detection)
            progress("validating_structure")
            structural_issues = self._structural_validator.validate(canonical, request.limits)
            progress("validating_records")
            semantic_issues = self._semantic_validator.validate(canonical, request.limits)
            issues = normalization_issues + structural_issues + semantic_issues
            if self._reject(issues, request.strict_mode):
                return self._result(
                    started,
                    path,
                    file_hash,
                    ImportResultStatus.REJECTED,
                    False,
                    None,
                    issues,
                    self._statistics(canonical, issues, None),
                )
            progress("mapping")
            package = self._mapper.map(
                canonical,
                original_file_hash=file_hash,
                original_filename=path.name,
                received_at=self._clock(),
                existing_issues=issues,
                expected_bank_id=request.expected_bank_id,
                expected_installation_id=request.expected_installation_id,
            )
            final_issues = package.issues
            status = (
                ImportResultStatus.COMPLETED_WITH_WARNINGS
                if any(issue.severity is ImportIssueSeverity.WARNING for issue in final_issues)
                else ImportResultStatus.COMPLETED
            )
            self._registry.add_hash(file_hash)
            progress("completed")
            statistics = self._statistics(canonical, final_issues, package)
            logger.info(
                "Importación MSL finalizada: schema=%s records=%d status=%s",
                package.detected_schema_version,
                statistics.total_records,
                status.value,
            )
            return self._result(
                started,
                path,
                file_hash,
                status,
                True,
                package,
                final_issues,
                statistics,
            )
        except ImportErrorBase as exc:
            logger.warning("Importación MSL rechazada: %s", type(exc).__name__)
            return self._exception_result(started, path, file_hash, exc)
        except Exception:
            logger.exception("Error inesperado durante la importación de %s", path.name)
            issue = ImportIssue(
                "IMPORT_FAILED",
                ImportIssueSeverity.FATAL,
                "La importación falló por un error interno controlado.",
                suggestion="Revise el log técnico.",
            )
            return self._result(
                started,
                path,
                file_hash,
                ImportResultStatus.FAILED,
                False,
                None,
                (issue,),
                self._statistics(canonical, (issue,), None),
            )

    @staticmethod
    def _schema_allowed(compatibility: SchemaCompatibility, allow_legacy: bool) -> bool:
        return compatibility is SchemaCompatibility.SUPPORTED or (
            allow_legacy
            and compatibility in {SchemaCompatibility.MISSING, SchemaCompatibility.LEGACY_VERSION}
        )

    @staticmethod
    def _reject(issues: tuple[ImportIssue, ...], strict: bool) -> bool:
        blocking = {ImportIssueSeverity.ERROR, ImportIssueSeverity.FATAL}
        return any(issue.severity in blocking for issue in issues) or (
            strict and any(issue.severity is ImportIssueSeverity.WARNING for issue in issues)
        )

    @staticmethod
    def _progress(callback: ProgressCallback | None, stage: str) -> None:
        if callback is not None:
            callback(stage)

    def _exception_result(
        self,
        started: float,
        path: Path,
        file_hash: str | None,
        exc: ImportErrorBase,
    ) -> ImportResult:
        mapping: list[tuple[type[ImportErrorBase], str, ImportResultStatus]] = [
            (ImportFileNotFoundError, "FILE_NOT_FOUND", ImportResultStatus.REJECTED),
            (ImportFileTooLargeError, "FILE_TOO_LARGE", ImportResultStatus.REJECTED),
            (InvalidJsonError, "INVALID_JSON", ImportResultStatus.INVALID_JSON),
            (ImportFileAccessError, "FILE_ACCESS_ERROR", ImportResultStatus.REJECTED),
        ]
        code = exc.code or "IMPORT_FAILED"
        status = ImportResultStatus.FAILED
        for error_type, candidate_code, candidate_status in mapping:
            if isinstance(exc, error_type):
                if exc.code is None:
                    code = candidate_code
                status = candidate_status
                break
        issue = ImportIssue(code, ImportIssueSeverity.FATAL, str(exc))
        return self._result(
            started,
            path,
            file_hash,
            status,
            False,
            None,
            (issue,),
            ImportStatistics(fatal_errors=1),
        )

    @staticmethod
    def _statistics(
        document: dict[str, object] | None,
        issues: tuple[ImportIssue, ...],
        package: ImportPackage | None,
    ) -> ImportStatistics:
        sources = document.get("sources", []) if document else []
        files = document.get("files", []) if document else []
        source_count = len(sources) if isinstance(sources, list) else 0
        file_count = len(files) if isinstance(files, list) else 0
        warning_count = sum(issue.severity is ImportIssueSeverity.WARNING for issue in issues)
        error_count = sum(issue.severity is ImportIssueSeverity.ERROR for issue in issues)
        fatal_count = sum(issue.severity is ImportIssueSeverity.FATAL for issue in issues)
        generated_ids = sum(
            issue.code in {"INTERNAL_ID_GENERATED", "INVALID_EXTERNAL_ID"} for issue in issues
        )
        duplicate_ids = sum(issue.code.startswith("DUPLICATE_") for issue in issues)
        unknown = sum(issue.code == "UNKNOWN_EXTENSION" for issue in issues)
        if package is None:
            return ImportStatistics(
                total_records=source_count + file_count,
                invalid_records=file_count,
                sources=source_count,
                warnings=warning_count,
                errors=error_count,
                fatal_errors=fatal_count,
                generated_ids=generated_ids,
                duplicate_ids=duplicate_ids,
                unknown_extensions=unknown,
            )
        valid_records = len(package.domain_files)
        return ImportStatistics(
            total_records=source_count + file_count,
            valid_records=valid_records,
            invalid_records=max(0, file_count - valid_records - len(package.ignored_files)),
            video_files=len(package.video_files),
            subtitle_files=len(package.subtitle_files),
            ignored_files=len(package.ignored_files),
            sources=len(package.sources),
            warnings=warning_count,
            errors=error_count,
            fatal_errors=fatal_count,
            generated_ids=generated_ids,
            duplicate_ids=duplicate_ids,
            unknown_extensions=unknown,
        )

    @staticmethod
    def _result(
        started: float,
        path: Path,
        file_hash: str | None,
        status: ImportResultStatus,
        success: bool,
        package: ImportPackage | None,
        issues: tuple[ImportIssue, ...],
        statistics: ImportStatistics,
    ) -> ImportResult:
        return ImportResult(
            success,
            status,
            package,
            issues,
            statistics,
            timedelta(seconds=perf_counter() - started),
            str(path),
            file_hash,
        )


def _resident_memory_bytes() -> int | None:
    """Devuelve el RSS del proceso en Windows sin retener el grafo importado."""
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        class ProcessMemoryCounters(ctypes.Structure):
            _fields_ = [
                ("cb", wintypes.DWORD),
                ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t),
            ]

        counters = ProcessMemoryCounters()
        counters.cb = ctypes.sizeof(counters)
        get_current_process = ctypes.windll.kernel32.GetCurrentProcess
        get_current_process.restype = wintypes.HANDLE
        get_process_memory = ctypes.windll.psapi.GetProcessMemoryInfo
        get_process_memory.argtypes = (
            wintypes.HANDLE,
            ctypes.POINTER(ProcessMemoryCounters),
            wintypes.DWORD,
        )
        get_process_memory.restype = wintypes.BOOL
        process = get_current_process()
        if not get_process_memory(process, ctypes.byref(counters), counters.cb):
            return None
        return int(counters.WorkingSetSize)
    except (AttributeError, OSError, TypeError, ValueError):
        return None
