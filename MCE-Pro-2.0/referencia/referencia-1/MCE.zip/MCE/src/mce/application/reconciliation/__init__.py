"""Reglas de cobertura para reconciliar disponibilidad."""

from mce.application.reconciliation.scope_matcher import ScopeMatcher

__all__ = ["ScopeMatcher"]
