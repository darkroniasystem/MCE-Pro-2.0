"""Lector seguro responsable solo de decodificar JSON."""

import json
from pathlib import Path
from typing import Any

import ijson  # type: ignore[import-untyped]

from mce.application.dto import ImportLimits
from mce.application.exceptions import (
    ImportFileAccessError,
    ImportFileNotFoundError,
    ImportFileTooLargeError,
    InvalidJsonError,
)
from mce.application.importers.streaming_json import StreamingJsonList

_STREAMING_THRESHOLD = 64 * 1024 * 1024
_ARRAY_KEYS = {"sources", "fuentes", "files", "archivos", "videos", "subtitles", "subtitulos"}
_METADATA_KEYS = {
    "scan_id",
    "schema_version",
    "app_version",
    "banco",
    "bank",
    "instalacion",
    "installation",
    "alcance_escaneo",
    "scan",
    "generator",
    "fecha_inicio",
    "fecha_fin",
    "estado",
    "summary",
    "resumen",
}


def _maximum_depth(root: Any, limit: int) -> int:
    """Calcula profundidad iterativamente y corta al superar el límite."""
    maximum = 1
    stack: list[tuple[Any, int]] = [(root, 1)]
    while stack:
        value, depth = stack.pop()
        maximum = max(maximum, depth)
        if maximum > limit:
            return maximum
        if isinstance(value, dict):
            stack.extend((child, depth + 1) for child in value.values())
        elif isinstance(value, list):
            stack.extend((child, depth + 1) for child in value)
    return maximum


class SafeJsonReader:
    """Abre un archivo regular UTF-8 sin seguir enlaces simbólicos."""

    def read(self, path: Path, limits: ImportLimits) -> dict[str, Any]:
        """Valida archivo, tamaño, sintaxis, raíz y profundidad."""
        if not path.exists():
            raise ImportFileNotFoundError("El archivo solicitado no existe.", code="FILE_NOT_FOUND")
        if path.is_symlink():
            raise ImportFileAccessError(
                "No se permiten enlaces simbólicos.", code="SYMLINK_NOT_ALLOWED"
            )
        if not path.is_file():
            raise ImportFileAccessError(
                "La ruta no corresponde a un archivo regular.", code="NOT_REGULAR_FILE"
            )
        if path.suffix.lower() != ".json":
            raise ImportFileAccessError(
                "Solo se permiten archivos con extensión .json.", code="INVALID_FILE_EXTENSION"
            )
        try:
            size = path.stat().st_size
        except OSError as exc:
            raise ImportFileAccessError(
                "No se pudo consultar el archivo.", code="FILE_ACCESS_ERROR"
            ) from exc
        if size == 0:
            raise InvalidJsonError("El archivo JSON está vacío.", code="FILE_EMPTY")
        if size > limits.max_file_size_bytes:
            raise ImportFileTooLargeError(
                f"El archivo supera el límite de {limits.max_file_size_mb} MB.",
                code="FILE_TOO_LARGE",
            )
        try:
            if size >= _STREAMING_THRESHOLD:
                return self._read_streaming(path, limits)
            with path.open("r", encoding="utf-8-sig", newline="") as stream:
                document = json.load(stream)
        except UnicodeDecodeError as exc:
            raise InvalidJsonError(
                "El archivo no usa UTF-8 ni UTF-8 con BOM.", code="INVALID_ENCODING"
            ) from exc
        except json.JSONDecodeError as exc:
            raise InvalidJsonError(
                f"JSON inválido en línea {exc.lineno}, columna {exc.colno}.",
                code="INVALID_JSON",
            ) from exc
        except ijson.JSONError as exc:
            raise InvalidJsonError(
                "El archivo no contiene JSON válido.", code="INVALID_JSON"
            ) from exc
        except RecursionError as exc:
            raise InvalidJsonError(
                "El JSON tiene una profundidad excesiva.", code="JSON_DEPTH_EXCEEDED"
            ) from exc
        except OSError as exc:
            raise ImportFileAccessError(
                "No se pudo leer el archivo.", code="FILE_ACCESS_ERROR"
            ) from exc
        if not isinstance(document, dict):
            raise InvalidJsonError("La raíz JSON debe ser un objeto.", code="ROOT_NOT_OBJECT")
        if _maximum_depth(document, limits.max_json_depth) > limits.max_json_depth:
            raise InvalidJsonError(
                f"El JSON supera la profundidad máxima de {limits.max_json_depth}.",
                code="JSON_DEPTH_EXCEEDED",
            )
        return document

    @staticmethod
    def _read_streaming(path: Path, limits: ImportLimits) -> dict[str, Any]:
        """Lee cabecera y expone matrices grandes como vistas incrementales."""
        containers: dict[str, str] = {}
        depth = 0
        root_seen = False
        with path.open("rb") as stream:
            for prefix, event, value in ijson.parse(stream):
                if not root_seen:
                    root_seen = True
                    if prefix != "" or event != "start_map":
                        raise InvalidJsonError(
                            "La raíz JSON debe ser un objeto.", code="ROOT_NOT_OBJECT"
                        )
                if event in {"start_map", "start_array"}:
                    depth += 1
                    if depth > limits.max_json_depth:
                        raise InvalidJsonError(
                            f"El JSON supera la profundidad máxima de {limits.max_json_depth}.",
                            code="JSON_DEPTH_EXCEEDED",
                        )
                elif event in {"end_map", "end_array"}:
                    depth -= 1
                if prefix == "" and event == "map_key":
                    containers[str(value)] = "unknown"
                elif "." not in prefix and prefix and event in {"start_array", "start_map"}:
                    containers[prefix] = event
        document: dict[str, Any] = {}
        for key, container in containers.items():
            if key in _ARRAY_KEYS and container == "start_array":
                document[key] = StreamingJsonList(path, key)
            elif key in _METADATA_KEYS:
                with path.open("rb") as stream:
                    value = next(ijson.items(stream, key), None)
                document[key] = value
        return document
