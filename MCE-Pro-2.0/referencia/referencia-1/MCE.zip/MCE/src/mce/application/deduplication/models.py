"""Modelos de deduplicación y catálogo consolidado."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum


class DuplicateType(StrEnum):
    DUPLICATE_PHYSICAL_FILE = "duplicate_physical_file"
    SAME_CONTENT_DIFFERENT_FILE = "same_content_different_file"
    SAME_CONTENT_DIFFERENT_VERSION = "same_content_different_version"
    PROBABLE_DUPLICATE = "probable_duplicate"
    PATH_DUPLICATE = "path_duplicate"
    HASH_DUPLICATE = "hash_duplicate"
    METADATA_DUPLICATE = "metadata_duplicate"


class CatalogAvailabilityStatus(StrEnum):
    AVAILABLE = "available"
    MISSING = "missing"
    UNKNOWN = "unknown"
    REMOVED = "removed"
    EXCLUDED = "excluded"


@dataclass(frozen=True, slots=True)
class CatalogFile:
    file_id: str
    bank_id: str
    installation_id: str
    source_id: str
    path: str
    normalized_path: str
    name: str
    size_bytes: int | None = None
    file_hash: str | None = None
    duration_seconds: float | None = None
    content_id: str | None = None
    version_id: str | None = None
    resolution: str | None = None
    language: str | None = None
    edition: str | None = None
    episode_key: str | None = None
    structure_type: str | None = None


@dataclass(frozen=True, slots=True)
class CatalogContent:
    content_id: str
    title: str
    year: int | None = None
    external_ids: tuple[tuple[str, str], ...] = ()
    file_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CatalogVersion:
    version_id: str
    content_id: str
    edition: str | None = None
    language: str | None = None
    resolution: str | None = None
    file_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DuplicateEvidence:
    signal: str
    weight: float
    detail: str


@dataclass(frozen=True, slots=True)
class DuplicateCandidate:
    left_file_id: str
    right_file_id: str
    duplicate_type: DuplicateType
    confidence: float
    evidence: tuple[DuplicateEvidence, ...]


@dataclass(frozen=True, slots=True)
class AvailabilityRecord:
    availability_id: str
    file_id: str
    content_id: str | None
    version_id: str | None
    bank_id: str
    installation_id: str
    source_id: str
    status: CatalogAvailabilityStatus
    updated_at: datetime
    history: tuple[tuple[datetime, CatalogAvailabilityStatus], ...] = ()


@dataclass(frozen=True, slots=True)
class CatalogAudit:
    action: str
    actor: str
    at: datetime
    details: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class MergeSnapshot:
    merge_id: str
    target: CatalogContent
    sources: tuple[CatalogContent, ...]
    actor: str
    at: datetime


@dataclass(slots=True)
class InMemoryCatalog:
    contents: dict[str, CatalogContent] = field(default_factory=dict)
    versions: dict[str, CatalogVersion] = field(default_factory=dict)
    files: dict[str, CatalogFile] = field(default_factory=dict)
    availabilities: dict[str, AvailabilityRecord] = field(default_factory=dict)
    merges: dict[str, MergeSnapshot] = field(default_factory=dict)
    audit: list[CatalogAudit] = field(default_factory=list)
