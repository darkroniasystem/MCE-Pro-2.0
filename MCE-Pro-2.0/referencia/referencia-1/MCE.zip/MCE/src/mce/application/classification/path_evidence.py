"""Evidencias locales obtenidas mediante recorrido jerárquico de rutas."""

from __future__ import annotations

import re
import unicodedata
from pathlib import PureWindowsPath
from typing import ClassVar

from mce.application.classification.models import (
    ClassificationCandidate,
    ClassificationEvidence,
    MediaKind,
    PathEvidenceResult,
)


class PathEvidenceEngine:
    """Recorre carpetas cercanas primero y conserva el origen de cada señal."""

    RULES: ClassVar[tuple[tuple[MediaKind, tuple[str, ...]], ...]] = (
        (MediaKind.ANIME, ("anime", "animes", "donghua", "donghuas")),
        (MediaKind.DORAMA, ("dorama", "doramas", "kdrama", "k-drama", "jdrama", "cdrama")),
        (MediaKind.NOVELA, ("novela", "novelas", "telenovela", "telenovelas")),
        (
            MediaKind.WESTERN_ANIMATION,
            ("animados", "animadas", "cartoon", "cartoons", "animacion", "animación"),
        ),
        (MediaKind.SERIES, ("series", "tv show", "tv shows", "reality")),
        (
            MediaKind.DOCUMENTARY,
            ("documental", "documentales", "documentary", "documentaries"),
        ),
        (MediaKind.MOVIE, ("pelicula", "peliculas", "película", "películas", "movies", "films")),
    )
    SEASON_SEGMENT = re.compile(
        r"(?i)^(?:season|temporada|temp|s)\s*[._ -]*\d{1,3}(?:\s*[\[(].*)?$"
    )

    def analyze(self, path: str) -> PathEvidenceResult:
        if not isinstance(path, str) or not path.strip():
            raise ValueError("path must not be empty")
        if "\x00" in path:
            raise ValueError("path must not contain null characters")
        parsed = PureWindowsPath(path)
        folders = parsed.parts[:-1] if parsed.suffix else parsed.parts
        traversed = tuple(
            segment for segment in reversed(folders) if segment not in {parsed.anchor, "\\", "/"}
        )
        candidates: list[ClassificationCandidate] = []
        kinds_seen: set[MediaKind] = set()
        for distance, segment in enumerate(traversed):
            normalized = unicodedata.normalize("NFKC", segment).casefold()
            if MediaKind.SEASON not in kinds_seen and self.SEASON_SEGMENT.fullmatch(
                normalized.strip()
            ):
                confidence = max(62.0, 86.0 - distance * 2.0)
                evidence = ClassificationEvidence(
                    signal=f"path_segment:{distance}",
                    value=f"{segment}|season",
                    weight=confidence,
                )
                candidates.append(
                    ClassificationCandidate(MediaKind.SEASON, confidence, (evidence,))
                )
                kinds_seen.add(MediaKind.SEASON)
            for kind, keywords in self.RULES:
                if kind in kinds_seen:
                    continue
                matched = next(
                    (keyword for keyword in keywords if self._contains(normalized, keyword)),
                    None,
                )
                if matched is None:
                    continue
                confidence = max(62.0, 86.0 - distance * 2.0)
                evidence = ClassificationEvidence(
                    signal=f"path_segment:{distance}",
                    value=f"{segment}|{matched}",
                    weight=confidence,
                )
                candidates.append(ClassificationCandidate(kind, confidence, (evidence,)))
                kinds_seen.add(kind)
        candidates.sort(key=lambda item: item.confidence, reverse=True)
        return PathEvidenceResult(path, traversed, tuple(candidates))

    @staticmethod
    def _contains(text: str, keyword: str) -> bool:
        return bool(re.search(rf"(?<![\w]){re.escape(keyword.casefold())}(?![\w])", text))
