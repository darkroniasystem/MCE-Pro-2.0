"""Contrato de auditoría estructurada y reversible."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID


@dataclass(frozen=True, slots=True)
class AuditEvent:
    event_id: str
    occurred_at: datetime
    actor: str
    action: str
    object_type: str
    object_id: str
    previous_value: Any
    new_value: Any
    correlation_id: str
    reversible: bool = False
    reversed_by: str | None = None

    def __post_init__(self) -> None:
        UUID(self.event_id)
        UUID(self.correlation_id)
        if self.occurred_at.tzinfo is None:
            raise ValueError("audit timestamp requires timezone information")
        for value in (self.actor, self.action, self.object_type, self.object_id):
            if not value.strip():
                raise ValueError("audit text values must not be empty")


class AuditRepository(Protocol):
    def add(self, event: AuditEvent) -> None: ...
    def get(self, event_id: str) -> AuditEvent | None: ...
    def list_page(self, *, offset: int = 0, limit: int = 100) -> tuple[AuditEvent, ...]: ...


class AuditService:
    def __init__(self, repository: AuditRepository):
        self._repository = repository

    def record(self, event: AuditEvent) -> None:
        if event.reversed_by is not None:
            raise ValueError("new audit events cannot already be reversed")
        self._repository.add(event)

    def list_page(self, *, offset: int = 0, limit: int = 100) -> tuple[AuditEvent, ...]:
        if offset < 0 or not 1 <= limit <= 1000:
            raise ValueError("invalid audit pagination")
        return self._repository.list_page(offset=offset, limit=limit)
