"""Orquestacion por obra unica con cache, cuota y cancelacion cooperativa."""

from __future__ import annotations

import logging
from dataclasses import replace
from hashlib import sha256
from threading import Condition

from mce.application.ai_review.models import (
    PROMPT_VERSION,
    SCHEMA_VERSION,
    AIRateLimitDeferred,
    AIReviewDecision,
    AIReviewInput,
    AIReviewResult,
    AIReviewState,
    EvidenceSource,
)
from mce.application.ai_review.ports import AIAnalyzer, AIReviewCache, QuotaGuard, SearchProvider
from mce.application.ai_review.sanitizer import sanitized_payload
from mce.application.ai_review.validator import EvidenceValidator

logger = logging.getLogger(__name__)


class AIReviewOrchestrator:
    def __init__(
        self,
        search: SearchProvider,
        analyzer: AIAnalyzer,
        validator: EvidenceValidator,
        cache: AIReviewCache,
        quota: QuotaGuard,
        *,
        test_mode: bool = False,
    ) -> None:
        self.search = search
        self.analyzer = analyzer
        self.validator = validator
        self.cache = cache
        self.quota = quota
        self.test_mode = test_mode
        self._condition = Condition()
        self._inflight: set[str] = set()

    def review(self, item: AIReviewInput) -> AIReviewResult:
        fingerprint = self.fingerprint(item)
        cached = self.cache.get(fingerprint)
        if cached is not None:
            return replace(cached, cached=True, query_fingerprint=fingerprint)
        with self._condition:
            while fingerprint in self._inflight:
                self._condition.wait()
                cached = self.cache.get(fingerprint)
                if cached is not None:
                    return replace(cached, cached=True, query_fingerprint=fingerprint)
            self._inflight.add(fingerprint)
        try:
            return self._review_uncached(item, fingerprint)
        finally:
            with self._condition:
                self._inflight.discard(fingerprint)
                self._condition.notify_all()

    def _review_uncached(self, item: AIReviewInput, fingerprint: str) -> AIReviewResult:
        if not self.quota.acquire(2):
            result = self._deferred(AIReviewState.QUOTA_EXHAUSTED, "cuota IA agotada")
            return replace(result, query_fingerprint=fingerprint)
        try:
            sources = self.search.search(self.query(item))
            result = self.validator.validate(item, self.analyzer.analyze(item, sources))
        except AIRateLimitDeferred as exc:
            result = self._deferred(AIReviewState.WAITING_RATE_LIMIT, str(exc))
            return replace(result, query_fingerprint=fingerprint, provider="groq")
        except Exception as exc:
            message = str(exc).replace("GEMINI_API_KEY", "credencial").replace(
                "TAVILY_API_KEY", "credencial"
            )
            result = self._deferred(AIReviewState.ERROR, message[:500])
            return replace(result, query_fingerprint=fingerprint)
        if self.test_mode and result.decision is AIReviewDecision.APPROVE:
            result = replace(
                result,
                state=AIReviewState.HUMAN,
                decision=AIReviewDecision.HUMAN_REVIEW,
                reason=f"modo de prueba · {result.reason}",
            )
        result = replace(
            result,
            provider=result.provider
            or str(getattr(self.analyzer, "name", "unknown")),
            query_fingerprint=fingerprint,
        )
        self.cache.put(fingerprint, result)
        return result

    @staticmethod
    def _deferred(state: AIReviewState, reason: str) -> AIReviewResult:
        return AIReviewResult(
            SCHEMA_VERSION,
            state,
            AIReviewDecision.HUMAN_REVIEW,
            None,
            None,
            None,
            (),
            0,
            (),
            reason=reason,
        )

    @staticmethod
    def query(item: AIReviewInput) -> str:
        safe = sanitized_payload(item)
        parts = [str(safe["title"]), str(safe["category"])]
        alternatives = safe.get("alternative_titles")
        if isinstance(alternatives, tuple):
            parts.extend(str(value) for value in alternatives[:2])
        if safe["year_hint"] is not None:
            parts.append(str(safe["year_hint"]))
        return " ".join(parts)

    def fingerprint(self, item: AIReviewInput) -> str:
        search_name = str(getattr(self.search, "name", type(self.search).__name__))
        analyzer_name = str(getattr(self.analyzer, "name", type(self.analyzer).__name__))
        model = str(getattr(self.analyzer, "model", "unknown"))
        payload = "|".join(
            (
                item.title.casefold().strip(),
                item.category.casefold().strip(),
                str(item.year_hint or ""),
                search_name,
                analyzer_name,
                model,
                PROMPT_VERSION,
                SCHEMA_VERSION,
            )
        )
        return sha256(payload.encode("utf-8")).hexdigest()


class ValidatedAnalyzerChain:
    """Valida Qwen y, si no resuelve, valida también el único fallback Groq."""

    name = "qwen-local-then-groq"

    def __init__(
        self,
        primary: AIAnalyzer,
        fallback: AIAnalyzer,
        validator: EvidenceValidator,
    ) -> None:
        self.primary = primary
        self.fallback = fallback
        self.validator = validator
        self.model = (
            f"{getattr(primary, 'model', 'local')}|"
            f"{getattr(fallback, 'model', 'remote')}"
        )
        self.primary_calls = 0
        self.primary_accepted = 0
        self.fallback_calls = 0
        self.fallback_accepted = 0
        self.fallback_human_review = 0
        self.primary_failures = 0
        self.last_route = "sin llamadas"

    def analyze(
        self, item: AIReviewInput, sources: tuple[EvidenceSource, ...]
    ) -> AIReviewResult:
        try:
            self.primary_calls += 1
            primary = self.primary.analyze(item, sources)
            validated = self.validator.validate(item, primary)
            if validated.decision is AIReviewDecision.APPROVE:
                self.primary_accepted += 1
                self.last_route = "Qwen aceptado"
                logger.info(
                    "event=ai_analyzer_route route=qwen_accepted work_id=%s",
                    item.work_group_id,
                )
                return validated
            self.last_route = "Qwen no concluyente -> Groq"
            logger.info(
                "event=ai_analyzer_route route=qwen_rejected_to_groq work_id=%s "
                "status=%s action=%s score=%.1f",
                item.work_group_id,
                primary.analysis_status or "unknown",
                primary.recommended_action or "unknown",
                validated.deterministic_score,
            )
        except Exception as exc:
            self.primary_failures += 1
            self.last_route = "Qwen falló -> Groq"
            logger.warning(
                "event=ai_analyzer_route route=qwen_failed_to_groq work_id=%s error=%s",
                item.work_group_id,
                str(exc)[:200],
            )

        self.fallback_calls += 1
        fallback = self.fallback.analyze(item, sources)
        validated_fallback = self.validator.validate(item, fallback)
        if validated_fallback.decision is AIReviewDecision.APPROVE:
            self.fallback_accepted += 1
            self.last_route = "Groq aceptado por validador"
            route = "groq_accepted"
        else:
            self.fallback_human_review += 1
            self.last_route = "Groq no concluyente -> revisión humana"
            route = "groq_to_human_review"
        logger.info(
            "event=ai_analyzer_route route=%s work_id=%s score=%.1f",
            route,
            item.work_group_id,
            validated_fallback.deterministic_score,
        )
        return validated_fallback
