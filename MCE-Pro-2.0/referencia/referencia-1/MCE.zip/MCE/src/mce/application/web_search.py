"""Búsqueda web de respaldo, desacoplada de los proveedores estructurados."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from mce.application.identification.models import (
    ContentCandidate,
    IdentificationQuery,
    IdentificationResult,
    IdentificationStatus,
)


@dataclass(frozen=True, slots=True)
class WebSearchEvidence:
    source: str
    title: str
    media_type: str | None
    year: int | None
    description: str
    source_url: str
    score: float
    collected_at: datetime
    query: str
    provider: str = "tavily"


class WebSearchProvider(Protocol):
    name: str

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]: ...


@dataclass(frozen=True, slots=True)
class WebFallbackDecision:
    used: bool
    reason: str | None = None
    query: str | None = None
    evidence: tuple[WebSearchEvidence, ...] = ()
    from_cache: bool = False


class WebSearchFallbackService:
    """Recolecta evidencia web solo cuando el resultado estructurado lo requiere."""

    def __init__(self, provider: WebSearchProvider, *, limit: int = 8) -> None:
        if limit < 2:
            raise ValueError("web fallback must collect at least two candidates")
        self.provider = provider
        self.limit = limit

    def collect(
        self, query: IdentificationQuery, result: IdentificationResult
    ) -> WebFallbackDecision:
        reason = self._reason(query, result)
        if reason is None:
            return WebFallbackDecision(False)
        search_query = self.build_query(query)
        evidence = self.provider.search(search_query, limit=self.limit)
        return WebFallbackDecision(
            True,
            reason,
            search_query,
            evidence,
            bool(getattr(self.provider, "last_from_cache", False)),
        )

    @staticmethod
    def build_query(query: IdentificationQuery) -> str:
        parts = [query.title.strip(), query.kind.value]
        aliases = tuple(
            dict.fromkeys(
                value.strip()
                for value in (query.original_title, *query.aliases)
                if value and value.strip() and value.casefold() != query.title.casefold()
            )
        )
        parts.extend(aliases[:2])
        if query.year is not None:
            parts.append(str(query.year))
        if query.season is not None:
            parts.extend(("season", str(query.season)))
        return " ".join(part for part in parts if part)

    @staticmethod
    def _reason(query: IdentificationQuery, result: IdentificationResult) -> str | None:
        if result.status is IdentificationStatus.AMBIGUOUS:
            return "multiple_candidates"
        if result.status is IdentificationStatus.PROBABLE:
            return "confidence_65_84"
        if result.status is IdentificationStatus.NOT_FOUND_CONFIRMED:
            return "structured_not_found"
        if result.status is IdentificationStatus.PROVIDER_PARTIAL:
            return "essential_evidence_missing"
        selected: ContentCandidate | None = result.selected
        if selected is not None and selected.metadata.kind is not query.kind:
            return "type_conflict"
        if selected is not None and not _has_essential_evidence(selected):
            return "essential_evidence_missing"
        return None


def _has_essential_evidence(candidate: ContentCandidate) -> bool:
    metadata = candidate.metadata
    return bool(metadata.title and (metadata.year is not None or metadata.original_title))


def utc_now() -> datetime:
    return datetime.now(UTC)
