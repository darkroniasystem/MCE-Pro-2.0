"""Deduplicación y consolidación reversible."""

from mce.application.deduplication.detector import FindDuplicateCandidates
from mce.application.deduplication.service import CatalogConsolidationService

__all__ = ["CatalogConsolidationService", "FindDuplicateCandidates"]
