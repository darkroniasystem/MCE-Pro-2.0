"""Resultados estables del procesamiento coordinado."""

from dataclasses import dataclass

from mce.application.dto import ProcessingStage, SessionItem


@dataclass(frozen=True, slots=True)
class ProcessedMedia:
    """Resultado explicable de un elemento sin modificar el archivo físico."""

    item: SessionItem
    title: str
    year: int | None
    media_kind: str
    confidence: float
    identification_status: str
    stage: ProcessingStage
    warning: str | None = None


@dataclass(frozen=True, slots=True)
class ProcessingBatchResult:
    """Lote final con filas destinadas a revisión o catálogo."""

    session_id: str
    items: tuple[ProcessedMedia, ...]
    review_rows: tuple[dict[str, object], ...]
    catalog_rows: tuple[dict[str, object], ...]
    deferred_reason: str | None = None
    audit_rows: tuple[dict[str, object], ...] = ()
    summary: dict[str, object] | None = None


@dataclass(frozen=True, slots=True)
class ProcessingProgress:
    """Instantánea ligera del pipeline para interfaces y telemetría local."""

    stage: str
    stage_label: str
    processed: int
    total: int
    overall_percent: float
    stage_percent: int
    identified: int = 0
    pending_review: int = 0
    errors: int = 0
