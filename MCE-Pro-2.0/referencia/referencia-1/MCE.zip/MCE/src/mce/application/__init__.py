"""Casos de uso y DTO de la aplicación MCE."""
