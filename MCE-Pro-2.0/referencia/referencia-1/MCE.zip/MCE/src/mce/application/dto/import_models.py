"""DTO del pipeline; representan datos aún no confirmados del catálogo."""

from dataclasses import dataclass, field
from datetime import timedelta
from enum import StrEnum
from pathlib import Path
from typing import Any

from mce.domain.entities import PhysicalFile, Scan, ScanImport, Source, Subtitle
from mce.domain.value_objects import (
    BankId,
    InstallationId,
    NormalizedPath,
    PhysicalFileId,
    ScanId,
    ScanScope,
    SourceId,
    SourceType,
)


class ImportIssueSeverity(StrEnum):
    """Impacto estable de una incidencia de importación."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    FATAL = "fatal"


class ImportResultStatus(StrEnum):
    """Resultado final explícito del intento de importación."""

    COMPLETED = "completed"
    COMPLETED_WITH_WARNINGS = "completed_with_warnings"
    REJECTED = "rejected"
    INVALID_JSON = "invalid_json"
    UNSUPPORTED_SCHEMA = "unsupported_schema"
    INCOMPATIBLE = "incompatible"
    DUPLICATE = "duplicate"
    FAILED = "failed"


class DetectedMediaType(StrEnum):
    """Clasificación técnica por extensión, sin identificar contenidos."""

    VIDEO = "video"
    SUBTITLE = "subtitle"
    SUBTITLE_PROBABLE = "subtitle_probable"
    DVD = "dvd"
    AUXILIARY = "auxiliary"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class ImportLimits:
    """Límites de seguridad inyectables del lector y validadores."""

    # Los inventarios de bancos de copia pueden contener millones de rutas.
    # Se conserva un techo explícito para impedir lecturas de tamaño ilimitado.
    max_file_size_mb: int = 1024
    max_total_records: int = 2_000_000
    max_sources: int = 10_000
    max_path_length: int = 32_767
    max_filename_length: int = 255
    max_json_depth: int = 50

    def __post_init__(self) -> None:
        for name in (
            "max_file_size_mb",
            "max_total_records",
            "max_sources",
            "max_path_length",
            "max_filename_length",
            "max_json_depth",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        if self.max_path_length == 0 or self.max_filename_length == 0 or self.max_json_depth == 0:
            raise ValueError("path, filename and depth limits must be positive")

    @property
    def max_file_size_bytes(self) -> int:
        """Devuelve el límite binario utilizado antes de abrir el JSON."""
        return self.max_file_size_mb * 1024 * 1024


@dataclass(frozen=True, slots=True)
class ImportIssue:
    """Diagnóstico traducible asociado a una ubicación concreta."""

    code: str
    severity: ImportIssueSeverity
    message: str
    location: str | None = None
    record_index: int | None = None
    field_name: str | None = None
    raw_value: Any = None
    suggestion: str | None = None


@dataclass(frozen=True, slots=True)
class ImportRequest:
    """Solicitud de importación sin dependencias de interfaz."""

    file_path: Path
    expected_bank_id: BankId | None = None
    expected_installation_id: InstallationId | None = None
    allow_legacy: bool = True
    strict_mode: bool = False
    force_duplicate: bool = False
    limits: ImportLimits = field(default_factory=ImportLimits)


@dataclass(frozen=True, slots=True)
class ImportedSourceDTO:
    """Fuente normalizada, pero aún no persistida."""

    temporary_id: SourceId
    declared_id: str | None
    source_type: SourceType
    display_name: str
    original_root_path: str
    normalized_root_path: NormalizedPath
    issues: tuple[ImportIssue, ...] = ()


@dataclass(frozen=True, slots=True)
class ImportedFileDTO:
    """Archivo externo conservando nombre, rutas y valores declarados."""

    temporary_id: PhysicalFileId
    declared_id: str | None
    source_reference: str | None
    resolved_source_id: SourceId | None
    original_name: str
    original_path: str
    relative_path: str | None
    full_path: str | None
    normalized_path: NormalizedPath
    extension: str
    detected_media_type: DetectedMediaType
    declared_media_type: str | None
    size_bytes: int | None
    raw_extension: str | None
    raw_items: tuple[tuple[str, Any], ...] = ()
    issues: tuple[ImportIssue, ...] = ()


@dataclass(frozen=True, slots=True)
class ImportedScanDTO:
    """Encabezado y colecciones normalizadas de un escaneo externo."""

    declared_scan_id: str | None
    generated_scan_id: ScanId
    schema_version: str | None
    generator_name: str | None
    generator_version: str | None
    started_at_raw: str | None
    finished_at_raw: str | None
    scope: ScanScope
    bank_data: tuple[tuple[str, Any], ...]
    installation_data: tuple[tuple[str, Any], ...]
    sources: tuple[ImportedSourceDTO, ...]
    files: tuple[ImportedFileDTO, ...]
    summary: tuple[tuple[str, Any], ...]


@dataclass(frozen=True, slots=True)
class ImportStatistics:
    """Contadores coherentes con registros e incidencias finales."""

    total_records: int = 0
    valid_records: int = 0
    invalid_records: int = 0
    video_files: int = 0
    subtitle_files: int = 0
    ignored_files: int = 0
    sources: int = 0
    warnings: int = 0
    errors: int = 0
    fatal_errors: int = 0
    generated_ids: int = 0
    duplicate_ids: int = 0
    unknown_extensions: int = 0


@dataclass(frozen=True, slots=True)
class ImportPackage:
    """Paquete atómico validado y mapeado completamente en memoria."""

    scan: ImportedScanDTO
    sources: tuple[ImportedSourceDTO, ...]
    video_files: tuple[ImportedFileDTO, ...]
    subtitle_files: tuple[ImportedFileDTO, ...]
    ignored_files: tuple[ImportedFileDTO, ...]
    issues: tuple[ImportIssue, ...]
    original_file_hash: str
    original_filename: str
    detected_schema_version: str | None
    domain_scan: Scan
    domain_import: ScanImport
    domain_sources: tuple[Source, ...]
    domain_files: tuple[PhysicalFile, ...]
    domain_subtitles: tuple[Subtitle, ...]


@dataclass(frozen=True, slots=True)
class ImportResult:
    """Resultado estable que nunca usa un booleano como único diagnóstico."""

    success: bool
    status: ImportResultStatus
    package: ImportPackage | None
    issues: tuple[ImportIssue, ...]
    statistics: ImportStatistics
    duration: timedelta
    source_file: str
    file_hash: str | None
