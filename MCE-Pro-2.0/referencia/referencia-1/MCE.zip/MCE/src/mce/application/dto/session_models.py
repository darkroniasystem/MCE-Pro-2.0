"""Modelos inmutables para espacios de trabajo y sesiones de procesamiento."""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from enum import StrEnum
from uuid import UUID

from mce.application.exceptions import InvalidSessionTransitionError
from mce.domain.value_objects import ImportId, PhysicalFileId, ScanScope, SourceId


class SessionStatus(StrEnum):
    """Estados del ciclo de vida de una sesión."""

    CREATED = "created"
    READY = "ready"
    RUNNING = "running"
    PAUSED = "paused"
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING_REVIEW = "waiting_review"
    WAITING_INTERNET = "waiting_internet"
    ARCHIVED = "archived"


class SessionItemStatus(StrEnum):
    """Estados independientes de cada elemento de una sesión."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    WARNING = "warning"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"


class ProcessingStage(StrEnum):
    """Etapas acumulativas ejecutadas por el coordinador de procesamiento."""

    IMPORTED = "imported"
    NORMALIZED = "normalized"
    CLASSIFIED = "classified"
    CLEANED = "cleaned"
    GROUPED = "grouped"
    READY_FOR_ENRICHMENT = "ready_for_enrichment"
    IDENTIFIED = "identified"
    ENRICHED = "enriched"
    REVIEWED = "reviewed"
    CONSOLIDATED = "consolidated"
    PERSISTED = "persisted"


@dataclass(frozen=True, slots=True)
class SessionItem:
    """Referencia de trabajo que conserva la identidad y ruta importadas."""

    item_id: str
    import_id: ImportId
    source_id: SourceId
    physical_file_id: PhysicalFileId
    original_path: str
    original_name: str | None = None
    bank_id: str | None = None
    installation_id: str | None = None
    size_bytes: int | None = None
    file_hash: str | None = None
    stage: ProcessingStage = ProcessingStage.IMPORTED
    status: SessionItemStatus = SessionItemStatus.PENDING
    warning: str | None = None
    error: str | None = None
    detected_category: str | None = None
    category_confidence: float | None = None
    classification_reason: str | None = None
    matched_rules: tuple[str, ...] = ()
    classification_version: str | None = None
    classified_at: datetime | None = None
    classification_status: str = "classification_pending"
    clean_title: str | None = None
    original_group_title: str | None = None
    order_prefix: str | None = None
    detected_year: int | None = None
    season_number: int | None = None
    episode_number: int | None = None
    technical_tags: tuple[str, ...] = ()
    language_hints: tuple[str, ...] = ()
    normalization_trace: tuple[str, ...] = ()
    normalization_version: str | None = None
    possible_extra: bool = False
    cleaning_reason: str | None = None
    cleaning_version: str | None = None
    cleaned_at: datetime | None = None
    cleaning_status: str = "cleaning_pending"
    parent_content_id: str | None = None
    work_group_id: str | None = None
    work_title: str | None = None
    grouping_confidence: float | None = None
    grouping_reason: str | None = None
    grouping_version: str | None = None
    grouping_status: str = "grouping_pending"
    enrichment_status: str = "pending_enrichment"
    identification_confidence: float | None = None
    metadata_confidence: float | None = None
    final_confidence: float | None = None
    final_category: str | None = None
    classification_resolution_status: str | None = None
    classification_resolution_explanation: str | None = None
    classification_conflicts: tuple[str, ...] = ()
    human_title_correction: str | None = None
    human_title_locked: bool = False
    human_decision_at: datetime | None = None
    review_reason: str | None = None
    providers_completed: tuple[str, ...] = ()
    providers_pending: tuple[str, ...] = ()
    providers_failed: tuple[str, ...] = ()
    identification_query_fingerprints: tuple[str, ...] = ()
    metadata_from_cache: bool = False
    web_search_used: bool = False
    web_search_reason: str | None = None
    web_search_decision: str | None = None
    web_search_query: str | None = None
    web_search_evidence: tuple[str, ...] = ()
    web_search_from_cache: bool = False
    ai_review_state: str | None = None
    ai_provider: str | None = None
    ai_model: str | None = None
    ai_prompt_version: str | None = None
    ai_schema_version: str | None = None
    ai_query_fingerprint: str | None = None
    ai_sources: tuple[str, ...] = ()
    ai_contradictions: tuple[str, ...] = ()
    ai_model_confidence: float | None = None
    ai_mce_score: float | None = None
    ai_from_cache: bool = False
    ai_reason: str | None = None
    next_retry_at: datetime | None = None

    def __post_init__(self) -> None:
        _require_uuid(self.item_id, "item_id")
        if not self.original_path:
            raise ValueError("original_path must not be empty")
        if self.size_bytes is not None and self.size_bytes < 0:
            raise ValueError("size_bytes must be non-negative")
        if self.file_hash is not None and (
            len(self.file_hash) != 64
            or any(character not in "0123456789abcdef" for character in self.file_hash)
        ):
            raise ValueError("file_hash must be a lowercase SHA-256 digest")
        if self.category_confidence is not None and not 0 <= self.category_confidence <= 100:
            raise ValueError("category_confidence must be between 0 and 100")
        if self.final_confidence is not None and not 0 <= self.final_confidence <= 100:
            raise ValueError("final_confidence must be between 0 and 100")
        if self.grouping_confidence is not None and not 0 <= self.grouping_confidence <= 100:
            raise ValueError("grouping_confidence must be between 0 and 100")
        if (
            self.identification_confidence is not None
            and not 0 <= self.identification_confidence <= 100
        ):
            raise ValueError("identification_confidence must be between 0 and 100")
        if self.metadata_confidence is not None and not 0 <= self.metadata_confidence <= 100:
            raise ValueError("metadata_confidence must be between 0 and 100")

    def start(self) -> SessionItem:
        """Marca el elemento como activo."""
        if self.status is not SessionItemStatus.PENDING:
            raise InvalidSessionTransitionError(f"cannot start item from {self.status.value}")
        return replace(self, status=SessionItemStatus.PROCESSING)

    def finish(self, *, warning: str | None = None) -> SessionItem:
        """Finaliza el elemento con o sin advertencia recuperable."""
        if self.status is not SessionItemStatus.PROCESSING:
            raise InvalidSessionTransitionError(f"cannot finish item from {self.status.value}")
        status = SessionItemStatus.WARNING if warning else SessionItemStatus.COMPLETED
        return replace(self, status=status, warning=warning)

    def fail(self, error: str) -> SessionItem:
        """Registra un fallo individual sin alterar otros elementos."""
        if self.status not in {SessionItemStatus.PENDING, SessionItemStatus.PROCESSING}:
            raise InvalidSessionTransitionError(f"cannot fail item from {self.status.value}")
        if not error.strip():
            raise ValueError("item error must not be empty")
        return replace(self, status=SessionItemStatus.FAILED, error=error.strip())

    def cancel(self) -> SessionItem:
        """Cancela un elemento aún no terminado."""
        if self.status not in {SessionItemStatus.PENDING, SessionItemStatus.PROCESSING}:
            return self
        return replace(self, status=SessionItemStatus.CANCELLED)

    def processed(self, stage: ProcessingStage, *, warning: str | None = None) -> SessionItem:
        """Registra el último paso alcanzado por el coordinador semántico."""
        if stage is ProcessingStage.IMPORTED:
            raise ValueError("processed stage must advance beyond imported")
        return replace(
            self,
            stage=stage,
            status=SessionItemStatus.WARNING if warning else SessionItemStatus.COMPLETED,
            warning=warning,
            error=None,
        )


@dataclass(frozen=True, slots=True)
class SessionSummary:
    """Contadores derivados y auditables por estado."""

    total: int
    pending: int
    processing: int
    completed: int
    warning: int
    failed: int
    skipped: int
    cancelled: int

    @property
    def processed(self) -> int:
        """Cantidad que ya no está pendiente ni en ejecución."""
        return self.total - self.pending - self.processing

    @property
    def percent(self) -> float:
        """Progreso porcentual, incluyendo el caso de sesión vacía."""
        return 100.0 if self.total == 0 else self.processed * 100.0 / self.total


@dataclass(frozen=True, slots=True)
class ProcessingSession:
    """Unidad reanudable asociada exactamente a una importación válida."""

    session_id: str
    workspace_id: str
    import_id: ImportId
    package_hash: str
    scan_scope: ScanScope
    items: tuple[SessionItem, ...]
    created_at: datetime
    updated_at: datetime
    status: SessionStatus = SessionStatus.CREATED
    failure_reason: str | None = None
    retry_count: int = 0
    bank_name: str | None = None

    def __post_init__(self) -> None:
        _require_uuid(self.session_id, "session_id")
        _require_uuid(self.workspace_id, "workspace_id")
        valid_digest = len(self.package_hash) == 64 and all(
            c in "0123456789abcdef" for c in self.package_hash
        )
        if not valid_digest:
            raise ValueError("package_hash must be a lowercase SHA-256 digest")
        if self.created_at.tzinfo is None or self.updated_at.tzinfo is None:
            raise ValueError("session timestamps require timezone information")
        if self.retry_count < 0:
            raise ValueError("retry_count must be non-negative")
        if self.bank_name is not None and not self.bank_name.strip():
            raise ValueError("bank_name must not be blank")
        if len({item.item_id for item in self.items}) != len(self.items):
            raise ValueError("session item identifiers must be unique")
        if any(item.import_id != self.import_id for item in self.items):
            raise ValueError("every session item must preserve the session import identifier")

    def transition(self, target: SessionStatus, *, at: datetime) -> ProcessingSession:
        """Aplica una transición legal de sesión."""
        allowed = {
            SessionStatus.CREATED: {
                SessionStatus.READY,
                SessionStatus.CANCELLED,
                SessionStatus.ARCHIVED,
            },
            SessionStatus.READY: {
                SessionStatus.RUNNING,
                SessionStatus.CANCELLED,
                SessionStatus.ARCHIVED,
            },
            SessionStatus.RUNNING: {
                SessionStatus.READY,
                SessionStatus.PAUSED,
                SessionStatus.CANCELLED,
                SessionStatus.COMPLETED,
                SessionStatus.FAILED,
                SessionStatus.WAITING_REVIEW,
                SessionStatus.WAITING_INTERNET,
            },
            SessionStatus.PAUSED: {
                SessionStatus.RUNNING,
                SessionStatus.CANCELLED,
                SessionStatus.ARCHIVED,
            },
            SessionStatus.WAITING_REVIEW: {
                SessionStatus.RUNNING,
                SessionStatus.CANCELLED,
                SessionStatus.COMPLETED,
                SessionStatus.ARCHIVED,
            },
            SessionStatus.WAITING_INTERNET: {
                SessionStatus.RUNNING,
                SessionStatus.CANCELLED,
                SessionStatus.ARCHIVED,
            },
            SessionStatus.COMPLETED: {SessionStatus.ARCHIVED},
            SessionStatus.CANCELLED: {SessionStatus.ARCHIVED},
            SessionStatus.FAILED: {SessionStatus.ARCHIVED},
            SessionStatus.ARCHIVED: set(),
        }
        if target not in allowed[self.status]:
            raise InvalidSessionTransitionError(
                f"cannot transition session from {self.status.value} to {target.value}"
            )
        if target is SessionStatus.COMPLETED and any(
            item.status in {SessionItemStatus.PENDING, SessionItemStatus.PROCESSING}
            for item in self.items
        ):
            raise InvalidSessionTransitionError("cannot complete a session with unfinished items")
        items = self.items
        if target is SessionStatus.CANCELLED:
            items = tuple(item.cancel() for item in items)
        return replace(self, status=target, items=items, updated_at=at)

    def mark_failed(self, reason: str, *, at: datetime) -> ProcessingSession:
        """Detiene la sesión por un error fatal explícito."""
        if self.status is not SessionStatus.RUNNING:
            raise InvalidSessionTransitionError("only a running session can fail")
        if not reason.strip():
            raise ValueError("failure reason must not be empty")
        return replace(
            self, status=SessionStatus.FAILED, failure_reason=reason.strip(), updated_at=at
        )

    def reactivate_after_local_preparation(self, *, at: datetime) -> ProcessingSession:
        """Reactiva una cancelación solo después de recalcular localmente sus elementos."""
        if self.status is not SessionStatus.CANCELLED:
            return self
        items = tuple(
            replace(
                item,
                status=(
                    SessionItemStatus.SKIPPED
                    if item.classification_status == "unsupported_media"
                    else SessionItemStatus.COMPLETED
                    if item.stage is ProcessingStage.CONSOLIDATED
                    else SessionItemStatus.PENDING
                ),
            )
            if item.status is SessionItemStatus.CANCELLED
            else item
            for item in self.items
        )
        return replace(
            self,
            status=SessionStatus.READY,
            items=items,
            failure_reason=None,
            updated_at=at,
        )

    def prepare_retry(self, *, at: datetime) -> ProcessingSession:
        """Devuelve una sesión fallida a ready según política explícita."""
        if self.status is not SessionStatus.FAILED:
            raise InvalidSessionTransitionError("only a failed session can be prepared for retry")
        return replace(
            self,
            status=SessionStatus.READY,
            failure_reason=None,
            retry_count=self.retry_count + 1,
            updated_at=at,
        )

    def restore_archived(self, *, at: datetime) -> ProcessingSession:
        """Restaura un archivado sin descartar los resultados ya confirmados."""
        if self.status is not SessionStatus.ARCHIVED:
            raise InvalidSessionTransitionError("only an archived session can be restored")
        terminal_items = {
            SessionItemStatus.COMPLETED,
            SessionItemStatus.WARNING,
            SessionItemStatus.FAILED,
            SessionItemStatus.SKIPPED,
        }
        target = (
            SessionStatus.COMPLETED
            if self.items and all(item.status in terminal_items for item in self.items)
            else SessionStatus.READY
        )
        return replace(self, status=target, updated_at=at)

    def replace_item(self, changed: SessionItem, *, at: datetime) -> ProcessingSession:
        """Sustituye un elemento por identidad sin mutar la sesión original."""
        if self.status is not SessionStatus.RUNNING:
            raise InvalidSessionTransitionError(
                "items can only change while the session is running"
            )
        if not any(item.item_id == changed.item_id for item in self.items):
            raise KeyError(changed.item_id)
        return replace(
            self,
            items=tuple(
                changed if item.item_id == changed.item_id else item for item in self.items
            ),
            updated_at=at,
        )

    def replace_all_items(
        self, changed: tuple[SessionItem, ...], *, at: datetime
    ) -> ProcessingSession:
        """Sustituye atómicamente el lote procesado preservando identidades."""
        if self.status is not SessionStatus.RUNNING:
            raise InvalidSessionTransitionError("items can only change while a session is running")
        if {item.item_id for item in changed} != {item.item_id for item in self.items}:
            raise ValueError("processed items must match the complete session")
        return replace(self, items=changed, updated_at=at)

    def apply_review_resolution(
        self, changed: tuple[SessionItem, ...], *, at: datetime
    ) -> ProcessingSession:
        """Aplica una decisión humana sin reabrir el procesamiento automático."""
        if self.status not in {
            SessionStatus.READY,
            SessionStatus.WAITING_REVIEW,
            SessionStatus.COMPLETED,
            SessionStatus.PAUSED,
            SessionStatus.WAITING_INTERNET,
            SessionStatus.FAILED,
        }:
            raise InvalidSessionTransitionError(
                "review resolutions require a recoverable inactive session"
            )
        if {item.item_id for item in changed} != {item.item_id for item in self.items}:
            raise ValueError("reviewed items must match the complete session")
        return replace(self, items=changed, updated_at=at)

    def apply_local_review_repreparation(
        self, changed: tuple[SessionItem, ...], *, at: datetime
    ) -> ProcessingSession:
        """Actualiza títulos de revisión sin reabrir el ciclo de la sesión."""
        if self.status is SessionStatus.RUNNING:
            raise InvalidSessionTransitionError(
                "review items cannot be locally reprepared while the session is running"
            )
        if {item.item_id for item in changed} != {item.item_id for item in self.items}:
            raise ValueError("reviewed items must match the complete session")
        return replace(self, items=changed, updated_at=at)

    @property
    def summary(self) -> SessionSummary:
        """Calcula estadísticas sin almacenar contadores redundantes."""
        counts = {status: 0 for status in SessionItemStatus}
        for item in self.items:
            counts[item.status] += 1
        return SessionSummary(len(self.items), *(counts[status] for status in SessionItemStatus))


@dataclass(frozen=True, slots=True)
class Workspace:
    """Contenedor lógico de sesiones, sin representar el catálogo."""

    workspace_id: str
    name: str
    session_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _require_uuid(self.workspace_id, "workspace_id")
        if not self.name.strip():
            raise ValueError("workspace name must not be empty")
        if len(set(self.session_ids)) != len(self.session_ids):
            raise ValueError("workspace session identifiers must be unique")
        for session_id in self.session_ids:
            _require_uuid(session_id, "session_id")

    def add_session(self, session_id: str) -> Workspace:
        """Agrega una sesión evitando referencias duplicadas."""
        if session_id in self.session_ids:
            return self
        return replace(self, session_ids=(*self.session_ids, session_id))

    def remove_session(self, session_id: str) -> Workspace:
        """Retira una referencia de sesión sin afectar el catálogo."""
        return replace(
            self,
            session_ids=tuple(value for value in self.session_ids if value != session_id),
        )


@dataclass(frozen=True, slots=True)
class SessionCheckpoint:
    """Instantánea versionada que un adaptador puede serializar."""

    format_version: int
    session: ProcessingSession


@dataclass(frozen=True, slots=True)
class JobProgress:
    """Notificación de progreso desacoplada de cualquier interfaz."""

    session_id: str
    completed: int
    total: int
    percent: float


def _require_uuid(value: str, field: str) -> None:
    try:
        UUID(value)
    except (ValueError, TypeError, AttributeError) as exc:
        raise ValueError(f"{field} must be a UUID") from exc
