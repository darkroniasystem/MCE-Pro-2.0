"""Contrato mínimo para detectar recepciones repetidas."""

from typing import Protocol


class ImportRegistry(Protocol):
    """Registro sustituible de hashes ya procesados."""

    def contains_hash(self, file_hash: str) -> bool:
        """Indica si la huella ya está registrada."""
        ...

    def add_hash(self, file_hash: str) -> None:
        """Registra una huella tras completar la importación."""
        ...
