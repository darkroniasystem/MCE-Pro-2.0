"""Puertos sustituibles para busqueda, analisis, cache y cuota."""

from __future__ import annotations

from typing import Protocol

from mce.application.ai_review.models import AIReviewInput, AIReviewResult, EvidenceSource


class SearchProvider(Protocol):
    def search(self, query: str) -> tuple[EvidenceSource, ...]: ...


class AIAnalyzer(Protocol):
    def analyze(
        self, item: AIReviewInput, sources: tuple[EvidenceSource, ...]
    ) -> AIReviewResult: ...


class AIReviewCache(Protocol):
    def get(self, fingerprint: str) -> AIReviewResult | None: ...
    def put(self, fingerprint: str, result: AIReviewResult) -> None: ...


class QuotaGuard(Protocol):
    def acquire(self, calls: int = 1) -> bool: ...
