"""Validación coherente de fechas, referencias, rutas y resumen."""

import ntpath
from datetime import UTC, datetime
from typing import Any

from mce.application.dto import (
    DetectedMediaType,
    ImportIssue,
    ImportIssueSeverity,
    ImportLimits,
)
from mce.application.importers.media_classifier import classify_media


def parse_timestamp(value: Any) -> datetime | None:
    """Convierte ISO 8601 consciente de zona a UTC; devuelve None si es inválido."""
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(UTC)


class SemanticValidator:
    """Valida coherencia en tiempo lineal usando índices de identificadores."""

    def validate(self, document: dict[str, Any], limits: ImportLimits) -> tuple[ImportIssue, ...]:
        """Devuelve incidencias semánticas sin mutar el documento."""
        issues: list[ImportIssue] = []
        sources = document.get("sources")
        files = document.get("files")
        if not isinstance(sources, list) or not isinstance(files, list):
            return ()
        declared_sources: dict[str, int] = {}
        for index, source in enumerate(sources):
            if not isinstance(source, dict):
                continue
            source_id = source.get("source_id")
            if isinstance(source_id, str) and source_id.strip():
                if source_id in declared_sources:
                    issues.append(
                        self._warning(
                            "DUPLICATE_SOURCE_ID",
                            "source_id repetido.",
                            "sources",
                            index,
                            "source_id",
                            source_id,
                        )
                    )
                else:
                    declared_sources[source_id] = index
            else:
                issues.append(
                    self._warning(
                        "SOURCE_ID_MISSING",
                        "La fuente no declara source_id; se generará uno interno.",
                        "sources",
                        index,
                        "source_id",
                    )
                )
            name = source.get("display_name")
            path = source.get("root_path")
            if not self._text(name) and not self._text(path):
                issues.append(
                    self._warning(
                        "SOURCE_IDENTITY_MISSING",
                        "La fuente no tiene nombre ni ruta.",
                        "sources",
                        index,
                    )
                )
            if self._text(path):
                self._validate_path(str(path), limits, issues, "sources", index, "root_path")

        declared_files: set[str] = set()
        valid_media_counts = {"video": 0, "subtitle": 0}
        for index, record in enumerate(files):
            if not isinstance(record, dict):
                continue
            file_id = record.get("file_id")
            if isinstance(file_id, str) and file_id.strip():
                if file_id in declared_files:
                    issues.append(
                        self._warning(
                            "DUPLICATE_FILE_ID",
                            "file_id repetido.",
                            "files",
                            index,
                            "file_id",
                            file_id,
                        )
                    )
                declared_files.add(file_id)
            else:
                issues.append(
                    self._warning(
                        "FILE_ID_MISSING",
                        "El archivo no declara file_id; se generará uno interno.",
                        "files",
                        index,
                        "file_id",
                    )
                )
            name = str(record.get("name") or "").strip()
            if len(name) > limits.max_filename_length:
                issues.append(
                    self._warning(
                        "FILENAME_TOO_LONG",
                        "El nombre supera el límite configurado.",
                        "files",
                        index,
                        "name",
                        name,
                    )
                )
            for field_name in ("relative_path", "full_path"):
                path = record.get(field_name)
                if self._text(path):
                    self._validate_path(str(path), limits, issues, "files", index, field_name)
            if str(record.get("media_type") or "").lower() == "directory":
                issues.append(
                    self._warning(
                        "DIRECTORY_RECORD",
                        "El registro representa un directorio y será omitido.",
                        "files",
                        index,
                    )
                )
            source_reference = record.get("source_id")
            if self._text(source_reference) and source_reference not in declared_sources:
                issues.append(
                    self._warning(
                        "SOURCE_REFERENCE_NOT_FOUND",
                        "El archivo referencia una fuente inexistente.",
                        "files",
                        index,
                        "source_id",
                        source_reference,
                    )
                )
            elif not self._text(source_reference):
                issues.append(
                    self._warning(
                        "SOURCE_REFERENCE_MISSING",
                        "El archivo no declara source_id.",
                        "files",
                        index,
                        "source_id",
                    )
                )
            raw_extension = record.get("extension")
            extension = self._extension(name, raw_extension)
            detected = classify_media(name, extension)
            if detected is DetectedMediaType.UNKNOWN:
                issues.append(
                    self._warning(
                        "UNKNOWN_EXTENSION",
                        "La extensión no es multimedia reconocida; el archivo será omitido.",
                        "files",
                        index,
                        "extension",
                        raw_extension,
                    )
                )
            elif detected in {DetectedMediaType.SUBTITLE, DetectedMediaType.SUBTITLE_PROBABLE}:
                valid_media_counts["subtitle"] += 1
                if detected is DetectedMediaType.SUBTITLE_PROBABLE:
                    issues.append(
                        self._warning(
                            "AMBIGUOUS_TEXT_FILE",
                            "Un archivo .txt se clasificó como subtítulo probable.",
                            "files",
                            index,
                            "extension",
                            raw_extension,
                        )
                    )
            else:
                valid_media_counts["video"] += 1
            declared_type = str(record.get("media_type") or "").lower()
            if declared_type == "video" and detected in {
                DetectedMediaType.SUBTITLE,
                DetectedMediaType.SUBTITLE_PROBABLE,
            }:
                issues.append(
                    self._warning(
                        "INVALID_MEDIA_TYPE",
                        "Un subtítulo fue declarado como video.",
                        "files",
                        index,
                        "media_type",
                        declared_type,
                    )
                )
            if declared_type == "subtitle" and detected in {
                DetectedMediaType.VIDEO,
                DetectedMediaType.DVD,
            }:
                issues.append(
                    self._warning(
                        "INVALID_MEDIA_TYPE",
                        "Un video fue declarado como subtítulo.",
                        "files",
                        index,
                        "media_type",
                        declared_type,
                    )
                )
            name_extension = ntpath.splitext(name)[1].lower()
            declared_extension = str(raw_extension or "").strip().lower()
            if declared_extension and not declared_extension.startswith("."):
                declared_extension = f".{declared_extension}"
            if declared_extension and name_extension and declared_extension != name_extension:
                issues.append(
                    self._warning(
                        "EXTENSION_MISMATCH",
                        "La extensión declarada no coincide con el nombre.",
                        "files",
                        index,
                        "extension",
                        raw_extension,
                    )
                )
            size = record.get("size")
            if size is not None and (
                isinstance(size, bool) or not isinstance(size, int) or size < 0
            ):
                issues.append(
                    self._warning(
                        "INVALID_FILE_SIZE",
                        "El tamaño del archivo no es un entero no negativo.",
                        "files",
                        index,
                        "size",
                        size,
                    )
                )
            digest = record.get("hash")
            if digest is not None and not self._valid_sha256(digest):
                issues.append(
                    self._warning(
                        "INVALID_FILE_HASH",
                        "La huella multimedia no es SHA-256 válida y será omitida.",
                        "files",
                        index,
                        "hash",
                        digest,
                    )
                )

        scan = document.get("scan")
        if isinstance(scan, dict):
            started_raw = scan.get("started_at")
            finished_raw = scan.get("finished_at")
            started = parse_timestamp(started_raw)
            finished = parse_timestamp(finished_raw)
            if started_raw is not None and started is None:
                issues.append(
                    self._error(
                        "INVALID_TIMESTAMP",
                        "started_at no es ISO 8601 con zona horaria.",
                        "scan.started_at",
                        started_raw,
                    )
                )
            if finished_raw is not None and finished is None:
                issues.append(
                    self._error(
                        "INVALID_TIMESTAMP",
                        "finished_at no es ISO 8601 con zona horaria.",
                        "scan.finished_at",
                        finished_raw,
                    )
                )
            if started is not None and finished is not None and started > finished:
                issues.append(
                    self._error(
                        "INVALID_SCAN_RANGE", "started_at es posterior a finished_at.", "scan"
                    )
                )
            scope = scan.get("scope")
            if (
                isinstance(scope, dict)
                and scope.get("type") == "partial"
                and not scope.get("source_ids")
                and not scope.get("included_paths")
                and not declared_sources
            ):
                issues.append(
                    self._warning(
                        "PARTIAL_SCOPE_UNSPECIFIED",
                        "El escaneo parcial no declara fuentes ni rutas.",
                        "scan.scope",
                    )
                )
            if (
                isinstance(scope, dict)
                and scope.get("type") == "full"
                and scope.get("included_paths")
            ):
                issues.append(
                    self._warning(
                        "FULL_SCOPE_RESTRICTED",
                        "Un alcance completo no debe restringirse a rutas.",
                        "scan.scope",
                    )
                )

        generator = document.get("generator")
        if not isinstance(generator, dict) or not self._text(generator.get("version")):
            issues.append(
                self._warning(
                    "GENERATOR_VERSION_MISSING",
                    "No se indicó la versión de MSL.",
                    "generator.version",
                )
            )
        bank = document.get("bank")
        if not isinstance(bank, dict) or not self._text(bank.get("name")):
            issues.append(self._warning("BANK_MISSING", "No se indicó el banco de copia.", "bank"))
        installation = document.get("installation")
        if not isinstance(installation, dict) or not self._text(installation.get("name")):
            issues.append(
                self._warning(
                    "INSTALLATION_MISSING", "No se indicó la instalación de MSL.", "installation"
                )
            )

        summary = document.get("summary")
        if summary is None:
            issues.append(
                self._warning("SUMMARY_MISSING", "No existe resumen del escaneo.", "summary")
            )
        elif isinstance(summary, dict):
            expected = {
                "total_files": len(files),
                "video_files": valid_media_counts["video"],
                "subtitle_files": valid_media_counts["subtitle"],
            }
            aliases = {
                "total_files": ("total_files", "total"),
                "video_files": ("video_files", "videos"),
                "subtitle_files": ("subtitle_files", "subtitles", "subtitulos"),
            }
            for canonical, names in aliases.items():
                declared = next((summary[name] for name in names if name in summary), None)
                if declared is not None and declared != expected[canonical]:
                    issues.append(
                        self._warning(
                            "SUMMARY_MISMATCH",
                            f"{canonical} no coincide con los registros.",
                            "summary",
                            field_name=canonical,
                            raw_value=declared,
                        )
                    )
        return tuple(issues)

    @staticmethod
    def _text(value: Any) -> bool:
        return isinstance(value, str) and bool(value.strip())

    @staticmethod
    def _extension(name: str, declared: Any) -> str:
        extension = str(ntpath.splitext(name)[1] or declared or "").strip().lower()
        return extension if not extension or extension.startswith(".") else f".{extension}"

    @staticmethod
    def _valid_sha256(value: Any) -> bool:
        if not isinstance(value, str):
            return False
        normalized = value.strip().lower()
        return len(normalized) == 64 and all(
            character in "0123456789abcdef" for character in normalized
        )

    @classmethod
    def _validate_path(
        cls,
        path: str,
        limits: ImportLimits,
        issues: list[ImportIssue],
        location: str,
        index: int,
        field_name: str,
    ) -> None:
        if "\x00" in path:
            issues.append(
                cls._warning(
                    "PATH_CONTAINS_NULL",
                    "La ruta contiene un carácter nulo.",
                    location,
                    index,
                    field_name,
                )
            )
        if len(path) > limits.max_path_length:
            issues.append(
                cls._warning(
                    "PATH_TOO_LONG",
                    "La ruta supera el límite configurado.",
                    location,
                    index,
                    field_name,
                )
            )

    @staticmethod
    def _warning(
        code: str,
        message: str,
        location: str,
        record_index: int | None = None,
        field_name: str | None = None,
        raw_value: Any = None,
    ) -> ImportIssue:
        return ImportIssue(
            code,
            ImportIssueSeverity.WARNING,
            message,
            location,
            record_index,
            field_name,
            raw_value,
        )

    @staticmethod
    def _error(code: str, message: str, location: str, raw_value: Any = None) -> ImportIssue:
        return ImportIssue(code, ImportIssueSeverity.ERROR, message, location, raw_value=raw_value)
