"""Mapeo de documento canónico validado a DTO y dominio Fase 1."""

import ntpath
from datetime import UTC, datetime
from typing import Any, TypeVar
from uuid import NAMESPACE_URL, uuid5

from mce.application.dto import (
    DetectedMediaType,
    ImportedFileDTO,
    ImportedScanDTO,
    ImportedSourceDTO,
    ImportIssue,
    ImportIssueSeverity,
    ImportPackage,
)
from mce.application.importers.media_classifier import classify_media
from mce.application.importers.semantic_validator import parse_timestamp
from mce.domain.entities import PhysicalFile, Scan, ScanImport, Source, Subtitle
from mce.domain.value_objects import (
    BankId,
    FileFingerprint,
    ImportId,
    ImportStatus,
    InstallationId,
    NormalizedPath,
    PhysicalFileId,
    PhysicalFileStatus,
    ScanId,
    ScanScope,
    ScanScopeType,
    ScanStatus,
    SourceId,
    SourceType,
    SubtitleId,
)
from mce.domain.value_objects.identifiers import DomainId

IdT = TypeVar("IdT", bound=DomainId)


class ImportMapper:
    """Crea objetos internos solo después de una validación aceptada."""

    def map(
        self,
        document: dict[str, Any],
        *,
        original_file_hash: str,
        original_filename: str,
        received_at: datetime,
        existing_issues: tuple[ImportIssue, ...],
        expected_bank_id: BankId | None = None,
        expected_installation_id: InstallationId | None = None,
    ) -> ImportPackage:
        """Construye un paquete completo sin mutar estado global."""
        if received_at.tzinfo is None or received_at.utcoffset() is None:
            raise ValueError("received_at must include timezone information")
        received_at = received_at.astimezone(UTC)
        issues = list(existing_issues)
        raw_scan = document.get("scan")
        raw_bank = document.get("bank")
        raw_installation = document.get("installation")
        scan_data: dict[str, Any] = raw_scan if isinstance(raw_scan, dict) else {}
        bank_data: dict[str, Any] = raw_bank if isinstance(raw_bank, dict) else {}
        installation_data: dict[str, Any] = (
            raw_installation if isinstance(raw_installation, dict) else {}
        )
        bank_id = expected_bank_id or self._stable_bank_id(bank_data.get("bank_id"), issues)
        installation_id = expected_installation_id or self._id_or_new(
            installation_data.get("installation_id"),
            InstallationId,
            "installation_id",
            issues,
        )
        scan_id = self._id_or_new(scan_data.get("scan_id"), ScanId, "scan_id", issues)
        source_dtos, domain_sources, source_index = self._map_sources(
            document, installation_id, issues
        )
        file_dtos, domain_files, domain_subtitles = self._map_files(
            document, source_index, scan_id, issues
        )
        scope = self._map_scope(scan_data.get("scope"), source_index)
        started_at = parse_timestamp(scan_data.get("started_at")) or received_at
        finished_at = parse_timestamp(scan_data.get("finished_at"))
        domain_scan = Scan(
            scan_id,
            installation_id,
            started_at,
            finished_at,
            scope,
            ScanStatus.COMPLETED,
            str((document.get("generator") or {}).get("version") or "unknown"),
            str(document.get("schema_version") or "legacy"),
        )
        domain_import = ScanImport(
            ImportId.new(),
            scan_id,
            bank_id,
            original_filename,
            original_file_hash,
            received_at,
        )
        domain_import = (
            domain_import.transition_to(ImportStatus.VALIDATING)
            .transition_to(ImportStatus.VALID)
            .transition_to(ImportStatus.PROCESSING)
            .transition_to(ImportStatus.COMPLETED)
        )
        raw_generator = document.get("generator")
        generator: dict[str, Any] = raw_generator if isinstance(raw_generator, dict) else {}
        imported_scan = ImportedScanDTO(
            self._text_or_none(scan_data.get("scan_id")),
            scan_id,
            self._text_or_none(document.get("schema_version")),
            self._text_or_none(generator.get("name")),
            self._text_or_none(generator.get("version")),
            self._text_or_none(scan_data.get("started_at")),
            self._text_or_none(scan_data.get("finished_at")),
            scope,
            tuple(bank_data.items()),
            tuple(installation_data.items()),
            tuple(source_dtos),
            tuple(file_dtos),
            tuple((document.get("summary") or {}).items())
            if isinstance(document.get("summary"), dict)
            else (),
        )
        videos = tuple(
            item
            for item in file_dtos
            if item.detected_media_type in {DetectedMediaType.VIDEO, DetectedMediaType.DVD}
        )
        subtitles = tuple(
            item
            for item in file_dtos
            if item.detected_media_type
            in {DetectedMediaType.SUBTITLE, DetectedMediaType.SUBTITLE_PROBABLE}
        )
        ignored = tuple(
            item for item in file_dtos if item.detected_media_type is DetectedMediaType.UNKNOWN
        )
        return ImportPackage(
            imported_scan,
            tuple(source_dtos),
            videos,
            subtitles,
            ignored,
            tuple(issues),
            original_file_hash,
            original_filename,
            self._text_or_none(document.get("schema_version")),
            domain_scan,
            domain_import,
            tuple(domain_sources),
            tuple(domain_files),
            tuple(domain_subtitles),
        )

    def _map_sources(
        self,
        document: dict[str, Any],
        installation_id: InstallationId,
        issues: list[ImportIssue],
    ) -> tuple[list[ImportedSourceDTO], list[Source], dict[str, SourceId]]:
        dtos: list[ImportedSourceDTO] = []
        entities: list[Source] = []
        index: dict[str, SourceId] = {}
        raw_sources = document.get("sources")
        if not isinstance(raw_sources, list):
            return dtos, entities, index
        for record_index, record in enumerate(raw_sources):
            raw_sources[record_index] = None
            if not isinstance(record, dict):
                continue
            display_name = self._text_or_none(record.get("display_name"))
            root_path = self._text_or_none(record.get("root_path"))
            if display_name is None and root_path is None:
                continue
            declared_id = self._text_or_none(record.get("source_id"))
            if declared_id is not None and declared_id in index:
                continue
            source_id = self._id_or_new(
                declared_id, SourceId, f"sources[{record_index}].source_id", issues
            )
            if declared_id is not None:
                index[declared_id] = source_id
            index[str(source_id)] = source_id
            normalized_path = NormalizedPath(root_path or display_name or "unknown")
            try:
                source_type = SourceType(str(record.get("type") or "unknown"))
            except ValueError:
                source_type = SourceType.UNKNOWN
            name = display_name or root_path or "Fuente sin nombre"
            dto = ImportedSourceDTO(
                source_id,
                declared_id,
                source_type,
                name,
                root_path or "",
                normalized_path,
            )
            dtos.append(dto)
            entities.append(Source(source_id, installation_id, source_type, name, normalized_path))
        return dtos, entities, index

    def _map_files(
        self,
        document: dict[str, Any],
        source_index: dict[str, SourceId],
        scan_id: ScanId,
        issues: list[ImportIssue],
    ) -> tuple[list[ImportedFileDTO], list[PhysicalFile], list[Subtitle]]:
        dtos: list[ImportedFileDTO] = []
        entities: list[PhysicalFile] = []
        subtitles: list[Subtitle] = []
        raw_files = document.get("files")
        if not isinstance(raw_files, list):
            return dtos, entities, subtitles
        seen_declared: set[str] = set()
        for record_index, record in enumerate(raw_files):
            raw_files[record_index] = None
            if not isinstance(record, dict):
                continue
            name = self._text_or_none(record.get("name"))
            relative = self._text_or_none(record.get("relative_path"))
            full = self._text_or_none(record.get("full_path"))
            if name is None or (relative is None and full is None):
                continue
            if str(record.get("media_type") or "").lower() == "directory":
                continue
            if "\x00" in (relative or "") or "\x00" in (full or ""):
                continue
            declared_id = self._text_or_none(record.get("file_id"))
            if declared_id is not None and declared_id in seen_declared:
                continue
            if declared_id is not None:
                seen_declared.add(declared_id)
            source_reference = self._text_or_none(record.get("source_id"))
            source_id = source_index.get(source_reference or "")
            if source_id is None:
                continue
            file_id = self._id_or_new(
                declared_id, PhysicalFileId, f"files[{record_index}].file_id", issues
            )
            raw_extension = self._text_or_none(record.get("extension"))
            extension = (ntpath.splitext(name)[1] or raw_extension or "").strip().lower()
            if extension and not extension.startswith("."):
                extension = f".{extension}"
            detected = classify_media(name, extension)
            normalized = NormalizedPath(full or relative or name)
            raw_size = record.get("size")
            size = (
                raw_size
                if isinstance(raw_size, int) and not isinstance(raw_size, bool) and raw_size >= 0
                else None
            )
            crypto_hash = self._text_or_none(record.get("hash"))
            if crypto_hash is not None and not self._valid_sha256(crypto_hash):
                crypto_hash = None
            fingerprint = FileFingerprint(source_id, normalized, size, crypto_hash)
            dto = ImportedFileDTO(
                file_id,
                declared_id,
                source_reference,
                source_id,
                name,
                full or relative or name,
                relative,
                full,
                normalized,
                extension,
                detected,
                self._text_or_none(record.get("media_type")),
                size,
                raw_extension,
                tuple(
                    (key, record.get(key))
                    for key in ("file_id", "source_id", "media_type", "extension")
                ),
            )
            dtos.append(dto)
            if detected is DetectedMediaType.UNKNOWN:
                continue
            domain_file = PhysicalFile(
                file_id,
                scan_id,
                source_id,
                name,
                relative or name,
                normalized,
                extension or ntpath.splitext(name)[1] or ".unknown",
                fingerprint,
                PhysicalFileStatus.PRESENT,
                size_bytes=size,
                cryptographic_hash=crypto_hash,
            )
            entities.append(domain_file)
            if detected in {
                DetectedMediaType.SUBTITLE,
                DetectedMediaType.SUBTITLE_PROBABLE,
            }:
                subtitles.append(
                    Subtitle(
                        SubtitleId.new(),
                        physical_file_id=file_id,
                        format=extension.lstrip(".") or None,
                    )
                )
        return dtos, entities, subtitles

    @staticmethod
    def _stable_bank_id(raw: Any, issues: list[ImportIssue]) -> BankId:
        """Mapea una identidad externa estable sin confundirla con el UUID interno."""
        if isinstance(raw, str) and raw.strip():
            external_id = raw.strip()
            try:
                return BankId(external_id)
            except ValueError:
                return BankId(str(uuid5(NAMESPACE_URL, f"mce:msl-bank:{external_id}")))
        issues.append(
            ImportIssue(
                "INTERNAL_ID_GENERATED",
                ImportIssueSeverity.INFO,
                "Se generó un identificador interno porque falta bank_id.",
                "bank_id",
            )
        )
        return BankId.new()

    @staticmethod
    def _id_or_new(
        raw: Any,
        identifier_type: type[IdT],
        location: str,
        issues: list[ImportIssue],
    ) -> IdT:
        if isinstance(raw, str) and raw.strip():
            try:
                return identifier_type(raw.strip())
            except ValueError:
                issues.append(
                    ImportIssue(
                        "INVALID_EXTERNAL_ID",
                        ImportIssueSeverity.INFO,
                        "El ID externo no es UUID; se generó un ID interno.",
                        location,
                        raw_value=raw,
                    )
                )
                stable = uuid5(
                    NAMESPACE_URL,
                    f"mce:external:{identifier_type.__name__}:{raw.strip()}",
                )
                return identifier_type(str(stable))
        else:
            issues.append(
                ImportIssue(
                    "INTERNAL_ID_GENERATED",
                    ImportIssueSeverity.INFO,
                    "Se generó un identificador interno.",
                    location,
                )
            )
        return identifier_type.new()

    @staticmethod
    def _map_scope(value: Any, source_index: dict[str, SourceId]) -> ScanScope:
        scope = value if isinstance(value, dict) else {}
        try:
            scope_type = ScanScopeType(str(scope.get("type") or "partial"))
        except ValueError:
            scope_type = ScanScopeType.PARTIAL
        raw_source_ids = scope.get("source_ids")
        mapped_sources: list[SourceId] = []
        if isinstance(raw_source_ids, list):
            mapped_sources.extend(
                source_index[raw]
                for raw in raw_source_ids
                if isinstance(raw, str) and raw in source_index
            )
        if (
            scope_type in {ScanScopeType.PARTIAL, ScanScopeType.SELECTED_SOURCES}
            and not mapped_sources
        ):
            mapped_sources.extend(dict.fromkeys(source_index.values()))
        raw_paths = scope.get("included_paths")
        paths = (
            tuple(
                NormalizedPath(path)
                for path in raw_paths
                if isinstance(raw_paths, list) and isinstance(path, str) and path.strip()
            )
            if isinstance(raw_paths, list)
            else ()
        )
        if scope_type is ScanScopeType.SELECTED_SOURCES and not mapped_sources:
            scope_type = ScanScopeType.PARTIAL
        if scope_type is ScanScopeType.SELECTED_PATHS and not paths:
            scope_type = ScanScopeType.PARTIAL
        return ScanScope(scope_type, tuple(dict.fromkeys(mapped_sources)), paths)

    @staticmethod
    def _text_or_none(value: Any) -> str | None:
        return value.strip() if isinstance(value, str) and value.strip() else None

    @staticmethod
    def _valid_sha256(value: str) -> bool:
        normalized = value.lower()
        return len(normalized) == 64 and all(
            character in "0123456789abcdef" for character in normalized
        )
