"""Detección explicable sin eliminación de archivos."""

from collections import defaultdict
from collections.abc import Hashable, Iterable
from itertools import combinations

from mce.application.deduplication.models import (
    CatalogFile,
    DuplicateCandidate,
    DuplicateEvidence,
    DuplicateType,
)


class FindDuplicateCandidates:
    def execute(self, files: tuple[CatalogFile, ...]) -> tuple[DuplicateCandidate, ...]:
        found: list[DuplicateCandidate] = []
        for left_index, right_index in self._candidate_pairs(files):
            left, right = files[left_index], files[right_index]
            evidence = []
            kind = None
            same_location = left.bank_id == right.bank_id and left.source_id == right.source_id
            if same_location and left.normalized_path == right.normalized_path:
                evidence.append(
                    DuplicateEvidence("normalized_path", 95, "misma ruta en banco y fuente")
                )
                kind = DuplicateType.PATH_DUPLICATE
            if left.file_hash and left.file_hash == right.file_hash:
                evidence.append(DuplicateEvidence("full_hash", 100, "hash completo exacto"))
                kind = (
                    DuplicateType.DUPLICATE_PHYSICAL_FILE
                    if same_location
                    else DuplicateType.HASH_DUPLICATE
                )
            if left.content_id and left.content_id == right.content_id:
                version_signals = (left.edition, left.language, left.resolution) != (
                    right.edition,
                    right.language,
                    right.resolution,
                )
                kind = (
                    DuplicateType.SAME_CONTENT_DIFFERENT_VERSION
                    if version_signals
                    else DuplicateType.SAME_CONTENT_DIFFERENT_FILE
                )
                evidence.append(DuplicateEvidence("content_id", 90, "mismo contenido identificado"))
            elif (
                left.name.casefold() == right.name.casefold()
                and left.size_bytes == right.size_bytes
            ):
                kind = kind or DuplicateType.METADATA_DUPLICATE
                evidence.append(DuplicateEvidence("name_size", 65, "nombre y tamaño coinciden"))
            elif left.name.casefold() == right.name.casefold():
                kind = kind or DuplicateType.PROBABLE_DUPLICATE
                evidence.append(
                    DuplicateEvidence("same_name", 45, "mismo nombre sin identidad suficiente")
                )
            if kind:
                confidence = min(100, sum(item.weight for item in evidence) / len(evidence))
                found.append(
                    DuplicateCandidate(
                        left.file_id, right.file_id, kind, confidence, tuple(evidence)
                    )
                )
        return tuple(found)

    @staticmethod
    def _candidate_pairs(files: tuple[CatalogFile, ...]) -> tuple[tuple[int, int], ...]:
        """Indexa las únicas señales capaces de producir un candidato.

        Evita comparar todo el catálogo contra sí mismo. Si un grupo comparte
        realmente una señal, sus pares siguen evaluándose con las reglas completas
        para conservar tipo, confianza y evidencia.
        """

        pairs: set[tuple[int, int]] = set()
        indexes: tuple[dict[Hashable, list[int]], ...] = (
            defaultdict(list),
            defaultdict(list),
            defaultdict(list),
            defaultdict(list),
        )
        for position, item in enumerate(files):
            indexes[0][(item.bank_id, item.source_id, item.normalized_path)].append(position)
            if item.file_hash:
                indexes[1][item.file_hash].append(position)
            if item.content_id:
                indexes[2][item.content_id].append(position)
            indexes[3][item.name.casefold()].append(position)
        for index in indexes:
            FindDuplicateCandidates._add_group_pairs(pairs, index.values())
        return tuple(sorted(pairs))

    @staticmethod
    def _add_group_pairs(target: set[tuple[int, int]], groups: Iterable[list[int]]) -> None:
        for positions in groups:
            if len(positions) > 1:
                target.update(combinations(positions, 2))
