"""Excepciones controladas del pipeline de importación."""


class ImportErrorBase(Exception):
    """Base para errores esperados de importación."""

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


class ImportFileNotFoundError(ImportErrorBase):
    """El archivo solicitado no existe."""


class ImportFileAccessError(ImportErrorBase):
    """El archivo no puede leerse de forma segura."""


class ImportFileTooLargeError(ImportErrorBase):
    """El archivo supera el límite configurado."""


class InvalidJsonError(ImportErrorBase):
    """El contenido no es JSON UTF-8 válido con raíz objeto."""


class UnsupportedSchemaError(ImportErrorBase):
    """La versión del esquema no es compatible."""


class ImportValidationError(ImportErrorBase):
    """La estructura o semántica impide producir un paquete."""


class ImportCancelledError(ImportErrorBase):
    """La importación fue cancelada explícitamente."""


class SessionError(ValueError):
    """Base para errores controlados de sesiones."""


class InvalidSessionTransitionError(SessionError):
    """La transición solicitada viola el ciclo de vida de la sesión."""


class InvalidSessionPackageError(SessionError):
    """El resultado de importación no puede originar una sesión."""


class DuplicateSessionError(SessionError):
    """El paquete ya está asociado a una sesión."""
