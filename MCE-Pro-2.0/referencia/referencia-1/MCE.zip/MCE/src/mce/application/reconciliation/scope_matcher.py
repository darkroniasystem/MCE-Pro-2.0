"""Cobertura pura y conservadora de un alcance MSL."""

from __future__ import annotations

from dataclasses import dataclass

from mce.domain.value_objects import NormalizedPath, ScanScopeType


@dataclass(frozen=True, slots=True)
class ScopeMatcher:
    scope_type: ScanScopeType
    source_ids: frozenset[str] = frozenset()
    included_paths: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "included_paths",
            tuple(NormalizedPath(path).normalized for path in self.included_paths),
        )

    def covers(self, source_id: str, normalized_path: str) -> bool:
        """Indica si una ausencia puede afirmarse con el alcance declarado."""
        if self.scope_type is ScanScopeType.FULL:
            return True
        if self.scope_type is ScanScopeType.PARTIAL:
            return False
        if self.scope_type is ScanScopeType.SELECTED_SOURCES:
            return source_id in self.source_ids
        path = NormalizedPath(normalized_path).normalized
        return any(
            path == included or path.startswith(included.rstrip("\\") + "\\")
            for included in self.included_paths
        )
