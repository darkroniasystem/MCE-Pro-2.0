"""Puntuación determinista con evidencia por regla."""

import unicodedata
from dataclasses import dataclass

from mce.application.identification.models import (
    IdentificationQuery,
    MatchScore,
    ProviderCandidate,
    ScoreEvidence,
)


def _key(value: str) -> str:
    return " ".join(unicodedata.normalize("NFKC", value).casefold().split())


@dataclass(frozen=True, slots=True)
class MatchPolicy:
    automatic_acceptance: float = 85
    manual_review: float = 65
    rejection: float = 35
    ambiguity_distance: float = 5


class MatchScorer:
    """Compara títulos, alias, año, tipo y metadatos auxiliares."""

    def score(self, query: IdentificationQuery, candidate: ProviderCandidate) -> MatchScore:
        evidence = []
        qtitle = _key(query.title)
        titles = [candidate.title, candidate.original_title or "", *candidate.translated_titles]
        aliases = [*candidate.aliases, *query.aliases]
        if any(_key(value) == qtitle for value in titles if value):
            evidence.append(ScoreEvidence("title_exact", 70, "título exacto"))
        elif any(_key(value) == qtitle for value in aliases if value):
            evidence.append(ScoreEvidence("alias_exact", 60, "alias exacto"))
        elif any(qtitle in _key(value) or _key(value) in qtitle for value in titles if value):
            evidence.append(ScoreEvidence("title_partial", 30, "título parcial"))
        if (
            query.original_title
            and candidate.original_title
            and _key(query.original_title) == _key(candidate.original_title)
        ):
            evidence.append(ScoreEvidence("original_title", 20, "título original exacto"))
        if query.year and candidate.year:
            evidence.append(
                ScoreEvidence(
                    "year_exact" if query.year == candidate.year else "year_conflict",
                    15 if query.year == candidate.year else -20,
                    f"{query.year}/{candidate.year}",
                )
            )
        evidence.append(
            ScoreEvidence(
                "type_compatible", 15 if query.kind is candidate.kind else -25, candidate.kind.value
            )
        )
        if query.country and candidate.country and _key(query.country) == _key(candidate.country):
            evidence.append(ScoreEvidence("country", 5, "país compatible"))
        if (
            query.director
            and candidate.director
            and _key(query.director) == _key(candidate.director)
        ):
            evidence.append(ScoreEvidence("director", 8, "director exacto"))
        if (
            query.cast
            and candidate.cast
            and {_key(v) for v in query.cast} & {_key(v) for v in candidate.cast}
        ):
            evidence.append(ScoreEvidence("cast", 5, "reparto coincidente"))
        if query.duration_minutes and candidate.duration_minutes:
            difference = abs(query.duration_minutes - candidate.duration_minutes)
            evidence.append(
                ScoreEvidence(
                    "duration", 5 if difference <= 5 else -5, f"diferencia {difference} min"
                )
            )
        return MatchScore(max(0, min(100, sum(item.points for item in evidence))), tuple(evidence))
