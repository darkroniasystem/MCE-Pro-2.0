"""Contrato para huellas del archivo original."""

from pathlib import Path
from typing import Protocol


class HashCalculator(Protocol):
    """Calcula SHA-256 sin imponer almacenamiento."""

    def calculate(self, path: Path) -> str:
        """Devuelve el SHA-256 hexadecimal del archivo solicitado."""
        ...
