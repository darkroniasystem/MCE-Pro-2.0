"""Colecciones JSON incrementales para inventarios MSL grandes."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

import ijson  # type: ignore[import-untyped]


class StreamingJsonList(list[Any]):
    """Lista compatible que vuelve a leer una matriz JSON sin materializarla."""

    def __init__(
        self,
        path: Path,
        prefix: str,
        transform: Callable[[Any], Any] | None = None,
    ) -> None:
        super().__init__()
        self.path = path
        self.prefix = prefix
        self.transform = transform or (lambda value: value)
        self._count: int | None = None

    def __iter__(self) -> Iterator[Any]:
        with self.path.open("rb") as stream:
            for value in ijson.items(stream, f"{self.prefix}.item"):
                yield self.transform(value)

    def __len__(self) -> int:
        if self._count is None:
            self._count = sum(1 for _ in self)
        return self._count

    def __setitem__(self, index: int | slice, value: Any) -> None:  # type: ignore[override]
        # Los elementos se crean al iterar y se liberan de inmediato; no hay
        # referencia almacenada que deba reemplazarse.
        return None

    def transformed(self, transform: Callable[[Any], Any]) -> StreamingJsonList:
        previous = self.transform
        return StreamingJsonList(self.path, self.prefix, lambda value: transform(previous(value)))


class CombinedStreamingList(list[Any]):
    """Vista concatenada de colecciones sin copiar sus elementos."""

    def __init__(self, *parts: list[Any]) -> None:
        super().__init__()
        self.parts = parts

    def __iter__(self) -> Iterator[Any]:
        for part in self.parts:
            yield from part
        yield from super().__iter__()

    def __len__(self) -> int:
        return sum(len(part) for part in self.parts) + super().__len__()

    def __setitem__(self, index: int | slice, value: Any) -> None:  # type: ignore[override]
        return None
