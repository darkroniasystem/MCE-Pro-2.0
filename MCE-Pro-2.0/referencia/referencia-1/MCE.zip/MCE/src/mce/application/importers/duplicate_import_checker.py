"""Política explícita para hashes ya registrados."""

from mce.application.ports import ImportRegistry


class DuplicateImportChecker:
    """Consulta el registro sin decidir persistencia futura."""

    def __init__(self, registry: ImportRegistry) -> None:
        self._registry = registry

    def is_duplicate(self, file_hash: str) -> bool:
        """Indica si el mismo archivo original ya fue completado."""
        return self._registry.contains_hash(file_hash)
