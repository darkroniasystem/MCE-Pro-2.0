"""Casos de uso reversibles del catálogo maestro."""

from collections.abc import Callable, Iterable
from dataclasses import replace
from datetime import datetime
from pathlib import PureWindowsPath

from mce.application.deduplication.models import (
    CatalogAudit,
    CatalogAvailabilityStatus,
    CatalogContent,
    CatalogVersion,
    DuplicateCandidate,
    InMemoryCatalog,
    MergeSnapshot,
)


class CatalogConsolidationService:
    def __init__(
        self,
        catalog: InMemoryCatalog,
        clock: Callable[[], datetime],
        id_generator: Callable[[], str],
    ) -> None:
        self.catalog = catalog
        self.clock = clock
        self.ids = id_generator

    def merge_content(self, target_id: str, source_ids: Iterable[str], actor: str) -> str:
        target = self.catalog.contents[target_id]
        sources = tuple(self.catalog.contents[value] for value in source_ids)
        snapshot = MergeSnapshot(self.ids(), target, sources, actor, self.clock())
        file_ids = tuple(
            dict.fromkeys(
                (*target.file_ids, *(fid for source in sources for fid in source.file_ids))
            )
        )
        self.catalog.contents[target_id] = replace(target, file_ids=file_ids)
        for source in sources:
            for fid in source.file_ids:
                self.catalog.files[fid] = replace(self.catalog.files[fid], content_id=target_id)
            del self.catalog.contents[source.content_id]
        self.catalog.merges[snapshot.merge_id] = snapshot
        self._audit("merge", actor, {"merge_id": snapshot.merge_id, "target": target_id})
        return snapshot.merge_id

    def revert_merge(self, merge_id: str, actor: str) -> None:
        snapshot = self.catalog.merges.pop(merge_id)
        self.catalog.contents[snapshot.target.content_id] = snapshot.target
        for source in snapshot.sources:
            self.catalog.contents[source.content_id] = source
            for fid in source.file_ids:
                self.catalog.files[fid] = replace(
                    self.catalog.files[fid], content_id=source.content_id
                )
        self._audit("revert_merge", actor, {"merge_id": merge_id})

    def split_content(
        self,
        content_id: str,
        file_ids: Iterable[str],
        new_content: CatalogContent,
        actor: str,
    ) -> None:
        current = self.catalog.contents[content_id]
        moved = tuple(fid for fid in file_ids if fid in current.file_ids)
        self.catalog.contents[content_id] = replace(
            current, file_ids=tuple(fid for fid in current.file_ids if fid not in moved)
        )
        self.catalog.contents[new_content.content_id] = replace(new_content, file_ids=moved)
        for fid in moved:
            self.catalog.files[fid] = replace(
                self.catalog.files[fid], content_id=new_content.content_id
            )
        self._audit("split", actor, {"source": content_id, "target": new_content.content_id})

    def attach_physical_file(self, content_id: str, file_id: str, actor: str) -> None:
        content = self.catalog.contents[content_id]
        self.catalog.contents[content_id] = replace(
            content, file_ids=tuple(dict.fromkeys((*content.file_ids, file_id)))
        )
        self.catalog.files[file_id] = replace(self.catalog.files[file_id], content_id=content_id)
        self._audit("attach_file", actor, {"file": file_id})

    def detach_physical_file(self, content_id: str, file_id: str, actor: str) -> None:
        content = self.catalog.contents[content_id]
        self.catalog.contents[content_id] = replace(
            content, file_ids=tuple(fid for fid in content.file_ids if fid != file_id)
        )
        self.catalog.files[file_id] = replace(
            self.catalog.files[file_id], content_id=None, version_id=None
        )
        self._audit("detach_file", actor, {"file": file_id})

    def create_content_version(self, version: CatalogVersion, actor: str) -> None:
        if version.content_id not in self.catalog.contents:
            raise KeyError(version.content_id)
        self.catalog.versions[version.version_id] = version
        for fid in version.file_ids:
            self.catalog.files[fid] = replace(
                self.catalog.files[fid],
                content_id=version.content_id,
                version_id=version.version_id,
            )
        self._audit("create_version", actor, {"version": version.version_id})

    def resolve_duplicate(self, candidate: DuplicateCandidate, actor: str, resolution: str) -> None:
        self._audit(
            "resolve_duplicate",
            actor,
            {
                "left": candidate.left_file_id,
                "right": candidate.right_file_id,
                "resolution": resolution,
            },
        )

    def apply_scan_availability(
        self,
        observed_file_ids: Iterable[str],
        *,
        full_scan: bool,
        scope_source_ids: Iterable[str] = (),
        actor: str = "system",
        confirm_missing: bool = False,
    ) -> None:
        observed = set(observed_file_ids)
        now = self.clock()
        for availability_id, current in tuple(self.catalog.availabilities.items()):
            in_scope = full_scan or current.source_id in scope_source_ids
            if current.file_id in observed:
                status = CatalogAvailabilityStatus.AVAILABLE
            elif in_scope and full_scan and confirm_missing:
                status = CatalogAvailabilityStatus.MISSING
            else:
                continue
            if status is not current.status:
                self.catalog.availabilities[availability_id] = replace(
                    current,
                    status=status,
                    updated_at=now,
                    history=(*current.history, (now, current.status)),
                )
        self._audit("apply_scan", actor, {"full": str(full_scan), "observed": str(len(observed))})

    def movement_candidates(self) -> tuple[tuple[str, str, str, float], ...]:
        candidates: list[tuple[str, str, str, float]] = []
        files = tuple(self.catalog.files.values())
        for index, left in enumerate(files):
            for right in files[index + 1 :]:
                if left.bank_id != right.bank_id:
                    continue
                if (
                    left.file_hash
                    and right.file_hash
                    and left.file_hash != right.file_hash
                    and left.normalized_path == right.normalized_path
                ):
                    candidates.append((left.file_id, right.file_id, "replaced", 90.0))
                elif (
                    left.file_hash
                    and left.file_hash == right.file_hash
                    and left.normalized_path != right.normalized_path
                ):
                    if left.source_id != right.source_id:
                        change = "source_changed"
                    elif (
                        PureWindowsPath(left.normalized_path).parent
                        == PureWindowsPath(right.normalized_path).parent
                    ):
                        change = "renamed"
                    else:
                        change = "moved"
                    candidates.append((left.file_id, right.file_id, change, 95.0))
        return tuple(candidates)

    def _audit(self, action: str, actor: str, details: dict[str, str]) -> None:
        self.catalog.audit.append(
            CatalogAudit(action, actor, self.clock(), tuple(sorted(details.items())))
        )
