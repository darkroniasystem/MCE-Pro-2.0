"""Política conservadora de clasificación preliminar."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import ClassVar

from mce.application.classification.models import (
    ClassificationCandidate,
    ClassificationConflict,
    ClassificationEvidence,
    ContentClassification,
    MediaKind,
)
from mce.application.classification.path_evidence import PathEvidenceEngine
from mce.application.normalization.models import FilenameAnalysis


@dataclass(frozen=True, slots=True)
class ClassificationPolicy:
    minimum_confidence: float = 60.0
    conflict_distance: float = 8.0


class MediaClassifier:
    """Combina señales del nombre y ruta sin identificar una obra."""

    KEYWORDS: ClassVar[dict[MediaKind, tuple[str, ...]]] = {
        MediaKind.ANIME: ("anime",),
        MediaKind.DORAMA: ("dorama", "kdrama", "k-drama"),
        MediaKind.NOVELA: ("novela", "telenovela"),
        MediaKind.DOCUMENTARY: ("documental", "documentary"),
        MediaKind.WESTERN_ANIMATION: ("cartoon", "animacion", "animación"),
    }

    def __init__(
        self,
        policy: ClassificationPolicy | None = None,
        path_engine: PathEvidenceEngine | None = None,
    ):
        self.policy = policy or ClassificationPolicy()
        self.path_engine = path_engine or PathEvidenceEngine()

    def classify(self, analysis: FilenameAnalysis) -> ContentClassification:
        text = analysis.normalized_text.casefold()
        candidates: list[ClassificationCandidate] = []
        if analysis.original_path:
            candidates.extend(self.path_engine.analyze(analysis.original_path).candidates)
        if "video_ts" in text or "video ts" in text:
            candidates.append(self._candidate(MediaKind.DVD_DISC, 98, "dvd_structure", "VIDEO_TS"))
        if analysis.episode:
            candidates.append(
                self._candidate(MediaKind.EPISODE, 92, "episode_pattern", str(analysis.episode))
            )
        if self._contains_word(text, "temporada") or self._contains_word(text, "season"):
            candidates.append(self._candidate(MediaKind.SEASON, 82, "folder_keyword", "season"))
        elif "\\series\\" in text or "/series/" in text:
            candidates.append(self._candidate(MediaKind.SERIES, 80, "folder_keyword", "series"))
        if self._contains_word(text, "special") or self._contains_word(text, "especial"):
            candidates.append(self._candidate(MediaKind.SPECIAL, 78, "special_keyword", "special"))
        for kind, words in self.KEYWORDS.items():
            if any(self._contains_word(text, word) for word in words):
                candidates.append(self._candidate(kind, 86, "path_keyword", kind.value))
        if analysis.year and analysis.episode is None:
            candidates.append(
                self._candidate(
                    MediaKind.MOVIE, 72, "year_without_episode", str(analysis.year.value)
                )
            )
        candidates.sort(key=lambda item: item.confidence, reverse=True)
        if not candidates or candidates[0].confidence < self.policy.minimum_confidence:
            return ContentClassification(
                MediaKind.UNKNOWN, 0.0, (), ("evidencia insuficiente",), tuple(candidates)
            )
        winner = candidates[0]
        conflict = None
        warnings = []
        if (
            len(candidates) > 1
            and winner.confidence - candidates[1].confidence <= self.policy.conflict_distance
        ):
            conflict = ClassificationConflict((winner, candidates[1]), "señales de fuerza similar")
            warnings.append("clasificación conflictiva; requiere revisión")
        return ContentClassification(
            winner.kind,
            winner.confidence,
            winner.evidence,
            tuple(warnings),
            tuple(candidates[1:]),
            conflict,
        )

    @staticmethod
    def _candidate(
        kind: MediaKind, confidence: float, signal: str, value: str
    ) -> ClassificationCandidate:
        return ClassificationCandidate(
            kind, confidence, (ClassificationEvidence(signal, value, confidence),)
        )

    @staticmethod
    def _contains_word(text: str, word: str) -> bool:
        return bool(re.search(rf"(?<![\w]){re.escape(word.casefold())}(?![\w])", text))
