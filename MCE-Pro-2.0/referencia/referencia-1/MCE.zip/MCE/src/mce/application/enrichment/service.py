"""Consolidación y revisión humana auditables."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from datetime import datetime
from typing import Any

from mce.application.enrichment.models import (
    AuditRecord,
    ConflictOption,
    ConflictResolution,
    FieldLockState,
    MetadataConflict,
    MetadataField,
    ReviewItem,
    ReviewItemStatus,
)
from mce.domain.rules.field_priority import decide_field_update
from mce.domain.value_objects import FieldSourceType, LockType


class InMemoryReviewRepository:
    def __init__(self) -> None:
        self.items: dict[str, ReviewItem] = {}

    def save(self, item: ReviewItem) -> None:
        self.items[item.review_id] = item

    def get(self, identifier: str) -> ReviewItem | None:
        return self.items.get(identifier)

    def save_many(self, items: tuple[ReviewItem, ...]) -> None:
        self.items.update({item.review_id: item for item in items})

    def pending(self) -> tuple[ReviewItem, ...]:
        return tuple(
            item for item in self.items.values() if item.status is ReviewItemStatus.PENDING
        )


class MetadataConsolidator:
    """Combina campos por prioridad y crea conflictos sin sobrescribir en silencio."""

    def merge(self, item: ReviewItem, candidates: dict[str, MetadataField]) -> ReviewItem:
        fields = dict(item.fields)
        conflicts = list(item.conflicts)
        for name, candidate in candidates.items():
            current = fields.get(name)
            if current is None:
                fields[name] = candidate
                continue
            if current.value == candidate.value:
                continue
            lock = (
                LockType.MANUAL
                if current.lock_state is FieldLockState.MANUAL_LOCKED
                else LockType.SYSTEM
                if current.lock_state is FieldLockState.SYSTEM_LOCKED
                else None
            )
            decision = decide_field_update(
                current.provenance.source_type,
                candidate.provenance.source_type,
                current_confidence=current.provenance.confidence,
                candidate_confidence=candidate.provenance.confidence,
                lock_type=lock,
            )
            if (
                current.lock_state is FieldLockState.SYSTEM_LOCKED
                and candidate.provenance.source_type is not FieldSourceType.MANUAL
            ):
                decision = replace(decision, allowed=False, reason="system_lock")
            conflicts.append(
                MetadataConflict(
                    name,
                    (
                        ConflictOption(current.value, current.provenance),
                        ConflictOption(candidate.value, candidate.provenance),
                    ),
                )
            )
            if decision.allowed:
                fields[name] = candidate
        return replace(item, fields=fields, conflicts=tuple(conflicts))


class ReviewService:
    def __init__(self, repository: InMemoryReviewRepository, clock: Callable[[], datetime]) -> None:
        self.repository = repository
        self.clock = clock

    def list_pending_reviews(self) -> tuple[ReviewItem, ...]:
        return self.repository.pending()

    def get_review_details(self, review_id: str) -> ReviewItem:
        return self._required(review_id)

    def approve_candidate(
        self, review_id: str, actor: str, reason: str | None = None
    ) -> ReviewItem:
        return self._status(review_id, ReviewItemStatus.APPROVED, actor, reason)

    def reject_candidate(self, review_id: str, actor: str, reason: str | None = None) -> ReviewItem:
        return self._status(review_id, ReviewItemStatus.REJECTED, actor, reason)

    def decide_many(
        self,
        review_ids: tuple[str, ...],
        status: ReviewItemStatus,
        actor: str,
        reason: str | None = None,
    ) -> tuple[ReviewItem, ...]:
        now = self.clock()
        changed: list[ReviewItem] = []
        for review_id in dict.fromkeys(review_ids):
            item = self._required(review_id)
            if item.status is not ReviewItemStatus.PENDING:
                raise ValueError("review is already decided")
            record = AuditRecord(status.value, actor, now, review_id, reason=reason, origin="human")
            changed.append(replace(item, status=status, audit=(*item.audit, record)))
        result = tuple(changed)
        self.repository.save_many(result)
        return result

    def correct_metadata(
        self,
        review_id: str,
        field_name: str,
        value: Any,
        provenance: Any,
        actor: str,
        reason: str | None = None,
    ) -> ReviewItem:
        item = self._required(review_id)
        current = item.fields.get(field_name)
        if current and current.value == value:
            raise ValueError("correction must change the value")
        fields = dict(item.fields)
        fields[field_name] = MetadataField(
            value, provenance, current.lock_state if current else FieldLockState.UNLOCKED
        )
        record = AuditRecord(
            "correct",
            actor,
            self.clock(),
            review_id,
            field_name,
            current.value if current else None,
            value,
            reason,
            "manual",
        )
        changed = replace(
            item,
            fields=fields,
            audit=(*item.audit, record),
            corrections=(*item.corrections, record),
        )
        self.repository.save(changed)
        return changed

    def lock_field(
        self,
        review_id: str,
        field_name: str,
        actor: str,
        manual: bool = True,
        reason: str | None = None,
    ) -> ReviewItem:
        return self._lock(
            review_id,
            field_name,
            FieldLockState.MANUAL_LOCKED if manual else FieldLockState.SYSTEM_LOCKED,
            actor,
            reason,
        )

    def unlock_field(
        self, review_id: str, field_name: str, actor: str, reason: str | None = None
    ) -> ReviewItem:
        return self._lock(review_id, field_name, FieldLockState.UNLOCKED, actor, reason)

    def revert_correction(
        self, review_id: str, field_name: str, actor: str, reason: str | None = None
    ) -> ReviewItem:
        item = self._required(review_id)
        records = [r for r in item.corrections if r.field_name == field_name]
        if not records:
            raise ValueError("no correction to revert")
        last = records[-1]
        current = item.fields[field_name]
        fields = dict(item.fields)
        fields[field_name] = replace(current, value=last.old_value)
        audit = AuditRecord(
            "revert_correction",
            actor,
            self.clock(),
            review_id,
            field_name,
            current.value,
            last.old_value,
            reason,
            "manual",
        )
        changed = replace(
            item,
            fields=fields,
            audit=(*item.audit, audit),
            corrections=tuple(r for r in item.corrections if r is not last),
        )
        self.repository.save(changed)
        return changed

    def resolve_conflict(
        self,
        review_id: str,
        field_name: str,
        value: Any,
        actor: str,
        reason: str | None = None,
    ) -> ReviewItem:
        item = self._required(review_id)
        conflicts = []
        found = False
        selected = None
        for conflict in item.conflicts:
            if conflict.field_name == field_name and conflict.resolution is None:
                if value not in [option.value for option in conflict.options]:
                    raise ValueError("resolution must select a conflict option")
                selected = next(option for option in conflict.options if option.value == value)
                conflict = replace(
                    conflict, resolution=ConflictResolution(value, actor, self.clock(), reason)
                )
                found = True
            conflicts.append(conflict)
        if not found:
            raise ValueError("unresolved conflict not found")
        fields = dict(item.fields)
        old = fields[field_name].value
        assert selected is not None
        fields[field_name] = MetadataField(
            selected.value, selected.provenance, fields[field_name].lock_state
        )
        record = AuditRecord(
            "resolve_conflict",
            actor,
            self.clock(),
            review_id,
            field_name,
            old,
            value,
            reason,
            "human",
        )
        changed = replace(
            item, fields=fields, conflicts=tuple(conflicts), audit=(*item.audit, record)
        )
        self.repository.save(changed)
        return changed

    def _lock(
        self,
        review_id: str,
        field_name: str,
        state: FieldLockState,
        actor: str,
        reason: str | None,
    ) -> ReviewItem:
        item = self._required(review_id)
        current = item.fields[field_name]
        fields = dict(item.fields)
        fields[field_name] = replace(current, lock_state=state)
        record = AuditRecord(
            "lock" if state is not FieldLockState.UNLOCKED else "unlock",
            actor,
            self.clock(),
            review_id,
            field_name,
            current.lock_state.value,
            state.value,
            reason,
            "manual",
        )
        changed = replace(item, fields=fields, audit=(*item.audit, record))
        self.repository.save(changed)
        return changed

    def _status(
        self,
        review_id: str,
        status: ReviewItemStatus,
        actor: str,
        reason: str | None,
    ) -> ReviewItem:
        item = self._required(review_id)
        if item.status is not ReviewItemStatus.PENDING:
            raise ValueError("review is already decided")
        record = AuditRecord(
            status.value, actor, self.clock(), review_id, reason=reason, origin="human"
        )
        changed = replace(item, status=status, audit=(*item.audit, record))
        self.repository.save(changed)
        return changed

    def _required(self, review_id: str) -> ReviewItem:
        item = self.repository.get(review_id)
        if item is None:
            raise KeyError(review_id)
        return item
