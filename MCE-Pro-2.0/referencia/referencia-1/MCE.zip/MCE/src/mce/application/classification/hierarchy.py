"""Agrupación provisional obra-temporada-episodio-archivo-subtítulo."""

from __future__ import annotations

import re
import unicodedata
from collections import defaultdict
from pathlib import PureWindowsPath
from typing import cast

from mce.application.classification.models import (
    EpisodeGroupingCandidate,
    HierarchyGroupingResult,
    HierarchyMediaInput,
    MediaKind,
    SeasonGroupingCandidate,
    SubtitleInput,
    SubtitleMatchStatus,
    VideoInput,
    WorkHierarchyCandidate,
)
from mce.application.classification.structure import DvdGrouper, SubtitleMatcher

SEASON_FOLDER = re.compile(r"(?i)^(?:season|temporada|temp|s)\s*[._ -]*(\d{1,3})(?:\s*[\[(].*)?$")
EPISODIC_KINDS = frozenset(
    {
        MediaKind.SERIES,
        MediaKind.ANIME,
        MediaKind.DORAMA,
        MediaKind.NOVELA,
        MediaKind.WESTERN_ANIMATION,
        MediaKind.DOCUMENTARY,
    }
)


class HierarchyGrouper:
    """Construye candidatos deterministas sin persistir relaciones definitivas."""

    def __init__(
        self,
        subtitle_matcher: SubtitleMatcher | None = None,
        dvd_grouper: DvdGrouper | None = None,
    ) -> None:
        self._subtitle_matcher = subtitle_matcher or SubtitleMatcher()
        self._dvd_grouper = dvd_grouper or DvdGrouper()

    def group(self, items: tuple[HierarchyMediaInput, ...]) -> HierarchyGroupingResult:
        identifiers = [item.identifier for item in items]
        if len(set(identifiers)) != len(identifiers):
            raise ValueError("hierarchy input identifiers must be unique")
        discs = self._dvd_grouper.group(tuple(item.path for item in items))
        disc_paths = {path for disc in discs for group in disc.groups for path in group.file_paths}
        videos = tuple(
            item for item in items if not item.is_subtitle and item.path not in disc_paths
        )
        subtitles = tuple(item for item in items if item.is_subtitle)
        work_members: dict[str, list[HierarchyMediaInput]] = defaultdict(list)
        work_data: dict[str, tuple[str, MediaKind, str]] = {}
        video_work: dict[str, str] = {}
        for video in videos:
            title = self._work_title(video)
            key = self._work_key(video.bank_id, video.kind, title)
            work_members[key].append(video)
            work_data[key] = (video.bank_id, video.kind, title)
            video_work[video.identifier] = key

        matches = []
        subtitle_by_video: dict[str, list[str]] = defaultdict(list)
        subtitle_by_episode: dict[tuple[str, int, int], list[str]] = defaultdict(list)
        unresolved = []
        for subtitle in subtitles:
            bank_videos = tuple(
                VideoInput(video.identifier, video.path, video.name)
                for video in videos
                if video.bank_id == subtitle.bank_id
            )
            match = self._subtitle_matcher.match(
                SubtitleInput(
                    subtitle.identifier,
                    subtitle.path,
                    subtitle.name,
                    subtitle.language,
                ),
                bank_videos,
            )
            matches.append(match)
            if match.video_id is not None and match.status in {
                SubtitleMatchStatus.MATCHED,
                SubtitleMatchStatus.PROBABLE,
            }:
                subtitle_by_video[match.video_id].append(subtitle.identifier)
            elif match.status is SubtitleMatchStatus.AMBIGUOUS:
                exact = tuple(
                    video
                    for video in videos
                    if video.bank_id == subtitle.bank_id
                    and PureWindowsPath(video.path).parent == PureWindowsPath(subtitle.path).parent
                    and self._stem_key(video.name) == self._stem_key(subtitle.name)
                    and video.episode_number is not None
                )
                episode_keys = {
                    (
                        video_work[video.identifier],
                        video.season_number or 0,
                        cast(int, video.episode_number),
                    )
                    for video in exact
                }
                if len(episode_keys) == 1:
                    subtitle_by_episode[next(iter(episode_keys))].append(subtitle.identifier)
                else:
                    unresolved.append(subtitle.identifier)
            else:
                unresolved.append(subtitle.identifier)

        works = []
        for key in sorted(work_members):
            members = sorted(work_members[key], key=lambda item: item.identifier)
            bank_id, kind, title = work_data[key]
            episodes: dict[tuple[int, int], list[HierarchyMediaInput]] = defaultdict(list)
            standalone = []
            for video in members:
                if video.episode_number is None:
                    standalone.append(video.identifier)
                    continue
                episodes[(video.season_number or 0, video.episode_number)].append(video)
            seasons: dict[int, list[EpisodeGroupingCandidate]] = defaultdict(list)
            for (season_number, episode_number), episode_videos in sorted(episodes.items()):
                video_ids = tuple(video.identifier for video in episode_videos)
                subtitle_ids = tuple(
                    subtitle_id
                    for video_id in video_ids
                    for subtitle_id in subtitle_by_video.get(video_id, ())
                ) + tuple(subtitle_by_episode.get((key, season_number, episode_number), ()))
                seasons[season_number].append(
                    EpisodeGroupingCandidate(
                        season_number,
                        episode_number,
                        video_ids,
                        subtitle_ids,
                    )
                )
            season_rows = tuple(
                SeasonGroupingCandidate(number, tuple(seasons[number]))
                for number in sorted(seasons)
            )
            confidence = 95.0 if episodes else 85.0
            works.append(
                WorkHierarchyCandidate(
                    key,
                    bank_id,
                    title,
                    kind,
                    season_rows,
                    tuple(standalone),
                    confidence,
                )
            )
        return HierarchyGroupingResult(
            tuple(works),
            discs,
            tuple(matches),
            tuple(sorted(unresolved)),
        )

    @staticmethod
    def _work_title(item: HierarchyMediaInput) -> str:
        path = PureWindowsPath(item.path)
        parent = path.parent
        season_match = SEASON_FOLDER.fullmatch(parent.name.strip())
        if season_match:
            parent = parent.parent
        if item.kind in EPISODIC_KINDS and parent.name.strip():
            return parent.name.strip()
        return (item.clean_title or path.stem or item.name).strip()

    @staticmethod
    def _work_key(bank_id: str, kind: MediaKind, title: str) -> str:
        normalized = unicodedata.normalize("NFKC", title).casefold()
        normalized = re.sub(r"\s+", " ", normalized).strip()
        if not bank_id.strip() or not normalized:
            raise ValueError("bank_id and work title must not be empty")
        return f"{bank_id.strip()}:{kind.value}:{normalized}"

    @staticmethod
    def _stem_key(name: str) -> str:
        stem = PureWindowsPath(name).stem.casefold()
        return re.sub(r"(?i)[._ -](?:es|spa|lat|latino|en|eng|forced|sdh)$", "", stem)
