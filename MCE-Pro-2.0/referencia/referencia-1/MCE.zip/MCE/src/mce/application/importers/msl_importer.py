"""Fachada nominal del importador MSL."""

from mce.application.importers.import_service import ImportService


class MslImporter(ImportService):
    """Nombre explícito para consumidores que importan exclusivamente MSL."""
