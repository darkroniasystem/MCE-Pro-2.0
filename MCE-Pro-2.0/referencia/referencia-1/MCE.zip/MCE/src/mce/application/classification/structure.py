"""Asociaciones preliminares de subtítulos, discos y agrupaciones."""

from __future__ import annotations

import re
from collections import defaultdict
from difflib import SequenceMatcher
from pathlib import PureWindowsPath

from mce.application.classification.models import (
    DiscCandidate,
    DiscFileGroup,
    GroupingCandidate,
    MediaKind,
    SubtitleInput,
    SubtitleMatch,
    SubtitleMatchStatus,
    VideoInput,
)

LANG_SUFFIX = re.compile(r"(?i)[._ -](es|spa|lat|latino|en|eng|forced|sdh)$")


def _base(name: str) -> str:
    stem = PureWindowsPath(name).stem.casefold()
    return LANG_SUFFIX.sub("", stem)


class SubtitleMatcher:
    """Relaciona sin aceptar silenciosamente resultados ambiguos."""

    def match(self, subtitle: SubtitleInput, videos: tuple[VideoInput, ...]) -> SubtitleMatch:
        scored = []
        subdir = str(PureWindowsPath(subtitle.path).parent).casefold()
        base = _base(subtitle.name)
        for video in videos:
            same_dir = str(PureWindowsPath(video.path).parent).casefold() == subdir
            similarity = SequenceMatcher(None, base, _base(video.name)).ratio()
            score = similarity * 75 + (20 if same_dir else 0) + (5 if subtitle.language else 0)
            scored.append((score, video, same_dir, similarity))
        scored.sort(key=lambda item: item[0], reverse=True)
        if not scored or scored[0][0] < 55:
            return SubtitleMatch(subtitle.identifier, None, SubtitleMatchStatus.UNMATCHED, 0, ())
        best = scored[0]
        if len(scored) > 1 and best[0] - scored[1][0] < 5:
            return SubtitleMatch(
                subtitle.identifier,
                None,
                SubtitleMatchStatus.AMBIGUOUS,
                best[0],
                ("candidatos cercanos",),
            )
        status = SubtitleMatchStatus.MATCHED if best[0] >= 90 else SubtitleMatchStatus.PROBABLE
        evidence = ("mismo directorio",) if best[2] else ()
        return SubtitleMatch(subtitle.identifier, best[1].identifier, status, best[0], evidence)


class DvdGrouper:
    """Agrupa IFO/VOB de VIDEO_TS como disco, no como películas separadas."""

    def group(self, paths: tuple[str, ...]) -> tuple[DiscCandidate, ...]:
        roots = defaultdict(list)
        for path in paths:
            pure = PureWindowsPath(path)
            parts = [part.casefold() for part in pure.parts]
            if "video_ts" in parts and pure.suffix.casefold() in {".ifo", ".vob", ".bup"}:
                index = parts.index("video_ts")
                root = str(PureWindowsPath(*pure.parts[: index + 1]))
                roots[root].append(path)
        return tuple(
            DiscCandidate(root, (DiscFileGroup(root, tuple(sorted(files))),), 98)
            for root, files in sorted(roots.items())
        )


class PreliminaryGrouper:
    """Crea grupos provisionales por clave; nunca relaciones definitivas."""

    def group(
        self, kind: MediaKind, key: str, member_ids: tuple[str, ...], confidence: float
    ) -> GroupingCandidate:
        if not member_ids:
            raise ValueError("a grouping candidate requires members")
        return GroupingCandidate(kind, key, tuple(dict.fromkeys(member_ids)), confidence, True)
