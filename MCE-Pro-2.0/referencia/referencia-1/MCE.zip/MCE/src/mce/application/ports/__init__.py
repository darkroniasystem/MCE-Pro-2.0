"""Puertos de entrada/salida usados por la Fase 2."""

from mce.application.ports.file_reader import FileReader
from mce.application.ports.hash_calculator import HashCalculator
from mce.application.ports.import_registry import ImportRegistry
from mce.application.ports.session_ports import (
    CheckpointStore,
    Clock,
    IdGenerator,
    ProgressReporter,
    SessionRepository,
    WorkspaceRepository,
)

__all__ = [
    "CheckpointStore",
    "Clock",
    "FileReader",
    "HashCalculator",
    "IdGenerator",
    "ImportRegistry",
    "ProgressReporter",
    "SessionRepository",
    "WorkspaceRepository",
]
