"""Núcleo de Media Cleaner & Enrichment."""

from mce.version import __version__

__all__ = ["__version__"]
