# Registro de cambios

El formato se inspira en Keep a Changelog y el proyecto sigue versionado
semántico cuando existan versiones publicables.

## [Sin publicar]

- El enriquecimiento online procesa cada obra lógica seleccionada una sola vez;
  el progreso usa un total congelado de obras únicas mientras conserva todos los
  archivos, rutas, bancos y disponibilidades asociados.
- La aprobación y el rechazo masivos de revisión se ejecutan fuera del hilo visual,
  con progreso, acciones bloqueadas y un solo refresco final de la interfaz.
- Integrado Wikidata mediante `wbsearchentities` y `wbgetentities`, con
  validación audiovisual por claims, alias multilingües, QID e IDs externos.
- Conservados los fallos temporales del proveedor principal como resultados
  parciales pendientes de reintento.
- Taxonomía local restringida a Películas, Novelas, Doramas, Series, Anime y
  Animados; episodios y documentales se agrupan bajo su obra publicable.
- Migración 0008: título preferido y procedencia completa de alias.

- Enriquecimiento selectivo incorpora una barra propia cuyo total, porcentaje,
  velocidad y ETA se calculan únicamente sobre las categorías elegidas.
- El presupuesto local de proveedores aumenta de 5.000 a 100.000 solicitudes
  por ejecución para soportar catálogos grandes. Cuando se alcance un límite,
  falle la conexión o expire una consulta, la interfaz muestra ahora el motivo
  concreto comunicado por el proveedor.
- La revisión humana muestra ahora el título original, el título inglés y el
  proveedor del mejor candidato como evidencia, incluso cuando la coincidencia
  no es suficientemente segura para adoptarla automáticamente.
- TMDb continúa como buscador principal y una ausencia real pasa a revisión sin
  detener el lote.
- El indicador de proveedores calcula ahora su total real, sin un `5/5` fijo que
  mezclaba buscadores de títulos con proveedores auxiliares.

### Flujo de preparación y enriquecimiento

- Separación real entre clasificación/limpieza offline y enriquecimiento online.
- Resultados tipados de proveedor para éxito vacío, rate limit, timeout,
  indisponibilidad, autenticación y respuesta inválida.
- `not_found_confirmed` solo después de respuestas completas sin coincidencias.
- Los fallos transitorios no generan revisión humana ni confianza artificial.
- Migración `0005` preparada, con aplicación al catálogo maestro pendiente de
  autorización posterior al dry-run.
- Agrupación offline idempotente por obra y banco antes de consultar APIs.
- Confianzas independientes de categoría, agrupación, identificación y metadatos.
- Estimación visible de obras únicas y consultas por proveedor antes de confirmar.
- Migración `0006` para agrupación, publicación controlada, reglas propuestas y
  lotes reversibles.
- Títulos originales, españoles, ingleses, locales y alternativos persistidos
  independientemente con idioma, país, tipo y procedencia.
- Búsqueda de alias insensible a mayúsculas, tildes y puntuación, con equivalencia
  básica entre números romanos y arábigos y aislamiento estricto por banco.
- La clasificación local v2 elimina la categoría genérica `music`, da prioridad a
  episodios y temporadas sobre palabras de la ruta, separa subtítulos, excluye
  formatos de audio como `unsupported_media` y reserva los posibles videoclips para
  resolución asistida por proveedor o revisión humana.
- Conciertos y karaoke solo se clasifican automáticamente cuando existe una señal
  explícita completa; una carpeta llamada Música no basta para decidir la categoría.
- Una sesión cancelada vuelve de forma segura a `ready` cuando una nueva preparación
  local termina correctamente, permitiendo iniciar el enriquecimiento sin reimportar.
- La clasificación local v3 trata episodio y temporada como estructura interna:
  heredan Anime, Series, Novelas, Doramas, Documentales o Animación según la carpeta
  más cercana, y todos los capítulos se agrupan bajo una única obra padre.
- Cursos, conciertos y karaoke dejan de ser categorías visibles automáticas; se
  integran en una categoría existente cuando la ruta aporta evidencia suficiente o
  quedan pendientes de proveedor/revisión humana.
- Aprobar o rechazar una revisión humana cierra todos los archivos de la obra
  agrupada y cambia la categoría a `completada` cuando ya no quedan pendientes,
  sin cerrar prematuramente otras categorías de la sesión.
- La aprobación humana persiste atómicamente la obra, versión, banco, instalación,
  escaneo, importación, sesión, fuentes, archivos físicos, disponibilidad, alias e
  identificadores; las aprobaciones sin candidato crean contenido manual trazable.
- Reparación controlada del primer lote Anime: tres fichas incompletas retiradas con
  evento de auditoría y 75 archivos de cinco obras devueltos a enriquecimiento.
- La agrupación v4 detecta carpetas contenedoras como `Anime Online` y `Donghuas`,
  deriva la obra desde el título base de cada archivo y separa correctamente once
  obras donde antes existían cinco grupos demasiado amplios.
- Los checkpoints se escriben en JSON compacto; el inventario real pasó de 656,6 MB
  a 496,7 MB, reduciendo el trabajo de guardado tras decisiones humanas.
- Un candidato externo rechazado, sin coincidencia suficiente o ambiguo ya no se
  adopta implícitamente al pulsar Aprobar: MCE conserva el título correcto del banco
  como contenido manual y solo vincula candidatos externos con estado `probable`.
- Corregir manualmente un título descarta el candidato externo anterior para impedir
  asociaciones accidentales como `Anime Online` con Sword Art Online.

### Fase 12

- Distribución PyInstaller `onedir` con icono y metadatos de versión.
- Directorios mutables bajo `%LOCALAPPDATA%\MCE Desktop`, independientes del CWD.
- Migración no destructiva de checkpoints y caché locales heredados.
- Logs UTF-8 rotativos con nivel configurable, correlación y redacción de secretos.
- Recuperación automática de caché SQLite corrupta conservando una copia diagnóstica.
- Rechazo de rutas simbólicas en checkpoints, caché, exportaciones y respaldos.
- Benchmark reproducible hasta un millón de elementos y documentación operativa.
- Catálogo maestro PostgreSQL `mce` separado de `mce_test`, migrado a `0004` y
  protegido por validación exacta del destino.
- Runtime, auditoría, diagnóstico y persistencia prefieren `MCE_DATABASE_URL`
  solamente cuando apunta al catálogo maestro autorizado.
- Catálogo PDF A4 con carátulas, paginación y secciones para anime, novelas,
  películas, series, temporadas, episodios y contenido sin clasificar.
- Caché de carátulas acotada que admite solo HTTPS público y bloquea destinos
  locales o privados.
- Monitor de sesiones en tiempo real con etapa actual, doble progreso, velocidad,
  tiempo transcurrido, ETA y contadores de resultados; conserva pausa y cancelación.
- Identificación agrupada por obra/carpeta y serie, reutilización entre episodios y
  versiones, subtítulos locales sin API y una sola revisión por grupo.
- Controles de Sesiones reubicados para 16:9 y limpieza visual del monitor al borrar.
- El ejecutable rechaza `mce_test` y lee de forma segura `MCE_DATABASE_URL` del
  entorno de usuario de Windows cuando el proceso aún no heredó su actualización.
- Nombre visible del banco obligatorio antes de crear la sesión, conservado en
  checkpoints, sesiones, catálogo y PostgreSQL sin reemplazar el `bank_id` de MSL.

### Limitaciones de la candidata 0.12.0

- Pendiente la verificación independiente en una PC limpia sin Python.
- Pendiente la ejecución sobre Windows 11; la compilación local se validó en Windows 10.
- La lectura incremental redujo 72,7 % la memoria: de 2.104,82 a 573,93 MiB para
  284.041 registros, con equivalencia contractual automatizada.

### Añadido

- Exportadores JSON/CSV atómicos, Unicode, sin secretos y con protección de CSV.
- Contrato `mce.bot.catalog.v1` y vista PostgreSQL `bot_catalog_v1` para el futuro bot.
- Auditoría estructurada y reversión transaccional mediante migración `0004`.
- Asistencia segura para `pg_dump`/`pg_restore`, diagnóstico y mantenimiento local.
- Botones de exportación y actualización de salud en la interfaz de escritorio.

- Orquestación por capacidades, fusión determinista y errores HTTP seguros.
- Persistencia de IDs externos, aliases, campos normalizados y procedencia.
- Migraciones `0002` y `0003`, pruebas PostgreSQL y smoke tests live separados.
- Diagnóstico de cinco proveedores sin exposición de credenciales.

### Cambiado

- El límite predeterminado de inventarios MSL aumenta de 100 MiB a 1 GiB para
  admitir escaneos reales de bancos de copia, conservando un techo configurable.
- El botón Crear sesión queda conectado a `SessionService`, ejecuta fuera del hilo
  visual y actualiza automáticamente la tabla de sesiones locales.
- Los botones y secciones incorporan ayudas emergentes y las incidencias repetidas
  se presentan agrupadas por código y cantidad.
- Las sesiones se recuperan desde checkpoints JSON locales y pueden iniciar,
  pausar, reanudar o cancelar el pipeline de las fases 5 a 9.
- Revisión y Duplicados delegan en sus casos de uso reales; las fusiones son
  reversibles y las decisiones quedan reflejadas en Historial.
- Bancos, Fuentes y Diagnóstico muestran datos seguros derivados del flujo actual.
- El detector de duplicados indexa las señales relevantes y evita el recorrido
  cuadrático de archivos no relacionados.
- La base de código de producción pasa `mypy` en modo estricto y Ruff sin errores.

### Corregido

- La aplicación real ya no usa `FakeMetadataProvider`; compone TMDb online mediante
  HTTPS, credencial de entorno, reintentos, límites y caché persistente acotada.
- La falta de credencial, conexión o cuota deja la sesión en `waiting_internet` en
  vez de enviar todos los archivos a revisión.
- Los lotes conservan progreso parcial y reutilizan consultas de identificación
  idénticas antes de reanudarse.
- Las revisiones de una segunda sesión ya no reemplazan pendientes anteriores.
- Aprobar o rechazar admite selección múltiple y completa solamente la sesión
  cuyos pendientes hayan sido resueltos.
- Los metadatos técnicos necesarios para detectar duplicados se conservan sin
  mostrarse como columnas internas en las tablas.

## [0.10.0] - 2026-07-20

### Añadido

- Interfaz PySide6 con navegación por las once áreas de MCE.
- Previsualización asíncrona de JSON MSL y solicitud de creación de sesión.
- Tablas con búsqueda, paginación, selección múltiple y detalle.
- Temas persistentes, accesibilidad básica y confirmaciones destructivas.
- Pruebas de ViewModels, presentadores, trabajadores, señales y widgets.
- Dashboard en cuadrícula, iconos locales, barra superior y estados visuales.
- Asistente de importación por pasos, resumen mediante métricas y estados vacíos.
- Panel lateral de detalles e indicadores de estado consistentes en ambos temas.

## [0.9.0] - 2026-07-20

### Añadido

- Tipos explícitos de duplicado y evidencia ponderada.
- Catálogo separado de contenidos, versiones, archivos y disponibilidades.
- Fusiones, separaciones, versiones, adjuntos y resoluciones auditables.
- Reversión de fusiones mediante instantáneas.
- Política segura para escaneos completos y parciales.
- Detección controlada de movimientos, renombrados, cambios de fuente y reemplazos.

## [0.8.0] - 2026-07-20

### Añadido

- Metadatos por campo con procedencia y estados de bloqueo.
- Conflictos con opciones, resolución humana y auditoría.
- Casos de uso para listar, aprobar, rechazar, corregir, bloquear, desbloquear y revertir.
- Protección de correcciones manuales frente a actualizaciones automáticas.
- Puerto de modelo de lenguaje y proveedor falso con esquema estricto.

## [0.7.0] - 2026-07-20

### Añadido

- Puerto de metadatos y adaptadores falso, cacheado, resiliente y TMDb inyectable.
- Puntuación explicable por título, alias, año, tipo y señales auxiliares.
- Estados identificado, probable, ambiguo, no encontrado, error y offline.
- Caché estable con TTL y modo offline, reintentos exponenciales y cancelación.
- Tratamiento visible de timeout, 429, 4xx, 5xx y respuestas inválidas.

## [0.6.0] - 2026-07-20

### Añadido

- Clasificación preliminar con evidencia, confianza, alternativas y conflictos.
- Patrones de temporadas, episodios, rangos y numeración continua.
- Asociación conservadora de subtítulos con estados explícitos.
- Agrupación de estructuras `VIDEO_TS` y candidatos provisionales de grupos.
- Política configurable que conserva `unknown` cuando falta evidencia.

## [0.5.0] - 2026-07-20

### Añadido

- Pipeline puro de tokenización, clasificación de ruido y candidatos de título.
- Señales de año, resolución, codecs, audio, fuente, idioma, región, edición,
  episodio, volumen, parte, HDR, 3D, calidad y grupo de publicación.
- Trazas explicables, confianza y candidatos alternativos ante ambigüedad.
- Corpus multilingüe con películas, series, anime, doramas, DVD y casos numéricos.

### Garantizado

- Nombre y ruta originales nunca se modifican y ningún archivo se renombra.

### Fase 4 completada

- Dependencias SQLAlchemy 2.x, Alembic y psycopg 3.
- Esquema relacional inicial, configuración por `MCE_DATABASE_URL`, repositorio
  de bancos y unidad de trabajo transaccional.
- Pruebas reales contra PostgreSQL `mce_test` para migraciones, transacciones,
  restricciones, aislamiento, duplicados, sesiones, alcances y reversión.
- Normalización UTC al reconstruir entidades desde zonas de sesión PostgreSQL.

## [0.3.0] - 2026-07-20

### Añadido

- Espacios de trabajo y sesiones inmutables con estados y transiciones explícitas.
- Elementos por cada archivo importado que conservan `ImportId`, `SourceId`,
  `PhysicalFileId`, ruta original y alcance del escaneo.
- Estadísticas derivadas, progreso desacoplado y cancelación cooperativa.
- Repositorios temporales en memoria mediante puertos de aplicación.
- Checkpoints JSON UTF-8, atómicos, versionados y validables, con restauración.
- Pruebas unitarias e integradas para ciclo de vida, errores, reintento,
  duplicados, progreso, rutas, alcance y compatibilidad de checkpoints.

### Límites

- Solo la etapa `imported` está operativa.
- PostgreSQL, SQLAlchemy y el procesamiento semántico continúan fuera de alcance.

## [0.2.0] - 2026-07-19

### Añadido

- Pipeline separado de lectura, detección de esquema, normalización, validación,
  mapeo y resultado para JSON de MSL.
- Compatibilidad explícita con esquemas 1.0 y 2.2 y formato legado opcional.
- DTO de solicitud, fuentes, archivos, escaneo, paquete, resultado, incidencias,
  límites y estadísticas.
- Lector UTF-8 seguro con límites de tamaño, registros, rutas y profundidad.
- Clasificación técnica de videos, subtítulos, `.txt` ambiguos y estructuras DVD.
- SHA-256 por bloques y registro de duplicados en memoria mediante puertos.
- Modo normal y estricto sin duplicar reglas de validación.
- Fixtures anonimizadas y pruebas unitarias, integración y arquitectura.

### Cambiado

- El contrato documental MSL incorpora diferencias verificadas del formato real
  2.2: campos en español, colecciones `fuentes`/`videos` e IDs prefijados.
- Los IDs externos no UUID se conservan en DTO y reciben UUID internos para el
  dominio, dejando una incidencia informativa.


## [0.1.0] - 2026-07-19

### Añadido

- Entidades y objetos de valor del dominio para bancos, instalaciones, fuentes,
  escaneos, archivos, subtítulos, contenidos, temporadas, episodios,
  colecciones, disponibilidad, correcciones y trabajos.
- Identificadores UUID nominales, enumeraciones de estado, confianza, título y
  año validados.
- Transiciones explícitas e inmutables de trabajos de procesamiento.
- Serialización básica a primitivas y pruebas unitarias del dominio.
- Separación explícita de `Content`, `ContentVersion`, `PhysicalFile` y
  `Availability`.
- Entidades `ScanImport`, `FieldLock` y `ReviewDecision`.
- Objetos de valor para rutas normalizadas, huellas opcionales, procedencia,
  alcance compuesto, evidencias y conflictos.
- Reglas centrales de transición, prioridad de campos y disponibilidad.
- Excepciones específicas y prueba arquitectónica de imports prohibidos.

### Cambiado

- `Confidence` pasa de escala 0–1 a `ConfidenceScore` de 0–100, conservando un
  alias temporal para imports existentes.
- `ScanScope` pasa de enumeración simple a objeto de valor con tipo, fuentes y
  rutas incluidas.
- Los estados de trabajo, importación, revisión, archivo y disponibilidad se
  alinean con el contrato ampliado de Fase 1.
- `FileId`, `Year` y `Confidence` se conservan como alias compatibles de
  `PhysicalFileId`, `ReleaseYear` y `ConfidenceScore`.


## [0.0.0] - 2026-07-19

### Añadido

- Estructura instalable mínima del paquete `mce`.
- Definición del proyecto, arquitectura y límites de las capas.
- Contrato documental de entrada para escaneos de MediaScan Local.
- Catálogo inicial de errores y estrategia de pruebas.
- Preparación arquitectónica para una futura versión servidor.
- Configuración inicial de pytest, cobertura, Ruff y mypy.
