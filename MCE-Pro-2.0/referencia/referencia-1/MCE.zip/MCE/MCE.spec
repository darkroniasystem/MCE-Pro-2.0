from pathlib import Path

project_root = Path(SPECPATH)

public_config = (
    "classification_rules.json",
    "content_aliases.json",
    "default_settings.json",
    "provider_priorities.json",
    "title_noise_patterns.json",
)

datas = [
    *[
        (str(project_root / "config" / filename), "config")
        for filename in public_config
    ],
    (str(project_root / "migrations"), "migrations"),
    (str(project_root / "alembic.ini"), "."),
    (str(project_root / "README.md"), "."),
    (str(project_root / "RELEASE_NOTES.md"), "."),
    (str(project_root / "assets" / "mce-icon.png"), "assets"),
]

analysis = Analysis(
    [str(project_root / "src" / "mce" / "presentation" / "app.py")],
    pathex=[str(project_root / "src")],
    binaries=[],
    datas=datas,
    hiddenimports=[
        "psycopg_binary",
        "sqlalchemy.dialects.postgresql.psycopg",
        "winreg",
        "groq",
        "groq.resources.chat.completions",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "pytest", "mypy", "ruff"],
    noarchive=False,
    optimize=1,
)
pyz = PYZ(analysis.pure)

exe = EXE(
    pyz,
    analysis.scripts,
    [],
    exclude_binaries=True,
    name="MCE",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(project_root / "assets" / "mce.ico"),
    version=str(project_root / "packaging" / "version_info.txt"),
)

collection = COLLECT(
    exe,
    analysis.binaries,
    analysis.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="MCE",
)
