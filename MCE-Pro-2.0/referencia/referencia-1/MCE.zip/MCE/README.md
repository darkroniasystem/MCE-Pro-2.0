# MCE Desktop

> Proveedores online: TMDb continúa como fuente principal para cine/TV; AniList
> para anime; TVMaze para series; Fanart.tv para arte; Wikidata funciona sin
> credenciales como complemento de títulos, alias e identificadores y como
> respaldo controlado. Un timeout o rate limit nunca significa “no encontrado”.

Media Cleaner & Enrichment (MCE) convertirá los JSON producidos por MediaScan
Local (MSL) en un catálogo multimedia estructurado, revisable y exportable.

El proyecto implementa la **Fase 12: estabilización, seguridad y distribución**.
La capa visual delega en casos de uso, conserva la capacidad de respuesta mediante
trabajadores asíncronos y recupera sesiones mediante checkpoints locales.

## Alcance de la versión 1.0

MCE será una aplicación local para Windows 10 y 11. Importará JSON de MSL,
conservará el original, permitirá revisar resultados y, en fases posteriores,
sincronizará el catálogo aprobado con PostgreSQL y producirá exportaciones.

MCE nunca escaneará discos, moverá archivos multimedia ni los eliminará.

## Requisitos de desarrollo

- Windows 10 u 11.
- Python 3.12 o 3.13.
- PowerShell.

## Preparación del entorno

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest
```

Si solo está instalado Python 3.13, reemplace `py -3.12` por `py -3.13`.

Para iniciar la interfaz:

```powershell
mce-desktop
```

Para habilitar la identificación online de producción, configure la credencial
fuera del repositorio y reinicie la aplicación:

```powershell
[Environment]::SetEnvironmentVariable('TMDB_API_KEY', 'SU_CLAVE', 'User')
```

MCE no muestra ni guarda esa clave. Sin ella, una sesión queda en
`waiting_internet`; el proveedor falso se reserva exclusivamente para pruebas.
Consulte `.env.example` para los límites, idioma, región y TTL disponibles.

## Documentación

- [Definición del proyecto](PROJECT.md)
- [Arquitectura](docs/architecture.md)
- [Modelo de dominio](docs/domain_model.md)
- [Contrato de entrada de MSL](docs/msl_contract.md)
- [Formato de importación MSL](docs/msl_import_format.md)
- [Pipeline de importación](docs/import_pipeline.md)
- [Espacios de trabajo y sesiones](docs/workspace_sessions.md)
- [Normalización de nombres](docs/filename_normalization.md)
- [Clasificación multimedia](docs/media_classification.md)
- [Identificación de contenido](docs/content_identification.md)
- [Enriquecimiento y revisión](docs/enrichment_review.md)
- [Consolidación del catálogo](docs/catalog_consolidation.md)
- [Interfaz de escritorio](docs/desktop_interface.md)
- [Operaciones de la Fase 11](docs/phase11_operations.md)
- [Manual de usuario](docs/user_manual.md)
- [Instalación y distribución](docs/installation.md)
- [Solución de problemas](docs/troubleshooting.md)
- [Backup y restauración](docs/backup_restore.md)
- [Rendimiento de la Fase 12](docs/performance.md)
- [Códigos de error](docs/error_codes.md)
- [Estrategia de pruebas](docs/testing_strategy.md)
- [Flujo separado de preparación y enriquecimiento](docs/preparation_enrichment_flow.md)
- [Títulos alternativos y búsqueda](docs/title_aliases.md)
- [Preparación para servidor futuro](docs/future_server.md)

## Estado

La versión candidata `0.12.0` incorpora rutas de datos de usuario, logs rotativos
con redacción, recuperación de caché, endurecimiento de rutas y distribución
PyInstaller `onedir`. La calificación comercial queda pendiente de probar el
artefacto en una PC limpia sin Python y comprobar Windows 11. La importación
incremental del inventario real queda por debajo de 1 GiB sin eliminar datos.
Consulte [CHANGELOG.md](CHANGELOG.md) para los cambios documentados.

Para construir la distribución desde PowerShell:

```powershell
.\build_release.ps1
```

El resultado se genera en `dist\MCE\`; no debe copiarse solo el ejecutable.

## Proveedores reales de la Fase 10

MCE integra TMDb (`TMDB_API_KEY`), Fanart.tv (`FANART_API_KEY`), AniList
GraphQL, TVMaze REST y Wikidata. Las claves activas se leen
desde el entorno, se recortan con `strip()` y nunca se muestran ni persisten.

```powershell
# Suite normal sin Internet
.\.venv\Scripts\python.exe -m pytest
# PostgreSQL real de pruebas, exclusivamente mce_test
.\.venv\Scripts\python.exe -m pytest tests\integration\postgresql
# Smoke tests reales y limitados
.\.venv\Scripts\python.exe -m pytest -m live_providers tests\live
```

El catálogo maestro usa la base `mce` mediante `MCE_DATABASE_URL`. Las pruebas
continúan usando exclusivamente `mce_test` mediante `MCE_TEST_DATABASE_URL`; la
suite nunca limpia, trunca ni escribe datos ficticios en `mce`.

## Flujo de trabajo

Una sesión nueva pasa primero por **Preparar local**: clasificación y limpieza
deterministas, sin Internet ni proveedores. Solo después se habilita
**Enriquecer online**. Los límites, timeouts y proveedores temporalmente no
disponibles quedan en espera y nunca crean por sí solos una revisión humana.
El total y el porcentaje de esa etapa se calculan sobre las obras lógicas
seleccionadas, no sobre cada archivo físico. Todos los episodios agrupados
conservan sus rutas y disponibilidad, pero la obra se consulta una sola vez.
