# MCE Desktop 0.12.0

Versión candidata de la Fase 12 en distribución PyInstaller `onedir`.

Incluye importación MSL 2.2, sesiones recuperables, normalización, clasificación,
proveedores online, revisión, consolidación, PostgreSQL, exportaciones,
auditoría, reversión, backup, diagnóstico y mantenimiento. La cadena de
evidencia incorpora Exa, Serper, Tavily y Browser como último recurso, análisis
local opcional con Ollama/Qwen y fallback validado de Groq.

Los datos mutables se almacenan en `%LOCALAPPDATA%\MCE Desktop`; el directorio
de instalación permanece de solo lectura. La aplicación no ejecuta ni modifica
archivos indicados por MSL.

La distribución candidata fue reconstruida y arrancada directamente en un
entorno aislado. Las pruebas locales y PostgreSQL sobre `mce_test` aprobaron; el
catálogo maestro y las siete sesiones no fueron modificados. La declaración
comercial requiere todavía verificación independiente de la carpeta distribuida
en una PC limpia sin Python y una comprobación específica en Windows 11.

Chrome/Chromium, Ollama, `qwen2.5:3b` y las claves API son componentes externos y
no se incluyen en el paquete. Evidencia y huella de la compilación actual:
`docs/PHASE_R_RELEASE_REPORT.md`.
# Validación final de la Fase 19

- Suite completa: 400 pruebas superadas y 5 integraciones opcionales omitidas.
- Migraciones verificadas desde una base vacía y desde la revisión 0016.
- Distribución final auditada sin secretos ni dependencia de `samples`.
- Importación externa validada desde la interfaz después de eliminar `samples`.
- Arranque seguro protegido frente a la carga ansiosa de checkpoints mayores de 8 MiB.
- Fase 19 cerrada para el alcance de producción de una única computadora.
- Evidencia detallada en `docs/phase19_final_validation_2026-08-02.md`.
