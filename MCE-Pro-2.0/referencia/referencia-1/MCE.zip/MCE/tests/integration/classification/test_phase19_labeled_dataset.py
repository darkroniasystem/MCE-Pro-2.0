"""Métricas reproducibles del clasificador sobre las siete categorías físicas."""

import json
from dataclasses import replace
from pathlib import Path

from mce.application.dto import ImportRequest, Workspace
from mce.application.importers import ImportService
from mce.application.processing import LocalPreparationService
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)


def base_session():
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    ids = UuidGenerator()
    workspaces = InMemoryWorkspaceRepository()
    workspace = Workspace(ids.new_id(), "Fase 19")
    workspaces.save(workspace)
    return SessionService(
        workspaces,
        InMemorySessionRepository(),
        InMemoryCheckpointStore(),
        SystemClock(),
        ids,
    ).create(workspace.workspace_id, imported)


def test_labeled_paths_measure_accuracy_false_positives_and_pending() -> None:
    dataset_path = Path(__file__).parents[2] / "fixtures" / "classification" / (
        "phase19_labeled_paths.json"
    )
    dataset = json.loads(dataset_path.read_text(encoding="utf-8"))
    cases = dataset["cases"]
    assert {case["commercial_category"] for case in cases} == {
        "animado",
        "combos",
        "concursos",
        "doramas",
        "novelas",
        "peliculas",
        "serie",
    }
    service = LocalPreparationService()
    base = base_session()
    original = base.items[0]
    actual: list[str] = []
    for case in cases:
        path = str(case["path"])
        item = replace(
            original,
            original_path=path,
            original_name=Path(path.replace("\\", "/")).name,
        )
        classified, _ = service.classify(replace(base, items=(item,)))
        actual.append(classified.items[0].detected_category or "unclassified")
    correct = sum(value == case["expected"] for value, case in zip(actual, cases, strict=True))
    false_positives = sum(
        case["expected"] == "unclassified" and value != "unclassified"
        for value, case in zip(actual, cases, strict=True)
    )
    pending = sum(value == "unclassified" for value in actual)
    assert correct / len(cases) >= 0.95
    assert false_positives == 0
    assert pending == 1
