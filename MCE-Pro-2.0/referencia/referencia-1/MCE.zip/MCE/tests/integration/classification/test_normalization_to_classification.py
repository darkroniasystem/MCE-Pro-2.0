"""Integración Fase 4 a Fase 5 sin crear relaciones definitivas."""

from mce.application.classification import MediaClassifier
from mce.application.classification.models import MediaKind
from mce.application.normalization import FilenameNormalizationPipeline


def test_normalized_episode_flows_to_explainable_classification():
    analysis = FilenameNormalizationPipeline().analyze("The.Boys.S03E05.1080p.mkv")
    result = MediaClassifier().classify(analysis)
    assert result.kind is MediaKind.EPISODE
    assert result.evidence[0].signal == "episode_pattern"
    assert analysis.original_name == "The.Boys.S03E05.1080p.mkv"
    assert not hasattr(result, "content_id")
