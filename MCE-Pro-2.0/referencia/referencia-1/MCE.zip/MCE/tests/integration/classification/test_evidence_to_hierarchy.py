"""Integración local de Fases 4, 5 y 6 sin persistencia editorial."""

from mce.application.classification import HierarchyGrouper, MediaClassifier
from mce.application.classification.models import HierarchyMediaInput, MediaKind
from mce.application.normalization import FilenameNormalizationPipeline


def test_normalized_and_classified_episode_builds_provisional_hierarchy():
    name = "Show.S02E03.1080p.mkv"
    path = rf"D:\Series\Show\Temporada 2\{name}"
    analysis = FilenameNormalizationPipeline().analyze(name, original_path=path)
    classification = MediaClassifier().classify(analysis)
    assert classification.kind is MediaKind.EPISODE
    item = HierarchyMediaInput(
        identifier="video-1",
        bank_id="bank-a",
        path=path,
        name=name,
        kind=MediaKind.SERIES,
        clean_title=analysis.candidates[0].value,
        season_number=analysis.episode.season,
        episode_number=analysis.episode.episode_start,
    )
    work = HierarchyGrouper().group((item,)).works[0]
    assert work.title == "Show" and work.provisional
    episode = work.seasons[0].episodes[0]
    assert (episode.season_number, episode.episode_number) == (2, 3)
    assert episode.video_ids == ("video-1",)
