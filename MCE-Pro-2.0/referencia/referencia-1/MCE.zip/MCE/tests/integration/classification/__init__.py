"""Pruebas integradas de clasificación."""
