"""Pruebas integradas de sesiones y checkpoints."""
