"""Conversión de una importación real en sesión reanudable."""

import json
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

import pytest

from mce.application.dto import (
    ImportRequest,
    ProcessingStage,
    SessionItemStatus,
    SessionStatus,
    Workspace,
)
from mce.application.importers import ImportService
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
)
from mce.infrastructure.checkpoints import (
    IncompatibleCheckpointError,
    InvalidCheckpointError,
    JsonCheckpointStore,
)

FIXTURES = Path(__file__).parents[2] / "fixtures" / "msl"
NOW = datetime(2026, 7, 20, 12, tzinfo=UTC)


class FixedClock:
    def now(self) -> datetime:
        return NOW


class Uuids:
    def new_id(self) -> str:
        return str(uuid4())


class Reporter:
    def __init__(self) -> None:
        self.values = []

    def report(self, progress) -> None:
        self.values.append(progress)


def build_service(tmp_path: Path):
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    workspace = Workspace(str(uuid4()), "Banco de prueba")
    workspaces.save(workspace)
    reporter = Reporter()
    service = SessionService(
        workspaces, sessions, JsonCheckpointStore(tmp_path), FixedClock(), Uuids(), reporter
    )
    return service, workspaces, sessions, workspace, reporter


def imported_result(filename: str = "valid_complete_v1.json"):
    return ImportService(clock=lambda: NOW).import_file(ImportRequest(FIXTURES / filename))


def test_import_package_creates_items_and_preserves_identity_scope_and_paths(
    tmp_path: Path,
) -> None:
    service, workspaces, _sessions, workspace, reporter = build_service(tmp_path)
    result = imported_result()
    session = service.create(workspace.workspace_id, result)
    assert session.status is SessionStatus.READY
    assert len(session.items) == len(result.package.domain_files)
    assert session.import_id == result.package.domain_import.import_id
    assert session.scan_scope == result.package.domain_scan.scope
    assert [item.original_path for item in session.items] == [
        item.normalized_path.original for item in result.package.domain_files
    ]
    assert {item.source_id for item in session.items} == {
        item.source_id for item in result.package.domain_files
    }
    assert workspaces.get(workspace.workspace_id).session_ids == (session.session_id,)
    assert reporter.values[-1].total == len(session.items)
    assert not hasattr(session, "contents")


def test_same_package_cannot_create_an_accidental_second_session(tmp_path: Path) -> None:
    service, *_rest, workspace, _reporter = build_service(tmp_path)
    result = imported_result()
    service.create(workspace.workspace_id, result)
    with pytest.raises(ValueError, match="already has a session"):
        service.create(workspace.workspace_id, result)


def test_deleted_session_is_archived_and_checkpoint_is_preserved(tmp_path: Path) -> None:
    service, workspaces, sessions, workspace, _reporter = build_service(tmp_path)
    result = imported_result("valid_minimal_v1.json")
    created = service.create(workspace.workspace_id, result)
    checkpoint = service.checkpoint(created.session_id)

    service.delete(created.session_id)

    assert sessions.get(created.session_id).status is SessionStatus.ARCHIVED
    assert created.session_id not in workspaces.get(workspace.workspace_id).session_ids
    assert checkpoint.exists()
    with pytest.raises(ValueError, match="already has a session"):
        service.create(workspace.workspace_id, result)
    restored = service.restore_archived(created.session_id)
    assert restored.status is SessionStatus.READY
    assert created.session_id in workspaces.get(workspace.workspace_id).session_ids


def test_running_session_cannot_be_deleted(tmp_path: Path) -> None:
    service, _workspaces, sessions, workspace, _reporter = build_service(tmp_path)
    created = service.create(workspace.workspace_id, imported_result("valid_minimal_v1.json"))
    service.checkpoint(created.session_id)
    service.transition(created.session_id, SessionStatus.RUNNING)

    with pytest.raises(ValueError, match="running session"):
        service.delete(created.session_id)

    assert sessions.get(created.session_id) is not None


def test_checkpoint_roundtrip_restores_partial_scan_scope(tmp_path: Path) -> None:
    service, _workspaces, _sessions, workspace, _reporter = build_service(tmp_path)
    session = service.create(workspace.workspace_id, imported_result("valid_minimal_v1.json"))
    service.checkpoint(session.session_id)
    restored = service.restore(session.session_id)
    assert restored == session
    assert restored.scan_scope == session.scan_scope


def test_checkpoint_checksum_rejects_valid_json_tampering(tmp_path: Path) -> None:
    service, _workspaces, _sessions, workspace, _reporter = build_service(tmp_path)
    session = service.create(workspace.workspace_id, imported_result("valid_minimal_v1.json"))
    path = service.checkpoint(session.session_id)
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["session"]["status"] = "completed"
    path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(InvalidCheckpointError, match="checksum"):
        JsonCheckpointStore(tmp_path).load(session.session_id)


def test_invalid_and_incompatible_checkpoints_are_rejected(tmp_path: Path) -> None:
    store = JsonCheckpointStore(tmp_path)
    identifier = str(uuid4())
    path = tmp_path / f"{identifier}.json"
    path.write_text("{bad", encoding="utf-8")
    with pytest.raises(InvalidCheckpointError):
        store.load(identifier)
    path.write_text(json.dumps({"format_version": 999, "session": {}}), encoding="utf-8")
    with pytest.raises(IncompatibleCheckpointError):
        store.load(identifier)


def test_cancel_and_fatal_failure_are_persisted(tmp_path: Path) -> None:
    service, _workspaces, sessions, workspace, _reporter = build_service(tmp_path)
    session = service.create(workspace.workspace_id, imported_result())
    running = service.transition(session.session_id, SessionStatus.RUNNING)
    failed = service.fail(running.session_id, "error fatal")
    assert sessions.get(failed.session_id).status is SessionStatus.FAILED
    retry = service.retry(failed.session_id)
    assert retry.status is SessionStatus.READY
    running = service.transition(retry.session_id, SessionStatus.RUNNING)
    cancelled = service.transition(running.session_id, SessionStatus.CANCELLED)
    assert all(item.status.value == "cancelled" for item in cancelled.items)


def test_human_title_retry_reopens_only_the_reviewed_group(tmp_path: Path) -> None:
    service, _workspaces, sessions, workspace, _reporter = build_service(tmp_path)
    created = service.create(workspace.workspace_id, imported_result("valid_minimal_v1.json"))
    original = created.items[0]
    reviewed = replace(
        original,
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        clean_title="0052 - CUENTOS DE TERRAMAR - MANGA GHIBLI",
        work_title="0052 - CUENTOS DE TERRAMAR - MANGA GHIBLI",
        warning="requiere revision humana",
        enrichment_status="needs_human_review",
        providers_completed=("anilist",),
        review_reason="not_found_confirmed",
    )
    sessions.save(replace(created, items=(reviewed,), status=SessionStatus.WAITING_REVIEW))

    retried = service.requeue_review_items(
        created.session_id,
        (reviewed.item_id,),
        corrected_title="Cuentos de Terramar",
    )

    item = retried.items[0]
    assert item.original_name == original.original_name
    assert item.original_path == original.original_path
    assert item.clean_title == item.work_title == "Cuentos de Terramar"
    assert item.stage is ProcessingStage.READY_FOR_ENRICHMENT
    assert item.status is SessionItemStatus.PENDING
    assert item.enrichment_status == "pending_enrichment"
    assert item.review_reason == "pending_normalization_retry"
    assert item.providers_completed == ()
    assert item.human_title_locked
