"""Pruebas de persistencia."""
