"""Pruebas aisladas del mapeo y transacciones SQLAlchemy."""

from datetime import UTC, datetime

import pytest
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from mce.domain.entities import Bank
from mce.domain.value_objects import BankId
from mce.infrastructure.database.models import Base
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork


def factory():
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)  # Permitido exclusivamente en prueba aislada.
    return sessionmaker(engine, expire_on_commit=False)


def test_bank_roundtrip_and_pagination() -> None:
    made = factory()
    bank = Bank(BankId.new(), "Banco Ñ", datetime.now(UTC), code="B1")
    with SqlAlchemyUnitOfWork(made) as uow:
        uow.banks.add(bank)
        uow.commit()
    with SqlAlchemyUnitOfWork(made) as uow:
        assert uow.banks.get(bank.bank_id) == bank
        assert uow.banks.list_page(limit=1) == (bank,)


def test_rollback_leaves_no_partial_bank() -> None:
    made = factory()
    bank = Bank(BankId.new(), "Temporal", datetime.now(UTC))
    with pytest.raises(RuntimeError), SqlAlchemyUnitOfWork(made) as uow:
        uow.banks.add(bank)
        raise RuntimeError("boom")
    with SqlAlchemyUnitOfWork(made) as uow:
        assert uow.banks.get(bank.bank_id) is None


def test_unique_bank_code_constraint() -> None:
    made = factory()
    now = datetime.now(UTC)
    with pytest.raises(IntegrityError), SqlAlchemyUnitOfWork(made) as uow:
        uow.banks.add(Bank(BankId.new(), "A", now, code="same"))
        uow.banks.add(Bank(BankId.new(), "B", now, code="same"))
        uow.commit()
