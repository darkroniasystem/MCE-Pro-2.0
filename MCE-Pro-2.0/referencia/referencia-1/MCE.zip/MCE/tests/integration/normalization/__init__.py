"""Pruebas integradas de normalización."""
