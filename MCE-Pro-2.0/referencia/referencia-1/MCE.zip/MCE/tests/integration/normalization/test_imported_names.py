"""El pipeline consume DTO importados sin alterar el paquete."""

from pathlib import Path

from mce.application.dto import ImportRequest
from mce.application.importers import ImportService
from mce.application.normalization import FilenameNormalizationPipeline

FIXTURE = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_complete_v1.json"


def test_imported_files_generate_derived_analysis_only():
    result = ImportService().import_file(ImportRequest(FIXTURE))
    package = result.package
    originals = tuple((item.original_name, item.original_path) for item in package.video_files)
    analyses = tuple(
        FilenameNormalizationPipeline().analyze(
            item.original_name, original_path=item.original_path
        )
        for item in package.video_files
    )
    assert all(item.candidates for item in analyses)
    assert originals == tuple(
        (item.original_name, item.original_path) for item in package.video_files
    )
    assert not hasattr(package, "normalized_titles")
