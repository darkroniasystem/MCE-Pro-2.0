"""Flujo controlado desde nombre hasta candidato externo."""

from tests.fakes import FakeMetadataProvider

from mce.application.classification import MediaClassifier
from mce.application.identification import IdentificationService
from mce.application.identification.models import (
    IdentificationQuery,
    IdentificationStatus,
    ProviderCandidate,
    SearchKind,
)
from mce.application.normalization import FilenameNormalizationPipeline


def test_name_classification_and_fake_provider_form_explainable_pipeline():
    analysis = FilenameNormalizationPipeline().analyze("Avatar.2009.1080p.mkv")
    classification = MediaClassifier().classify(analysis)
    query = IdentificationQuery(analysis.candidates[0].value, SearchKind.MOVIE, analysis.year.value)
    provider = FakeMetadataProvider(
        (ProviderCandidate("fake", "10", SearchKind.MOVIE, "Avatar", year=2009),)
    )
    result = IdentificationService(provider).identify(query)
    assert classification.kind.value == "movie"
    assert result.status is IdentificationStatus.PROBABLE and result.selected
    assert result.selected.metadata.external_id == "10"
    assert analysis.original_name == "Avatar.2009.1080p.mkv"
