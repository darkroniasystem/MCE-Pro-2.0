"""Pruebas integradas de identificación."""
