"""Fixtures seguras para PostgreSQL real."""

from __future__ import annotations

import os

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from mce.infrastructure.database.models import Base


@pytest.fixture(scope="session")
def pg_engine():
    raw = os.environ.get("MCE_TEST_DATABASE_URL")
    if not raw:
        pytest.fail("MCE_TEST_DATABASE_URL is required")
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce_test":
        pytest.fail("PostgreSQL tests are restricted to the exact mce_test database")
    engine = create_engine(raw, pool_pre_ping=True)
    with engine.connect() as connection:
        assert connection.execute(text("select current_database()")).scalar_one() == "mce_test"
    yield engine
    engine.dispose()


@pytest.fixture()
def pg_factory(pg_engine):
    names = ", ".join(f'"{table.name}"' for table in reversed(Base.metadata.sorted_tables))
    with pg_engine.begin() as connection:
        connection.execute(text(f"TRUNCATE TABLE {names} RESTART IDENTITY CASCADE"))
    yield sessionmaker(pg_engine, expire_on_commit=False)
    with pg_engine.begin() as connection:
        connection.execute(text(f"TRUNCATE TABLE {names} RESTART IDENTITY CASCADE"))
