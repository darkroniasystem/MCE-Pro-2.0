"""Criterios finales de persistencia ejecutados sobre PostgreSQL real."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from sqlalchemy import inspect, select
from sqlalchemy.exc import IntegrityError

from mce.domain.entities import Bank
from mce.domain.value_objects import BankId
from mce.infrastructure.database.models import (
    BankModel,
    InstallationModel,
    PhysicalFileModel,
    ProcessingSessionModel,
    ScanImportModel,
    ScanModel,
    SourceModel,
)
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork

NOW = datetime(2026, 7, 20, tzinfo=UTC)


def uid():
    return str(uuid4())


def bank(code):
    return Bank(BankId.new(), f"Banco {code}", NOW, code=code)


def seed_scan(session, bank_id, scope="full", digest=None):
    installation = InstallationModel(
        id=uid(), bank_id=bank_id, name="PC", status="active", created_at=NOW
    )
    session.add(installation)
    session.flush()
    scan = ScanModel(
        id=uid(),
        installation_id=installation.id,
        started_at=NOW,
        scope_type=scope,
        scope_data={"type": scope},
        status="completed",
        msl_version="2.2",
        schema_version="2.2",
    )
    session.add(scan)
    session.flush()
    imported = ScanImportModel(
        id=uid(),
        scan_id=scan.id,
        bank_id=bank_id,
        original_filename="scan.json",
        file_hash=digest or uuid4().hex * 2,
        received_at=NOW,
        status="completed",
        is_duplicate=False,
        errors=[],
    )
    session.add(imported)
    session.flush()
    return scan, imported


def test_real_connection_schema_indexes_and_foreign_keys(pg_engine) -> None:
    inspector = inspect(pg_engine)
    assert {"banks", "scan_imports", "processing_sessions", "physical_files"} <= set(
        inspector.get_table_names()
    )
    assert inspector.get_foreign_keys("scan_imports")
    assert any(
        index["name"] == "ix_scan_imports_file_hash"
        for index in inspector.get_indexes("scan_imports")
    )


def test_bank_commit_roundtrip_and_pagination(pg_factory) -> None:
    values = [bank("C"), bank("A"), bank("B")]
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        for value in values:
            uow.banks.add(value)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert uow.banks.get(values[0].bank_id) == values[0]
        assert [item.code for item in uow.banks.list_page(offset=1, limit=1)] == ["B"]


def test_external_bank_identity_is_stable_and_unique(pg_factory) -> None:
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        first = uow.banks.resolve_external(
            "bank_dccd7b23723d1533", name="Banco MSL", created_at=NOW
        )
        second = uow.banks.resolve_external(
            "bank_dccd7b23723d1533", name="Otro nombre", created_at=NOW
        )
        uow.commit()
    assert first == second
    with pg_factory() as session:
        assert session.scalar(
            select(BankModel).where(BankModel.external_bank_id == "bank_dccd7b23723d1533")
        ).id == str(first)


def test_rollback_and_failed_transaction_leave_no_partial_data(pg_factory) -> None:
    value = bank("ROLL")
    with pytest.raises(RuntimeError), SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(value)
        raise RuntimeError("stop")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert uow.banks.get(value.bank_id) is None


def test_unique_constraints_and_real_foreign_keys(pg_factory) -> None:
    with pytest.raises(IntegrityError), SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(bank("SAME"))
        uow.banks.add(bank("SAME"))
        uow.commit()
    with pytest.raises(IntegrityError), pg_factory.begin() as session:
        session.add(
            InstallationModel(
                id=uid(), bank_id=uid(), name="orphan", status="active", created_at=NOW
            )
        )


def test_bank_isolation_and_duplicate_import_hash(pg_factory) -> None:
    first, second = bank("ONE"), bank("TWO")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(first)
        uow.banks.add(second)
        uow.commit()
    digest = "a" * 64
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        _, imported = seed_scan(uow.session, str(first.bank_id), digest=digest)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert uow.scan_imports.get_for_bank(imported.id, str(first.bank_id)) is not None
        assert uow.scan_imports.get_for_bank(imported.id, str(second.bank_id)) is None
        assert uow.scan_imports.find_by_hash(digest).id == imported.id
    with pytest.raises(IntegrityError), SqlAlchemyUnitOfWork(pg_factory) as uow:
        seed_scan(uow.session, str(second.bank_id), digest=digest)
        uow.commit()


def test_full_and_partial_sessions_preserve_out_of_scope_rows(pg_factory) -> None:
    owner = bank("SCOPE")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(owner)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        full, first = seed_scan(uow.session, str(owner.bank_id), "full")
        source = SourceModel(
            id=uid(),
            installation_id=full.installation_id,
            source_type="local_volume",
            display_name="Disco E",
            root_path="E:/",
            normalized_root_path="e:/",
            status="active",
        )
        uow.session.add(source)
        uow.session.flush()
        outside = PhysicalFileModel(
            id=uid(),
            bank_id=str(owner.bank_id),
            scan_id=full.id,
            source_id=source.id,
            original_name="outside.mkv",
            relative_path="outside.mkv",
            original_path=r"E:\outside.mkv",
            normalized_path=r"e:\outside.mkv",
            extension=".mkv",
            size_bytes=10,
            fingerprint_key="outside-fingerprint",
            status="present",
        )
        uow.session.add(outside)
        partial, second = seed_scan(uow.session, str(owner.bank_id), "partial")
        uow.session.add_all(
            [
                ProcessingSessionModel(
                    id=uid(),
                    workspace_id=uid(),
                    import_id=first.id,
                    package_hash=first.file_hash,
                    scope_data={"type": "full"},
                    status="completed",
                    retry_count=0,
                    created_at=NOW,
                    updated_at=NOW,
                    version=1,
                ),
                ProcessingSessionModel(
                    id=uid(),
                    workspace_id=uid(),
                    import_id=second.id,
                    package_hash=second.file_hash,
                    scope_data={"type": "partial"},
                    status="completed",
                    retry_count=0,
                    created_at=NOW,
                    updated_at=NOW,
                    version=1,
                ),
            ]
        )
        uow.commit()
    with pg_factory() as session:
        assert (
            session.scalar(select(ScanModel).where(ScanModel.id == full.id)).status == "completed"
        )
        assert (
            session.scalar(select(ScanModel).where(ScanModel.id == partial.id)).scope_type
            == "partial"
        )
        assert (
            session.scalar(select(ScanImportModel).where(ScanImportModel.id == first.id)).status
            == "completed"
        )
        assert session.get(PhysicalFileModel, outside.id).status == "present"


def test_controlled_import_reversion(pg_factory) -> None:
    owner = bank("REV")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(owner)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        _, item = seed_scan(uow.session, str(owner.bank_id))
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert uow.scan_imports.revert(item.id, str(owner.bank_id), at=NOW)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        restored = uow.scan_imports.get_for_bank(item.id, str(owner.bank_id))
        assert restored.status == "reverted" and restored.reverted_at is not None
