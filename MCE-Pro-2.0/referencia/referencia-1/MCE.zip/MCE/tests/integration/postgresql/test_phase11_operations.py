"""Auditoría, reversión y contrato del bot sobre PostgreSQL real."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest
from sqlalchemy import func, select, text
from tests.integration.postgresql.test_phase4_postgresql import bank

from mce.application.operations import AuditEvent, AuditService
from mce.infrastructure.database.models import AuditEventModel, BankModel
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork
from mce.infrastructure.operations.reversal import TransactionalReversalService


def event(object_id: str, correlation_id: str) -> AuditEvent:
    return AuditEvent(
        str(uuid4()),
        datetime.now(UTC),
        "operator",
        "bank.rename",
        "bank",
        object_id,
        {"name": "Antes"},
        {"name": "Después"},
        correlation_id,
        True,
    )


def test_audit_is_persisted_paginated_and_reverted_transactionally(pg_factory) -> None:
    owner = bank("AUDIT1")
    correlation_id = str(uuid4())
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(owner)
        AuditService(uow.audit_events).record(event(str(owner.bank_id), correlation_id))
        uow.commit()
        event_id = uow.audit_events.list_page(limit=1)[0].event_id

    def restore_name(session, original) -> None:
        row = session.get(BankModel, original.object_id)
        assert row is not None
        row.name = original.previous_value["name"]

    reversal_id = TransactionalReversalService(pg_factory).revert(
        event_id, actor="operator", handler=restore_name
    )
    with pg_factory() as session:
        original = session.get(AuditEventModel, event_id)
        reversal = session.get(AuditEventModel, reversal_id)
        assert original is not None and original.reversed_by == reversal_id
        assert reversal is not None and reversal.correlation_id == correlation_id
        assert session.get(BankModel, str(owner.bank_id)).name == "Antes"
        assert session.scalar(select(func.count()).select_from(AuditEventModel)) == 2


def test_failed_reversal_leaves_no_partial_audit(pg_factory) -> None:
    owner = bank("AUDIT2")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(owner)
        recorded = event(str(owner.bank_id), str(uuid4()))
        AuditService(uow.audit_events).record(recorded)
        uow.commit()

    def fail(_session, _original) -> None:
        raise RuntimeError("controlled failure")

    with pytest.raises(RuntimeError, match="controlled"):
        TransactionalReversalService(pg_factory).revert(
            recorded.event_id, actor="operator", handler=fail
        )
    with pg_factory() as session:
        original = session.get(AuditEventModel, recorded.event_id)
        assert original is not None and original.reversed_by is None
        assert session.scalar(select(func.count()).select_from(AuditEventModel)) == 1


def test_bot_catalog_view_has_stable_contract(pg_factory) -> None:
    with pg_factory() as session:
        columns = session.execute(
            text(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_schema=current_schema() AND table_name='bot_catalog_v1'"
            )
        ).scalars()
        names = set(columns)
    assert {
        "content_id",
        "title",
        "original_title",
        "content_type",
        "year",
        "bank_id",
        "aliases",
        "metadata",
        "contract_version",
    } <= names
