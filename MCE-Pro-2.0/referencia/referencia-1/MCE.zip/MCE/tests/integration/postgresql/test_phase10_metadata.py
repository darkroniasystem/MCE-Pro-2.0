"""Persistencia real de metadatos de Fase 10 en PostgreSQL mce_test."""

from pathlib import Path

from sqlalchemy import func, select
from tests.integration.postgresql.test_phase4_postgresql import bank

from mce.application.dto import ImportRequest, Workspace
from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.application.importers import ImportService
from mce.application.processing import LocalPreparationService
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)
from mce.infrastructure.database.metadata_persistence import MetadataPersistenceService
from mce.infrastructure.database.models import (
    AvailabilityModel,
    ContentAliasModel,
    ContentModel,
    ContentVersionModel,
    ExternalIdentifierModel,
    NormalizedMetadataModel,
    PhysicalFileModel,
    ProcessingSessionModel,
    ScanImportModel,
    ScanModel,
    SourceModel,
)
from mce.infrastructure.database.unit_of_work import SqlAlchemyUnitOfWork


def candidate() -> ProviderCandidate:
    return ProviderCandidate(
        "tmdb",
        "550",
        SearchKind.MOVIE,
        "El club de la lucha",
        "Fight Club",
        aliases=("Misión Imposible IV", "Fight-Club"),
        spanish_title="El club de la lucha",
        english_title="Fight Club",
        year=1999,
        overview="Sinopsis",
        genres=("Drama",),
        external_ids=(("tmdb_movie", "550"), ("imdb", "tt0137523")),
        images=(("poster", "https://image.tmdb.org/example.jpg"),),
        source_url="https://www.themoviedb.org/movie/550",
    )


def test_metadata_is_idempotent_traced_and_isolated_by_bank(pg_factory) -> None:
    first, second = bank("META1"), bank("META2")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(first)
        uow.banks.add(second)
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        one = uow.metadata_catalog.save_candidate(
            candidate(), bank_id=str(first.bank_id), alias="Fight Club 1999", confidence=96
        )
        uow.commit()
        one_id = one.id
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        repeated = uow.metadata_catalog.save_candidate(
            candidate(), bank_id=str(first.bank_id), alias="Fight Club 1999", confidence=97
        )
        other = uow.metadata_catalog.save_candidate(
            candidate(), bank_id=str(second.bank_id), alias="Fight Club 1999", confidence=96
        )
        uow.commit()
        other_id = other.id
        assert repeated.id == one_id and other_id != one_id
    with pg_factory() as session:
        assert session.scalar(select(func.count()).select_from(ContentModel)) == 2
        assert session.scalar(select(func.count()).select_from(ExternalIdentifierModel)) == 6
        assert session.scalar(select(func.count()).select_from(ContentAliasModel)) == 8
        assert session.scalar(select(func.count()).select_from(NormalizedMetadataModel)) >= 6
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert (
            uow.metadata_catalog.get_by_external_id("tmdb", "550", bank_id=str(first.bank_id)).id
            == one_id
        )
        assert (
            uow.metadata_catalog.get_by_external_id("tmdb", "550", bank_id=str(second.bank_id)).id
            == other_id
        )
        assert {
            row.id
            for row in uow.metadata_catalog.search_by_title(
                "EL.CLUB-DE-LA-LUCHA", bank_id=str(first.bank_id)
            )
        } == {one_id}
        assert {
            row.id
            for row in uow.metadata_catalog.search_by_title(
                "mision imposible 4", bank_id=str(first.bank_id)
            )
        } == {one_id}
        assert {
            row.id
            for row in uow.metadata_catalog.search_by_title(
                "Misión-Imposible-IV", bank_id=str(second.bank_id)
            )
        } == {other_id}
        uow.metadata_catalog.add_manual_alias(
            one_id, "El club", bank_id=str(first.bank_id), language="es"
        )
        uow.metadata_catalog.add_manual_alias(one_id, "FC Global", bank_id=None, language="en")
        uow.commit()
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        assert {
            row.id
            for row in uow.metadata_catalog.search_by_title("el-club", bank_id=str(first.bank_id))
        } == {one_id}
        assert uow.metadata_catalog.search_by_title("el-club", bank_id=str(second.bank_id)) == ()
        assert {
            row.id
            for row in uow.metadata_catalog.search_by_title("fc.global", bank_id=str(first.bank_id))
        } == {one_id}


def test_metadata_transaction_rolls_back_without_partial_rows(pg_factory) -> None:
    owner = bank("METAROLL")
    with SqlAlchemyUnitOfWork(pg_factory) as uow:
        uow.banks.add(owner)
        uow.commit()
    try:
        with SqlAlchemyUnitOfWork(pg_factory) as uow:
            uow.metadata_catalog.save_candidate(
                candidate(), bank_id=str(owner.bank_id), alias="rollback", confidence=90
            )
            raise RuntimeError("controlled failure")
    except RuntimeError:
        pass
    with pg_factory() as session:
        assert session.scalar(select(func.count()).select_from(ContentModel)) == 0


def test_approved_group_persists_complete_catalog_graph(pg_factory) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    ids = UuidGenerator()
    workspaces = InMemoryWorkspaceRepository()
    workspace = Workspace(ids.new_id(), "Persistencia completa")
    workspaces.save(workspace)
    processing = SessionService(
        workspaces,
        InMemorySessionRepository(),
        InMemoryCheckpointStore(),
        SystemClock(),
        ids,
    ).create(workspace.workspace_id, imported)
    local = LocalPreparationService()
    classified, _ = local.classify(processing)
    cleaned, _ = local.clean(classified)
    grouped, _ = local.group(cleaned)
    service = MetadataPersistenceService(pg_factory)

    content_id = service.save_approved_group(
        candidate(),
        grouped,
        grouped.items,
        alias=grouped.items[0].work_title or "Fight Club",
        confidence=96,
    )

    with pg_factory() as session:
        content = session.get(ContentModel, content_id)
        physical = session.get(PhysicalFileModel, str(grouped.items[0].physical_file_id))
        assert content is not None
        assert content.publication_status == "publication_ready"
        assert content.catalog_stage == "approved"
        assert content.work_group_id == grouped.items[0].work_group_id
        assert physical is not None
        assert physical.content_id == content_id
        assert physical.content_version_id is not None
        assert physical.enrichment_status == "enrichment_complete"
        assert session.scalar(select(func.count()).select_from(ContentVersionModel)) == 1
        assert session.scalar(select(func.count()).select_from(AvailabilityModel)) == 1
        assert session.scalar(select(func.count()).select_from(SourceModel)) == 1
        assert session.scalar(select(func.count()).select_from(ScanModel)) == 1
        assert session.scalar(select(func.count()).select_from(ScanImportModel)) == 1
        assert session.scalar(select(func.count()).select_from(ProcessingSessionModel)) == 1
