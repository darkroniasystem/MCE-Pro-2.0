"""Pruebas contra PostgreSQL real y exclusivamente mce_test."""
