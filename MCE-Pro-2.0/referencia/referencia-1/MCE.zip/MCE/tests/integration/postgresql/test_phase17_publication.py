"""Publicación completa, atómica, versionada y reversible."""

from uuid import uuid4

import pytest
from sqlalchemy import func, select
from tests.integration.postgresql.test_phase15_multibank import seed_bank_inventory

from mce.infrastructure.database.models import (
    CatalogPublicationEntryModel,
    CatalogPublicationModel,
    ContentModel,
)
from mce.infrastructure.database.publication import CatalogPublicationService


def approved(title: str) -> ContentModel:
    return ContentModel(
        id=str(uuid4()),
        content_type="movie",
        main_title=title,
        status="active",
        identification_status="identified",
        review_status="approved",
        catalog_stage="approved",
        publication_status="publication_ready",
        version=1,
    )


def seed_valid(session, title: str, drive: str) -> tuple[ContentModel, str]:
    row = approved(title)
    bank_id = str(uuid4())
    session.add(row)
    seed_bank_inventory(session, bank_id, row.id, drive)
    session.commit()
    return row, bank_id


def test_new_version_is_complete_and_previous_version_is_superseded(pg_factory) -> None:
    with pg_factory() as session:
        first, first_bank = seed_valid(session, "Primera", "E")
    service = CatalogPublicationService(pg_factory)
    version_one = service.publish()
    assert version_one.status == "active"
    assert version_one.catalog_version == 1
    assert version_one.entry_count == 1

    with pg_factory() as session:
        second, second_bank = seed_valid(session, "Segunda", "F")
    version_two = service.publish()

    assert version_two.status == "active"
    assert version_two.catalog_version == 2
    assert version_two.entry_count == 2
    assert {row["work_id"] for row in service.active_catalog()} == {first.id, second.id}
    assert {row["bank_id"] for row in service.active_catalog(bank_id=first_bank)} == {
        first_bank
    }
    assert {row["bank_id"] for row in service.active_catalog(bank_id=second_bank)} == {
        second_bank
    }
    with pg_factory() as session:
        statuses = dict(
            session.execute(
                select(
                    CatalogPublicationModel.catalog_version,
                    CatalogPublicationModel.status,
                )
            ).tuples().all()
        )
        assert statuses == {1: "superseded", 2: "active"}
        assert session.scalar(
            select(func.count()).select_from(CatalogPublicationEntryModel)
        ) == 3


def test_failure_during_activation_leaves_previous_version_untouched(pg_factory) -> None:
    with pg_factory() as session:
        first, _ = seed_valid(session, "Estable", "G")
    stable = CatalogPublicationService(pg_factory).publish()
    with pg_factory() as session:
        second, _ = seed_valid(session, "Nueva", "H")

    def fail() -> None:
        raise RuntimeError("fallo controlado antes de activar")

    with pytest.raises(RuntimeError, match="fallo controlado"):
        CatalogPublicationService(pg_factory, before_activate=fail).publish()

    service = CatalogPublicationService(pg_factory)
    assert {row["work_id"] for row in service.active_catalog()} == {first.id}
    with pg_factory() as session:
        assert session.scalar(
            select(func.count()).select_from(CatalogPublicationModel)
        ) == 1
        assert session.get(CatalogPublicationModel, stable.publication_id).status == "active"
        assert session.get(ContentModel, second.id).catalog_stage == "approved"


def test_validation_failure_is_audited_without_replacing_active(pg_factory) -> None:
    with pg_factory() as session:
        first, _ = seed_valid(session, "Válida", "I")
    service = CatalogPublicationService(pg_factory)
    active = service.publish()
    with pg_factory() as session:
        invalid = approved("Sin disponibilidad")
        session.add(invalid)
        session.commit()

    failed = service.publish()

    assert failed.status == "failed"
    assert failed.validation_report["valid"] is False
    assert {error["code"] for error in failed.validation_report["errors"]} == {
        "MISSING_AVAILABILITY"
    }
    assert {row["work_id"] for row in service.active_catalog()} == {first.id}
    with pg_factory() as session:
        assert session.get(CatalogPublicationModel, active.publication_id).status == "active"
        assert session.get(CatalogPublicationModel, failed.publication_id).status == "failed"


def test_invalid_approved_content_can_be_quarantined_and_restored(pg_factory) -> None:
    with pg_factory() as session:
        valid, _ = seed_valid(session, "Válida", "L")
        invalid = approved("Sin ruta")
        session.add(invalid)
        session.commit()
    service = CatalogPublicationService(pg_factory)
    failed = service.publish()

    assert service.quarantine_invalid(failed.publication_id, actor="test") == 1
    with pg_factory() as session:
        assert session.get(ContentModel, invalid.id).catalog_stage == "staging"
        assert session.get(ContentModel, valid.id).catalog_stage == "approved"

    assert service.restore_quarantined(failed.publication_id, actor="test") == 1
    with pg_factory() as session:
        restored = session.get(ContentModel, invalid.id)
        assert restored.catalog_stage == "approved"
        assert restored.publication_status == "publication_ready"


def test_rollback_reactivates_complete_previous_snapshot(pg_factory) -> None:
    with pg_factory() as session:
        first, _ = seed_valid(session, "Primera", "J")
    service = CatalogPublicationService(pg_factory)
    service.publish()
    with pg_factory() as session:
        second, _ = seed_valid(session, "Segunda", "K")
    service.publish()

    restored = service.rollback_to(1)

    assert restored.catalog_version == 1
    assert {row["work_id"] for row in service.active_catalog()} == {first.id}
    with pg_factory() as session:
        assert session.get(ContentModel, first.id).catalog_stage == "published"
        assert session.get(ContentModel, second.id).catalog_stage == "approved"
