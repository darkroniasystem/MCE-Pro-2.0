"""Persistencia y recuperación del ledger de sesiones sobre PostgreSQL real."""

import json
from dataclasses import replace
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy import func, select

from mce.application.dto import ImportRequest, ProcessingStage, SessionStatus, Workspace
from mce.application.exceptions import DuplicateSessionError
from mce.application.importers import ImportService
from mce.application.processing import LocalPreparationService
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)
from mce.infrastructure.database.models import (
    AvailabilityEventModel,
    BankModel,
    CatalogFileIdentityModel,
    ImportStagingDocumentModel,
    OriginalJsonModel,
    PhysicalFileModel,
    ProcessingCheckpointModel,
    ProcessingJobModel,
    ProcessingSessionModel,
    ScanImportModel,
    ScanModel,
)
from mce.infrastructure.database.session_ledger import (
    PostgresImportRegistry,
    PostgresSessionRepository,
)
from mce.infrastructure.imports import OriginalJsonArchive

FIXTURE = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_schema_v22.json"


def _service(pg_factory, originals: Path | None = None):
    workspaces = InMemoryWorkspaceRepository()
    workspace = Workspace(str(uuid4()), "Ledger test")
    workspaces.save(workspace)
    repository = PostgresSessionRepository(
        pg_factory,
        OriginalJsonArchive(originals) if originals is not None else None,
    )
    service = SessionService(
        workspaces,
        repository,
        InMemoryCheckpointStore(),
        SystemClock(),
        UuidGenerator(),
    )
    return workspace, repository, service


def test_session_job_and_restart_are_postgresql_authoritative(pg_factory) -> None:
    result = ImportService().import_file(ImportRequest(FIXTURE))
    workspace, repository, service = _service(pg_factory)
    session = service.create(workspace.workspace_id, result)
    job_id = repository.seed(session, result)
    service.transition(session.session_id, SessionStatus.RUNNING)

    restarted = PostgresSessionRepository(pg_factory)
    assert restarted.recover_interrupted() == 1
    restored = restarted.get(session.session_id)
    assert restored is not None
    assert restored.status is SessionStatus.PAUSED
    assert len(restored.items) == len(session.items)
    with pg_factory() as database:
        stored = database.get(ProcessingSessionModel, session.session_id)
        job = database.get(ProcessingJobModel, job_id)
        assert stored is not None and stored.recoverable
        assert job is not None and job.status == "interrupted"
        assert database.scalar(select(func.count()).select_from(ProcessingCheckpointModel)) == 1


def test_refreshing_summaries_does_not_interrupt_a_live_job(pg_factory) -> None:
    result = ImportService().import_file(ImportRequest(FIXTURE))
    workspace, repository, service = _service(pg_factory)
    session = service.create(workspace.workspace_id, result)
    job_id = repository.seed(session, result)
    running = service.transition(session.session_id, SessionStatus.RUNNING)

    summaries = repository.list_summaries()

    assert summaries
    assert repository.get(running.session_id).status is SessionStatus.RUNNING
    with pg_factory() as database:
        job = database.get(ProcessingJobModel, job_id)
        assert job is not None and job.status == SessionStatus.RUNNING.value


def test_enrichment_job_counts_unique_works_and_cache_hits(pg_factory) -> None:
    result = ImportService().import_file(ImportRequest(FIXTURE))
    workspace, repository, service = _service(pg_factory)
    created = service.create(workspace.workspace_id, result)
    job_id = repository.seed(created, result)
    local = LocalPreparationService()
    classified, _ = local.classify(created)
    cleaned, _ = local.clean(classified)
    grouped, _ = local.group(cleaned)
    repository.save(grouped)
    service.configure_enrichment_job(created.session_id, None)
    finished_items = tuple(
        replace(
            item,
            stage=ProcessingStage.REVIEWED,
            metadata_from_cache=True,
            providers_completed=("tmdb", "wikidata"),
        )
        if item.stage is ProcessingStage.READY_FOR_ENRICHMENT
        else item
        for item in grouped.items
    )
    repository.save(replace(grouped, items=finished_items))

    with pg_factory() as database:
        job = database.get(ProcessingJobModel, job_id)
        assert job is not None
        assert job.job_type == "enrichment"
        assert job.total == job.processed == job.succeeded == 1
        assert job.cache_hits == 1


def test_corrupt_postgresql_checkpoint_fails_closed_on_restart(pg_factory) -> None:
    result = ImportService().import_file(ImportRequest(FIXTURE))
    workspace, repository, service = _service(pg_factory)
    session = service.create(workspace.workspace_id, result)
    job_id = repository.seed(session, result)
    service.transition(session.session_id, SessionStatus.RUNNING)
    with pg_factory.begin() as database:
        job = database.get(ProcessingJobModel, job_id)
        assert job is not None and job.current_checkpoint is not None
        checkpoint = database.get(ProcessingCheckpointModel, job.current_checkpoint)
        assert checkpoint is not None
        checkpoint.checksum = "0" * 64

    restarted = PostgresSessionRepository(pg_factory)
    assert restarted.recover_interrupted() == 0
    with pg_factory() as database:
        stored = database.get(ProcessingSessionModel, session.session_id)
        job = database.get(ProcessingJobModel, job_id)
        assert stored is not None and stored.status == "failed" and not stored.recoverable
        assert job is not None and job.status == "checkpoint_invalid"


def test_duplicate_is_detected_from_postgresql_after_restart(pg_factory) -> None:
    result = ImportService().import_file(ImportRequest(FIXTURE))
    registry = PostgresImportRegistry(pg_factory)
    assert result.file_hash is not None
    assert not registry.contains_hash(result.file_hash)
    registry.add_hash(result.file_hash)
    assert not registry.contains_hash(result.file_hash)
    workspace, repository, service = _service(pg_factory)
    first = service.create(workspace.workspace_id, result)
    repository.seed(first, result)
    assert registry.contains_hash(result.file_hash)

    second_workspaces = InMemoryWorkspaceRepository()
    second_workspaces.save(workspace)
    restarted = PostgresSessionRepository(pg_factory)
    restarted_service = SessionService(
        second_workspaces,
        restarted,
        InMemoryCheckpointStore(),
        SystemClock(),
        UuidGenerator(),
    )
    with pytest.raises(DuplicateSessionError):
        restarted_service.create(workspace.workspace_id, result)
    with pg_factory() as database:
        assert database.scalar(select(func.count()).select_from(BankModel)) == 1


def test_seed_archives_original_and_creates_staging_manifest(pg_factory, tmp_path: Path) -> None:
    source = tmp_path / "selected.json"
    source.write_bytes(FIXTURE.read_bytes())
    before = source.read_bytes()
    result = ImportService().import_file(ImportRequest(source))
    workspace, repository, service = _service(pg_factory, tmp_path / "originals")
    session = service.create(workspace.workspace_id, result)

    repository.seed(session, result)

    with pg_factory() as database:
        original = database.get(OriginalJsonModel, result.file_hash)
        staging = database.get(ImportStagingDocumentModel, str(session.import_id))
        stored = database.get(ProcessingSessionModel, session.session_id)
        assert original is not None and Path(original.storage_reference).read_bytes() == before
        assert staging is not None and staging.original_hash == result.file_hash
        assert staging.source_count == result.statistics.sources
        assert staging.video_count == result.statistics.video_files
        assert stored is not None and stored.original_reference == original.storage_reference
        assert stored.source_path == str(source.resolve())
    assert source.read_bytes() == before


def test_changed_original_aborts_before_postgresql_writes(pg_factory, tmp_path: Path) -> None:
    source = tmp_path / "selected.json"
    source.write_bytes(FIXTURE.read_bytes())
    result = ImportService().import_file(ImportRequest(source))
    source.write_text('{"changed":true}', encoding="utf-8")
    workspace, repository, service = _service(pg_factory, tmp_path / "originals")
    session = service.create(workspace.workspace_id, result)

    with pytest.raises(ValueError, match="changed after validation"):
        repository.seed(session, result)

    with pg_factory() as database:
        assert database.scalar(select(func.count()).select_from(OriginalJsonModel)) == 0
        assert database.scalar(select(func.count()).select_from(ProcessingSessionModel)) == 0


def _scan_variant(
    tmp_path: Path,
    name: str,
    scan_id: str,
    *,
    size: int | None = None,
    scope_type: str = "parcial",
    include_video: bool = True,
) -> Path:
    document = json.loads(FIXTURE.read_text(encoding="utf-8"))
    document["scan_id"] = scan_id
    document["alcance_escaneo"]["tipo"] = scope_type
    if size is not None:
        document["videos"][0]["tamano"] = size
    if not include_video:
        document["videos"] = []
    target = tmp_path / name
    target.write_text(json.dumps(document, ensure_ascii=False), encoding="utf-8")
    return target


def test_new_scans_reuse_logical_identity_and_count_changes(pg_factory, tmp_path: Path) -> None:
    workspace, repository, service = _service(pg_factory)
    paths = (
        _scan_variant(tmp_path, "scan-1.json", "scan_incremental_1"),
        _scan_variant(tmp_path, "scan-2.json", "scan_incremental_2"),
        _scan_variant(tmp_path, "scan-3.json", "scan_incremental_3", size=123),
    )
    sessions = []
    for path in paths:
        result = ImportService().import_file(ImportRequest(path))
        created = service.create(workspace.workspace_id, result)
        repository.seed(created, result)
        sessions.append(created.session_id)

    with pg_factory() as database:
        assert database.scalar(select(func.count()).select_from(ScanModel)) == 3
        assert database.scalar(select(func.count()).select_from(ScanImportModel)) == 3
        assert database.scalar(select(func.count()).select_from(PhysicalFileModel)) == 3
        assert database.scalar(select(func.count()).select_from(CatalogFileIdentityModel)) == 1
        first, second, third = (
            database.get(ProcessingSessionModel, session_id) for session_id in sessions
        )
        assert first is not None and first.inserted_count == 1
        assert second is not None and second.duplicate_count == 1
        assert third is not None and third.updated_count == 1


def test_repeated_scan_id_rolls_back_without_partial_rows(pg_factory, tmp_path: Path) -> None:
    first_path = _scan_variant(tmp_path, "first.json", "scan_repeated")
    second_path = _scan_variant(tmp_path, "second.json", "scan_repeated", size=999)
    workspace, repository, service = _service(pg_factory)
    first_result = ImportService().import_file(ImportRequest(first_path))
    first = service.create(workspace.workspace_id, first_result)
    repository.seed(first, first_result)
    second_result = ImportService().import_file(ImportRequest(second_path))
    second = service.create(workspace.workspace_id, second_result)

    with pytest.raises(DuplicateSessionError, match="scan_id"):
        repository.seed(second, second_result)

    with pg_factory() as database:
        assert database.scalar(select(func.count()).select_from(ScanModel)) == 1
        assert database.scalar(select(func.count()).select_from(ScanImportModel)) == 1
        assert database.scalar(select(func.count()).select_from(ProcessingSessionModel)) == 1
        assert database.scalar(select(func.count()).select_from(CatalogFileIdentityModel)) == 1


def test_partial_preserves_absence_full_marks_it_and_sighting_restores(
    pg_factory, tmp_path: Path
) -> None:
    workspace, repository, service = _service(pg_factory)
    paths = (
        _scan_variant(tmp_path, "seen.json", "scan_seen"),
        _scan_variant(
            tmp_path,
            "partial-empty.json",
            "scan_partial_empty",
            include_video=False,
        ),
        _scan_variant(
            tmp_path,
            "full-empty.json",
            "scan_full_empty",
            scope_type="completo",
            include_video=False,
        ),
        _scan_variant(tmp_path, "seen-again.json", "scan_seen_again"),
    )
    expected = (
        ("present", 0),
        ("present", 0),
        ("missing", 1),
        ("present", 2),
    )
    for path, (status, event_count) in zip(paths, expected, strict=True):
        result = ImportService().import_file(ImportRequest(path))
        created = service.create(workspace.workspace_id, result)
        repository.seed(created, result)
        with pg_factory() as database:
            identity = database.scalar(select(CatalogFileIdentityModel))
            assert identity is not None and identity.status == status
            assert (
                database.scalar(select(func.count()).select_from(AvailabilityEventModel))
                == event_count
            )
