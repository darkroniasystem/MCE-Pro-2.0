"""Dry-run, auditoría e integridad de la consolidación histórica."""

from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
from sqlalchemy import func, select

from mce.infrastructure.database.bank_consolidation import BankConsolidationService
from mce.infrastructure.database.models import (
    AuditEventModel,
    BankConsolidationModel,
    BankModel,
    InstallationModel,
)

NOW = datetime(2026, 7, 31, tzinfo=UTC)


def _bank(identifier: str, name: str, created_at: datetime) -> BankModel:
    return BankModel(
        id=identifier,
        external_bank_id=None,
        name=name,
        code=None,
        branch=None,
        status="active",
        created_at=created_at,
    )


def test_dry_run_and_consolidation_preserve_references(pg_factory) -> None:
    canonical_id, duplicate_id = str(uuid4()), str(uuid4())
    with pg_factory.begin() as database:
        database.add_all(
            [
                _bank(canonical_id, "Antiguo", NOW - timedelta(days=1)),
                _bank(duplicate_id, "Duplicado", NOW),
                InstallationModel(
                    id=str(uuid4()),
                    bank_id=duplicate_id,
                    name="PC duplicado",
                    machine_identifier="machine-2",
                    status="active",
                    created_at=NOW,
                ),
            ]
        )
    service = BankConsolidationService(pg_factory)
    plan = service.dry_run("bank_history", (duplicate_id, canonical_id))
    assert plan.canonical_bank_id == canonical_id
    assert plan.references_by_table["installations"] == 1
    assert plan.executable

    consolidation_id = service.consolidate(plan, rollback_reference="pg_dump:bank_history-20260731")
    with pg_factory() as database:
        installation = database.scalar(select(InstallationModel))
        duplicate = database.get(BankModel, duplicate_id)
        audit = database.get(BankConsolidationModel, consolidation_id)
        assert installation is not None and installation.bank_id == canonical_id
        assert duplicate is not None and duplicate.status == "archived"
        assert audit is not None and audit.moved_records == 1
        assert database.scalar(select(func.count()).select_from(AuditEventModel)) == 1


def test_consolidation_failure_rolls_back_everything(pg_factory) -> None:
    canonical_id, duplicate_id = str(uuid4()), str(uuid4())
    installation_id = str(uuid4())
    with pg_factory.begin() as database:
        database.add_all(
            [
                _bank(canonical_id, "A", NOW - timedelta(days=1)),
                _bank(duplicate_id, "B", NOW),
                InstallationModel(
                    id=installation_id,
                    bank_id=duplicate_id,
                    name="PC",
                    machine_identifier=None,
                    status="active",
                    created_at=NOW,
                ),
            ]
        )
    service = BankConsolidationService(pg_factory)
    plan = service.dry_run("bank_rollback", (canonical_id, duplicate_id))
    with pytest.raises(RuntimeError, match="injected"):
        service.consolidate(
            plan,
            rollback_reference="pg_dump:rollback-test",
            fail_after_table="installations",
        )
    with pg_factory() as database:
        assert database.get(InstallationModel, installation_id).bank_id == duplicate_id
        assert database.scalar(select(func.count()).select_from(BankConsolidationModel)) == 0
        assert database.scalar(select(func.count()).select_from(AuditEventModel)) == 0
