"""Aislamiento de rutas y disponibilidad para la Fase 15."""

from datetime import UTC, datetime
from uuid import uuid4

import pytest

from mce.infrastructure.database.models import (
    AvailabilityModel,
    BankModel,
    ContentModel,
    InstallationModel,
    PhysicalFileModel,
    ScanModel,
    SourceModel,
)
from mce.infrastructure.database.repositories import BankScopedCatalogRepository

NOW = datetime.now(UTC)


def uid() -> str:
    return str(uuid4())


def seed_bank_inventory(session, bank_id: str, content_id: str, drive: str) -> None:
    installation_id = uid()
    source_id = uid()
    scan_id = uid()
    session.add(
        BankModel(
            id=bank_id,
            external_bank_id=f"external-{bank_id}",
            name=f"Banco {drive}",
            code=None,
            branch=None,
            status="active",
            created_at=NOW,
        )
    )
    session.add(
        InstallationModel(
            id=installation_id,
            bank_id=bank_id,
            name=f"PC {drive}",
            machine_identifier=f"machine-{drive}",
            status="active",
            created_at=NOW,
        )
    )
    session.add(
        SourceModel(
            id=source_id,
            installation_id=installation_id,
            source_type="local_volume",
            display_name=f"Disco {drive}",
            root_path=f"{drive}:/",
            normalized_root_path=f"{drive.casefold()}:/",
            status="active",
        )
    )
    session.add(
        ScanModel(
            id=scan_id,
            installation_id=installation_id,
            started_at=NOW,
            finished_at=NOW,
            scope_type="full",
            scope_data={"type": "full"},
            status="completed",
            msl_version="2.2",
            schema_version="2.2",
        )
    )
    session.flush()
    path = f"{drive}:/Peliculas/Obra compartida.mkv"
    session.add(
        PhysicalFileModel(
            id=uid(),
            bank_id=bank_id,
            scan_id=scan_id,
            source_id=source_id,
            content_id=content_id,
            original_name="Obra compartida.mkv",
            relative_path="Peliculas/Obra compartida.mkv",
            original_path=path,
            normalized_path=path.casefold(),
            extension=".mkv",
            size_bytes=100,
            fingerprint_key=f"fingerprint-{drive}",
            status="present",
        )
    )
    session.add(
        AvailabilityModel(
            id=uid(),
            content_id=content_id,
            bank_id=bank_id,
            payload={"bank_id": bank_id, "status": "available", "paths": [path]},
            created_at=NOW,
        )
    )


def test_routes_and_availability_never_cross_bank_boundary(pg_factory) -> None:
    content_id = uid()
    first_bank = uid()
    second_bank = uid()
    with pg_factory() as session:
        session.add(
            ContentModel(
                id=content_id,
                content_type="movie",
                main_title="Obra compartida",
                status="active",
                identification_status="identified",
                review_status="approved",
                version=1,
                bank_id=None,
            )
        )
        seed_bank_inventory(session, first_bank, content_id, "E")
        seed_bank_inventory(session, second_bank, content_id, "F")
        session.commit()

        catalog = BankScopedCatalogRepository(session)
        assert catalog.paths_for_content(content_id, bank_id=first_bank) == (
            "E:/Peliculas/Obra compartida.mkv",
        )
        assert catalog.paths_for_content(content_id, bank_id=second_bank) == (
            "F:/Peliculas/Obra compartida.mkv",
        )
        assert catalog.paths_for_content(content_id, bank_id=uid()) == ()
        assert catalog.availability_for_content(content_id, bank_id=first_bank).payload[
            "bank_id"
        ] == first_bank
        assert catalog.availability_for_content(content_id, bank_id=second_bank).payload[
            "bank_id"
        ] == second_bank
        with pytest.raises(ValueError, match="bank_id is required"):
            catalog.paths_for_content(content_id, bank_id=" ")
