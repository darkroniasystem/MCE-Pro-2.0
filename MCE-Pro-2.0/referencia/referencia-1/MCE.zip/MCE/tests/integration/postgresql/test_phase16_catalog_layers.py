"""Separación persistente de las tres capas del catálogo."""

from uuid import uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from mce.domain.value_objects import CatalogStage
from mce.infrastructure.database.models import ContentModel
from mce.infrastructure.database.repositories import CatalogLayerRepository


def content(stage: CatalogStage, title: str) -> ContentModel:
    return ContentModel(
        id=str(uuid4()),
        content_type="movie",
        main_title=title,
        status="active",
        identification_status="identified",
        review_status="approved" if stage is not CatalogStage.STAGING else "pending",
        catalog_stage=stage.value,
        version=1,
    )


def test_catalog_layers_never_return_records_from_another_stage(pg_factory) -> None:
    staging = content(CatalogStage.STAGING, "Candidato")
    approved = content(CatalogStage.APPROVED, "Confirmada")
    published = content(CatalogStage.PUBLISHED, "Publicada")
    with pg_factory() as session:
        session.add_all((staging, approved, published))
        session.commit()
        layers = CatalogLayerRepository(session)

        assert {row.id for row in layers.staging()} == {staging.id}
        assert {row.id for row in layers.approved()} == {approved.id}
        assert {row.id for row in layers.published()} == {published.id}
        assert not ({row.id for row in layers.published()} & {staging.id, approved.id})


def test_database_rejects_unknown_catalog_stage(pg_factory) -> None:
    invalid = content(CatalogStage.STAGING, "Inválida")
    invalid.catalog_stage = "mixed"
    with pg_factory() as session:
        session.add(invalid)
        with pytest.raises(IntegrityError):
            session.commit()
