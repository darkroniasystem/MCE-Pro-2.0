"""Detección y consolidación sin tocar archivos físicos."""

from datetime import UTC, datetime

from mce.application.deduplication import CatalogConsolidationService, FindDuplicateCandidates
from mce.application.deduplication.models import CatalogContent, CatalogFile, InMemoryCatalog


def test_duplicate_candidate_can_be_merged_and_reverted_without_file_deletion():
    first = CatalogFile(
        "f1", "b1", "i1", "s1", "E:/A.mkv", "e:/a.mkv", "A.mkv", file_hash="same", content_id="c1"
    )
    second = CatalogFile(
        "f2", "b1", "i1", "s2", "F:/A.mkv", "f:/a.mkv", "A.mkv", file_hash="same", content_id="c2"
    )
    assert FindDuplicateCandidates().execute((first, second))
    catalog = InMemoryCatalog(
        contents={
            "c1": CatalogContent("c1", "A", file_ids=("f1",)),
            "c2": CatalogContent("c2", "A", file_ids=("f2",)),
        },
        files={"f1": first, "f2": second},
    )
    service = CatalogConsolidationService(
        catalog, lambda: datetime(2026, 7, 20, tzinfo=UTC), lambda: "merge-1"
    )
    merge_id = service.merge_content("c1", ("c2",), "operator")
    service.revert_merge(merge_id, "operator")
    assert set(catalog.files) == {"f1", "f2"} and set(catalog.contents) == {"c1", "c2"}
