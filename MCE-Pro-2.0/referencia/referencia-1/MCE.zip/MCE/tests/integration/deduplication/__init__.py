"""Pruebas integradas de consolidación."""
