"""Pruebas integradas de enriquecimiento."""
