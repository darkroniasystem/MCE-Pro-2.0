"""Conversión de candidato en metadatos trazables."""

from datetime import UTC, datetime

from mce.application.enrichment import InMemoryReviewRepository, MetadataConsolidator, ReviewService
from mce.application.enrichment.models import MetadataField, ReviewItem, ReviewItemStatus
from mce.domain.value_objects import ConfidenceScore, FieldProvenance, FieldSourceType

NOW = datetime(2026, 7, 20, tzinfo=UTC)


def test_provider_candidate_can_be_reviewed_without_losing_imported_origin():
    imported = FieldProvenance(FieldSourceType.IMPORTED, "msl", "scan", NOW, ConfidenceScore(70))
    provider = FieldProvenance(FieldSourceType.PROVIDER, "tmdb", "10", NOW, ConfidenceScore(95))
    item = ReviewItem(
        "review-1",
        "tmdb:10",
        {
            "title": MetadataField("Avatar", imported),
            "release_year": MetadataField(2010, imported),
        },
    )
    merged = MetadataConsolidator().merge(
        item,
        {
            "release_year": MetadataField(2009, provider),
            "overview": MetadataField("Sinopsis", provider),
        },
    )
    repo = InMemoryReviewRepository()
    repo.save(merged)
    result = ReviewService(repo, lambda: NOW).approve_candidate("review-1", "operator")
    assert result.status is ReviewItemStatus.APPROVED
    assert result.fields["release_year"].value == 2009
    assert result.conflicts and result.audit[-1].actor == "operator"
