"""Pruebas de integración locales sin servicios externos."""
