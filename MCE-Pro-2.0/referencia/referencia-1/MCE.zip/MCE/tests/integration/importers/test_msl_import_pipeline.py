"""Escenarios completos sobre fixtures MSL anonimizadas."""

from datetime import UTC, datetime
from pathlib import Path

import pytest

from mce.application.dto import DetectedMediaType, ImportRequest, ImportResultStatus
from mce.application.importers import ImportService
from mce.application.importers.local_services import InMemoryImportRegistry
from mce.domain.entities import Content, ContentVersion
from mce.domain.value_objects import SourceType

FIXTURES = Path(__file__).parents[2] / "fixtures" / "msl"
NOW = datetime(2026, 7, 19, 16, tzinfo=UTC)


def import_fixture(name: str) -> object:
    """Importa una fixture con reloj determinista."""
    return ImportService(clock=lambda: NOW).import_file(ImportRequest(FIXTURES / name))


def test_imports_minimal_and_complete_v1() -> None:
    minimal = import_fixture("valid_minimal_v1.json")
    complete = import_fixture("valid_complete_v1.json")
    assert minimal.status is ImportResultStatus.COMPLETED  # type: ignore[attr-defined]
    assert complete.success  # type: ignore[attr-defined]
    assert complete.statistics.video_files == 1  # type: ignore[attr-defined]
    assert complete.statistics.subtitle_files == 1  # type: ignore[attr-defined]


def test_imports_network_and_unicode_without_touching_media() -> None:
    network = import_fixture("valid_network_share_v1.json")
    unicode_result = import_fixture("valid_unicode_v1.json")
    assert network.package.sources[0].source_type is SourceType.NETWORK_SHARE  # type: ignore[union-attr,attr-defined]
    assert network.package.sources[0].normalized_root_path.normalized.startswith("\\\\pc2")  # type: ignore[union-attr,attr-defined]
    assert unicode_result.package.video_files[0].original_name == "Amélie 日本語.mkv"  # type: ignore[union-attr,attr-defined]


def test_recognizes_dvd_without_grouping_it_as_content() -> None:
    result = import_fixture("valid_dvd_v1.json")
    assert all(
        item.detected_media_type is DetectedMediaType.DVD
        for item in result.package.video_files  # type: ignore[union-attr,attr-defined]
    )


def test_imports_reduced_synthetic_schema_22_and_preserves_external_values() -> None:
    result = import_fixture("valid_schema_v22.json")
    assert result.success  # type: ignore[attr-defined]
    assert result.package.detected_schema_version == "2.2"  # type: ignore[union-attr,attr-defined]
    assert result.package.sources[0].declared_id == "src_4444444444444444"  # type: ignore[union-attr,attr-defined]
    assert result.package.video_files[0].original_name.endswith(".MP4")  # type: ignore[union-attr,attr-defined]
    assert "INVALID_EXTERNAL_ID" in {issue.code for issue in result.issues}  # type: ignore[attr-defined]


def test_legacy_import_completes_with_warning() -> None:
    result = import_fixture("legacy_without_version.json")
    assert result.status is ImportResultStatus.COMPLETED_WITH_WARNINGS  # type: ignore[attr-defined]
    assert "SCHEMA_VERSION_MISSING" in {issue.code for issue in result.issues}  # type: ignore[attr-defined]


@pytest.mark.parametrize(
    ("fixture", "status"),
    [
        ("invalid_json.json", ImportResultStatus.INVALID_JSON),
        ("invalid_root.json", ImportResultStatus.INVALID_JSON),
        ("invalid_timestamps.json", ImportResultStatus.REJECTED),
        ("unsupported_version.json", ImportResultStatus.UNSUPPORTED_SCHEMA),
    ],
)
def test_rejects_invalid_documents(fixture: str, status: ImportResultStatus) -> None:
    assert import_fixture(fixture).status is status  # type: ignore[attr-defined]


def test_broken_reference_is_omitted_normally_and_rejected_strictly() -> None:
    path = FIXTURES / "invalid_source_reference.json"
    normal = ImportService(clock=lambda: NOW).import_file(ImportRequest(path))
    strict = ImportService(clock=lambda: NOW).import_file(ImportRequest(path, strict_mode=True))
    assert normal.success
    assert normal.package is not None and not normal.package.domain_files
    assert strict.status is ImportResultStatus.REJECTED


def test_unknown_extension_is_counted_and_ignored() -> None:
    result = import_fixture("unknown_extensions.json")
    assert result.success  # type: ignore[attr-defined]
    assert result.statistics.ignored_files == 1  # type: ignore[attr-defined]
    assert result.statistics.unknown_extensions == 1  # type: ignore[attr-defined]


def test_duplicate_registry_stops_second_pipeline() -> None:
    registry = InMemoryImportRegistry()
    service = ImportService(registry=registry, clock=lambda: NOW)
    request = ImportRequest(FIXTURES / "valid_minimal_v1.json")
    assert service.import_file(request).success
    assert service.import_file(request).status is ImportResultStatus.DUPLICATE


def test_mapper_creates_only_phase_one_import_entities() -> None:
    result = import_fixture("valid_complete_v1.json")
    package = result.package  # type: ignore[attr-defined]
    assert package is not None
    assert package.domain_scan is not None
    assert package.domain_import is not None
    assert package.domain_sources
    assert package.domain_files
    assert package.domain_subtitles
    assert not any(isinstance(item, (Content, ContentVersion)) for item in package.domain_files)


def test_external_bank_identity_maps_to_one_stable_internal_uuid() -> None:
    first = import_fixture("valid_schema_v22.json")
    second = import_fixture("valid_schema_v22.json")
    assert first.package is not None  # type: ignore[attr-defined]
    assert second.package is not None  # type: ignore[attr-defined]
    assert first.package.domain_import.bank_id == second.package.domain_import.bank_id  # type: ignore[attr-defined]
    assert str(first.package.domain_import.bank_id) != "bank_1111111111111111"  # type: ignore[attr-defined]
    assert (
        first.package.domain_scan.installation_id  # type: ignore[attr-defined]
        == second.package.domain_scan.installation_id  # type: ignore[attr-defined]
    )
    assert (
        first.package.domain_sources[0].source_id  # type: ignore[attr-defined]
        == second.package.domain_sources[0].source_id  # type: ignore[attr-defined]
    )
