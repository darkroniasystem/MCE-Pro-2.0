"""Integración del pipeline completo de importación."""
