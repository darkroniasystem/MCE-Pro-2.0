"""Infraestructura común y portable de la suite de pruebas."""

from __future__ import annotations

import os
from pathlib import Path

# Qt no necesita un escritorio visible durante las pruebas automatizadas.
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


PROJECT_ROOT = Path(__file__).resolve().parent.parent
TEST_RUNTIME = PROJECT_ROOT / ".test-runtime"
SYSTEM_TEMP = TEST_RUNTIME / "system-temp"


def pytest_configure() -> None:
    """Aísla temporales de Windows dentro de una ruta escribible del proyecto."""
    SYSTEM_TEMP.mkdir(parents=True, exist_ok=True)
    temporary = str(SYSTEM_TEMP)
    os.environ["TMPDIR"] = temporary
    os.environ["TEMP"] = temporary
    os.environ["TMP"] = temporary
    os.environ["MCE_DATA_DIR"] = str(TEST_RUNTIME / "app-data")
