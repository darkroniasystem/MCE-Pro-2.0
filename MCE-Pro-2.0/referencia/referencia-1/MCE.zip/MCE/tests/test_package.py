"""Pruebas básicas del esqueleto de la Fase 0."""

import sys

import mce


def test_package_exposes_initial_version() -> None:
    assert mce.__version__ == "0.12.0"


def test_supported_python_runtime() -> None:
    assert (3, 12) <= sys.version_info[:2] < (3, 14)
