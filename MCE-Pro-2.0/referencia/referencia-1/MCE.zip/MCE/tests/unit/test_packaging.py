"""Regresiones de la configuracion de empaquetado."""

from __future__ import annotations

import ast
from pathlib import Path


def test_pyinstaller_includes_dynamic_windows_registry_dependency() -> None:
    project_root = Path(__file__).resolve().parents[2]
    specification = ast.parse((project_root / "MCE.spec").read_text(encoding="utf-8"))
    analysis_call = next(
        node.value
        for node in specification.body
        if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == "analysis" for target in node.targets)
        and isinstance(node.value, ast.Call)
    )
    hiddenimports = next(
        keyword.value for keyword in analysis_call.keywords if keyword.arg == "hiddenimports"
    )

    assert "winreg" in ast.literal_eval(hiddenimports)