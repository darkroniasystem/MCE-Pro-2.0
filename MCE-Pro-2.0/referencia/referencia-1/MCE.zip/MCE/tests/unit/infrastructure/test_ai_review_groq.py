import json
from types import SimpleNamespace

import pytest

from mce.application.ai_review import (
    AIRateLimitDeferred,
    AIReviewDecision,
    AIReviewInput,
    AIReviewState,
    EvidenceSource,
    EvidenceValidator,
    ValidatedAnalyzerChain,
)
from mce.infrastructure.ai_review import GroqStructuredAnalyzer, SqliteRateLimitStore
from mce.infrastructure.local_ai import OllamaQwenAnalyzer


def valid_payload() -> str:
    return json.dumps(
        {
            "proposal": "approve",
            "canonical_title": "Vagabond",
            "original_title": "Baegabondeu",
            "alternative_titles": ["Vagabond"],
            "media_type": "dorama",
            "year": 2019,
            "seasons": [1],
            "genres": ["action"],
            "countries": ["KR"],
            "directors": [],
            "cast": [],
            "matches": ["title", "year", "type"],
            "contradictions": [],
            "sources": [
                {
                    "title": "Source",
                    "url": "https://example.com/vagabond",
                    "evidence": "2019 Korean series",
                    "supported_fields": ["title", "year", "type"],
                }
            ],
            "model_confidence": 98,
            "reason": "compatible evidence",
        }
    )


class FakeCompletions:
    def __init__(self, responses):
        self.responses = list(responses)
        self.models = []

    def create(self, **kwargs):
        self.models.append(kwargs["model"])
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return SimpleNamespace(
            choices=[SimpleNamespace(message=SimpleNamespace(content=response))]
        )


def client(responses):
    completions = FakeCompletions(responses)
    return SimpleNamespace(chat=SimpleNamespace(completions=completions)), completions


def evidence():
    return (
        EvidenceSource(
            "https://example.com/vagabond", "Source", "2019 Korean series", "tavily"
        ),
    )


def two_source_evidence():
    return (
        EvidenceSource(
            "https://example.com/vagabond", "Vagabond", "2019 Korean series", "tavily"
        ),
        EvidenceSource(
            "https://example.org/vagabond", "Vagabond", "2019 Korean series", "serper"
        ),
    )


class FakeOllama:
    def __init__(self, content: str) -> None:
        self.content = content

    def tags(self, timeout):
        return {"models": [{"name": "qwen2.5:3b"}]}

    def chat(self, payload, timeout):
        return {"message": {"content": self.content}}


def ambiguous_qwen_payload() -> str:
    return json.dumps(
        {
            "status": "ambiguous",
            "canonical_title": "Vagabond",
            "original_title": None,
            "year": 2019,
            "media_type": "dorama",
            "seasons": [],
            "confidence": 55,
            "fields": {},
            "matched_sources": [],
            "conflicts": [],
            "reasoning_summary": "Ambiguous evidence",
            "recommended_action": "escalate",
        }
    )


def test_groq_accepts_schema_valid_response_and_keeps_verified_sources() -> None:
    fake, calls = client([valid_payload()])
    analyzer = GroqStructuredAnalyzer(fake)

    result = analyzer.analyze(AIReviewInput("group", "Vagabond", "dorama", 2019), evidence())

    assert result.state is AIReviewState.PENDING
    assert result.model == "openai/gpt-oss-120b"
    assert len(result.sources) == 1
    assert calls.models == ["openai/gpt-oss-120b"]


def test_groq_never_returns_raw_approval_when_it_invents_a_source() -> None:
    payload = json.loads(valid_payload())
    payload["sources"].append(
        {
            "title": "Invented",
            "url": "https://invented.example/vagabond",
            "evidence": "not supplied",
            "supported_fields": ["title"],
        }
    )
    fake, _ = client([json.dumps(payload)])

    result = GroqStructuredAnalyzer(fake).analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), evidence()
    )

    assert result.hallucinated_source
    assert result.decision is AIReviewDecision.HUMAN_REVIEW
    assert result.state is AIReviewState.HUMAN


def test_groq_falls_back_once_from_120b_to_20b() -> None:
    fake, calls = client([RuntimeError("server unavailable"), valid_payload()])
    analyzer = GroqStructuredAnalyzer(fake)

    result = analyzer.analyze(AIReviewInput("group", "Vagabond", "dorama"), evidence())

    assert result.model == "openai/gpt-oss-20b"
    assert calls.models == ["openai/gpt-oss-120b", "openai/gpt-oss-20b"]


class FakeRateLimitError(Exception):
    status_code = 429

    def __init__(self, retry_after: str = "52") -> None:
        super().__init__("rate limited")
        self.response = SimpleNamespace(
            status_code=429, headers={"retry-after": retry_after}
        )


class FakeResetRateLimitError(Exception):
    status_code = 429

    def __init__(self) -> None:
        super().__init__("rate limited")
        self.response = SimpleNamespace(
            status_code=429,
            headers={
                "x-ratelimit-reset-requests": "4m30s",
                "x-ratelimit-reset-tokens": "1m",
            },
        )


def test_groq_429_defers_immediately_without_sleep_or_fallback() -> None:
    fake, calls = client([FakeRateLimitError()])
    waits = []
    analyzer = GroqStructuredAnalyzer(
        fake,
        min_interval_seconds=0,
        sleep=waits.append,
        monotonic=lambda: 0.0,
    )

    with pytest.raises(AIRateLimitDeferred, match="reintentar en 52 segundos"):
        analyzer.analyze(AIReviewInput("group", "Vagabond", "dorama"), evidence())

    assert calls.models == ["openai/gpt-oss-120b"]
    assert waits == []


def test_groq_repeated_429_never_spends_fallback_call() -> None:
    fake, calls = client([FakeRateLimitError("1m26.4s")])
    analyzer = GroqStructuredAnalyzer(
        fake,
        min_interval_seconds=0,
        sleep=lambda _seconds: None,
        monotonic=lambda: 0.0,
    )

    with pytest.raises(AIRateLimitDeferred):
        analyzer.analyze(AIReviewInput("group", "Unknown", "dorama"), evidence())

    with pytest.raises(AIRateLimitDeferred):
        analyzer.analyze(AIReviewInput("second", "Unknown 2", "dorama"), evidence())

    assert calls.models == ["openai/gpt-oss-120b"]
    assert analyzer.cooldown_skips == 1


def test_groq_uses_largest_authoritative_reset_header() -> None:
    fake, _ = client([FakeResetRateLimitError()])
    analyzer = GroqStructuredAnalyzer(
        fake,
        min_interval_seconds=0,
        monotonic=lambda: 0.0,
    )

    with pytest.raises(AIRateLimitDeferred) as raised:
        analyzer.analyze(AIReviewInput("group", "Unknown", "dorama"), evidence())

    assert raised.value.retry_after_seconds == 270
    assert raised.value.authoritative is True
    assert raised.value.quota_kind == "requests"


def test_groq_restores_provider_block_after_restart(tmp_path) -> None:
    store = SqliteRateLimitStore(tmp_path / "ai.sqlite3")
    store.save("groq", 300, False, "unknown")
    fake, calls = client([valid_payload()])
    analyzer = GroqStructuredAnalyzer(
        fake,
        min_interval_seconds=0,
        rate_limit_store=store,
    )

    with pytest.raises(AIRateLimitDeferred) as raised:
        analyzer.analyze(AIReviewInput("group", "Unknown", "dorama"), evidence())

    assert raised.value.retry_after_seconds > 295
    assert raised.value.authoritative is False
    assert calls.models == []


def test_groq_invalid_json_never_returns_approval() -> None:
    fake, _ = client(["not-json", "{}"])
    analyzer = GroqStructuredAnalyzer(fake)

    with pytest.raises(RuntimeError, match="todos los modelos"):
        analyzer.analyze(AIReviewInput("group", "Unknown", "movie"), evidence())


def test_real_chain_validates_structured_groq_fallback_before_approval() -> None:
    sources = two_source_evidence()
    groq_payload = json.loads(valid_payload())
    groq_payload["sources"].append(
        {
            "title": "Vagabond",
            "url": sources[1].url,
            "evidence": "2019 Korean series",
            "supported_fields": ["title", "year", "type"],
        }
    )
    fake, _ = client([json.dumps(groq_payload)])
    chain = ValidatedAnalyzerChain(
        OllamaQwenAnalyzer(FakeOllama(ambiguous_qwen_payload())),
        GroqStructuredAnalyzer(fake),
        EvidenceValidator(),
    )

    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )

    assert result.decision is AIReviewDecision.APPROVE
    assert result.state is AIReviewState.APPROVED
    assert result.provider == "groq"
    assert result.deterministic_score == 100
    assert chain.fallback_calls == 1 and chain.fallback_accepted == 1


def test_real_chain_rejects_url_invented_by_structured_groq_fallback() -> None:
    sources = two_source_evidence()
    groq_payload = json.loads(valid_payload())
    groq_payload["sources"].append(
        {
            "title": "Vagabond",
            "url": "https://invented.example/vagabond",
            "evidence": "invented",
            "supported_fields": ["title"],
        }
    )
    fake, _ = client([json.dumps(groq_payload)])
    chain = ValidatedAnalyzerChain(
        OllamaQwenAnalyzer(FakeOllama(ambiguous_qwen_payload())),
        GroqStructuredAnalyzer(fake),
        EvidenceValidator(),
    )

    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )

    assert result.decision is AIReviewDecision.HUMAN_REVIEW
    assert result.hallucinated_source
    assert chain.fallback_human_review == 1
