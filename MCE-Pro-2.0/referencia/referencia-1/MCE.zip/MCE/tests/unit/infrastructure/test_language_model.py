"""Proveedor de IA falso y validación estricta."""

import pytest
from tests.fakes import FakeLanguageModelProvider

from mce.infrastructure.language_models import (
    InvalidLanguageModelResponseError,
    LanguageModelUnavailableError,
)


def test_valid_language_model_suggestion_is_schema_checked():
    provider = FakeLanguageModelProvider(
        {"task": "overview", "value": "Texto", "explanation": "Reformulación"}
    )
    assert provider.suggest("overview", {}).value == "Texto"


@pytest.mark.parametrize(
    "response",
    [
        None,
        {},
        {"task": "overview", "value": "", "explanation": "x"},
        {"task": "other", "value": "x", "explanation": "x"},
        {"task": "overview", "value": "x", "explanation": "x", "extra": 1},
    ],
)
def test_invalid_language_model_responses_are_rejected(response):
    with pytest.raises(InvalidLanguageModelResponseError):
        FakeLanguageModelProvider(response).suggest("overview", {})


def test_disconnected_language_model_is_visible():
    with pytest.raises(LanguageModelUnavailableError):
        FakeLanguageModelProvider(unavailable=True).suggest("overview", {})
