"""Contrato del esquema relacional."""

from mce.infrastructure.database.models import Base


def test_required_phase_four_tables_exist() -> None:
    required = {
        "banks",
        "installations",
        "sources",
        "scans",
        "scan_imports",
        "processing_sessions",
        "processing_jobs",
        "contents",
        "content_versions",
        "physical_files",
        "subtitles",
        "collections",
        "seasons",
        "episodes",
        "availabilities",
        "corrections",
        "field_locks",
        "field_provenance",
        "review_decisions",
        "content_candidates",
        "metadata_candidates",
        "match_evidence",
        "metadata_conflicts",
        "ai_review_runs",
    }
    assert required <= set(Base.metadata.tables)


def test_foreign_keys_and_unique_hash_are_declared() -> None:
    imports = Base.metadata.tables["scan_imports"]
    assert imports.c.file_hash.unique
    assert imports.c.bank_id.foreign_keys
    assert Base.metadata.tables["physical_files"].c.source_id.foreign_keys
