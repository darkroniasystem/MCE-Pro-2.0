import sqlite3
from datetime import UTC, datetime, timedelta
from io import BytesIO
from pathlib import Path
from urllib.error import HTTPError, URLError

import pytest

from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.application.identification.service import (
    ProviderRateLimitError,
    ProviderServerError,
)
from mce.infrastructure.metadata import (
    SqliteMetadataCache,
    UrllibJsonTransport,
    build_metadata_runtime,
)

NOW = datetime(2026, 7, 21, tzinfo=UTC)


class Response:
    def __init__(self, payload: bytes) -> None:
        self.payload = payload

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return None

    def read(self) -> bytes:
        return self.payload


def test_https_transport_decodes_json_without_exposing_query(monkeypatch) -> None:
    captured = []

    def open_request(request, timeout):
        captured.append((request.full_url, timeout))
        return Response(b'{"results":[]}')

    monkeypatch.setattr("mce.infrastructure.metadata.http_transport.urlopen", open_request)
    result = UrllibJsonTransport().get_json(
        "/search/movie", {"api_key": "secret", "query": "Avatar"}, 3
    )
    assert result == {"results": []}
    assert captured[0][1] == 3


@pytest.mark.parametrize(
    ("error", "expected"),
    [
        (HTTPError("safe", 429, "rate", {}, None), ProviderRateLimitError),
        (HTTPError("safe", 432, "plan", {}, None), ProviderRateLimitError),
        (HTTPError("safe", 433, "paygo", {}, None), ProviderRateLimitError),
        (HTTPError("safe", 503, "down", {}, None), ProviderServerError),
        (URLError("offline"), ProviderServerError),
    ],
)
def test_https_transport_maps_failures_to_sanitized_provider_errors(
    monkeypatch, error, expected
) -> None:
    monkeypatch.setattr(
        "mce.infrastructure.metadata.http_transport.urlopen",
        lambda *args, **kwargs: (_ for _ in ()).throw(error),
    )
    with pytest.raises(expected) as raised:
        UrllibJsonTransport().get_json("/search/movie", {"api_key": "secret"}, 1)
    assert "secret" not in str(raised.value)


def test_https_transport_marks_remote_quota_without_exposing_body(monkeypatch) -> None:
    error = HTTPError(
        "safe",
        429,
        "rate",
        {},
        BytesIO(b'{"message":"monthly quota exhausted for private-account"}'),
    )
    monkeypatch.setattr(
        "mce.infrastructure.metadata.http_transport.urlopen",
        lambda *args, **kwargs: (_ for _ in ()).throw(error),
    )

    with pytest.raises(ProviderRateLimitError) as raised:
        UrllibJsonTransport(provider_name="Serper").post_json(
            "/search", {"q": "private title"}, 1
        )

    assert getattr(raised.value, "quota_exhausted", False) is True
    assert "private-account" not in str(raised.value)


@pytest.mark.parametrize("status", [432, 433])
def test_https_transport_marks_tavily_plan_limits_as_exhausted(
    monkeypatch, status
) -> None:
    error = HTTPError("safe", status, "quota", {}, None)
    monkeypatch.setattr(
        "mce.infrastructure.metadata.http_transport.urlopen",
        lambda *args, **kwargs: (_ for _ in ()).throw(error),
    )

    with pytest.raises(ProviderRateLimitError) as raised:
        UrllibJsonTransport(provider_name="Tavily").post_json(
            "/search", {"query": "public title"}, 1
        )

    assert getattr(raised.value, "quota_exhausted", False) is True
    assert "cuota del plan agotada" in str(raised.value)


def test_sqlite_cache_is_persistent_bounded_and_expires(tmp_path: Path) -> None:
    path = tmp_path / "metadata.sqlite3"
    cache = SqliteMetadataCache(path, max_entries=1)
    first = (ProviderCandidate("tmdb", "1", SearchKind.MOVIE, "Avatar"),)
    second = (ProviderCandidate("tmdb", "2", SearchKind.MOVIE, "Aliens"),)
    cache.put("first", first, NOW)
    assert SqliteMetadataCache(path, max_entries=1).get("first", NOW, timedelta(hours=1)) == first
    cache.put("second", second, NOW + timedelta(seconds=1))
    assert cache.get("first", NOW + timedelta(seconds=1), timedelta(hours=1)) is None
    assert cache.get("second", NOW + timedelta(hours=2), timedelta(hours=1)) is None


def test_corrupt_sqlite_cache_is_preserved_and_recreated(tmp_path: Path) -> None:
    path = tmp_path / "metadata.sqlite3"
    path.write_bytes(b"not-a-sqlite-database")

    cache = SqliteMetadataCache(path)

    assert cache.get("missing", NOW, timedelta(hours=1)) is None
    preserved = tuple(tmp_path.glob("metadata.sqlite3.corrupt-*"))
    assert len(preserved) == 1
    assert preserved[0].read_bytes() == b"not-a-sqlite-database"


def test_cache_checksum_evicts_a_tampered_payload(tmp_path: Path) -> None:
    path = tmp_path / "metadata.sqlite3"
    cache = SqliteMetadataCache(path)
    value = (ProviderCandidate("tmdb", "1", SearchKind.MOVIE, "Avatar"),)
    cache.put("movie", value, NOW)
    with sqlite3.connect(path) as connection:
        connection.execute(
            "UPDATE metadata_cache SET payload=? WHERE cache_key=?",
            (b"tampered", "movie"),
        )
    assert cache.get("movie", NOW, timedelta(hours=1)) is None


def test_production_factory_never_falls_back_to_fake(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.delenv("TMDB_API_KEY", raising=False)
    monkeypatch.delenv("FANART_API_KEY", raising=False)
    missing = build_metadata_runtime(tmp_path / "cache.sqlite3")
    assert missing.configured
    assert missing.provider.name == "cached:provider-manager"
    assert ("TMDb", "no configurada") in missing.provider_statuses

    monkeypatch.setenv("TMDB_API_KEY", "controlled-key")
    configured = build_metadata_runtime(tmp_path / "cache.sqlite3")
    assert configured.configured
    assert "online" in configured.message
    assert configured.provider.name.startswith("cached:")


def test_production_factory_configures_tavily_without_exposing_key(
    monkeypatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("TAVILY_API_KEY", "tavily-secret-for-test")
    runtime = build_metadata_runtime(tmp_path / "tavily-cache.sqlite3")
    assert runtime.web_fallback is not None
    assert ("Tavily", "configurada") in runtime.provider_statuses
    assert "tavily-secret-for-test" not in runtime.message


def test_production_factory_configures_serper_and_exa_without_network(
    monkeypatch,
) -> None:
    class NoopMetadataCache:
        def __init__(self, path, **kwargs):
            self.path = path

    class NoopWebCache:
        name = "cached:web:mock"

        def __init__(self, provider, path, **kwargs):
            self.provider = provider
            self.path = path

        def search(self, query, *, limit):
            return self.provider.search(query, limit=limit)

    monkeypatch.setenv("SERPER_API_KEY", "serper-secret-for-test")
    monkeypatch.setenv("EXA_API_KEY", "exa-secret-for-test")
    monkeypatch.delenv("MCE_SERPER_ENABLED", raising=False)
    monkeypatch.delenv("MCE_EXA_ENABLED", raising=False)
    monkeypatch.delenv("BROWSER_SEARCH_ENABLED", raising=False)
    monkeypatch.setattr(
        "mce.infrastructure.metadata.factory.SqliteMetadataCache", NoopMetadataCache
    )
    monkeypatch.setattr(
        "mce.infrastructure.metadata.factory.CachedWebSearchProvider", NoopWebCache
    )

    runtime = build_metadata_runtime(Path("unused-by-test.sqlite3"))

    assert ("Serper", "configurada") in runtime.provider_statuses
    assert ("Exa", "configurada") in runtime.provider_statuses
    assert ("Browser web", "desactivado") in runtime.provider_statuses
    assert "serper-secret-for-test" not in runtime.message
    assert "exa-secret-for-test" not in runtime.message


def test_factory_places_enabled_browser_after_three_web_apis(monkeypatch) -> None:
    class NoopMetadataCache:
        def __init__(self, path, **kwargs):
            self.path = path

    class NoopWebCache:
        name = "cached:web:mock"

        def __init__(self, provider, path, **kwargs):
            self.provider = provider

        def search(self, query, *, limit):
            return self.provider.search(query, limit=limit)

    monkeypatch.setenv("TAVILY_API_KEY", "test-tavily")
    monkeypatch.setenv("SERPER_API_KEY", "test-serper")
    monkeypatch.setenv("EXA_API_KEY", "test-exa")
    monkeypatch.setenv("BROWSER_SEARCH_ENABLED", "true")
    monkeypatch.setattr(
        "mce.infrastructure.metadata.factory.SqliteMetadataCache", NoopMetadataCache
    )
    monkeypatch.setattr(
        "mce.infrastructure.metadata.factory.CachedWebSearchProvider", NoopWebCache
    )

    runtime = build_metadata_runtime(Path("unused-by-test.sqlite3"))
    assert runtime.web_fallback is not None
    manager = runtime.web_fallback.provider.provider

    assert [item.provider_id for item in manager.registrations] == [
        "exa",
        "serper",
        "tavily",
        "browser",
    ]
    assert [item.priority for item in manager.registrations] == [10, 20, 30, 40]
    assert ("Browser web", "integrado · Playwright/Chrome se comprueba al usar") in (
        runtime.provider_statuses
    )
