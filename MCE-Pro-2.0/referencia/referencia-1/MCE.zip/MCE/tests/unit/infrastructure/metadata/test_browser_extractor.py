from dataclasses import dataclass, field

import pytest

from mce.infrastructure.metadata.browser_extractor import BrowserEvidenceExtractor
from mce.infrastructure.metadata.browser_search import BrowserSearchSettings, BrowserSearchStatus


@dataclass
class Node:
    text: str = ""
    attributes: dict[str, str] = field(default_factory=dict)
    children: dict[str, list["Node"]] = field(default_factory=dict)
    broken: bool = False
    dom_text: str | None = None


class Locator:
    def __init__(self, nodes):
        self.nodes = list(nodes)

    def count(self):
        return len(self.nodes)

    def nth(self, index):
        return Locator((self.nodes[index],))

    def locator(self, selector):
        found = []
        for node in self.nodes:
            found.extend(node.children.get(selector, ()))
        return Locator(found)

    def inner_text(self, *, timeout=None):
        if not self.nodes:
            return ""
        if self.nodes[0].broken:
            raise RuntimeError("DOM changed")
        return self.nodes[0].text

    def text_content(self, *, timeout=None):
        if not self.nodes or self.nodes[0].broken:
            return None
        node = self.nodes[0]
        return node.dom_text if node.dom_text is not None else node.text

    def get_attribute(self, name, *, timeout=None):
        if not self.nodes or self.nodes[0].broken:
            return None
        return self.nodes[0].attributes.get(name)


class Page:
    def __init__(self, selectors, body=""):
        self.selectors = dict(selectors)
        self.selectors["body"] = [Node(body)]
        self.url = "https://search.test/"

    def locator(self, selector):
        return Locator(self.selectors.get(selector, ()))


def settings(**changes):
    values = {
        "enabled": True,
        "headless": True,
        "timeout_seconds": 10,
        "max_concurrency": 1,
        "delay_min_ms": 1_000,
        "delay_max_ms": 2_500,
        "max_results": 5,
        "max_page_text_chars": 2_000,
    }
    values.update(changes)
    return BrowserSearchSettings(**values)


def result_node(title, url, text, snippet=""):
    return Node(
        text=text,
        children={
            "h3": [Node(title)],
            "a[href]": [Node(title, {"href": url})],
            ".snippet": [Node(snippet)] if snippet else [],
        },
    )


def test_extracts_structured_fields_using_fallback_result_selector() -> None:
    text = """Vincenzo
Dorama de 2021
Temporadas: 1
Género: Drama, Comedia
Reparto: Song Joong-ki, Jeon Yeo-been
Valoración: 8.4
Disponible en: Netflix
Títulos alternativos: 빈센조, Binsenjo"""
    page = Page(
        {"li.b_algo": [result_node("Vincenzo", "https://example.test/vincenzo", text)]},
        body=text,
    )

    result = BrowserEvidenceExtractor().extract(page, settings=settings(), limit=3)

    assert result.status is BrowserSearchStatus.SUCCESS
    assert len(result.evidence) == 1
    item = result.evidence[0]
    assert item.title == "Vincenzo" and item.year == 2021 and item.media_type == "dorama"
    assert item.seasons == 1 and item.rating == 8.4
    assert item.genres == ("Drama", "Comedia")
    assert item.cast == ("Song Joong-ki", "Jeon Yeo-been")
    assert item.platforms == ("Netflix",)
    assert item.alternate_titles == ("빈센조", "Binsenjo")


def test_extracts_partial_knowledge_panel_without_inventing_link_or_fields() -> None:
    panel = Node(
        "Vincenzo\nSerie coreana\nReparto: Song Joong-ki",
        children={"h2": [Node("Vincenzo")]},
    )
    page = Page({"#rhs": [panel]}, body=panel.text)

    result = BrowserEvidenceExtractor().extract(page, settings=settings(), limit=3)

    assert result.status is BrowserSearchStatus.PARTIAL
    assert result.evidence[0].origin == "knowledge_panel"
    assert result.evidence[0].source_url == ""
    assert result.evidence[0].year is None
    assert result.evidence[0].cast == ("Song Joong-ki",)


@pytest.mark.parametrize(
    ("body", "status"),
    [
        ("Please verify you are human with CAPTCHA", BrowserSearchStatus.CAPTCHA),
        ("429 Too Many Requests", BrowserSearchStatus.RATE_LIMITED),
        ("Access denied", BrowserSearchStatus.BLOCKED),
        ("Antes de continuar, acepta", BrowserSearchStatus.BLOCKED),
    ],
)
def test_detects_blocking_pages_without_attempting_bypass(body, status) -> None:
    result = BrowserEvidenceExtractor().extract(Page({}, body=body), settings=settings(), limit=3)

    assert result.status is status
    assert result.evidence == ()
    assert status.value in result.message


def test_discards_malformed_unsafe_and_duplicate_results_defensively() -> None:
    good = result_node("Vincenzo", "https://example.test/vincenzo", "Vincenzo dorama 2021")
    unsafe = result_node("Unsafe", "http://unsafe.test", "Unsafe 2020")
    broken = Node("Broken", broken=True, children={"h3": [Node("Broken", broken=True)]})
    page = Page(
        {
            "div.g": [broken, good, unsafe],
            "main article": [good],
        },
        body="Resultados normales",
    )

    result = BrowserEvidenceExtractor().extract(page, settings=settings(), limit=5)

    assert len(result.evidence) == 1
    assert result.evidence[0].source_url == "https://example.test/vincenzo"


def test_prefers_heading_link_and_falls_back_to_dom_text_content() -> None:
    result = Node(
        text="Vincenzo dorama 2021",
        children={
            "h2": [Node("", dom_text="Vincenzo")],
            "a[href]": [
                Node("Icono", {"href": "/images/favicon.ico"}),
                Node("Vincenzo", {"href": "https://example.test/vincenzo"}),
            ],
            "h2 a[href]": [Node("Vincenzo", {"href": "https://example.test/vincenzo"})],
        },
    )
    page = Page({"li.b_algo": [result]}, body="Resultados normales")

    extracted = BrowserEvidenceExtractor().extract(page, settings=settings(), limit=3)

    assert len(extracted.evidence) == 1
    assert extracted.evidence[0].title == "Vincenzo"
    assert extracted.evidence[0].source_url == "https://example.test/vincenzo"


def test_limits_results_and_visible_page_text() -> None:
    rows = [
        result_node(f"Obra {index}", f"https://example.test/{index}", f"Obra {index} 2021")
        for index in range(5)
    ]
    page = Page({"div.g": rows}, body="x" * 500)

    result = BrowserEvidenceExtractor().extract(
        page,
        settings=settings(max_results=2, max_page_text_chars=40),
        limit=10,
    )

    assert len(result.evidence) == 2
    assert len(result.page_text) == 40


def test_reports_no_evidence_when_selectors_are_absent() -> None:
    result = BrowserEvidenceExtractor().extract(
        Page({}, body="Página normal sin resultados"),
        settings=settings(),
        limit=3,
    )

    assert result.status is BrowserSearchStatus.NO_EVIDENCE
    assert "no contiene evidencia" in result.message
