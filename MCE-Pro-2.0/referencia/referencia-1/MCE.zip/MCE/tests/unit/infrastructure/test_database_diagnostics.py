from mce.infrastructure.database import diagnostics
from mce.infrastructure.database.diagnostics import (
    inspect_runtime_database_configuration,
    inspect_test_database_configuration,
    runtime_database_url,
)


def test_database_diagnostic_hides_credentials_and_rejects_non_test_database(monkeypatch) -> None:
    monkeypatch.setenv(
        "MCE_TEST_DATABASE_URL", "postgresql+psycopg://user:secret@localhost:5432/mce_test"
    )
    safe = inspect_test_database_configuration()
    assert safe.safe and safe.database == "mce_test"
    assert "secret" not in safe.message
    monkeypatch.setenv(
        "MCE_TEST_DATABASE_URL", "postgresql+psycopg://user:secret@localhost:5432/postgres"
    )
    rejected = inspect_test_database_configuration()
    assert not rejected.safe and rejected.message == "destino rechazado"


def test_runtime_database_prefers_exact_master_without_exposing_secret(monkeypatch) -> None:
    monkeypatch.setenv(
        "MCE_TEST_DATABASE_URL", "postgresql+psycopg://user:test-secret@localhost/mce_test"
    )
    monkeypatch.setenv("MCE_DATABASE_URL", "postgresql+psycopg://user:master-secret@localhost/mce")

    status = inspect_runtime_database_configuration()

    assert status.safe and status.database == "mce"
    assert status.message == "catálogo maestro configurado"
    assert "secret" not in status.message
    assert runtime_database_url() is not None


def test_runtime_database_rejects_administrative_or_ambiguous_targets(monkeypatch) -> None:
    monkeypatch.setenv(
        "MCE_TEST_DATABASE_URL", "postgresql+psycopg://user:secret@localhost/mce_test"
    )
    for database in ("postgres", "mce_master", "mce_test"):
        monkeypatch.setenv(
            "MCE_DATABASE_URL", f"postgresql+psycopg://user:secret@localhost/{database}"
        )
        assert not inspect_runtime_database_configuration().safe
        assert runtime_database_url() is None


def test_frozen_runtime_never_falls_back_to_mce_test(monkeypatch) -> None:
    monkeypatch.setattr(diagnostics.sys, "frozen", True, raising=False)
    monkeypatch.setattr(
        diagnostics,
        "_environment_value",
        lambda variable: (
            "postgresql+psycopg://user:hidden@localhost/mce_test"
            if variable == "MCE_TEST_DATABASE_URL"
            else ""
        ),
    )

    status = inspect_runtime_database_configuration()

    assert not status.safe
    assert status.message == "catálogo maestro sin configurar"
    assert runtime_database_url() is None

def test_frozen_runtime_reads_master_url_from_user_registry(monkeypatch) -> None:
    class RegistryKey:
        def __enter__(self):
            return self

        def __exit__(self, *_args) -> None:
            return None

    monkeypatch.delenv("MCE_DATABASE_URL", raising=False)
    monkeypatch.setattr(diagnostics.sys, "frozen", True, raising=False)
    monkeypatch.setattr(diagnostics.os, "name", "nt")
    monkeypatch.setattr(diagnostics.winreg, "OpenKey", lambda *_args: RegistryKey())
    monkeypatch.setattr(
        diagnostics.winreg,
        "QueryValueEx",
        lambda *_args: ("postgresql+psycopg://user:hidden@localhost/mce", 1),
    )

    status = inspect_runtime_database_configuration()

    assert status.safe and status.database == "mce"
    assert runtime_database_url() is not None
