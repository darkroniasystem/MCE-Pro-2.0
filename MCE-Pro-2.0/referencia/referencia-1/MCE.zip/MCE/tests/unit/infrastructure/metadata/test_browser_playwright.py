from dataclasses import dataclass, field

from mce.infrastructure.metadata.browser_playwright import (
    PlaywrightBrowserAutomationBackend,
)
from mce.infrastructure.metadata.browser_search import (
    BrowserSearchSettings,
    BrowserSearchStatus,
)


@dataclass
class Node:
    text: str = ""
    attributes: dict[str, str] = field(default_factory=dict)
    children: dict[str, list["Node"]] = field(default_factory=dict)


class Locator:
    def __init__(self, nodes):
        self.nodes = list(nodes)

    def count(self):
        return len(self.nodes)

    def nth(self, index):
        return Locator((self.nodes[index],))

    def locator(self, selector):
        found = []
        for node in self.nodes:
            found.extend(node.children.get(selector, ()))
        return Locator(found)

    def inner_text(self, *, timeout=None):
        return self.nodes[0].text if self.nodes else ""

    def get_attribute(self, name, *, timeout=None):
        return self.nodes[0].attributes.get(name) if self.nodes else None


class Page:
    url = "https://www.bing.com/search"

    def __init__(self) -> None:
        result = Node(
            "Vincenzo dorama 2021",
            children={
                "h3": [Node("Vincenzo")],
                "a[href]": [Node("Vincenzo", {"href": "https://example.test/vincenzo"})],
                ".b_caption p": [Node("Dorama de 2021")],
            },
        )
        self.selectors = {
            "body": [Node("Vincenzo dorama 2021")],
            "li.b_algo": [result],
        }
        self.closed = False
        self.visited = ""

    def goto(self, url, **kwargs):
        self.visited = url

    def locator(self, selector):
        return Locator(self.selectors.get(selector, ()))

    def close(self):
        self.closed = True


class Browser:
    def __init__(self) -> None:
        self.pages = []
        self.closed = False

    def new_page(self):
        page = Page()
        self.pages.append(page)
        return page

    def is_connected(self):
        return not self.closed

    def close(self):
        self.closed = True


class Chromium:
    def __init__(self, browser) -> None:
        self.browser = browser
        self.launches = 0
        self.options = None

    def launch(self, **options):
        self.launches += 1
        self.options = options
        return self.browser


class Manager:
    def __init__(self) -> None:
        self.browser = Browser()
        self.chromium = Chromium(self.browser)
        self.stopped = False

    def start(self):
        return self

    def stop(self):
        self.stopped = True


def settings() -> BrowserSearchSettings:
    return BrowserSearchSettings(
        enabled=True,
        timeout_seconds=2,
        delay_min_ms=0,
        delay_max_ms=0,
    )


def test_backend_reuses_browser_and_closes_each_page() -> None:
    manager = Manager()
    backend = PlaywrightBrowserAutomationBackend(playwright_factory=lambda: manager)

    first = backend.search("Vincenzo dorama", limit=3, settings=settings())
    second = backend.search("Vincenzo dorama", limit=3, settings=settings())
    backend.close()

    assert first.status is BrowserSearchStatus.SUCCESS
    assert second.hits[0].title == "Vincenzo"
    assert manager.chromium.launches == 1
    assert manager.chromium.options == {"headless": True, "channel": "chrome"}
    assert len(manager.browser.pages) == 2
    assert all(page.closed for page in manager.browser.pages)
    assert manager.browser.closed and manager.stopped


def test_browser_diagnostic_reports_playwright_and_chromium_separately() -> None:
    manager = Manager()
    backend = PlaywrightBrowserAutomationBackend(playwright_factory=lambda: manager)

    diagnostic = backend.diagnose(headless=False)

    assert diagnostic.playwright_available
    assert diagnostic.chromium_available
    assert diagnostic.message == "Playwright y Chrome/Chromium disponibles"
    assert manager.chromium.options == {"headless": False, "channel": "chrome"}
    assert manager.browser.closed and manager.stopped


def test_browser_diagnostic_explains_missing_playwright() -> None:
    def unavailable():
        raise RuntimeError("Browser: Playwright no está instalado")

    diagnostic = PlaywrightBrowserAutomationBackend(
        playwright_factory=unavailable
    ).diagnose()

    assert not diagnostic.playwright_available
    assert not diagnostic.chromium_available
    assert "Playwright no está instalado" in diagnostic.message


def test_backend_reports_missing_playwright_or_browser_clearly() -> None:
    def unavailable():
        raise RuntimeError("Browser: Playwright no está instalado")

    backend = PlaywrightBrowserAutomationBackend(playwright_factory=unavailable)
    result = backend.search("Vincenzo", limit=1, settings=settings())
    backend.close()

    assert result.status is BrowserSearchStatus.UNAVAILABLE
    assert "Chrome/Chromium no pudo iniciarse" in result.message
