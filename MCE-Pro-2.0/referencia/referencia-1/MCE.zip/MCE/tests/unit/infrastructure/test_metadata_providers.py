"""Caché, resiliencia, cancelación y adaptador TMDb controlado."""

from datetime import UTC, datetime, timedelta

import pytest
from tests.fakes import FakeMetadataProvider
from tests.unit.application.identification.test_identification import candidate

from mce.application.identification.models import IdentificationQuery, SearchKind
from mce.application.identification.service import (
    ProviderError,
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderResponseError,
    ProviderServerError,
    ProviderTimeoutError,
)
from mce.infrastructure.metadata import (
    CachedMetadataProvider,
    ControlledMetadataProvider,
    InMemoryMetadataCache,
    RateLimitedMetadataProvider,
    ResilientMetadataProvider,
    TmdbMetadataProvider,
)

QUERY = IdentificationQuery("Avatar", SearchKind.MOVIE, 2009)
NOW = datetime(2026, 7, 20, tzinfo=UTC)


def test_cache_has_stable_key_avoids_calls_and_supports_offline():
    fake = FakeMetadataProvider((candidate(),))
    cache = InMemoryMetadataCache()
    provider = CachedMetadataProvider(fake, cache, clock=lambda: NOW)
    assert (
        provider.search_movie(QUERY) == provider.search_movie(QUERY)
        and fake.calls == 1
        and provider.last_from_cache
    )
    offline = CachedMetadataProvider(fake, cache, offline=True, clock=lambda: NOW)
    assert offline.search_movie(QUERY) and offline.last_from_cache


def test_expired_or_missing_offline_cache_is_visible():
    provider = CachedMetadataProvider(
        FakeMetadataProvider(),
        InMemoryMetadataCache(),
        ttl=timedelta(seconds=1),
        offline=True,
        clock=lambda: NOW,
    )
    with pytest.raises(ProviderOfflineError):
        provider.search_movie(QUERY)


class Flaky(FakeMetadataProvider):
    def _search(self):
        self.calls += 1
        if self.calls < 3:
            raise ProviderRateLimitError("429")
        return self.results


def test_retries_rate_limit_with_bounded_exponential_wait():
    waits = []
    flaky = Flaky((candidate(),))
    result = ResilientMetadataProvider(
        flaky, retries=2, base_delay=1, sleep=waits.append
    ).search_movie(QUERY)
    assert result and waits == [1, 2] and flaky.calls == 3


def test_retry_exhaustion_and_cancellation_are_visible():
    with pytest.raises(ProviderTimeoutError):
        ResilientMetadataProvider(
            FakeMetadataProvider(error=ProviderTimeoutError("timeout")),
            retries=1,
            sleep=lambda _: None,
        ).search_movie(QUERY)
    with pytest.raises(ProviderError, match="cancelada"):
        ResilientMetadataProvider(FakeMetadataProvider(), cancelled=lambda: True).search_movie(
            QUERY
        )


def test_server_errors_retry_but_local_request_limit_stops_calls():
    waits = []
    with pytest.raises(ProviderServerError):
        ResilientMetadataProvider(
            FakeMetadataProvider(error=ProviderServerError("500")), retries=1, sleep=waits.append
        ).search_movie(QUERY)
    assert len(waits) == 1
    limited = RateLimitedMetadataProvider(FakeMetadataProvider((candidate(),)), 1)
    assert limited.search_movie(QUERY)
    with pytest.raises(ProviderRateLimitError):
        limited.search_movie(QUERY)


def test_provider_control_opens_circuit_and_recovers_after_cooldown():
    timeline = [0.0]
    controlled = ControlledMetadataProvider(
        FakeMetadataProvider(error=ProviderServerError("caído")),
        failure_threshold=2,
        cooldown_seconds=10,
        monotonic=lambda: timeline[0],
        sleep=lambda _: None,
    )
    with pytest.raises(ProviderServerError):
        controlled.search_movie(QUERY)
    with pytest.raises(ProviderServerError):
        controlled.search_movie(QUERY)
    with pytest.raises(ProviderOfflineError, match="circuito"):
        controlled.search_movie(QUERY)
    timeline[0] = 11
    with pytest.raises(ProviderServerError):
        controlled.search_movie(QUERY)


class Transport:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def get_json(self, path, params, timeout):
        self.calls.append((path, params, timeout))
        return self.payload


def test_tmdb_adapter_maps_controlled_response_without_internet():
    transport = Transport(
        {
            "results": [
                {
                    "id": 10,
                    "title": "Avatar",
                    "original_title": "Avatar",
                    "release_date": "2009-12-18",
                }
            ]
        }
    )
    result = TmdbMetadataProvider("hidden", transport, timeout=3).search_movie(QUERY)
    assert result[0].external_id == "10" and result[0].year == 2009 and transport.calls[0][2] == 3
    assert transport.calls[0][1]["primary_release_year"] == 2009
    assert "year" not in transport.calls[0][1]


def test_tmdb_rejects_missing_credential_and_invalid_response():
    with pytest.raises(ValueError):
        TmdbMetadataProvider("", Transport({}))
    with pytest.raises(ProviderResponseError):
        TmdbMetadataProvider("key", Transport({"bad": []})).search_movie(QUERY)


def test_tmdb_details_extracts_alternative_and_translated_titles():
    transport = Transport(
        {
            "id": 10,
            "title": "El viaje",
            "original_title": "The Journey",
            "release_date": "2020-01-01",
            "alternative_titles": {
                "titles": [{"iso_3166_1": "MX", "title": "Viaje", "type": "short"}]
            },
            "translations": {
                "translations": [
                    {
                        "iso_639_1": "en",
                        "iso_3166_1": "US",
                        "data": {"title": "The Journey"},
                    },
                    {
                        "iso_639_1": "es",
                        "iso_3166_1": "ES",
                        "data": {"title": "El viaje"},
                    },
                ]
            },
        }
    )

    result = TmdbMetadataProvider("hidden", transport).get_movie_details("10")

    assert result.spanish_title == "El viaje"
    assert result.english_title == "The Journey"
    assert {alias.title for alias in result.title_aliases} == {
        "Viaje",
        "The Journey",
        "El viaje",
    }
    assert {alias.country for alias in result.title_aliases} >= {"MX", "US", "ES"}


def test_tmdb_reads_credential_from_environment_without_default(monkeypatch):
    monkeypatch.delenv("TMDB_API_KEY", raising=False)
    with pytest.raises(ValueError):
        TmdbMetadataProvider.from_environment(Transport({}))
    monkeypatch.setenv("TMDB_API_KEY", "controlled-test-key")
    assert TmdbMetadataProvider.from_environment(Transport({})).name == "tmdb"


def test_contaminated_negative_cache_does_not_block_clean_title_or_new_version():
    fake = FakeMetadataProvider()
    cache = InMemoryMetadataCache()
    provider = CachedMetadataProvider(fake, cache, clock=lambda: NOW)
    contaminated = IdentificationQuery(
        "1009-MAKE IT RIGHT THE SERIES series",
        SearchKind.SERIES,
        query_variant="legacy_contaminated",
        normalizer_version="mce-filename-normalizer-v2",
    )
    clean = IdentificationQuery(
        "Make It Right The Series",
        SearchKind.SERIES,
        query_variant="clean_title",
        normalizer_version="mce-filename-normalizer-v3",
    )

    assert provider.search_series(contaminated) == ()
    assert provider.search_series(contaminated) == ()
    assert fake.calls == 1
    assert provider.search_series(clean) == ()
    assert fake.calls == 2


def test_yearless_and_structured_year_queries_have_separate_cache_entries():
    fake = FakeMetadataProvider()
    cache = InMemoryMetadataCache()
    provider = CachedMetadataProvider(fake, cache, clock=lambda: NOW)
    without_year = IdentificationQuery(
        "Rambo 1", SearchKind.MOVIE, query_variant="clean_title"
    )
    with_year = IdentificationQuery(
        "Rambo 1",
        SearchKind.MOVIE,
        year=1990,
        query_variant="structured_year_hint",
    )

    provider.search_movie(without_year)
    provider.search_movie(without_year)
    provider.search_movie(with_year)
    provider.search_movie(with_year)

    assert fake.calls == 2
