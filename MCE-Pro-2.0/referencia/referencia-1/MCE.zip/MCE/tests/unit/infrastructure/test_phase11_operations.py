"""Backup, diagnóstico y mantenimiento sin procesos reales."""

import json
import sqlite3
import subprocess
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from mce.infrastructure.operations import (
    HealthCheck,
    HealthService,
    MaintenanceService,
    PostgresBackupService,
)


class FakeRunner:
    def __init__(self) -> None:
        self.commands: list[list[str]] = []
        self.environments: list[dict[str, str]] = []

    def __call__(self, command, **kwargs):
        values = list(command)
        self.commands.append(values)
        if "pg_dump" in values[0]:
            Path(values[values.index("--file") + 1]).write_bytes(b"PGDMP-test")
        if "env" in kwargs:
            self.environments.append(kwargs["env"])
        return subprocess.CompletedProcess(values, 0, "ok", "")


def test_backup_uses_official_tools_without_password_in_command(tmp_path: Path) -> None:
    runner = FakeRunner()
    service = PostgresBackupService(runner)
    raw_url = "postgresql+psycopg://tester:very-secret@localhost:5432/mce_test"
    target = tmp_path / "mce.dump"
    result = service.create(raw_url, target)
    assert result.success and target.read_bytes() == b"PGDMP-test"
    assert all("very-secret" not in part for part in runner.commands[0])
    assert runner.environments[0]["PGPASSWORD"] == "very-secret"
    assert service.validate(target).success
    assert service.restore(raw_url, target).success
    master_url = raw_url.replace("mce_test", "mce")
    with pytest.raises(ValueError, match="explicit authorization"):
        service.restore(master_url, target)
    assert service.restore(master_url, target, allow_master=True).success
    with pytest.raises(ValueError, match="mce_test or mce"):
        service.restore(raw_url.replace("mce_test", "mce_master"), target)


def test_maintenance_detects_interruption_archives_terminal_and_clears_cache(
    tmp_path: Path,
) -> None:
    checkpoints = tmp_path / "checkpoints"
    checkpoints.mkdir()
    running = checkpoints / "running.json"
    running.write_text(json.dumps({"session": {"status": "running"}}), encoding="utf-8")
    terminal = checkpoints / "done.json"
    terminal.write_text(json.dumps({"session": {"status": "completed"}}), encoding="utf-8")
    (checkpoints / "broken.json").write_text("{bad", encoding="utf-8")
    service = MaintenanceService()
    report = service.inspect_checkpoints(checkpoints)
    assert report.interrupted_sessions == ("running",)
    assert report.invalid_checkpoints == ("broken.json",)
    archived = service.archive_session(terminal, tmp_path / "archive")
    assert archived.is_file() and not terminal.exists()
    with pytest.raises(ValueError, match="terminal"):
        service.archive_session(running, tmp_path / "archive")

    cache = tmp_path / "cache.sqlite3"
    with sqlite3.connect(cache) as connection:
        connection.execute("CREATE TABLE metadata_cache(cache_key TEXT, created_at TEXT)")
        connection.execute(
            "INSERT INTO metadata_cache VALUES(?, ?)",
            ("old", (datetime.now(UTC) - timedelta(days=90)).isoformat()),
        )
    assert service.clear_expired_cache(cache, older_than=datetime.now(UTC)) == 1


def test_health_report_contains_no_credentials(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv(
        "MCE_TEST_DATABASE_URL",
        "postgresql+psycopg://tester:very-secret@localhost:5432/mce_test",
    )

    def database_checks(_root):
        return (
            HealthCheck("postgresql", "ok", "disponible"),
            HealthCheck("migrations", "ok", "al día"),
        )

    report = HealthService(database_checks).inspect(tmp_path, tmp_path / "missing.sqlite3")
    rendered = " ".join(item.message for item in report.checks)
    assert report.healthy
    assert "very-secret" not in rendered
    assert any(item.name == "postgresql" and item.status == "ok" for item in report.checks)
