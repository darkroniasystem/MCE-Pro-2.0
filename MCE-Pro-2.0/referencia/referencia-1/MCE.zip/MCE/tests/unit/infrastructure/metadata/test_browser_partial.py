from datetime import UTC, datetime

from mce.application.enrichment.models import FieldLockState, MetadataField, ReviewItem
from mce.application.enrichment.service import MetadataConsolidator
from mce.domain.value_objects import ConfidenceScore, FieldProvenance, FieldSourceType
from mce.infrastructure.metadata.browser_extractor import (
    BrowserPageExtraction,
    ExtractedBrowserEvidence,
)
from mce.infrastructure.metadata.browser_partial import (
    BrowserPartialEnrichmentMapper,
    BrowserQwenEvidenceAdapter,
)
from mce.infrastructure.metadata.browser_search import BrowserSearchStatus

NOW = datetime(2026, 8, 14, 12, tzinfo=UTC)


def full_evidence(**changes):
    values = {
        "title": "Vincenzo",
        "source_url": "https://example.test/vincenzo",
        "snippet": "Dorama coreano de 2021",
        "year": 2021,
        "media_type": "dorama",
        "seasons": 1,
        "genres": ("Drama", "Comedia"),
        "cast": ("Song Joong-ki", "Jeon Yeo-been"),
        "rating": 8.4,
        "platforms": ("Netflix",),
        "alternate_titles": ("빈센조", "Binsenjo"),
        "visible_text": "evidencia",
        "origin": "organic",
    }
    values.update(changes)
    return ExtractedBrowserEvidence(**values)


def extraction(evidence, status=BrowserSearchStatus.PARTIAL):
    return BrowserPageExtraction(status, tuple(evidence), "página")


def test_maps_only_demonstrated_fields_with_existing_field_provenance() -> None:
    result = BrowserPartialEnrichmentMapper(lambda: NOW).map(extraction((full_evidence(),)))

    assert len(result) == 1
    partial = result[0]
    assert partial.fields["title"].value == "Vincenzo"
    assert partial.fields["season_count"].value == 1
    assert partial.fields["ratings"].value == (("browser_search", "8.4"),)
    assert partial.fields["aliases"].value == ("빈센조", "Binsenjo")
    assert "poster" not in partial.fields
    assert "duration_minutes" not in partial.fields
    assert "episode_count" not in partial.fields
    assert "director" not in partial.fields
    assert partial.is_partial

    provenance = partial.fields["year"].provenance
    assert provenance.source_type is FieldSourceType.PROVIDER
    assert provenance.source_name == "browser_search"
    assert provenance.external_reference == "https://example.test/vincenzo"
    assert provenance.obtained_at == NOW
    assert provenance.confidence is None


def test_panel_without_url_preserves_partial_data_and_does_not_invent_reference() -> None:
    evidence = full_evidence(
        source_url="",
        year=None,
        seasons=None,
        genres=(),
        rating=None,
        platforms=(),
        alternate_titles=(),
        origin="knowledge_panel",
    )

    partial = BrowserPartialEnrichmentMapper(lambda: NOW).map(extraction((evidence,)))[0]

    assert partial.source_url is None
    assert "source_url" not in partial.fields
    assert "year" not in partial.fields
    assert partial.fields["title"].provenance.external_reference is None
    assert partial.origin == "knowledge_panel"


def test_non_evidence_statuses_do_not_create_partial_metadata() -> None:
    mapper = BrowserPartialEnrichmentMapper(lambda: NOW)
    for status in (
        BrowserSearchStatus.NO_EVIDENCE,
        BrowserSearchStatus.CAPTCHA,
        BrowserSearchStatus.BLOCKED,
        BrowserSearchStatus.RATE_LIMITED,
        BrowserSearchStatus.TIMEOUT,
        BrowserSearchStatus.UNAVAILABLE,
    ):
        assert mapper.map(extraction((full_evidence(),), status)) == ()


def test_existing_consolidator_fills_absent_fields_without_bypassing_manual_lock() -> None:
    manual = FieldProvenance(
        FieldSourceType.MANUAL,
        "user",
        None,
        NOW,
        ConfidenceScore(100),
    )
    item = ReviewItem(
        "review-1",
        "candidate-1",
        {
            "title": MetadataField("Título manual", manual, FieldLockState.MANUAL_LOCKED),
        },
    )
    partial = BrowserPartialEnrichmentMapper(lambda: NOW).map(extraction((full_evidence(),)))[0]

    merged = MetadataConsolidator().merge(item, partial.fields)

    assert merged.fields["title"].value == "Título manual"
    assert merged.fields["year"].value == 2021
    assert merged.fields["genres"].value == ("Drama", "Comedia")
    assert any(conflict.field_name == "title" for conflict in merged.conflicts)


def test_each_source_keeps_its_own_field_provenance() -> None:
    first = full_evidence()
    second = full_evidence(
        title="Vincenzo ficha 2",
        source_url="https://second.test/vincenzo",
        year=None,
        rating=None,
    )

    result = BrowserPartialEnrichmentMapper(lambda: NOW).map(extraction((first, second)))

    assert len(result) == 2
    assert result[0].fields["year"].provenance.external_reference == first.source_url
    assert "year" not in result[1].fields
    assert result[1].fields["title"].provenance.external_reference == second.source_url


def test_completeness_is_descriptive_and_not_identity_confidence() -> None:
    partial = BrowserPartialEnrichmentMapper(lambda: NOW).map(extraction((full_evidence(),)))[0]

    assert 0 < partial.completeness_percent < 100
    assert partial.fields["title"].provenance.confidence is None


def test_adapts_partial_browser_evidence_to_qwen_without_inventing_fields() -> None:
    partial = BrowserPartialEnrichmentMapper(lambda: NOW).map(
        extraction((full_evidence(),))
    )[0]

    evidence = BrowserQwenEvidenceAdapter.adapt((partial,))[0]

    assert evidence.provider == "browser_search"
    assert evidence.url == "https://example.test/vincenzo"
    assert evidence.year == 2021
    assert evidence.seasons == (1,)
    assert evidence.cast == ("Song Joong-ki", "Jeon Yeo-been")
    assert evidence.rating == 8.4
    assert evidence.origin == "organic"
