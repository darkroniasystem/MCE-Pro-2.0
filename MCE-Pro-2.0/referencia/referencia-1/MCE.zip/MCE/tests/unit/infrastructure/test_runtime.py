"""Rutas y logging seguros para desarrollo y ejecutable."""

import logging
from pathlib import Path

import pytest

from mce.infrastructure.runtime import (
    RuntimePaths,
    configure_logging,
    correlation_scope,
    resource_path,
)


def test_runtime_paths_are_isolated_from_current_directory(tmp_path: Path, monkeypatch) -> None:
    target = tmp_path / "user-data"
    monkeypatch.setenv("MCE_DATA_DIR", str(target))
    paths = RuntimePaths.discover()
    assert paths.data == target.resolve()
    assert paths.cache.is_dir()
    assert paths.checkpoints.is_dir()
    assert paths.originals.is_dir()
    assert paths.exports.is_dir()
    assert paths.logs.is_dir()


def test_legacy_data_is_copied_without_overwrite(tmp_path: Path, monkeypatch) -> None:
    project = tmp_path / "project"
    legacy = project / "data" / "session_checkpoints"
    legacy.mkdir(parents=True)
    (legacy / "one.json").write_text('{"value": 1}', encoding="utf-8")
    monkeypatch.setenv("MCE_DATA_DIR", str(tmp_path / "runtime"))
    paths = RuntimePaths.discover()
    assert paths.import_legacy(project) == 1
    (paths.checkpoints / "one.json").write_text('{"value": 2}', encoding="utf-8")
    assert paths.import_legacy(project) == 0
    assert "2" in (paths.checkpoints / "one.json").read_text(encoding="utf-8")


def test_resource_path_rejects_escape() -> None:
    assert resource_path("config/default_settings.json").name == "default_settings.json"
    with pytest.raises(ValueError, match="relative"):
        resource_path("../secret")


def test_rotating_log_redacts_credentials_and_adds_correlation(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("TMDB_API_KEY", "top-secret-key")
    destination = configure_logging(tmp_path)
    with correlation_scope("correlation-test"):
        logging.getLogger("mce.test").warning(
            "url=%s key=%s",
            "postgresql://user:password@localhost/mce_test",
            "top-secret-key",
        )
    logging.shutdown()
    content = destination.read_text(encoding="utf-8")
    assert "password" not in content
    assert "top-secret-key" not in content
    assert "postgresql://user:***@localhost/mce_test" in content
    assert "correlation=correlation-test" in content
