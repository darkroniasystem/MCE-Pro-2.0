from unittest.mock import MagicMock

from mce.infrastructure.database.session_ledger import PostgresSessionRepository


def test_list_summaries_never_recovers_interrupted_jobs() -> None:
    database = MagicMock()
    database.execute.return_value = ()
    context = MagicMock()
    context.__enter__.return_value = database
    factory = MagicMock(return_value=context)
    repository = PostgresSessionRepository(factory)
    repository.recover_interrupted = MagicMock(return_value=0)  # type: ignore[method-assign]

    assert repository.list_summaries() == ()
    repository.recover_interrupted.assert_not_called()
