import json
from pathlib import Path

import pytest

from mce.application.identification.models import IdentificationQuery, SearchKind
from mce.application.identification.service import ProviderResponseError
from mce.infrastructure.metadata.wikidata import (
    WikidataCandidateScorer,
    WikidataClient,
    WikidataEntityMapper,
    WikidataProviderConfig,
    WikidataResponseParser,
    WikidataSearchProvider,
)


class FixtureTransport:
    def __init__(self, entity_payload):
        self.entity_payload = entity_payload
        self.calls = []

    def get_json(self, path, params, timeout):
        self.calls.append((path, params, timeout))
        if params["action"] == "wbsearchentities":
            return {"search": [{"id": "Q130232994"}]}
        return self.entity_payload


@pytest.fixture
def entity_payload():
    path = Path(__file__).parents[3] / "fixtures" / "metadata" / "wikidata_old_guard.json"
    return json.loads(path.read_text(encoding="utf-8"))


def test_action_api_search_and_entity_calls_are_controlled(entity_payload):
    transport = FixtureTransport(entity_payload)
    config = WikidataProviderConfig(max_search_variants=2, max_candidates=4)
    provider = WikidataSearchProvider(WikidataClient(transport, config), config)

    rows = provider.search_movie(
        IdentificationQuery(
            "The Old Guard 2",
            SearchKind.MOVIE,
            2025,
            aliases=("The Old Guard II", "Old Guard 2"),
        )
    )

    assert len(rows) == 1
    assert [call[1]["action"] for call in transport.calls] == [
        "wbsearchentities",
        "wbsearchentities",
        "wbgetentities",
    ]
    assert all(call[0] == "/w/api.php" for call in transport.calls)


def test_mapper_preserves_titles_aliases_qid_and_external_ids(entity_payload):
    config = WikidataProviderConfig()
    entity = entity_payload["entities"]["Q130232994"]
    candidate = WikidataEntityMapper(config).map(entity, SearchKind.MOVIE)

    assert candidate is not None
    assert candidate.external_id == "Q130232994"
    assert candidate.spanish_title == "La vieja guardia 2"
    assert candidate.english_title == "The Old Guard 2"
    assert candidate.original_title == "The Old Guard 2"
    assert "The Old Guard II" in candidate.aliases
    assert ("wikidata", "Q130232994") in candidate.external_ids
    assert ("imdb", "tt14961624") in candidate.external_ids
    assert ("tmdb_movie", "846422") in candidate.external_ids
    assert candidate.year == 2025
    assert all(
        alias.provenance.startswith("wikidata:Q130232994") for alias in candidate.title_aliases
    )


@pytest.mark.parametrize("blocked_type", ["Q5", "Q7366", "Q482994", "Q571", "Q7889"])
def test_non_audiovisual_entities_are_rejected(entity_payload, blocked_type):
    entity = entity_payload["entities"]["Q130232994"]
    entity["claims"]["P31"][0]["mainsnak"]["datavalue"]["value"]["id"] = blocked_type

    assert WikidataEntityMapper(WikidataProviderConfig()).map(entity, SearchKind.MOVIE) is None


def test_wrong_audiovisual_type_is_rejected(entity_payload):
    entity = entity_payload["entities"]["Q130232994"]
    entity["claims"]["P31"][0]["mainsnak"]["datavalue"]["value"]["id"] = "Q5398426"

    assert WikidataEntityMapper(WikidataProviderConfig()).map(entity, SearchKind.MOVIE) is None


def test_score_rewards_alias_year_and_type(entity_payload):
    candidate = WikidataEntityMapper(WikidataProviderConfig()).map(
        entity_payload["entities"]["Q130232994"], SearchKind.MOVIE
    )
    assert candidate is not None
    score = WikidataCandidateScorer().score(
        IdentificationQuery("The Old Guard II", SearchKind.MOVIE, 2025),
        candidate,
    )
    wrong_year = WikidataCandidateScorer().score(
        IdentificationQuery("The Old Guard II", SearchKind.MOVIE, 1999),
        candidate,
    )

    assert score.alias_score == 1.0
    assert score.type_score == 1.0
    assert score.final_score > wrong_year.final_score
    assert score.final_score >= 0.9


def test_empty_valid_search_is_not_an_error():
    assert WikidataResponseParser.search_ids({"search": []}) == ()


@pytest.mark.parametrize("payload", [{}, [], {"error": {"code": "bad"}}])
def test_invalid_or_error_response_is_typed(payload):
    with pytest.raises(ProviderResponseError):
        WikidataResponseParser.search_ids(payload)


def test_sitelink_is_exposed_without_html_scraping(entity_payload):
    candidate = WikidataEntityMapper(WikidataProviderConfig()).map(
        entity_payload["entities"]["Q130232994"], SearchKind.MOVIE
    )

    assert candidate is not None
    assert candidate.source_url == "https://es.wikipedia.org/wiki/La_vieja_guardia_2"
