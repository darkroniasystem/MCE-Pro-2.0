"""Contratos controlados de los proveedores externos de Fase 10."""

import pytest

from mce.application.identification.models import IdentificationQuery, SearchKind
from mce.application.identification.service import ProviderResponseError
from mce.infrastructure.metadata.external_providers import (
    AniListMetadataProvider,
    FanartMetadataProvider,
    TvMazeMetadataProvider,
)


class Transport:
    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    def get_json(self, path, params, timeout, headers=None):
        self.calls.append(("GET", path, params))
        return self.payload

    def post_json(self, path, payload, timeout, headers=None):
        self.calls.append(("POST", path, payload))
        return self.payload


QUERY = IdentificationQuery("Avatar", SearchKind.MOVIE, 2009)


def test_fanart_selection_is_deterministic_and_deduplicated() -> None:
    provider = FanartMetadataProvider(
        "key",
        Transport(
            {
                "movieposter": [
                    {"url": "https://img/en.jpg", "lang": "en", "likes": "8"},
                    {"url": "https://img/es.jpg", "lang": "es", "likes": "2"},
                    {"url": "https://img/es.jpg", "lang": "es", "likes": "2"},
                ]
            }
        ),
    )
    assert provider.get_images("550", SearchKind.MOVIE) == (
        ("movieposter", "https://img/es.jpg"),
        ("movieposter", "https://img/en.jpg"),
    )


def test_anilist_uses_graphql_variables_and_strips_html() -> None:
    transport = Transport(
        {
            "data": {
                "Page": {
                    "media": [
                        {
                            "id": 16498,
                            "idMal": 16498,
                            "title": {
                                "romaji": "Shingeki no Kyojin",
                                "english": "Attack on Titan",
                                "native": "進撃の巨人",
                            },
                            "synonyms": ["AoT"],
                            "format": "TV",
                            "episodes": 25,
                            "duration": 24,
                            "seasonYear": 2013,
                            "genres": ["Action"],
                            "countryOfOrigin": "JP",
                            "description": "<b>Humanity</b> fights.",
                            "averageScore": 84,
                            "studios": {"nodes": [{"name": "Wit Studio"}]},
                            "coverImage": {"extraLarge": "https://img/poster.jpg"},
                            "bannerImage": None,
                        }
                    ]
                }
            }
        }
    )
    result = AniListMetadataProvider(transport).search_series(
        IdentificationQuery("Attack on Titan", SearchKind.ANIME, 2013)
    )[0]
    assert result.kind is SearchKind.ANIME and result.overview == "Humanity fights."
    assert transport.calls[0][2]["variables"]["search"] == "Attack on Titan"


def test_anilist_graphql_errors_are_rejected() -> None:
    with pytest.raises(ProviderResponseError, match="GraphQL"):
        AniListMetadataProvider(
            Transport({"data": None, "errors": [{"message": "bad"}]})
        ).search_series(IdentificationQuery("x", SearchKind.ANIME))


def test_tvmaze_maps_series_and_external_ids() -> None:
    provider = TvMazeMetadataProvider(
        Transport(
            [
                {
                    "score": 1,
                    "show": {
                        "id": 82,
                        "name": "Game of Thrones",
                        "premiered": "2011-04-17",
                        "genres": ["Drama"],
                        "summary": "<p>Winter.</p>",
                        "externals": {"imdb": "tt0944947", "thetvdb": 121361},
                        "image": {"original": "https://img/got.jpg"},
                        "rating": {"average": 9.0},
                        "network": {"name": "HBO", "country": {"code": "US"}},
                        "url": "https://www.tvmaze.com/shows/82/game-of-thrones",
                    },
                }
            ]
        )
    )
    candidate = provider.search_series(IdentificationQuery("Game of Thrones", SearchKind.SERIES))[0]
    assert ("imdb", "tt0944947") in candidate.external_ids
    assert candidate.networks == ("HBO",) and candidate.overview == "Winter."
