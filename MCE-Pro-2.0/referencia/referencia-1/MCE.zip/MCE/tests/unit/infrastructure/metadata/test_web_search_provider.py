import sqlite3
from dataclasses import replace
from datetime import timedelta

import pytest

from mce.infrastructure.metadata.web_search import (
    CachedWebSearchProvider,
    ExaWebSearchProvider,
    ResilientControlledWebSearchProvider,
    SequentialWebSearchProvider,
    SerperWebSearchProvider,
    TavilyWebSearchProvider,
    WebProviderRegistration,
)


class Transport:
    def __init__(self) -> None:
        self.calls = 0

    def post_json(self, path, payload, timeout, headers=None):
        self.calls += 1
        assert path == "/search"
        assert payload["include_answer"] is False
        assert payload["include_raw_content"] is False
        assert headers == {"Authorization": "Bearer secret"}
        return {
            "results": [
                {
                    "title": "Sandman (serie de televisión)",
                    "url": "https://one.example/sandman",
                    "content": "Serie estrenada en 2022",
                    "score": 0.93,
                },
                {
                    "title": "The Sandman",
                    "url": "https://two.example/title",
                    "content": "TV series 2022",
                    "score": 0.88,
                },
                {"title": "inseguro", "url": "http://bad.example"},
            ]
        }


def test_tavily_maps_multiple_safe_candidates_without_exposing_key() -> None:
    transport = Transport()
    result = TavilyWebSearchProvider("secret", transport).search("Sandman series 2022", limit=8)
    assert len(result) == 2
    assert result[0].source == "one.example"
    assert result[0].media_type == "series" and result[0].year == 2022
    assert result[0].provider == "tavily" and result[0].score == 93
    assert result[0].query == "Sandman series 2022"


def test_web_results_are_cached_independently_of_sessions(tmp_path) -> None:
    transport = Transport()
    controlled = ResilientControlledWebSearchProvider(
        TavilyWebSearchProvider("secret", transport)
    )
    cached = CachedWebSearchProvider(
        controlled,
        tmp_path / "metadata.sqlite3",
        ttl=timedelta(hours=1),
    )
    first = cached.search("Sandman series 2022", limit=8)
    second = cached.search("Sandman series 2022", limit=8)
    assert first == second
    assert transport.calls == 1 and controlled.calls == 1 and cached.last_from_cache


def test_web_cache_recovers_from_tampering_without_reusing_bad_evidence(tmp_path) -> None:
    transport = Transport()
    path = tmp_path / "tampered-web.sqlite3"
    cached = CachedWebSearchProvider(
        TavilyWebSearchProvider("secret", transport), path, ttl=timedelta(hours=1)
    )
    cached.search("Sandman series 2022", limit=8)
    with sqlite3.connect(path) as connection:
        connection.execute("UPDATE web_search_cache SET payload='{}'")

    recovered = CachedWebSearchProvider(
        TavilyWebSearchProvider("secret", transport), path, ttl=timedelta(hours=1)
    ).search("Sandman series 2022", limit=8)

    assert recovered
    assert transport.calls == 2


def test_web_cache_does_not_persist_transient_provider_failure(tmp_path) -> None:
    class Flaky:
        name = "web:flaky"

        def __init__(self) -> None:
            self.calls = 0

        def search(self, query, *, limit):
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("temporary failure")
            return ()

    provider = Flaky()
    cached = CachedWebSearchProvider(provider, tmp_path / "flaky.sqlite3")

    with pytest.raises(RuntimeError, match="temporary"):
        cached.search("obra", limit=5)
    assert cached.search("obra", limit=5) == ()
    assert cached.search("obra", limit=5) == ()
    assert provider.calls == 2
    assert cached.last_from_cache


def test_tavily_control_retries_transient_failure_without_real_requests() -> None:
    from mce.application.identification.service import ProviderTimeoutError

    class Flaky:
        name = "web:tavily"

        def __init__(self):
            self.calls = 0

        def search(self, query, *, limit):
            self.calls += 1
            if self.calls == 1:
                raise ProviderTimeoutError("timeout")
            return ()

    flaky = Flaky()
    waits = []
    controlled = ResilientControlledWebSearchProvider(
        flaky, retries=1, base_delay=0.1, sleep=waits.append
    )
    assert controlled.search("obra", limit=8) == ()
    assert flaky.calls == 2 and waits == [0.1]


class SerperTransport:
    def post_json(self, path, payload, timeout, headers=None):
        assert path == "/search" and payload == {"q": "Vagabond dorama 2019", "num": 3}
        assert headers == {"X-API-KEY": "secret"}
        return {
            "organic": [
                {
                    "title": "Vagabond (TV series)",
                    "link": "https://one.example/vagabond",
                    "snippet": "South Korean television series released in 2019",
                }
            ]
        }


class ExaTransport:
    def post_json(self, path, payload, timeout, headers=None):
        assert path == "/search" and payload["numResults"] == 3
        assert payload["contents"]["text"]["maxCharacters"] == 500
        assert headers == {"x-api-key": "secret"}
        return {
            "results": [
                {
                    "title": "Vagabond Korean series",
                    "url": "https://two.example/vagabond",
                    "text": "A 2019 television series",
                    "score": 0.91,
                }
            ]
        }


def test_serper_and_exa_map_safe_evidence_without_exposing_keys() -> None:
    serper = SerperWebSearchProvider("secret", SerperTransport()).search(
        "Vagabond dorama 2019", limit=3
    )
    exa = ExaWebSearchProvider(
        "secret", ExaTransport(), max_characters=500
    ).search("Vagabond dorama 2019", limit=3)
    assert serper[0].provider == "serper" and serper[0].year == 2019
    assert exa[0].provider == "exa" and exa[0].score == 91


def test_serper_limits_content_and_uses_result_date_defensively() -> None:
    class DefensiveTransport:
        def post_json(self, path, payload, timeout, headers=None):
            return {
                "organic": [
                    None,
                    {"title": "inseguro", "link": "http://bad.example"},
                    {
                        "title": "Vagabond",
                        "link": "https://safe.example/vagabond",
                        "snippet": "Dorama coreano " + "x" * 300,
                        "date": "2019",
                    },
                ]
            }

    result = SerperWebSearchProvider(
        "secret", DefensiveTransport(), max_characters=100
    ).search("Vagabond", limit=5)

    assert len(result) == 1 and len(result[0].description) == 100
    assert result[0].year == 2019 and result[0].source_url.startswith("https://")


def test_exa_uses_highlights_and_published_date_when_text_is_missing() -> None:
    class DefensiveTransport:
        def post_json(self, path, payload, timeout, headers=None):
            return {
                "results": [
                    {"title": "sin URL"},
                    {
                        "title": "Vagabond",
                        "url": "https://safe.example/vagabond",
                        "highlights": ["South Korean television series"],
                        "publishedDate": "2019-09-20",
                        "score": "unexpected",
                    },
                ]
            }

    result = ExaWebSearchProvider(
        "secret", DefensiveTransport(), max_characters=200
    ).search("Vagabond", limit=5)

    assert len(result) == 1 and result[0].year == 2019
    assert "South Korean television series" in result[0].description


def test_rate_limit_is_not_retried_and_quota_is_reported() -> None:
    from mce.application.identification.service import ProviderRateLimitError

    class Limited:
        name = "web:serper"

        def __init__(self):
            self.calls = 0

        def search(self, query, *, limit):
            self.calls += 1
            raise ProviderRateLimitError("Serper: quota exhausted")

    limited = Limited()
    waits: list[float] = []
    controlled = ResilientControlledWebSearchProvider(
        limited, retries=3, base_delay=0.1, sleep=waits.append
    )

    with pytest.raises(ProviderRateLimitError):
        controlled.search("obra", limit=3)

    state = controlled.telemetry("serper")
    assert limited.calls == 1 and controlled.http_calls == 1 and waits == []
    assert state.rate_limit_hits == 1 and state.quota_exhausted_count == 1
    assert state.last_error == "quota_exhausted"


def test_multi_provider_continues_after_rate_limit_without_duplicate_retry() -> None:
    from mce.application.identification.service import ProviderRateLimitError

    class Limited:
        name = "web:serper"

        def __init__(self):
            self.calls = 0

        def search(self, query, *, limit):
            self.calls += 1
            raise ProviderRateLimitError("429")

    evidence = TavilyWebSearchProvider("secret", Transport()).search("Sandman", limit=8)
    limited = Limited()

    class Successful:
        name = "web:exa"

        def search(self, query, *, limit):
            return evidence

    controlled = ResilientControlledWebSearchProvider(limited, retries=3)
    manager = SequentialWebSearchProvider(
        (
            WebProviderRegistration(controlled, "serper", True, 10),
            WebProviderRegistration(Successful(), "exa", True, 20),
        )
    )

    assert manager.search("Sandman", limit=8) == evidence
    assert limited.calls == 1
    assert [attempt.status for attempt in manager.last_attempts] == [
        "rate_limited",
        "sufficient",
    ]


def test_multi_provider_stops_after_first_sufficient_result() -> None:
    calls: list[str] = []

    class Provider:
        def __init__(self, name, result):
            self.name, self.result = name, result

        def search(self, query, *, limit):
            calls.append(self.name)
            return self.result

    first = Provider("web:tavily", ())
    evidence = TavilyWebSearchProvider("secret", Transport()).search(
        "Sandman series 2022", limit=8
    )
    third = Provider("web:exa", evidence)
    manager = SequentialWebSearchProvider(
        (
            WebProviderRegistration(first, "tavily", True, 10),
            WebProviderRegistration(Provider("web:serper", evidence), "serper", True, 20),
            WebProviderRegistration(third, "exa", True, 30),
        )
    )
    assert manager.search("Sandman", limit=8) == evidence
    assert calls == ["web:tavily", "web:serper"]
    assert [item.status for item in manager.last_attempts] == [
        "insufficient",
        "sufficient",
    ]


def test_multi_provider_accumulates_complementary_evidence_before_stopping() -> None:
    calls: list[str] = []
    evidence = TavilyWebSearchProvider("secret", Transport()).search("Sandman", limit=8)

    class Provider:
        def __init__(self, name, result):
            self.name, self.result = name, result

        def search(self, query, *, limit):
            calls.append(self.name)
            return self.result

    manager = SequentialWebSearchProvider(
        (
            WebProviderRegistration(Provider("web:tavily", evidence[:1]), "tavily", True, 10),
            WebProviderRegistration(Provider("web:serper", evidence[1:]), "serper", True, 20),
            WebProviderRegistration(Provider("web:exa", ()), "exa", True, 30),
        )
    )

    result = manager.search("Sandman", limit=8)

    assert result == evidence
    assert calls == ["web:tavily", "web:serper"]
    assert [attempt.new_result_count for attempt in manager.last_attempts] == [1, 1]
    assert [attempt.accumulated_result_count for attempt in manager.last_attempts] == [1, 2]


def test_multi_provider_deduplicates_normalized_urls_and_preserves_domain_diversity() -> None:
    calls: list[str] = []
    evidence = TavilyWebSearchProvider("secret", Transport()).search("Sandman", limit=8)
    duplicate = replace(
        evidence[0], source_url="https://ONE.example/sandman/#same", provider="serper"
    )

    class Provider:
        def __init__(self, name, result):
            self.name, self.result = name, result

        def search(self, query, *, limit):
            calls.append(self.name)
            return self.result

    manager = SequentialWebSearchProvider(
        (
            WebProviderRegistration(Provider("web:tavily", evidence[:1]), "tavily", True, 10),
            WebProviderRegistration(Provider("web:serper", (duplicate,)), "serper", True, 20),
            WebProviderRegistration(Provider("web:exa", evidence[1:]), "exa", True, 30),
        )
    )

    result = manager.search("Sandman", limit=2)

    assert result == evidence
    assert calls == ["web:tavily", "web:serper", "web:exa"]
    assert [attempt.new_result_count for attempt in manager.last_attempts] == [1, 0, 1]


def test_web_provider_telemetry_exposes_common_runtime_state() -> None:
    from mce.application.identification.service import ProviderTimeoutError

    class Failing:
        name = "web:tavily"
        timeout = 7

        def search(self, query, *, limit):
            raise ProviderTimeoutError("timeout")

    clock = [100.0]
    controlled = ResilientControlledWebSearchProvider(
        Failing(),
        retries=0,
        failure_threshold=1,
        cooldown_seconds=30,
        monotonic=lambda: clock[0],
    )
    with pytest.raises(ProviderTimeoutError):
        controlled.search("obra", limit=3)

    state = controlled.telemetry("tavily", priority=10, cache_hits=4)

    assert state.provider_id == "tavily" and state.timeout == 7
    assert state.total_requests == 1 and state.total_failures == 1
    assert state.consecutive_failures == 1 and state.circuit_state == "open"
    assert state.cooldown_until == 130 and state.cache_hits == 4
    clock[0] = 131
    assert controlled.telemetry("tavily").circuit_state == "half-open"


def test_shared_cache_reuses_legacy_tavily_entry_for_multi_provider(tmp_path) -> None:
    transport = Transport()
    legacy = CachedWebSearchProvider(
        ResilientControlledWebSearchProvider(
            TavilyWebSearchProvider("secret", transport)
        ),
        tmp_path / "metadata.sqlite3",
        ttl=timedelta(hours=1),
    )
    expected = legacy.search("Sandman series 2022", limit=8)

    class NeverCalled:
        name = "web:multi-v1"

        def search(self, query, *, limit):
            raise AssertionError("legacy cache should avoid all providers")

    shared = CachedWebSearchProvider(
        NeverCalled(), tmp_path / "metadata.sqlite3", ttl=timedelta(hours=1)
    )
    assert shared.search("Sandman series 2022", limit=8) == expected
    assert shared.last_from_cache
