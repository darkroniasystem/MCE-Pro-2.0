from datetime import UTC, datetime

from sqlalchemy import create_engine, func, select
from sqlalchemy.orm import Session, sessionmaker

from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.infrastructure.database.metadata_persistence import MetadataPersistenceService
from mce.infrastructure.database.models import (
    BankModel,
    Base,
    CanonicalWorkModel,
    ContentModel,
)
from mce.infrastructure.database.repositories import MetadataCatalogRepository


def test_same_external_identity_reuses_canonical_work_across_banks() -> None:
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    candidate = ProviderCandidate(
        provider="tmdb",
        external_id="1399",
        kind=SearchKind.SERIES,
        title="Game of Thrones",
        year=2011,
    )
    now = datetime.now(UTC)
    with Session(engine) as session:
        session.add_all(
            (
                BankModel(
                    id="00000000-0000-0000-0000-000000000001",
                    name="A",
                    code=None,
                    branch=None,
                    status="active",
                    created_at=now,
                ),
                BankModel(
                    id="00000000-0000-0000-0000-000000000002",
                    name="B",
                    code=None,
                    branch=None,
                    status="active",
                    created_at=now,
                ),
            )
        )
        repository = MetadataCatalogRepository(session)
        first = repository.save_candidate(
            candidate,
            bank_id="00000000-0000-0000-0000-000000000001",
            alias="Juego de Tronos",
        )
        second = repository.save_candidate(
            candidate,
            bank_id="00000000-0000-0000-0000-000000000002",
            alias="Game of Thrones",
        )
        session.flush()

        assert first.id != second.id
        assert first.bank_id != second.bank_id
        assert first.canonical_work_id == second.canonical_work_id
        assert session.scalar(select(func.count()).select_from(CanonicalWorkModel)) == 1
        assert session.scalar(select(func.count()).select_from(ContentModel)) == 2


def test_same_bank_reimport_is_idempotent_for_content_and_canonical_identity() -> None:
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    candidate = ProviderCandidate(
        provider="tmdb",
        external_id="550",
        kind=SearchKind.MOVIE,
        title="Fight Club",
        year=1999,
    )
    now = datetime.now(UTC)
    with Session(engine) as session:
        bank_id = "00000000-0000-0000-0000-000000000003"
        session.add(
            BankModel(
                id=bank_id,
                name="C",
                code=None,
                branch=None,
                status="active",
                created_at=now,
            )
        )
        repository = MetadataCatalogRepository(session)
        first = repository.save_candidate(candidate, bank_id=bank_id, alias="Fight Club")
        second = repository.save_candidate(candidate, bank_id=bank_id, alias="Fight Club")
        session.flush()

        assert first.id == second.id
        assert session.scalar(select(func.count()).select_from(ContentModel)) == 1
        assert session.scalar(select(func.count()).select_from(CanonicalWorkModel)) == 1


def test_confirmed_global_alias_resolves_identity_for_another_bank_without_provider() -> None:
    engine = create_engine("sqlite+pysqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = sessionmaker(engine, expire_on_commit=False)
    candidate = ProviderCandidate(
        provider="tmdb",
        external_id="1399",
        kind=SearchKind.SERIES,
        title="Game of Thrones",
        translated_titles=("Juego de Tronos",),
        year=2011,
    )
    now = datetime.now(UTC)
    with factory() as session:
        session.add(
            BankModel(
                id="00000000-0000-0000-0000-000000000010",
                name="A",
                code=None,
                branch=None,
                status="active",
                created_at=now,
            )
        )
        MetadataCatalogRepository(session).save_candidate(
            candidate,
            bank_id="00000000-0000-0000-0000-000000000010",
            alias="Game of Thrones",
        )
        session.commit()

    found = MetadataPersistenceService(factory).find_known_candidate(
        "Juego de Tronos",
        SearchKind.SERIES,
        "00000000-0000-0000-0000-000000000099",
    )

    assert found is not None
    assert found.provider == "tmdb"
    assert found.external_id == "1399"
