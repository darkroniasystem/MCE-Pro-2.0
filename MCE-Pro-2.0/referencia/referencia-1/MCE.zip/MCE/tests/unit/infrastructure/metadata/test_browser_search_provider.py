import base64

import pytest

from mce.application.identification.service import (
    ProviderConfigurationError,
    ProviderOfflineError,
    ProviderTimeoutError,
)
from mce.infrastructure.metadata.browser_search import (
    BrowserSearchHit,
    BrowserSearchProvider,
    BrowserSearchResponse,
    BrowserSearchSettings,
    BrowserSearchStatus,
    UnavailableBrowserAutomationBackend,
)
from mce.infrastructure.metadata.web_search import (
    SequentialWebSearchProvider,
    WebProviderRegistration,
)


class Backend:
    def __init__(self, response: BrowserSearchResponse) -> None:
        self.response = response
        self.calls = 0

    def search(self, query, *, limit, settings):
        self.calls += 1
        assert settings.max_concurrency == 1
        return self.response


def settings(**changes) -> BrowserSearchSettings:
    values = {
        "enabled": True,
        "headless": True,
        "timeout_seconds": 10,
        "max_concurrency": 1,
        "delay_min_ms": 1_000,
        "delay_max_ms": 2_500,
        "max_results": 3,
        "max_page_text_chars": 100,
    }
    values.update(changes)
    return BrowserSearchSettings(**values)


def test_browser_maps_partial_dom_evidence_without_inventing_missing_fields() -> None:
    backend = Backend(
        BrowserSearchResponse(
            BrowserSearchStatus.PARTIAL,
            (
                BrowserSearchHit(
                    "Vincenzo",
                    "https://example.test/vincenzo",
                    "Serie coreana estrenada en 2021",
                    media_type="dorama",
                    score=98,
                ),
                BrowserSearchHit("inseguro", "http://unsafe.test"),
            ),
        )
    )
    provider = BrowserSearchProvider(backend, settings())

    result = provider.search("Vincenzo 2021 serie coreana", limit=8)

    assert len(result) == 1 and result[0].provider == "browser_search"
    assert result[0].year == 2021 and result[0].media_type == "dorama"
    assert backend.calls == 1 and provider.last_status is BrowserSearchStatus.PARTIAL


@pytest.mark.parametrize(
    ("status", "expected"),
    [
        (BrowserSearchStatus.CAPTCHA, ProviderOfflineError),
        (BrowserSearchStatus.BLOCKED, ProviderOfflineError),
        (BrowserSearchStatus.TIMEOUT, ProviderTimeoutError),
    ],
)
def test_browser_reports_blocking_states_without_bypass(status, expected) -> None:
    provider = BrowserSearchProvider(
        Backend(BrowserSearchResponse(status, message=f"Browser: {status.value}")),
        settings(),
    )

    with pytest.raises(expected, match=status.value):
        provider.search("obra", limit=3)


def test_browser_unavailable_and_disabled_are_explicit() -> None:
    unavailable = BrowserSearchProvider(
        UnavailableBrowserAutomationBackend("Playwright no disponible"), settings()
    )
    with pytest.raises(ProviderConfigurationError, match="Playwright no disponible"):
        unavailable.search("obra", limit=3)

    disabled = BrowserSearchProvider(
        Backend(BrowserSearchResponse(BrowserSearchStatus.SUCCESS)),
        settings(enabled=False),
    )
    with pytest.raises(ProviderConfigurationError, match="deshabilitado"):
        disabled.search("obra", limit=3)


def test_browser_returns_empty_for_no_evidence() -> None:
    provider = BrowserSearchProvider(
        Backend(BrowserSearchResponse(BrowserSearchStatus.NO_EVIDENCE)), settings()
    )
    assert provider.search("obra", limit=3) == ()


def test_browser_discards_unrelated_results_and_unwraps_relevant_bing_url() -> None:
    destination = "https://example.test/vincenzo"
    encoded = base64.urlsafe_b64encode(destination.encode()).decode().rstrip("=")
    backend = Backend(
        BrowserSearchResponse(
            BrowserSearchStatus.PARTIAL,
            (
                BrowserSearchHit(
                    "YouTube",
                    "https://www.youtube.com/",
                    "Enjoy videos and music",
                ),
                BrowserSearchHit(
                    "Vincenzo Korean drama",
                    f"https://www.bing.com/ck/a?u=a1{encoded}&ntb=1",
                    "Vincenzo serie coreana 2021",
                ),
            ),
        )
    )
    provider = BrowserSearchProvider(backend, settings())

    result = provider.search("Vincenzo dorama 2021", limit=3)

    assert len(result) == 1
    assert result[0].title == "Vincenzo Korean drama"
    assert result[0].source_url == destination


def test_browser_marks_unrelated_batch_as_no_evidence() -> None:
    provider = BrowserSearchProvider(
        Backend(
            BrowserSearchResponse(
                BrowserSearchStatus.PARTIAL,
                (
                    BrowserSearchHit(
                        "Capital One",
                        "https://capitalone.example/",
                        "Checking and savings accounts",
                    ),
                ),
            )
        ),
        settings(),
    )

    assert provider.search("Spirited Away anime 2001", limit=3) == ()
    assert provider.last_status is BrowserSearchStatus.NO_EVIDENCE
    assert "no relacionada" in provider.last_message


def test_browser_requires_two_distinctive_terms_for_multilingual_long_query() -> None:
    provider = BrowserSearchProvider(
        Backend(
            BrowserSearchResponse(
                BrowserSearchStatus.PARTIAL,
                (
                    BrowserSearchHit(
                        "Money market news",
                        "https://finance.example/money",
                        "Money and banking coverage",
                    ),
                    BrowserSearchHit(
                        "Money Heist",
                        "https://catalog.example/money-heist",
                        "Spanish television series",
                    ),
                ),
            )
        ),
        settings(),
    )

    result = provider.search("La casa de papel Money Heist series 2017", limit=3)

    assert [item.title for item in result] == ["Money Heist"]


def test_browser_runs_only_after_api_evidence_remains_insufficient() -> None:
    calls: list[str] = []

    class EmptyProvider:
        def __init__(self, name: str) -> None:
            self.name = name

        def search(self, query, *, limit):
            calls.append(self.name)
            return ()

    backend = Backend(
        BrowserSearchResponse(
            BrowserSearchStatus.SUCCESS,
            (
                BrowserSearchHit("Vincenzo", "https://one.test/vincenzo", "Dorama 2021"),
                BrowserSearchHit("Vincenzo", "https://two.test/vincenzo", "Serie 2021"),
            ),
        )
    )
    browser = BrowserSearchProvider(backend, settings())
    manager = SequentialWebSearchProvider(
        (
            WebProviderRegistration(EmptyProvider("tavily"), "tavily", True, 10),
            WebProviderRegistration(EmptyProvider("serper"), "serper", True, 20),
            WebProviderRegistration(EmptyProvider("exa"), "exa", True, 30),
            WebProviderRegistration(browser, "browser", True, 40),
        )
    )

    result = manager.search("Vincenzo", limit=5)

    assert calls == ["tavily", "serper", "exa"] and backend.calls == 1
    assert len(result) == 2 and manager.last_attempts[-1].provider_id == "browser"
