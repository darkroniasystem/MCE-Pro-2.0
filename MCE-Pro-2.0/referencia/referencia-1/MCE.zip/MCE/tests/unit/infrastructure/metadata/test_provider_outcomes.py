from tests.fakes import FakeMetadataProvider

from mce.application.identification import IdentificationService
from mce.application.identification.models import (
    IdentificationQuery,
    IdentificationStatus,
    ProviderCandidate,
    SearchKind,
)
from mce.application.identification.service import ProviderRateLimitError
from mce.infrastructure.metadata import (
    MetadataProviderManager,
    ProviderRegistration,
)


class RateLimitedProvider(FakeMetadataProvider):
    name = "tmdb"

    def search_movie(self, query):
        raise ProviderRateLimitError("límite temporal")


def test_rate_limit_is_waiting_and_never_not_found() -> None:
    provider = RateLimitedProvider()
    manager = MetadataProviderManager((ProviderRegistration(provider, movies=True, series=True),))

    result = IdentificationService(manager).identify(
        IdentificationQuery("The Old Guard 2", SearchKind.MOVIE, 2025)
    )

    assert result.status is IdentificationStatus.WAITING_RATE_LIMIT
    assert result.candidates == ()
    assert result.attempts[0].status.value == "rate_limited"


def test_empty_completed_provider_confirms_not_found() -> None:
    manager = MetadataProviderManager(
        (ProviderRegistration(FakeMetadataProvider(), movies=True, series=True),)
    )

    result = IdentificationService(manager).identify(
        IdentificationQuery("Obra inexistente controlada", SearchKind.MOVIE)
    )

    assert result.status is IdentificationStatus.NOT_FOUND_CONFIRMED
    assert result.attempts[0].status.value == "success_no_results"


def test_tmdb_no_results_allows_wikidata_fallback() -> None:
    tmdb = FakeMetadataProvider()
    tmdb.name = "tmdb"
    wikidata = FakeMetadataProvider(
        (
            ProviderCandidate(
                "wikidata",
                "Q130232994",
                SearchKind.MOVIE,
                "The Old Guard 2",
                year=2025,
                aliases=("The Old Guard II",),
            ),
        )
    )
    wikidata.name = "wikidata"
    manager = MetadataProviderManager(
        (
            ProviderRegistration(tmdb, movies=True, series=True, primary_for=(SearchKind.MOVIE,)),
            ProviderRegistration(wikidata, movies=True, series=True, role="complementary"),
        )
    )

    result = IdentificationService(manager).identify(
        IdentificationQuery("The Old Guard II", SearchKind.MOVIE, 2025)
    )

    assert result.status is IdentificationStatus.IDENTIFIED
    assert result.selected is not None
    assert result.selected.metadata.provider == "wikidata"
    assert result.candidates[0].metadata.provider == "wikidata"
    assert [attempt.status.value for attempt in result.attempts] == [
        "success_no_results",
        "success_with_results",
    ]


def test_tmdb_temporary_failure_keeps_wikidata_result_partial() -> None:
    tmdb = RateLimitedProvider()
    wikidata = FakeMetadataProvider(
        (
            ProviderCandidate(
                "wikidata",
                "Q130232994",
                SearchKind.MOVIE,
                "The Old Guard 2",
                year=2025,
            ),
        )
    )
    wikidata.name = "wikidata"
    manager = MetadataProviderManager(
        (
            ProviderRegistration(tmdb, movies=True, series=True, primary_for=(SearchKind.MOVIE,)),
            ProviderRegistration(wikidata, movies=True, series=True, role="complementary"),
        )
    )

    result = IdentificationService(manager).identify(
        IdentificationQuery("The Old Guard 2", SearchKind.MOVIE, 2025)
    )

    assert result.status is IdentificationStatus.PROVIDER_PARTIAL
    assert result.selected is not None
    assert result.attempts[0].status.value == "rate_limited"


def test_manager_resets_cache_telemetry_for_each_unique_work() -> None:
    provider = FakeMetadataProvider()
    provider.name = "cached:tmdb"
    provider.last_from_cache = True
    manager = MetadataProviderManager((ProviderRegistration(provider, movies=True, series=True),))
    manager.search_movie(IdentificationQuery("Primera", SearchKind.MOVIE))
    assert manager.last_from_cache
    provider.last_from_cache = False
    manager.search_movie(IdentificationQuery("Segunda", SearchKind.MOVIE))
    assert not manager.last_from_cache


def test_cached_empty_result_is_counted_as_a_cache_hit() -> None:
    provider = FakeMetadataProvider()
    provider.name = "cached:tmdb"
    provider.last_from_cache = True
    manager = MetadataProviderManager((ProviderRegistration(provider, movies=True, series=True),))

    result = IdentificationService(manager).identify(
        IdentificationQuery("Sin coincidencias", SearchKind.MOVIE)
    )

    assert result.status is IdentificationStatus.NOT_FOUND_CONFIRMED
    assert result.from_cache
