import json
import sqlite3
from contextlib import suppress
from pathlib import Path

from mce.application.ai_review import (
    PROMPT_VERSION,
    AIFieldEvidence,
    AIReviewDecision,
    AIReviewInput,
    AIReviewOrchestrator,
    AIReviewResult,
    AIReviewState,
    EvidenceSource,
    EvidenceValidator,
    ValidatedAnalyzerChain,
)
from mce.infrastructure.ai_review import SqliteAIReviewStore
from mce.infrastructure.local_ai import OllamaQwenAnalyzer


def source(domain: str) -> EvidenceSource:
    return EvidenceSource(
        f"https://{domain}/vagabond",
        "Vagabond",
        "Korean television series released in 2019",
        "test",
    )


def response(*urls: str, confidence: float = 98) -> dict[str, object]:
    proposal = {
        "status": "matched",
        "canonical_title": "Vagabond",
        "original_title": "배가본드",
        "year": 2019,
        "media_type": "dorama",
        "confidence": confidence,
        "matched_sources": [
            {
                "url": url,
                "evidence": "2019 Korean television series",
            }
            for url in urls
        ],
        "conflicts": [],
        "reasoning_summary": "Two sources agree.",
        "recommended_action": "accept",
    }
    return {"message": {"content": json.dumps(proposal)}}


class Ollama:
    def __init__(self, replies):
        self.replies = list(replies)
        self.chat_calls = 0
        self.payloads = []

    def tags(self, timeout):
        return {"models": [{"name": "qwen2.5:3b"}]}

    def chat(self, payload, timeout):
        self.chat_calls += 1
        self.payloads.append(payload)
        return self.replies.pop(0)


class OfflineOllama:
    def __init__(self) -> None:
        self.tags_calls = 0
        self.chat_calls = 0

    def tags(self, timeout):
        self.tags_calls += 1
        assert timeout <= 3
        raise RuntimeError("Ollama no está disponible")

    def chat(self, payload, timeout):
        self.chat_calls += 1
        raise AssertionError("the slow inference call must be skipped while Ollama is offline")


def test_ollama_diagnostic_requires_model_and_real_inference() -> None:
    transport = Ollama([{"message": {"content": "OK"}}])
    analyzer = OllamaQwenAnalyzer(transport)
    diagnostic = analyzer.diagnose()
    assert diagnostic.connected and diagnostic.model_present and diagnostic.inference_ok


def test_qwen_preflight_opens_circuit_immediately_when_ollama_is_offline() -> None:
    transport = OfflineOllama()
    analyzer = OllamaQwenAnalyzer(transport, timeout=120, cooldown_seconds=60)

    for expected_message in (
        "Ollama no está disponible",
        "Circuito de Ollama abierto temporalmente",
    ):
        try:
            analyzer.analyze(
                AIReviewInput("group", "Vagabond", "dorama"),
                (source("one.example"),),
            )
        except RuntimeError as exc:
            assert expected_message in str(exc)
        else:
            raise AssertionError("offline Ollama must fall back without inference")

    assert transport.tags_calls == 1
    assert transport.chat_calls == 0
    assert analyzer.circuit_state == "open"


def test_qwen_retries_invalid_json_once_and_rejects_hallucinated_source() -> None:
    sources = (source("one.example"), source("two.example"))
    transport = Ollama(
        [
            {"message": {"content": "not-json"}},
            response(sources[0].url, "https://invented.example/work"),
        ]
    )
    analyzer = OllamaQwenAnalyzer(transport, invalid_json_retries=1)
    proposal = analyzer.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )
    validated = EvidenceValidator().validate(
        AIReviewInput("group", "Vagabond", "dorama", 2019), proposal
    )
    assert analyzer.calls == 2 and analyzer.invalid_json == 1
    assert proposal.hallucinated_source
    assert proposal.decision is AIReviewDecision.HUMAN_REVIEW
    assert validated.decision is AIReviewDecision.HUMAN_REVIEW


def test_qwen_recovers_fenced_json_and_common_field_aliases() -> None:
    sources = (source("one.example"),)
    payload = json.loads(response(sources[0].url)["message"]["content"])
    payload["reason"] = payload.pop("reasoning_summary")
    payload["action"] = payload.pop("recommended_action")
    payload["sources"] = payload.pop("matched_sources")
    wrapped = {"message": {"content": f"Resultado:\n```json\n{json.dumps(payload)}\n```"}}
    analyzer = OllamaQwenAnalyzer(Ollama([wrapped]))

    result = analyzer.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )

    assert result.canonical_title == "Vagabond"
    assert analyzer.invalid_json == 0


def test_qwen_receives_structured_browser_fields_and_preserves_field_sources() -> None:
    evidence = EvidenceSource(
        "https://catalog.example/vincenzo",
        "Vincenzo",
        "Serie coreana de 2021 disponible en Netflix",
        "browser_search",
        year=2021,
        media_type="dorama",
        seasons=(1,),
        genres=("Drama", "Comedia"),
        cast=("Song Joong-ki",),
        rating=8.4,
        platforms=("Netflix",),
        origin="knowledge_panel",
    )
    proposal = {
        "status": "partial_match",
        "canonical_title": "Vincenzo",
        "original_title": None,
        "year": 2021,
        "media_type": "dorama",
        "seasons": [1],
        "confidence": 88,
        "fields": {
            "year": {
                "value": 2021,
                "confidence": 95,
                "sources": [evidence.url],
            },
            "genres": {
                "value": ["Drama", "Comedia"],
                "confidence": 85,
                "sources": [evidence.url],
            },
        },
        "matched_sources": [{"url": evidence.url, "evidence": "2021"}],
        "conflicts": [],
        "reasoning_summary": "Metadatos parciales demostrados.",
        "recommended_action": "partial_accept",
    }
    transport = Ollama([{"message": {"content": json.dumps(proposal)}}])
    analyzer = OllamaQwenAnalyzer(transport)

    result = analyzer.analyze(
        AIReviewInput("group", "Vincenzo S01E01", "dorama"), (evidence,)
    )

    sent = json.loads(transport.payloads[0]["messages"][1]["content"])
    browser = sent["untrusted_web_evidence"][0]
    assert browser["cast"] == ["Song Joong-ki"]
    assert browser["platforms"] == ["Netflix"]
    assert result.decision is AIReviewDecision.HUMAN_REVIEW
    assert result.seasons == (1,)
    assert result.field_evidence[1].value == ("Drama", "Comedia")


def test_qwen_flags_invented_url_cited_by_an_individual_field() -> None:
    evidence = source("one.example")
    payload = json.loads(response(evidence.url)["message"]["content"])
    payload["fields"] = {
        "year": {
            "value": 2019,
            "confidence": 99,
            "sources": ["https://invented.example/vagabond"],
        }
    }
    analyzer = OllamaQwenAnalyzer(
        Ollama([{"message": {"content": json.dumps(payload)}}])
    )

    result = analyzer.analyze(
        AIReviewInput("group", "Vagabond", "dorama"), (evidence,)
    )

    assert result.hallucinated_source


def test_qwen_bounded_context_is_complete_json_instead_of_truncated_text() -> None:
    evidence = EvidenceSource(
        "https://one.example/work",
        "Vagabond",
        "x" * 8_000,
        "browser_search",
        cast=tuple(f"Actor {index}" for index in range(100)),
    )
    transport = Ollama([response(evidence.url)])
    analyzer = OllamaQwenAnalyzer(transport, max_context_chars=700)

    analyzer.analyze(AIReviewInput("group", "Vagabond", "dorama"), (evidence,))

    context = transport.payloads[0]["messages"][1]["content"]
    assert len(context) <= 700
    assert isinstance(json.loads(context), dict)


def test_qwen_rejects_extra_schema_keys_after_single_retry() -> None:
    payload = json.loads(response("https://one.example/vagabond")["message"]["content"])
    payload["invented_contract_key"] = True
    reply = {"message": {"content": json.dumps(payload)}}
    analyzer = OllamaQwenAnalyzer(Ollama([reply, reply]), invalid_json_retries=1)

    try:
        analyzer.analyze(
            AIReviewInput("group", "Vagabond", "dorama"),
            (source("one.example"),),
        )
    except RuntimeError as exc:
        assert "esquema" in str(exc)
    else:
        raise AssertionError("Qwen must reject unknown schema keys")
    assert analyzer.calls == 2 and analyzer.invalid_json == 2


def test_local_cache_round_trip_preserves_structured_qwen_provenance(
    tmp_path: Path,
) -> None:
    evidence = EvidenceSource(
        "https://one.example/vincenzo",
        "Vincenzo",
        "2021 Korean drama",
        "browser_search",
        seasons=(1,),
        genres=("Drama",),
    )
    result = AIReviewResult(
        "mce.ai-review.v1",
        AIReviewState.HUMAN,
        AIReviewDecision.HUMAN_REVIEW,
        "Vincenzo",
        "dorama",
        2021,
        (1,),
        0,
        (evidence,),
        field_evidence=(
            AIFieldEvidence("genres", ("Drama",), 90, (evidence.url,)),
        ),
        analysis_status="partial_match",
        recommended_action="partial_accept",
    )
    store = SqliteAIReviewStore(tmp_path / "qwen-cache.sqlite")

    store.put("fingerprint", result)
    restored = store.get("fingerprint")

    assert restored is not None
    assert restored.sources[0].seasons == (1,)
    assert restored.sources[0].genres == ("Drama",)
    assert restored.field_evidence[0].value == ("Drama",)
    assert restored.field_evidence[0].source_urls == (evidence.url,)
    assert restored.analysis_status == "partial_match"
    assert restored.recommended_action == "partial_accept"


def test_ai_cache_survives_restart_without_repeating_search_or_models(
    tmp_path: Path,
) -> None:
    calls = {"search": 0, "analyze": 0}
    sources = (source("one.example"), source("two.example"))

    class Search:
        name = "persistent-search"

        def search(self, query):
            calls["search"] += 1
            return sources

    class Analyzer:
        name = "persistent-analyzer"
        model = "model-v1"

        def analyze(self, item, evidence):
            calls["analyze"] += 1
            return AIReviewResult(
                "mce.ai-review.v1",
                AIReviewState.PENDING,
                AIReviewDecision.APPROVE,
                "Vagabond",
                "dorama",
                2019,
                (),
                0,
                evidence,
                prompt_version=PROMPT_VERSION,
            )

    path = tmp_path / "restart-cache.sqlite"
    first_store = SqliteAIReviewStore(path)
    item = AIReviewInput("group", "Vagabond", "dorama", 2019)
    first = AIReviewOrchestrator(
        Search(), Analyzer(), EvidenceValidator(), first_store, first_store
    ).review(item)

    second_store = SqliteAIReviewStore(path)
    second = AIReviewOrchestrator(
        Search(), Analyzer(), EvidenceValidator(), second_store, second_store
    ).review(item)

    assert first.decision is AIReviewDecision.APPROVE
    assert second.cached
    assert calls == {"search": 1, "analyze": 1}


def test_ai_cache_discards_tampering_and_nonterminal_checkpoints(tmp_path: Path) -> None:
    path = tmp_path / "safe-cache.sqlite"
    store = SqliteAIReviewStore(path)
    completed = AIReviewResult(
        "mce.ai-review.v1",
        AIReviewState.HUMAN,
        AIReviewDecision.HUMAN_REVIEW,
        "Vagabond",
        "dorama",
        2019,
        (),
        90,
        (source("one.example"),),
    )
    store.put("tampered", completed)
    store.put(
        "transient",
        AIReviewResult(
            "mce.ai-review.v1",
            AIReviewState.WAITING_RATE_LIMIT,
            AIReviewDecision.HUMAN_REVIEW,
            None,
            None,
            None,
            (),
            0,
            (),
        ),
    )
    with sqlite3.connect(path) as connection:
        connection.execute(
            "UPDATE ai_review_cache SET payload=? WHERE fingerprint=?",
            ("{}", "tampered"),
        )

    assert store.get("tampered") is None
    assert store.get("transient") is None
    with sqlite3.connect(path) as connection:
        remaining = connection.execute("SELECT COUNT(*) FROM ai_review_cache").fetchone()
    assert remaining == (0,)


def test_validated_chain_skips_groq_when_qwen_is_accepted() -> None:
    sources = (source("one.example"), source("two.example"))
    qwen = OllamaQwenAnalyzer(
        Ollama([response(*(value.url for value in sources))])
    )

    class NeverGroq:
        model = "openai/gpt-oss-120b"

        def analyze(self, item, evidence):
            raise AssertionError("Groq must not be called")

    chain = ValidatedAnalyzerChain(qwen, NeverGroq(), EvidenceValidator())
    result = chain.analyze(AIReviewInput("group", "Vagabond", "dorama", 2019), sources)
    assert result.state is AIReviewState.APPROVED
    assert chain.primary_accepted == 1 and chain.fallback_calls == 0


def test_validated_chain_calls_groq_when_qwen_fails() -> None:
    qwen = OllamaQwenAnalyzer(
        Ollama([{"message": {"content": "bad"}}, {"message": {"content": "bad"}}])
    )

    class Groq:
        model = "openai/gpt-oss-120b"

        def analyze(self, item, evidence):
            return AIReviewResult(
                "mce.ai-review.v1",
                AIReviewState.HUMAN,
                AIReviewDecision.HUMAN_REVIEW,
                "Vagabond",
                "dorama",
                2019,
                (),
                0,
                evidence,
                provider="groq",
            )

    chain = ValidatedAnalyzerChain(qwen, Groq(), EvidenceValidator())
    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019),
        (source("one.example"),),
    )
    assert result.provider == "groq"
    assert chain.primary_failures == 1 and chain.fallback_calls == 1


def test_validated_chain_accepts_one_matching_public_source_without_groq() -> None:
    one_source = (source("one.example"),)
    qwen = OllamaQwenAnalyzer(Ollama([response(one_source[0].url)]))

    class Groq:
        model = "openai/gpt-oss-120b"

        def analyze(self, item, evidence):
            return AIReviewResult(
                "mce.ai-review.v1",
                AIReviewState.HUMAN,
                AIReviewDecision.HUMAN_REVIEW,
                "Vagabond",
                "dorama",
                2019,
                (),
                0,
                evidence,
                provider="groq",
                model_confidence=70,
            )

    chain = ValidatedAnalyzerChain(qwen, Groq(), EvidenceValidator())
    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), one_source
    )

    assert result.decision is AIReviewDecision.APPROVE
    assert result.provider == "ollama"
    assert chain.fallback_calls == 0


def test_validated_chain_escalates_low_confidence_and_validates_groq_result() -> None:
    sources = (source("one.example"), source("two.example"))
    low_confidence = response(*(value.url for value in sources), confidence=60)
    qwen = OllamaQwenAnalyzer(Ollama([low_confidence]))

    class Groq:
        model = "openai/gpt-oss-120b"

        def analyze(self, item, evidence):
            return AIReviewResult(
                "mce.ai-review.v1",
                AIReviewState.PENDING,
                AIReviewDecision.APPROVE,
                "Vagabond",
                "dorama",
                2019,
                (),
                0,
                evidence,
                provider="groq",
                model_confidence=98,
            )

    chain = ValidatedAnalyzerChain(qwen, Groq(), EvidenceValidator())
    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )

    assert result.decision is AIReviewDecision.APPROVE
    assert result.deterministic_score == 100
    assert chain.fallback_calls == 1 and chain.fallback_accepted == 1
    assert chain.last_route == "Groq aceptado por validador"


def test_validated_chain_rejects_hallucinated_groq_source_after_fallback() -> None:
    sources = (source("one.example"), source("two.example"))
    qwen_payload = json.loads(response(*(value.url for value in sources))["message"]["content"])
    qwen_payload["status"] = "ambiguous"
    qwen_payload["recommended_action"] = "escalate"
    qwen = OllamaQwenAnalyzer(
        Ollama([{"message": {"content": json.dumps(qwen_payload)}}])
    )

    class Groq:
        model = "openai/gpt-oss-120b"

        def analyze(self, item, evidence):
            return AIReviewResult(
                "mce.ai-review.v1",
                AIReviewState.PENDING,
                AIReviewDecision.APPROVE,
                "Vagabond",
                "dorama",
                2019,
                (),
                0,
                evidence,
                provider="groq",
                model_confidence=99,
                hallucinated_source=True,
            )

    chain = ValidatedAnalyzerChain(qwen, Groq(), EvidenceValidator())
    result = chain.analyze(
        AIReviewInput("group", "Vagabond", "dorama", 2019), sources
    )

    assert result.decision is AIReviewDecision.HUMAN_REVIEW
    assert result.hallucinated_source
    assert "fuente no suministrada" in result.contradictions[0]
    assert chain.fallback_human_review == 1


def test_qwen_circuit_opens_after_repeated_failures_and_recovers() -> None:
    clock = [10.0]

    class Offline:
        def tags(self, timeout):
            return {"models": [{"name": "qwen2.5:3b"}]}

        def chat(self, payload, timeout):
            raise TimeoutError("timeout")

    analyzer = OllamaQwenAnalyzer(
        Offline(),
        failure_threshold=2,
        cooldown_seconds=30,
        monotonic=lambda: clock[0],
    )
    item = AIReviewInput("group", "Vagabond", "dorama", 2019)
    for _ in range(2):
        with suppress(TimeoutError):
            analyzer.analyze(item, (source("one.example"),))
    assert analyzer.circuit_state == "open"
    assert analyzer.calls == 2 and analyzer.timeouts == 2

    try:
        analyzer.analyze(item, (source("one.example"),))
    except RuntimeError as exc:
        assert "Circuito" in str(exc)
    assert analyzer.calls == 2

    clock[0] += 31
    assert analyzer.circuit_state == "half-open"
