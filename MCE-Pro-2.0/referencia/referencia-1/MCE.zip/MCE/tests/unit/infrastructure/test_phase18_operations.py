"""Integridad de arranque, restauración protegida y diagnóstico redactado."""

from __future__ import annotations

import json
import subprocess
import zipfile
from pathlib import Path

from mce.infrastructure.operations import (
    DiagnosticContext,
    DiagnosticPackageService,
    HealthCheck,
    PostgresBackupService,
    StartupIntegrityService,
)
from mce.infrastructure.operations.health import migration_head
from mce.infrastructure.runtime import RuntimePaths


class BackupRunner:
    def __init__(self, *, fail_dump: bool = False) -> None:
        self.fail_dump = fail_dump
        self.commands: list[list[str]] = []

    def __call__(self, command, **_kwargs):
        values = list(command)
        self.commands.append(values)
        if Path(values[0]).stem == "pg_dump" and not self.fail_dump:
            Path(values[values.index("--file") + 1]).write_bytes(b"PGDMP-safety")
        return subprocess.CompletedProcess(values, 1 if self.fail_dump else 0, "", "")


def runtime_paths(root: Path) -> RuntimePaths:
    paths = RuntimePaths(
        root,
        root / "logs",
        root / "cache",
        root / "checkpoints",
        root / "originals",
        root / "exports",
        root / "config",
        root / "backups",
    )
    paths.ensure()
    return paths


def test_safe_restore_creates_valid_restore_point_before_pg_restore(tmp_path: Path) -> None:
    runner = BackupRunner()
    service = PostgresBackupService(runner)
    source = tmp_path / "source.dump"
    source.write_bytes(b"PGDMP-source")
    safety = tmp_path / "before-restore.dump"
    result = service.restore_safely(
        "postgresql+psycopg://tester:secret@localhost/mce",
        source,
        safety,
        allow_master=True,
    )
    assert result.success and safety.is_file()
    assert [Path(command[0]).stem for command in runner.commands] == [
        "pg_dump",
        "pg_restore",
        "pg_restore",
        "pg_restore",
    ]


def test_safe_restore_stops_when_restore_point_cannot_be_created(tmp_path: Path) -> None:
    runner = BackupRunner(fail_dump=True)
    source = tmp_path / "source.dump"
    source.write_bytes(b"PGDMP-source")
    result = PostgresBackupService(runner).restore_safely(
        "postgresql+psycopg://tester:secret@localhost/mce",
        source,
        tmp_path / "safety.dump",
        allow_master=True,
    )
    assert not result.success and "destino intacto" in result.message
    assert all(Path(command[0]).stem != "pg_restore" for command in runner.commands)


def test_diagnostic_package_anonymizes_and_redacts(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("TAVILY_API_KEY", "top-secret-key")
    paths = runtime_paths(tmp_path)
    (paths.logs / "mce-desktop.log").write_text(
        "password=hunter2 postgresql://user:db-secret@localhost/mce top-secret-key",
        encoding="utf-8",
    )
    target = DiagnosticPackageService().create(
        paths.exports / "diagnostic.zip",
        DiagnosticContext(
            active_stage="finalization",
            bank_id="real-bank-id",
            error="token=visible-token",
            statistics={"api_key": "must-hide", "rows": 13},
        ),
        logs_directory=paths.logs,
    )
    with zipfile.ZipFile(target) as archive:
        payload = json.loads(archive.read("diagnostic.json"))
        log = archive.read("logs/latest.log").decode()
    rendered = json.dumps(payload) + log
    assert payload["context"]["bank_id"].startswith("bank-")
    assert payload["context"]["statistics"]["api_key"] == "***"
    for secret in ("real-bank-id", "hunter2", "db-secret", "top-secret-key", "visible-token"):
        assert secret not in rendered


def test_startup_critical_error_enables_safe_mode(tmp_path: Path, monkeypatch) -> None:
    paths = runtime_paths(tmp_path)
    service = StartupIntegrityService()
    monkeypatch.setattr(
        service,
        "_database_integrity",
        lambda _root: (
            HealthCheck("tables", "error", "faltan tablas"),
            HealthCheck("integrity", "error", "sin comprobar"),
        ),
    )
    report = service.inspect(tmp_path, paths)
    assert report.safe_mode
    assert any(check.name == "configuration" and check.status == "ok" for check in report.checks)


def test_large_checkpoint_is_deferred_instead_of_loaded(tmp_path: Path) -> None:
    paths = runtime_paths(tmp_path)
    large = paths.checkpoints / "large.json"
    large.write_bytes(b"{" + b"x" * 1024 + b"}")
    report = StartupIntegrityService().maintenance.inspect_checkpoints(
        paths.checkpoints, maximum_eager_bytes=128
    )
    assert report.deferred_checkpoints == ("large.json",)
    assert report.invalid_checkpoints == ()

def test_migration_head_does_not_depend_on_process_working_directory(
    tmp_path: Path, monkeypatch
) -> None:
    project_root = Path(__file__).resolve().parents[3]
    monkeypatch.chdir(tmp_path)

    assert migration_head(project_root)
