"""Integridad byte a byte del archivo local de originales."""

import hashlib
from pathlib import Path

import pytest

from mce.infrastructure.imports import OriginalJsonArchive


def test_archive_preserves_bytes_and_reuses_content_address(tmp_path: Path) -> None:
    source = tmp_path / "scan.json"
    payload = b'{"schema_version":"2.2","texto":"\xc3\xb1"}\r\n'
    source.write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    archive = OriginalJsonArchive(tmp_path / "originals")

    first = archive.preserve(source, digest)
    second = archive.preserve(source, digest)

    target = Path(first.storage_reference)
    assert target.read_bytes() == payload
    assert first == second
    assert target.name == f"{digest}.json"
    assert source.read_bytes() == payload


def test_archive_rejects_a_file_changed_after_validation(tmp_path: Path) -> None:
    source = tmp_path / "scan.json"
    source.write_text("{}", encoding="utf-8")
    old_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    source.write_text('{"changed":true}', encoding="utf-8")

    with pytest.raises(ValueError, match="changed after validation"):
        OriginalJsonArchive(tmp_path / "originals").preserve(source, old_hash)
