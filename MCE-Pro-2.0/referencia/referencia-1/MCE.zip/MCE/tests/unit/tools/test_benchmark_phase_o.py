from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

MODULE_PATH = Path(__file__).parents[3] / "tools" / "benchmark_phase_o.py"
SPEC = importlib.util.spec_from_file_location("benchmark_phase_o", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
benchmark = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = benchmark
SPEC.loader.exec_module(benchmark)


def test_normalization_and_alias_matching_are_deterministic() -> None:
    case = benchmark.CASES[4]

    assert benchmark.normalized("Parásitos — 2019") == "parasitos 2019"
    assert benchmark.matches_case(case, "La Casa de Papel reparto y episodios")
    assert not benchmark.matches_case(case, "Unrelated television result")


def test_percentile_uses_nearest_rank_in_existing_contract() -> None:
    values = [10.0, 20.0, 30.0, 40.0, 50.0]

    assert benchmark.percentile(values, 0.50) == 30.0
    assert benchmark.percentile(values, 0.95) == 50.0
    assert benchmark.percentile([], 0.95) is None


def test_summary_counts_failures_accuracy_and_throughput_without_secrets() -> None:
    rows = [
        {
            "outcome": "success",
            "elapsed_ms": 1_000.0,
            "exact": True,
            "false_positive": False,
            "json_valid": True,
            "process_peak_rss_mib": 100.0,
            "cpu_percent_system_capacity": 5.0,
            "system_vram_after_mib": 600.0,
        },
        {
            "outcome": "success",
            "elapsed_ms": 2_000.0,
            "exact": False,
            "false_positive": True,
            "json_valid": True,
            "process_peak_rss_mib": 120.0,
            "cpu_percent_system_capacity": 7.0,
            "system_vram_after_mib": 620.0,
        },
        {"outcome": "rate_limited", "elapsed_ms": 500.0},
    ]

    result = benchmark.summarize("provider", rows)

    assert result["successes"] == 2
    assert result["rate_limits"] == 1
    assert result["accuracy_percent"] == 50.0
    assert result["false_positives"] == 1
    assert result["latency_ms"]["p95"] == 2_000.0
    assert result["throughput_works_per_minute"] == 51.429
    assert result["resources"]["process_peak_rss_mib"] == 120.0


class FakeResult:
    def __init__(self, title: str, description: str = "") -> None:
        self.title = title
        self.description = description


class FakeProvider:
    def search(self, query: str, *, limit: int):
        assert limit == 3
        return (FakeResult("Vincenzo Korean drama 2021"),)


def test_search_benchmark_does_not_store_query_or_credentials(monkeypatch) -> None:
    monkeypatch.setattr(benchmark, "_system_vram_used_mib", lambda: None)
    report = benchmark.benchmark_search_provider(
        "fake", FakeProvider(), (benchmark.CASES[0],)
    )

    assert report["successes"] == 1
    assert report["exact"] == 1
    assert "query" not in report["rows"][0]
    assert "credential" not in str(report).casefold()


def test_windows_working_set_is_measurable() -> None:
    current, peak = benchmark._working_set_mib()

    if benchmark.os.name == "nt":
        assert current is not None and current > 0
        assert peak is not None and peak >= current
