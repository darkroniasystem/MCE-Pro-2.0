"""Despacho explícito de contratos MSL por schema_version."""

import pytest

from mce.application.importers.schema_adapters import (
    LegacyMslSchemaAdapter,
    MslSchema10Adapter,
    MslSchema22Adapter,
    MslSchemaAdapterRegistry,
    UnsupportedMslSchemaError,
)
from mce.application.importers.schema_detector import SchemaDetector


@pytest.mark.parametrize(
    ("document", "adapter_type", "embedded_subtitles"),
    [
        ({"schema_version": "1.0"}, MslSchema10Adapter, False),
        ({"schema_version": "2.2"}, MslSchema22Adapter, True),
        ({}, LegacyMslSchemaAdapter, False),
    ],
)
def test_registry_dispatches_each_supported_contract(
    document: dict[str, str],
    adapter_type: type[object],
    embedded_subtitles: bool,
) -> None:
    adapter = MslSchemaAdapterRegistry().resolve(SchemaDetector().detect(document))

    assert isinstance(adapter, adapter_type)
    assert adapter.include_embedded_subtitles is embedded_subtitles


@pytest.mark.parametrize("version", ["2.0", "9.0", "latest"])
def test_registry_never_adapts_an_unknown_contract(version: str) -> None:
    detection = SchemaDetector().detect({"schema_version": version})

    with pytest.raises(UnsupportedMslSchemaError):
        MslSchemaAdapterRegistry().resolve(detection)
