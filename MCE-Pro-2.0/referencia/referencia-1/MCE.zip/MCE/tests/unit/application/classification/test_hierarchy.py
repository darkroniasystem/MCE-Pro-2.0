"""Jerarquía provisional obra-temporada-episodio-archivo-subtítulo."""

import pytest

from mce.application.classification import HierarchyGrouper
from mce.application.classification.models import HierarchyMediaInput, MediaKind


def media(
    identifier: str,
    path: str,
    *,
    bank: str = "bank-a",
    kind: MediaKind = MediaKind.SERIES,
    season: int | None = None,
    episode: int | None = None,
    subtitle: bool = False,
    language: str | None = None,
) -> HierarchyMediaInput:
    return HierarchyMediaInput(
        identifier=identifier,
        bank_id=bank,
        path=path,
        name=path.rsplit("\\", 1)[-1],
        kind=kind,
        clean_title=None,
        season_number=season,
        episode_number=episode,
        language=language,
        is_subtitle=subtitle,
    )


def test_builds_work_season_episode_video_and_subtitle_hierarchy():
    result = HierarchyGrouper().group(
        (
            media("v1", r"D:\Series\Show\Temporada 1\Show S01E01.mkv", season=1, episode=1),
            media("v2", r"D:\Series\Show\Temporada 1\Show S01E01.mp4", season=1, episode=1),
            media("v3", r"D:\Series\Show\Temporada 1\Show S01E02.mkv", season=1, episode=2),
            media(
                "s1",
                r"D:\Series\Show\Temporada 1\Show S01E01.es.srt",
                season=1,
                episode=1,
                subtitle=True,
                language="es",
            ),
        )
    )
    assert len(result.works) == 1
    work = result.works[0]
    assert work.title == "Show" and work.provisional
    assert len(work.seasons) == 1 and len(work.seasons[0].episodes) == 2
    first = work.seasons[0].episodes[0]
    assert first.video_ids == ("v1", "v2")
    assert first.subtitle_ids == ("s1",)


def test_season_zero_represents_specials_without_inventing_season_one():
    result = HierarchyGrouper().group((media("v1", r"D:\Series\Show\Special.mkv", episode=1),))
    assert result.works[0].seasons[0].number == 0


def test_standalone_movie_remains_a_work_with_a_physical_file():
    item = HierarchyMediaInput(
        "v1",
        "bank-a",
        r"D:\Movies\Arrival.2016.mkv",
        "Arrival.2016.mkv",
        MediaKind.MOVIE,
        clean_title="Arrival",
    )
    work = HierarchyGrouper().group((item,)).works[0]
    assert work.title == "Arrival"
    assert work.standalone_video_ids == ("v1",)
    assert work.seasons == ()


def test_same_title_never_groups_across_banks():
    result = HierarchyGrouper().group(
        (
            media("a", r"D:\Series\Show\01.mkv", bank="bank-a", episode=1),
            media("b", r"D:\Series\Show\01.mkv", bank="bank-b", episode=1),
        )
    )
    assert len(result.works) == 2
    assert {work.bank_id for work in result.works} == {"bank-a", "bank-b"}


def test_dvd_control_files_form_a_disc_instead_of_independent_works():
    result = HierarchyGrouper().group(
        (
            media("ifo", r"E:\Movie\VIDEO_TS\VIDEO_TS.IFO", kind=MediaKind.DVD_DISC),
            media("vob", r"E:\Movie\VIDEO_TS\VTS_01_1.VOB", kind=MediaKind.DVD_DISC),
        )
    )
    assert result.works == ()
    assert len(result.discs) == 1
    assert len(result.discs[0].groups[0].file_paths) == 2


def test_ambiguous_subtitle_is_preserved_unresolved():
    result = HierarchyGrouper().group(
        (
            media("v1", r"D:\Show\Film A.mkv"),
            media("v2", r"D:\Show\Film B.mkv"),
            media("s1", r"D:\Show\Film.srt", subtitle=True),
        )
    )
    assert result.unresolved_subtitle_ids == ("s1",)
    assert all(
        not episode.subtitle_ids
        for work in result.works
        for season in work.seasons
        for episode in season.episodes
    )


def test_subtitle_cannot_cross_bank_boundary():
    result = HierarchyGrouper().group(
        (
            media("v1", r"D:\Show\Movie.mkv", bank="bank-a"),
            media("s1", r"D:\Show\Movie.es.srt", bank="bank-b", subtitle=True),
        )
    )
    assert result.unresolved_subtitle_ids == ("s1",)


def test_result_is_deterministic_for_same_input():
    items = (media("v1", r"D:\Series\Show\S01\01.mkv", season=1, episode=1),)
    assert HierarchyGrouper().group(items) == HierarchyGrouper().group(items)


def test_duplicate_identifiers_fail_closed():
    duplicate = media("same", r"D:\Series\Show\01.mkv", episode=1)
    with pytest.raises(ValueError, match="unique"):
        HierarchyGrouper().group((duplicate, duplicate))
