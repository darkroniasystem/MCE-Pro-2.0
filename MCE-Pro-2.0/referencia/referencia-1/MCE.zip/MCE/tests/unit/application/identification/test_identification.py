"""Puntuación, estados y umbrales explicables."""

from tests.fakes import FakeMetadataProvider

from mce.application.identification import IdentificationService, MatchPolicy, MatchScorer
from mce.application.identification.models import (
    IdentificationQuery,
    IdentificationStatus,
    ProviderCandidate,
    SearchKind,
)
from mce.application.identification.service import (
    ProviderError,
    ProviderOfflineError,
    ProviderTimeoutError,
)


def candidate(title="Avatar", year=2009, **changes):
    values = dict(
        provider="fake",
        external_id="1",
        kind=SearchKind.MOVIE,
        title=title,
        original_title="Avatar",
        translated_titles=("Avatar",),
        aliases=("Project 880",),
        year=year,
        country="US",
        cast=("Actor A",),
        director="James",
        duration_minutes=162,
    )
    values.update(changes)
    return ProviderCandidate(**values)


def query(**changes):
    values = dict(title="Avatar", kind=SearchKind.MOVIE, year=2009)
    values.update(changes)
    return IdentificationQuery(**values)


def test_exact_title_year_and_type_is_identified_without_ai():
    result = IdentificationService(FakeMetadataProvider((candidate(),))).identify(query())
    assert result.status is IdentificationStatus.IDENTIFIED and result.selected
    assert {item.rule for item in result.selected.score.evidence} >= {
        "title_exact",
        "year_exact",
        "type_compatible",
    }


def test_multiple_reliable_signals_reach_automatic_acceptance():
    result = IdentificationService(FakeMetadataProvider((candidate(),))).identify(
        query(
            original_title="Avatar",
            country="US",
            cast=("Actor A",),
            director="James",
            duration_minutes=162,
        )
    )
    assert result.status is IdentificationStatus.IDENTIFIED
    assert result.selected is not None and result.selected.score.total >= 95


def test_alias_original_spanish_and_auxiliary_signals_score():
    item = candidate(
        title="The Secret",
        original_title="El secreto",
        translated_titles=("El Secreto",),
        aliases=("Secreto",),
    )
    score = MatchScorer().score(
        query(
            title="Secreto",
            original_title="El secreto",
            country="US",
            cast=("Actor A",),
            director="James",
            duration_minutes=160,
        ),
        item,
    )
    assert score.total >= 80 and any(e.rule == "alias_exact" for e in score.evidence)


def test_year_conflict_is_negative_evidence():
    score = MatchScorer().score(query(year=2010), candidate(year=2009))
    assert next(e.points for e in score.evidence if e.rule == "year_conflict") == -20


def test_multiple_close_candidates_are_ambiguous():
    provider = FakeMetadataProvider((candidate(), candidate(external_id="2")))
    assert (
        IdentificationService(provider).identify(query()).status is IdentificationStatus.AMBIGUOUS
    )


def test_not_found_probable_and_configurable_thresholds():
    assert (
        IdentificationService(FakeMetadataProvider()).identify(query()).status
        is IdentificationStatus.NOT_FOUND
    )
    weak = candidate(title="Avatar Return", year=None, original_title=None, translated_titles=())
    result = IdentificationService(
        FakeMetadataProvider((weak,)), MatchPolicy(automatic_acceptance=90, manual_review=20)
    ).identify(query())
    assert result.status is IdentificationStatus.PROBABLE


def test_provider_errors_offline_and_timeout_are_explicit():
    assert (
        IdentificationService(FakeMetadataProvider(error=ProviderOfflineError("offline")))
        .identify(query())
        .status
        is IdentificationStatus.OFFLINE
    )
    assert (
        IdentificationService(FakeMetadataProvider(error=ProviderTimeoutError("timeout")))
        .identify(query())
        .status
        is IdentificationStatus.PROVIDER_ERROR
    )
    assert (
        IdentificationService(FakeMetadataProvider(error=ProviderError("down")))
        .identify(query())
        .status
        is IdentificationStatus.PROVIDER_ERROR
    )
