from datetime import UTC, datetime

from tests.fakes import FakeMetadataProvider
from tests.unit.application.identification.test_identification import candidate

from mce.application.identification import IdentificationService
from mce.application.identification.models import (
    IdentificationQuery,
    IdentificationStatus,
    SearchKind,
)
from mce.application.web_search import WebSearchEvidence, WebSearchFallbackService


class WebProvider:
    name = "web:test"

    def __init__(self) -> None:
        self.queries: list[tuple[str, int]] = []
        self.last_from_cache = False

    def search(self, query: str, *, limit: int) -> tuple[WebSearchEvidence, ...]:
        self.queries.append((query, limit))
        return (
            WebSearchEvidence(
                "example.org",
                "Sandman",
                "series",
                2022,
                "Serie",
                "https://example.org/sandman",
                100,
                datetime(2026, 1, 1, tzinfo=UTC),
                query,
            ),
            WebSearchEvidence(
                "example.net",
                "The Sandman",
                "series",
                2022,
                "TV series",
                "https://example.net/sandman",
                95,
                datetime(2026, 1, 1, tzinfo=UTC),
                query,
            ),
        )


def test_fallback_runs_for_structured_not_found_and_preserves_review_status() -> None:
    web = WebProvider()
    service = IdentificationService(
        FakeMetadataProvider(), web_fallback=WebSearchFallbackService(web)
    )
    result = service.identify(IdentificationQuery("Sandman", SearchKind.SERIES, 2022, season=1))
    assert result.status is IdentificationStatus.NOT_FOUND_CONFIRMED
    assert result.selected is None
    assert result.web_fallback is not None
    assert result.web_fallback.used and len(result.web_fallback.evidence) == 2
    assert web.queries == [("Sandman series 2022 season 1", 8)]


def test_fallback_runs_for_probable_and_ambiguous_but_not_high_confidence() -> None:
    web = WebProvider()
    fallback = WebSearchFallbackService(web)
    probable = IdentificationService(
        FakeMetadataProvider(
            (
                candidate(
                    title="Avatar Extended",
                    original_title="Avatar Original",
                    translated_titles=(),
                    aliases=(),
                ),
            )
        ),
        web_fallback=fallback,
    ).identify(
        IdentificationQuery(
            "Avatar", SearchKind.MOVIE, 2009, original_title="Avatar Original"
        )
    )
    assert probable.status is IdentificationStatus.PROBABLE
    assert probable.web_fallback.reason == "confidence_65_84"

    ambiguous = IdentificationService(
        FakeMetadataProvider((candidate(), candidate(external_id="2"))),
        web_fallback=fallback,
    ).identify(IdentificationQuery("Avatar", SearchKind.MOVIE, 2009))
    assert ambiguous.status is IdentificationStatus.AMBIGUOUS
    assert ambiguous.web_fallback.reason == "multiple_candidates"

    identified = IdentificationService(
        FakeMetadataProvider((candidate(),)), web_fallback=fallback
    ).identify(
        IdentificationQuery(
            "Avatar",
            SearchKind.MOVIE,
            2009,
            original_title="Avatar",
            country="US",
            cast=("Actor A",),
            director="James",
            duration_minutes=162,
        )
    )
    assert identified.status is IdentificationStatus.IDENTIFIED
    assert identified.web_fallback is not None and not identified.web_fallback.used
    assert len(web.queries) == 2
