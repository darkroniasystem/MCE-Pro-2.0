"""Pruebas unitarias de identificación."""
