"""Recorrido jerárquico y explicable de rutas de la Fase 5."""

import pytest

from mce.application.classification import PathEvidenceEngine
from mce.application.classification.models import MediaKind


@pytest.fixture(scope="module")
def engine() -> PathEvidenceEngine:
    return PathEvidenceEngine()


def test_traverses_from_parent_toward_root_and_preserves_segments(engine):
    result = engine.analyze(r"D:\Biblioteca\Series\The Show\Temporada 2\Episode.mkv")
    assert result.traversed_segments[:3] == ("Temporada 2", "The Show", "Series")
    assert [candidate.kind for candidate in result.candidates] == [
        MediaKind.SEASON,
        MediaKind.SERIES,
    ]
    assert result.candidates[0].evidence[0].signal == "path_segment:0"


def test_nearest_specific_folder_outranks_distant_generic_folder(engine):
    result = engine.analyze(r"D:\Películas\Archivo\Anime\Frieren\01.mkv")
    assert result.candidates[0].kind is MediaKind.ANIME
    assert result.candidates[0].confidence > result.candidates[1].confidence


def test_word_boundaries_prevent_substring_false_positives(engine):
    result = engine.analyze(r"D:\AnimationTests\Novelaciones\Video.mkv")
    assert result.candidates == ()


def test_same_kind_uses_only_the_nearest_evidence(engine):
    result = engine.analyze(r"D:\Anime\Archivo\Animes\Serie\01.mkv")
    anime = [candidate for candidate in result.candidates if candidate.kind is MediaKind.ANIME]
    assert len(anime) == 1
    assert "Animes" in anime[0].evidence[0].value


def test_unc_path_is_traversed_without_treating_anchor_as_evidence(engine):
    result = engine.analyze(r"\\servidor\media\Doramas\Serie\01.mkv")
    assert "Doramas" in result.traversed_segments
    assert result.candidates[0].kind is MediaKind.DORAMA


def test_invalid_paths_fail_closed(engine):
    with pytest.raises(ValueError, match="empty"):
        engine.analyze(" ")
    with pytest.raises(ValueError, match="null"):
        engine.analyze("D:\\Anime\\bad\x00name.mkv")
