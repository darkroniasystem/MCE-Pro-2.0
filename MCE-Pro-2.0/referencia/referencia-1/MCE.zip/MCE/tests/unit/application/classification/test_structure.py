"""Subtítulos, DVD y grupos preliminares."""

from mce.application.classification import DvdGrouper, PreliminaryGrouper, SubtitleMatcher
from mce.application.classification.models import (
    MediaKind,
    SubtitleInput,
    SubtitleMatchStatus,
    VideoInput,
)


def test_subtitle_exact_probable_ambiguous_and_unmatched():
    matcher = SubtitleMatcher()
    videos = (
        VideoInput("v1", r"D:\A\Movie.mkv", "Movie.mkv"),
        VideoInput("v2", r"D:\B\Other.mkv", "Other.mkv"),
    )
    assert (
        matcher.match(
            SubtitleInput("s1", r"D:\A\Movie.es.srt", "Movie.es.srt", "es"), videos
        ).status
        is SubtitleMatchStatus.MATCHED
    )
    probable = matcher.match(SubtitleInput("s2", r"D:\X\Movi.srt", "Movi.srt"), videos)
    assert probable.status is SubtitleMatchStatus.PROBABLE and probable.video_id == "v1"
    ambiguous = matcher.match(
        SubtitleInput("s3", r"D:\X\Film.srt", "Film.srt"),
        (
            VideoInput("a", r"D:\X\Film A.mkv", "Film A.mkv"),
            VideoInput("b", r"D:\X\Film B.mkv", "Film B.mkv"),
        ),
    )
    assert ambiguous.status is SubtitleMatchStatus.AMBIGUOUS and ambiguous.video_id is None
    assert (
        matcher.match(SubtitleInput("s4", r"D:\X\zzz.srt", "zzz.srt"), videos).status
        is SubtitleMatchStatus.UNMATCHED
    )


def test_dvd_files_form_one_disc_candidate():
    paths = (
        r"E:\Movie\VIDEO_TS\VIDEO_TS.IFO",
        r"E:\Movie\VIDEO_TS\VTS_01_0.IFO",
        r"E:\Movie\VIDEO_TS\VTS_01_1.VOB",
        r"E:\Movie\cover.jpg",
    )
    discs = DvdGrouper().group(paths)
    assert len(discs) == 1 and len(discs[0].groups[0].file_paths) == 3


def test_grouping_is_provisional_and_deduplicates_members():
    group = PreliminaryGrouper().group(MediaKind.SEASON, "show:s1", ("a", "a", "b"), 78)
    assert group.provisional and group.member_ids == ("a", "b")
