"""Pruebas unitarias de clasificación."""
