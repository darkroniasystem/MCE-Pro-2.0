"""Versionado y compatibilidad controlada de esquemas."""

import pytest

from mce.application.importers.schema_detector import SchemaCompatibility, SchemaDetector


@pytest.mark.parametrize("version", ["1.0", "2.2"])
def test_detects_supported_versions(version: str) -> None:
    result = SchemaDetector().detect({"schema_version": version})
    assert result.compatibility is SchemaCompatibility.SUPPORTED


def test_detects_missing_future_unsupported_and_malformed() -> None:
    detector = SchemaDetector()
    assert detector.detect({}).compatibility is SchemaCompatibility.MISSING
    assert (
        detector.detect({"schema_version": "9.0"}).compatibility
        is SchemaCompatibility.FUTURE_VERSION
    )
    assert (
        detector.detect({"schema_version": "2.0"}).compatibility is SchemaCompatibility.UNSUPPORTED
    )
    assert (
        detector.detect({"schema_version": "latest"}).compatibility is SchemaCompatibility.MALFORMED
    )
