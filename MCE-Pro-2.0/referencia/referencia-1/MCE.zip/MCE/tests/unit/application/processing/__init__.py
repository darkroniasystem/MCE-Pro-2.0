"""Pruebas del coordinador de procesamiento."""
