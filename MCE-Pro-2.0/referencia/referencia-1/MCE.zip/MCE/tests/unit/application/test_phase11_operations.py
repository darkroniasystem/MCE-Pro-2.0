"""Contratos puros de exportación y auditoría."""

import csv
import json
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

import pytest

from mce.application.operations import (
    AuditEvent,
    AuditService,
    BotCatalogRecord,
    ExportFormat,
    ExportRequest,
    ExportService,
)


class AuditMemory:
    def __init__(self) -> None:
        self.rows: list[AuditEvent] = []

    def add(self, event: AuditEvent) -> None:
        self.rows.append(event)

    def get(self, event_id: str) -> AuditEvent | None:
        return next((row for row in self.rows if row.event_id == event_id), None)

    def list_page(self, *, offset: int = 0, limit: int = 100) -> tuple[AuditEvent, ...]:
        return tuple(self.rows[offset : offset + limit])


def test_json_export_is_unicode_versioned_and_drops_secrets(tmp_path: Path) -> None:
    destination = tmp_path / "catálogo.json"
    result = ExportService().export(
        ExportRequest(
            "catalog",
            destination,
            ExportFormat.JSON,
            ({"title": "Amélie", "api_key": "never-export"},),
        )
    )
    payload = json.loads(destination.read_text(encoding="utf-8"))
    assert payload == {
        "contract_version": "mce.export.v1",
        "dataset": "catalog",
        "rows": [{"title": "Amélie"}],
    }
    assert result.row_count == 1
    assert result.byte_count > 0


def test_csv_export_streams_unicode_and_neutralizes_formulas(tmp_path: Path) -> None:
    destination = tmp_path / "files.csv"
    rows = ({"name": f"Película {number}", "path": "=CMD()"} for number in range(2_000))
    result = ExportService().export(
        ExportRequest("physical_files", destination, ExportFormat.CSV, rows)
    )
    with destination.open(encoding="utf-8-sig", newline="") as stream:
        exported = list(csv.DictReader(stream))
    assert result.row_count == 2_000
    assert exported[0] == {"name": "Película 0", "path": "'=CMD()"}


def test_bot_contract_is_stable_and_independent() -> None:
    record = BotCatalogRecord(
        str(uuid4()),
        "El laberinto del fauno",
        original_title="Pan's Labyrinth",
        aliases=("El laberinto",),
        content_type="movie",
        year=2006,
    )
    contract = record.to_contract()
    assert contract["contract_version"] == "mce.bot.catalog.v1"
    assert contract["title"] == "El laberinto del fauno"
    assert contract["aliases"] == ("El laberinto",)


def test_audit_requires_timezone_and_paginates() -> None:
    repository = AuditMemory()
    event = AuditEvent(
        str(uuid4()),
        datetime.now(UTC),
        "operator",
        "correction",
        "content",
        str(uuid4()),
        {"title": "Antes"},
        {"title": "Después"},
        str(uuid4()),
        True,
    )
    service = AuditService(repository)
    service.record(event)
    assert service.list_page() == (event,)
    with pytest.raises(ValueError, match="pagination"):
        service.list_page(limit=0)
    with pytest.raises(ValueError, match="timezone"):
        AuditEvent(
            str(uuid4()),
            datetime.now(),
            "operator",
            "correction",
            "content",
            str(uuid4()),
            None,
            None,
            str(uuid4()),
        )
