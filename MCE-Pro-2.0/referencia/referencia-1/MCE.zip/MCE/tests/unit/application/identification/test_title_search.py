from mce.application.identification.title_search import normalize_search_title


def test_title_search_ignores_case_accents_punctuation_and_basic_roman_numbers() -> None:
    assert normalize_search_title("Misión: Imposible—IV") == "mision imposible 4"
    assert normalize_search_title("MISION.imposible-4") == "mision imposible 4"


def test_different_words_are_not_collapsed() -> None:
    assert normalize_search_title("Rocky II") != normalize_search_title("Rocky III")
