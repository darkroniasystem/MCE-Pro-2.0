"""Pruebas unitarias de enriquecimiento."""
