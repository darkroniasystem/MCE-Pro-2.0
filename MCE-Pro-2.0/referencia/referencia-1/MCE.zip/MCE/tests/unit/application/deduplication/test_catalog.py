"""Consolidación reversible, versiones y disponibilidad."""

from datetime import UTC, datetime
from itertools import count

from mce.application.deduplication.models import (
    AvailabilityRecord,
    CatalogAvailabilityStatus,
    CatalogContent,
    CatalogFile,
    CatalogVersion,
    InMemoryCatalog,
)
from mce.application.deduplication.service import CatalogConsolidationService

NOW = datetime(2026, 7, 20, tzinfo=UTC)


def file(identifier, content=None, **changes):
    values = dict(
        file_id=identifier,
        bank_id="b1",
        installation_id="i1",
        source_id="s1",
        path=f"E:/{identifier}",
        normalized_path=f"e:/{identifier}",
        name=identifier,
        content_id=content,
    )
    values.update(changes)
    return CatalogFile(**values)


def setup():
    catalog = InMemoryCatalog()
    ids = count(1)
    return catalog, CatalogConsolidationService(catalog, lambda: NOW, lambda: f"merge-{next(ids)}")


def test_merge_and_revert_are_auditable_and_do_not_delete_files():
    catalog, service = setup()
    catalog.files = {"f1": file("f1", "c1"), "f2": file("f2", "c2")}
    catalog.contents = {
        "c1": CatalogContent("c1", "Avatar", 2009, file_ids=("f1",)),
        "c2": CatalogContent("c2", "Avatar", 2009, file_ids=("f2",)),
    }
    merge_id = service.merge_content("c1", ("c2",), "ana")
    assert (
        set(catalog.contents["c1"].file_ids) == {"f1", "f2"}
        and "c2" not in catalog.contents
        and len(catalog.files) == 2
    )
    service.revert_merge(merge_id, "ana")
    assert set(catalog.contents) == {"c1", "c2"} and catalog.files["f2"].content_id == "c2"
    assert [record.action for record in catalog.audit] == ["merge", "revert_merge"]


def test_split_attach_detach_and_content_version():
    catalog, service = setup()
    catalog.files = {"f1": file("f1", "c1"), "f2": file("f2", "c1")}
    catalog.contents = {"c1": CatalogContent("c1", "Show", file_ids=("f1", "f2"))}
    service.split_content("c1", ("f2",), CatalogContent("c2", "Show Special"), "ana")
    service.detach_physical_file("c2", "f2", "ana")
    service.attach_physical_file("c1", "f2", "ana")
    service.create_content_version(
        CatalogVersion("v1", "c1", "extended", "latino", "1080p", ("f2",)), "ana"
    )
    assert catalog.files["f2"].version_id == "v1" and catalog.versions["v1"].edition == "extended"


def test_partial_scan_never_marks_out_of_scope_missing():
    catalog, service = setup()
    catalog.files = {"f1": file("f1"), "f2": file("f2", source_id="s2")}
    catalog.availabilities = {
        "a1": AvailabilityRecord(
            "a1", "f1", None, None, "b1", "i1", "s1", CatalogAvailabilityStatus.AVAILABLE, NOW
        ),
        "a2": AvailabilityRecord(
            "a2", "f2", None, None, "b1", "i1", "s2", CatalogAvailabilityStatus.AVAILABLE, NOW
        ),
    }
    service.apply_scan_availability((), full_scan=False, scope_source_ids=("s1",))
    assert all(
        item.status is CatalogAvailabilityStatus.AVAILABLE
        for item in catalog.availabilities.values()
    )


def test_full_scan_requires_safe_confirmation_before_missing():
    catalog, service = setup()
    catalog.files = {"f1": file("f1")}
    catalog.availabilities = {
        "a1": AvailabilityRecord(
            "a1", "f1", None, None, "b1", "i1", "s1", CatalogAvailabilityStatus.AVAILABLE, NOW
        )
    }
    service.apply_scan_availability((), full_scan=True, confirm_missing=False)
    assert catalog.availabilities["a1"].status is CatalogAvailabilityStatus.AVAILABLE
    service.apply_scan_availability((), full_scan=True, confirm_missing=True)
    assert (
        catalog.availabilities["a1"].status is CatalogAvailabilityStatus.MISSING
        and catalog.availabilities["a1"].history
    )


def test_move_rename_and_source_change_require_exact_hash():
    catalog, service = setup()
    catalog.files = {
        "a": file("a", file_hash="hash"),
        "b": file("b", file_hash="hash", source_id="s2"),
    }
    assert service.movement_candidates()[0][2] == "source_changed"
    catalog.files["b"] = file("b", file_hash=None)
    assert service.movement_candidates() == ()


def test_rename_move_and_replacement_are_distinguished_by_hash_and_path():
    catalog, service = setup()
    catalog.files = {
        "a": file("a", file_hash="same", normalized_path="e:/folder/old.mkv"),
        "b": file("b", file_hash="same", normalized_path="e:/folder/new.mkv"),
        "c": file("c", file_hash="same", normalized_path="e:/other/new.mkv"),
    }
    assert {item[2] for item in service.movement_candidates()} == {"renamed", "moved"}
    catalog.files = {
        "a": file("a", file_hash="old", normalized_path="e:/same.mkv"),
        "b": file("b", file_hash="new", normalized_path="e:/same.mkv"),
    }
    assert service.movement_candidates()[0][2] == "replaced"


def test_episode_dvd_and_subtitle_files_remain_distinct_physical_records():
    catalog, _ = setup()
    catalog.files = {
        "episode": file("episode", structure_type="episode", episode_key="S01E01"),
        "dvd": file("dvd", structure_type="dvd_disc"),
        "sub": file("sub", structure_type="subtitle"),
    }
    assert {item.structure_type for item in catalog.files.values()} == {
        "episode",
        "dvd_disc",
        "subtitle",
    }
