"""Reglas puras de sesiones y elementos."""

from dataclasses import replace
from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest

from mce.application.dto import (
    ProcessingSession,
    ProcessingStage,
    SessionItem,
    SessionItemStatus,
    SessionStatus,
)
from mce.application.workspaces import CancellationToken
from mce.domain.value_objects import ImportId, PhysicalFileId, ScanScope, ScanScopeType, SourceId

NOW = datetime(2026, 7, 20, tzinfo=UTC)


def make_item() -> SessionItem:
    return SessionItem(
        str(uuid4()),
        ImportId.new(),
        SourceId.new(),
        PhysicalFileId.new(),
        r"D:\Películas\Avatar.mkv",
    )


def make_session(*items: SessionItem) -> ProcessingSession:
    import_id = items[0].import_id
    items = tuple(
        SessionItem(
            item.item_id,
            import_id,
            item.source_id,
            item.physical_file_id,
            item.original_path,
            item.stage,
            item.status,
            item.warning,
            item.error,
        )
        for item in items
    )
    return ProcessingSession(
        str(uuid4()),
        str(uuid4()),
        import_id,
        "a" * 64,
        ScanScope(ScanScopeType.PARTIAL, (items[0].source_id,)),
        tuple(items),
        NOW,
        NOW,
    )


def test_session_pause_resume_cancel_and_illegal_transitions() -> None:
    session = make_session(make_item()).transition(SessionStatus.READY, at=NOW)
    running = session.transition(SessionStatus.RUNNING, at=NOW)
    paused = running.transition(SessionStatus.PAUSED, at=NOW)
    resumed = paused.transition(SessionStatus.RUNNING, at=NOW)
    cancelled = resumed.transition(SessionStatus.CANCELLED, at=NOW)
    assert cancelled.status is SessionStatus.CANCELLED
    assert cancelled.items[0].status is SessionItemStatus.CANCELLED
    with pytest.raises(ValueError):
        cancelled.transition(SessionStatus.COMPLETED, at=NOW)


def test_cancelled_session_can_only_be_reactivated_after_local_preparation() -> None:
    session = make_session(make_item()).transition(SessionStatus.READY, at=NOW)
    cancelled = session.transition(SessionStatus.CANCELLED, at=NOW)
    prepared_item = replace(
        cancelled.items[0],
        stage=ProcessingStage.READY_FOR_ENRICHMENT,
        classification_status="classified",
        cleaning_status="cleaned",
        status=SessionItemStatus.CANCELLED,
    )
    prepared = replace(cancelled, items=(prepared_item,))

    reactivated = prepared.reactivate_after_local_preparation(at=NOW)

    assert reactivated.status is SessionStatus.READY
    assert reactivated.items[0].status is SessionItemStatus.PENDING


def test_item_failure_is_recoverable_and_summary_reports_progress() -> None:
    first, second = make_item(), make_item()
    session = make_session(first, second).transition(SessionStatus.READY, at=NOW)
    first, second = session.items
    session = session.transition(SessionStatus.RUNNING, at=NOW)
    session = session.replace_item(first.start().finish(warning="ruta dudosa"), at=NOW)
    session = session.replace_item(second.start().fail("registro dañado"), at=NOW)
    assert session.summary.warning == 1
    assert session.summary.failed == 1
    assert session.summary.percent == 100.0
    assert session.transition(SessionStatus.COMPLETED, at=NOW).status is SessionStatus.COMPLETED


def test_failed_session_requires_explicit_retry_and_completed_never_runs() -> None:
    item = make_item()
    running = (
        make_session(item)
        .transition(SessionStatus.READY, at=NOW)
        .transition(SessionStatus.RUNNING, at=NOW)
    )
    failed = running.mark_failed("fatal", at=NOW + timedelta(seconds=1))
    retry = failed.prepare_retry(at=NOW + timedelta(seconds=2))
    assert retry.status is SessionStatus.READY
    assert retry.retry_count == 1
    completed = running.replace_item(item.start().finish(), at=NOW).transition(
        SessionStatus.COMPLETED, at=NOW
    )
    with pytest.raises(ValueError):
        completed.transition(SessionStatus.RUNNING, at=NOW)
    with pytest.raises(ValueError):
        running.transition(SessionStatus.COMPLETED, at=NOW)


def test_stage_advances_explicitly_and_cannot_return_to_imported() -> None:
    item = make_item()
    assert item.stage is ProcessingStage.IMPORTED
    processed = item.processed(ProcessingStage.NORMALIZED)
    assert processed.stage is ProcessingStage.NORMALIZED
    with pytest.raises(ValueError, match="advance beyond imported"):
        processed.processed(ProcessingStage.IMPORTED)


def test_cancellation_token_is_cooperative() -> None:
    token = CancellationToken()
    assert not token.is_cancelled
    token.cancel()
    assert token.is_cancelled
