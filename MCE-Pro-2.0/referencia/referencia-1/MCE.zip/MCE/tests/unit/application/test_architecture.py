"""Límites arquitectónicos de la capa de aplicación."""

import ast
from pathlib import Path

FORBIDDEN = {
    "sqlalchemy",
    "psycopg",
    "sqlite3",
    "PySide6",
    "httpx",
    "requests",
    "reportlab",
    "openpyxl",
}


def imported_roots(path: Path) -> set[str]:
    """Extrae módulos raíz mediante AST, sin ejecutar el archivo."""
    roots: set[str] = set()
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            roots.add(node.module.split(".", 1)[0])
    return roots


def test_application_importer_has_no_prohibited_dependencies() -> None:
    root = Path(__file__).parents[3] / "src" / "mce" / "application"
    violations = {
        str(path): imported_roots(path) & FORBIDDEN
        for path in root.rglob("*.py")
        if imported_roots(path) & FORBIDDEN
    }
    assert not violations


def test_domain_never_imports_application() -> None:
    root = Path(__file__).parents[3] / "src" / "mce" / "domain"
    violations = [
        str(path)
        for path in root.rglob("*.py")
        if "mce.application" in path.read_text(encoding="utf-8")
    ]
    assert not violations


def test_production_presentation_never_composes_fake_metadata_provider() -> None:
    root = Path(__file__).parents[3] / "src" / "mce" / "presentation"
    violations = [
        str(path)
        for path in root.rglob("*.py")
        if "FakeMetadataProvider" in path.read_text(encoding="utf-8")
    ]
    assert not violations
