"""Pruebas unitarias del subsistema de sesiones."""
