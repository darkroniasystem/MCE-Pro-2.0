from mce.application.classification import (
    ClassificationResolutionStatus,
    ClassificationResolver,
    ClassificationSignal,
    ClassificationSignalSource,
)


def signal(source, category, confidence, origin, detail="evidencia", locked=False):
    return ClassificationSignal(source, category, confidence, origin, detail, locked)


def test_local_and_two_structured_tv_signals_resolve_series_with_explanation() -> None:
    result = ClassificationResolver().resolve(
        (
            signal(ClassificationSignalSource.LOCAL, "series", 92, "mce-local"),
            signal(ClassificationSignalSource.PROVIDER, "tv", 90, "tmdb"),
            signal(ClassificationSignalSource.PROVIDER, "series", 88, "tvmaze"),
        )
    )
    assert result.status is ClassificationResolutionStatus.RESOLVED
    assert result.final_category == "series"
    assert "3 señales fiables" in result.explanation


def test_episodic_local_evidence_and_ambiguous_movie_provider_requires_review() -> None:
    result = ClassificationResolver().resolve(
        (
            signal(ClassificationSignalSource.LOCAL, "episode", 95, "mce-local"),
            signal(ClassificationSignalSource.PROVIDER, "movie", 82, "tmdb"),
            signal(ClassificationSignalSource.WEB, "series", 90, "tavily:example"),
        )
    )
    assert result.status is ClassificationResolutionStatus.REQUIRES_REVIEW
    assert result.final_category is None
    assert "local_provider_contradiction" in result.conflicts


def test_web_alone_cannot_determine_final_category() -> None:
    result = ClassificationResolver().resolve(
        (signal(ClassificationSignalSource.WEB, "series", 99, "tavily:example"),)
    )
    assert result.status is ClassificationResolutionStatus.REQUIRES_REVIEW
    assert "insufficient_reliable_consensus" in result.conflicts


def test_locked_human_correction_is_protected_from_all_automatic_signals() -> None:
    result = ClassificationResolver().resolve(
        (
            signal(ClassificationSignalSource.LOCAL, "movie", 99, "mce-local"),
            signal(ClassificationSignalSource.PROVIDER, "movie", 99, "tmdb"),
            signal(
                ClassificationSignalSource.HUMAN,
                "series",
                100,
                "desktop-user",
                "corrección confirmada",
                True,
            ),
        )
    )
    assert result.status is ClassificationResolutionStatus.HUMAN_PROTECTED
    assert result.final_category == "series"
    assert "no pueden sobrescribirla" in result.explanation


def test_conflicting_human_decisions_never_overwrite_each_other() -> None:
    result = ClassificationResolver().resolve(
        (
            signal(ClassificationSignalSource.HUMAN, "movie", 100, "ana"),
            signal(ClassificationSignalSource.HUMAN, "series", 100, "luis"),
        )
    )
    assert result.status is ClassificationResolutionStatus.REQUIRES_REVIEW
    assert result.conflicts == ("conflicting_human_decisions",)
