from dataclasses import replace
from pathlib import Path

import pytest

from mce.application.dto import ImportRequest, ProcessingStage, Workspace
from mce.application.dto.session_models import SessionItemStatus
from mce.application.importers import ImportService
from mce.application.processing import (
    LocalPreparationService,
    enrichment_category,
    matches_enrichment_selection,
)
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)
from mce.domain.value_objects import PhysicalFileId


def _session():
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    ids = UuidGenerator()
    workspaces = InMemoryWorkspaceRepository()
    workspace = Workspace(ids.new_id(), "Preparación offline")
    workspaces.save(workspace)
    return SessionService(
        workspaces,
        InMemorySessionRepository(),
        InMemoryCheckpointStore(),
        SystemClock(),
        ids,
    ).create(workspace.workspace_id, imported)


def test_local_preparation_classifies_and_cleans_without_provider() -> None:
    service = LocalPreparationService()
    classified, classification = service.classify(_session())
    cleaned, summary = service.clean(classified)

    assert classification.total == summary.total == 1
    assert summary.ready_for_enrichment == 1
    assert cleaned.items[0].clean_title
    assert cleaned.items[0].enrichment_status == "pending_enrichment"


def test_local_preparation_is_idempotent() -> None:
    service = LocalPreparationService()
    classified, _ = service.classify(_session())
    cleaned, first = service.clean(classified)
    classified_again, _ = service.classify(cleaned)
    cleaned_again, second = service.clean(classified_again)

    assert cleaned_again == cleaned
    assert second == first


def test_concurso_is_one_of_the_seven_enrichable_content_categories() -> None:
    service = LocalPreparationService()
    base = _session()
    item = replace(
        base.items[0],
        original_name="La.Voz.S01E01.mkv",
        original_path=r"F:\\Concursos\\La Voz\\Temporada 1\\La.Voz.S01E01.mkv",
    )

    classified, _ = service.classify(replace(base, items=(item,)))

    assert classified.items[0].detected_category == "concurso"
    assert {
        "movie",
        "series",
        "novela",
        "dorama",
        "anime",
        "concurso",
        "western_animation",
    } == service.CONTENT_CATEGORIES


def test_one_hundred_series_episodes_become_one_work_and_one_query_estimate() -> None:
    service = LocalPreparationService()
    base = _session()
    original = base.items[0]
    episodes = tuple(
        replace(
            original,
            item_id=UuidGenerator().new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_name=f"Mi.Serie.S01E{number:02d}.mkv",
            original_path=(rf"F:\Series\Mi Serie\Temporada 1\Mi.Serie.S01E{number:02d}.mkv"),
        )
        for number in range(1, 101)
    )
    expanded = replace(base, items=episodes)
    classified, _ = service.classify(expanded)
    cleaned, _ = service.clean(classified)
    grouped, summary = service.group(cleaned)
    estimate = service.estimate(grouped, frozenset({"series"}))

    assert summary.unique_works == 1
    assert len({item.work_group_id for item in grouped.items}) == 1
    assert estimate.selected_files == 100
    assert estimate.unique_works == 1
    assert set(estimate.estimated_queries_by_provider.values()) == {1}


def _classify_path(path: str):
    service = LocalPreparationService()
    session = _session()
    item = replace(
        session.items[0],
        original_path=path,
        original_name=Path(path.replace("\\", "/")).name,
    )
    classified, _ = service.classify(replace(session, items=(item,)))
    return service, classified


def test_musical_movie_is_not_classified_as_generic_music() -> None:
    _, classified = _classify_path(r"F:\Música\Matilda The Musical 2022.mp4")

    assert classified.items[0].detected_category != "music"
    assert classified.items[0].matched_rules != ("music",)


def test_structural_episode_wins_over_music_folder_name() -> None:
    _, classified = _classify_path(
        r"F:\Música\Big Time Rush\Temporada 1\Big.Time.Rush.1x18.El.Videoclip.mkv"
    )

    assert classified.items[0].detected_category == "series"
    assert classified.items[0].classification_reason == ("estructura episódica agrupada como serie")


def test_concert_and_karaoke_wait_for_provider_or_human_review() -> None:
    _, concert = _classify_path(r"F:\Eventos\Concierto de Adele 2016.mkv")
    _, karaoke = _classify_path(r"F:\Karaoke\Grandes éxitos.vob")

    assert concert.items[0].detected_category == "unclassified"
    assert karaoke.items[0].detected_category == "unclassified"
    assert concert.items[0].category_confidence == 50.0
    assert karaoke.items[0].category_confidence == 50.0


def test_audio_is_excluded_from_video_catalog_without_losing_bank_identity() -> None:
    service, classified = _classify_path(r"F:\Música\Album\Canción.mp3")
    cleaned, _ = service.clean(classified)
    grouped, _ = service.group(cleaned)
    item = grouped.items[0]

    assert item.detected_category == "unsupported_media"
    assert item.classification_status == "unsupported_media"
    assert item.enrichment_status == "enrichment_complete"
    assert item.status.value == "skipped"
    assert item.bank_id == _session().items[0].bank_id


def test_subtitle_in_music_folder_is_not_sent_to_enrichment() -> None:
    service, classified = _classify_path(r"F:\Música\Serie\Serie.S01E01.srt")
    cleaned, _ = service.clean(classified)
    grouped, _ = service.group(cleaned)
    item = grouped.items[0]

    assert item.detected_category == "subtitle"
    assert item.stage.value == "consolidated"
    assert item.enrichment_status == "enrichment_complete"


def test_old_music_classification_is_reprocessed_by_version() -> None:
    service = LocalPreparationService()
    session = _session()
    legacy = replace(
        session.items[0],
        original_path=r"F:\Música\Series\Champion\Champion.1x01.mkv",
        original_name="Champion.1x01.mkv",
        detected_category="music",
        classification_status="classified",
        classification_version="mce-local-classification-v1",
        cleaning_status="cleaned",
        grouping_status="grouped",
        grouping_version="mce-work-grouping-v1",
    )

    classified, _ = service.classify(replace(session, items=(legacy,)))
    cleaned, _ = service.clean(classified)
    grouped, _ = service.group(cleaned)

    assert grouped.items[0].detected_category == "series"
    assert grouped.items[0].classification_version == service.CLASSIFICATION_VERSION
    assert grouped.items[0].grouping_version == service.GROUPING_VERSION


def test_anime_episodes_across_seasons_form_one_parent_work() -> None:
    service = LocalPreparationService()
    base = _session()
    original = base.items[0]
    paths = (
        r"F:\Animes\Solo Leveling\Temporada 1\Solo.Leveling.S01E01.mkv",
        r"F:\Animes\Solo Leveling\1RA TEMP [12 CAP]\Solo.Leveling.S01E02.mkv",
        r"F:\Animes\Solo Leveling\Season 2\Solo.Leveling.S02E01.mkv",
    )
    items = tuple(
        replace(
            original,
            item_id=UuidGenerator().new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_path=path,
            original_name=Path(path.replace("\\", "/")).name,
        )
        for path in paths
    )

    classified, _ = service.classify(replace(base, items=items))
    cleaned, _ = service.clean(classified)
    grouped, summary = service.group(cleaned)

    assert {item.detected_category for item in grouped.items} == {"anime"}
    assert {item.work_title for item in grouped.items} == {"Solo Leveling"}
    assert len({item.work_group_id for item in grouped.items}) == 1
    assert summary.unique_works == 1


def test_nearest_series_folder_wins_over_older_movie_folder() -> None:
    _, classified = _classify_path(r"F:\Filmes HD\SERIES\Mi Serie\Temporada 1\Mi.Serie.S01E01.mkv")

    assert classified.items[0].detected_category == "series"


def test_generic_anime_container_splits_works_by_filename_base() -> None:
    service = LocalPreparationService()
    base = _session()
    original = base.items[0]
    names = (
        "Biao Ren Er 1.mp4",
        "Biao Ren Er 2.mp4",
        "Douluo Dalu II Jueshi Tangmen 62.ts",
        "Quanzhi Fashi VII 9.ts",
    )
    items = tuple(
        replace(
            original,
            item_id=UuidGenerator().new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_name=name,
            original_path=rf"F:\Animes\Donghuas [Anime] 2026\{name}",
        )
        for name in names
    )

    classified, _ = service.classify(replace(base, items=items))
    cleaned, _ = service.clean(classified)
    grouped, summary = service.group(cleaned)

    assert [item.work_title for item in grouped.items] == [
        "Biao Ren Er",
        "Biao Ren Er",
        "Douluo Dalu II Jueshi Tangmen",
        "Quanzhi Fashi VII",
    ]
    assert grouped.items[0].work_group_id == grouped.items[1].work_group_id
    assert summary.unique_works == 3


@pytest.mark.parametrize(
    ("path", "expected"),
    [
        (r"F:\Filmes\Dune Parte Dos 2024.mkv", "movie"),
        (r"F:\Novelas\El Jardin de Olivia\01-El Jardin.mp4", "novela"),
        (r"F:\Doramas\Goblin\Goblin.S01E01.mkv", "dorama"),
        (r"F:\Series\Dark\Dark.S01E01.mkv", "series"),
        (r"F:\Animes\Frieren\Frieren.S01E01.mkv", "anime"),
        (r"F:\Animados\Bluey\Bluey.S01E01.mkv", "western_animation"),
    ],
)
def test_final_visible_taxonomy_is_strict(path: str, expected: str) -> None:
    _, classified = _classify_path(path)

    assert classified.items[0].detected_category == expected


def test_cleaning_removes_episode_prefix_and_bank_noise_but_keeps_raw_name() -> None:
    service, classified = _classify_path(
        r"F:\Novelas\El Jardin de Olivia\01-El Jardin de Olivia TROCADERO-363 2025.mp4"
    )
    cleaned, _ = service.clean(classified)

    assert cleaned.items[0].original_name.startswith("01-El Jardin")
    assert "TROCADERO" not in (cleaned.items[0].clean_title or "").upper()


def _group_paths(paths: tuple[str, ...]):
    service = LocalPreparationService()
    base = _session()
    original = base.items[0]
    items = tuple(
        replace(
            original,
            item_id=UuidGenerator().new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_path=path,
            original_name=Path(path.replace("\\", "/")).name,
        )
        for path in paths
    )
    classified, _ = service.classify(replace(base, items=items))
    cleaned, _ = service.clean(classified)
    return service.group(cleaned)[0]


def test_ten_seasons_and_220_files_form_one_logical_work():
    paths = tuple(
        (
            f"F:/Series/The Walking Dead/Temporada {season}/"
            f"The.Walking.Dead.S{season:02d}E{episode:02d}.mkv"
        )
        for season in range(1, 11)
        for episode in range(1, 23)
    )

    grouped = _group_paths(paths)

    assert len(grouped.items) == 220
    assert len({item.work_group_id for item in grouped.items}) == 1
    assert {item.season_number for item in grouped.items} == set(range(1, 11))
    assert {item.work_title for item in grouped.items} == {"The Walking Dead"}


def test_distributed_seasons_across_unrelated_parents_form_one_work():
    paths = (
        r"F:\Series\La Casa del Dragon\Temp 1\La.Casa.Del.Dragon.S01E01.mkv",
        r"F:\Series\La Casa del Dragon\Temp 2\La.Casa.Del.Dragon.S02E01.mkv",
        r"G:\Nuevas\La Casa del Dragon Temp 3\La.Casa.Del.Dragon.S03E01.mkv",
        r"H:\Estrenos\La.Casa.Del.Dragon.Temp.4.1080p\La.Casa.Del.Dragon.S04E01.mkv",
    )

    grouped = _group_paths(paths)

    assert len({item.work_group_id for item in grouped.items}) == 1
    assert {item.season_number for item in grouped.items} == {1, 2, 3, 4}
    assert {item.work_title for item in grouped.items} == {"La Casa Del Dragon"}


@pytest.mark.parametrize(
    "titles",
    [
        (
            "The Walking Dead",
            "Fear the Walking Dead",
            "The Walking Dead Daryl Dixon",
            "The Walking Dead Dead City",
            "Tales of the Walking Dead",
        ),
        ("CSI", "CSI Miami", "CSI New York"),
        ("Narcos", "Narcos Mexico"),
    ],
)
def test_distinctive_spin_off_titles_never_merge(titles):
    paths = tuple(rf"F:\Series\{title}\Temporada 1\{title}.S01E01.mkv" for title in titles)

    grouped = _group_paths(paths)

    assert len({item.work_group_id for item in grouped.items}) == len(titles)


def test_real_28_file_group_uses_clean_folder_title_and_marks_extra():
    folder = "1009-MAKE IT RIGHT THE SERIES"
    paths = (
        rf"F:\Series\{folder}\Everytime_We_Touch_-_Frame_Book_(Cover)(360p).mp4",
        *(
            rf"F:\Series\{folder}\Make.It.Right.The.Series.S01E{episode:02d}.mkv"
            for episode in range(1, 28)
        ),
    )

    grouped = _group_paths(tuple(paths))

    assert len(grouped.items) == 28
    assert len({item.work_group_id for item in grouped.items}) == 1
    assert {item.work_title for item in grouped.items} == {"Make It Right The Series"}
    assert {item.original_group_title for item in grouped.items} == {folder}
    assert {item.order_prefix for item in grouped.items} == {"1009"}
    assert sum(item.possible_extra for item in grouped.items) == 1


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("0052 - CUENTOS DE TERRAMAR - MANGA GHIBLI", "CUENTOS DE TERRAMAR"),
        ("0058 - DRAGON NEST - MANGA LAT", "DRAGON NEST"),
        ("0064 - EL CASTILLO AMBULANTE - MANGA GHIBLI", "EL CASTILLO AMBULANTE"),
        (
            "0103 - FLAVORS OF YOUTH SHIKI ORIORI ANIMADOS MANGA LAT",
            "FLAVORS OF YOUTH SHIKI ORIORI",
        ),
        (
            "0110 - GODZILLA 1 PLANETA DE MONSTRUOS - ANIMADOS MANGA",
            "GODZILLA 1 PLANETA DE MONSTRUOS",
        ),
        ("0118 - HARU EN EL REINO DE LOS GATOS - MANGAS", "HARU EN EL REINO DE LOS GATOS"),
        ("Blade Runner 2049", "Blade Runner 2049"),
        ("300", "300"),
        ("Manga", "Manga"),
    ],
)
def test_review_retry_suggests_a_clean_title_without_losing_identity(raw, expected):
    assert LocalPreparationService().suggest_review_title(raw) == expected


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("Once We Get Married Wiki Drama Fandom files", "Once We Get Married"),
        ("Maids capitulo 13, dorama Maids sub", "Maids"),
        ("Zorro de nueve colas 2 Temp cap6", "Zorro de nueve colas 2"),
    ],
)
def test_review_reprepare_removes_observed_dorama_noise(raw: str, expected: str) -> None:
    assert LocalPreparationService().suggest_review_title(raw) == expected


def test_review_reprepare_recovers_episode_only_title_from_parent_folder() -> None:
    proposed = LocalPreparationService().suggest_review_title_from_evidence(
        "S02E05",
        original_name="S02E05.mkv",
        original_path=r"\\192.168.1.4\doramas\Legal High\Temporada 2\S02E05.mkv",
    )

    assert proposed == "Legal High"


def test_review_retry_is_selected_only_through_virtual_pending_category():
    item = replace(
        _session().items[0],
        detected_category="anime",
        stage=ProcessingStage.READY_FOR_ENRICHMENT,
        review_reason="pending_normalization_retry",
    )

    assert item.detected_category == "anime"
    assert enrichment_category(item) == "pending_retry"
    assert matches_enrichment_selection(item, frozenset({"pending_retry"}))
    assert not matches_enrichment_selection(item, frozenset({"anime"}))


@pytest.mark.parametrize(
    ("path", "base_category", "workflow_category", "expected_title"),
    [
        (
            r"F:\Películas\Dune 2021\VIDEO_TS\VTS_01_1.VOB",
            "movie",
            "movie_vob",
            "Dune 2021",
        ),
        (
            r"F:\Series\Dark\Temporada 1\VIDEO_TS\VTS_01_1.VOB",
            "series",
            "series_vob",
            "Dark",
        ),
        (
            r"F:\Doramas\Goblin\VIDEO_TS\VTS_01_1.VOB",
            "dorama",
            "dorama_vob",
            "Goblin",
        ),
        (
            r"F:\Novelas\La Madrastra\VIDEO_TS\VTS_01_1.VOB",
            "novela",
            "novela_vob",
            "La Madrastra",
        ),
        (
            r"F:\Anime\Evangelion\VIDEO_TS\VTS_01_1.VOB",
            "anime",
            "anime_vob",
            "Evangelion",
        ),
        (
            r"F:\Concursos\La Voz\VIDEO_TS\VTS_01_1.VOB",
            "concurso",
            "concurso_vob",
            "La Voz",
        ),
        (
            r"F:\Animados\Avatar\VIDEO_TS\VTS_01_1.VOB",
            "western_animation",
            "western_animation_vob",
            "Avatar",
        ),
        (
            r"F:\Documentales\Planeta Tierra\VIDEO_TS\VTS_01_1.VOB",
            "movie",
            "movie_vob",
            "Planeta Tierra",
        ),
    ],
)
def test_vob_has_separate_workflow_category_and_uses_folder_identity(
    path: str,
    base_category: str,
    workflow_category: str,
    expected_title: str,
) -> None:
    grouped = _group_paths((path,))
    item = grouped.items[0]

    assert item.detected_category == base_category
    assert enrichment_category(item) == workflow_category
    assert item.work_title == expected_title


def test_identical_vob_fragment_names_in_different_movies_never_merge() -> None:
    grouped = _group_paths(
        (
            r"F:\Películas\Dune 2021\VIDEO_TS\VTS_01_1.VOB",
            r"F:\Películas\Avatar 2009\VIDEO_TS\VTS_01_1.VOB",
            r"F:\Películas\Dune 2021\VIDEO_TS\VTS_01_2.VOB",
        )
    )

    assert {item.work_title for item in grouped.items} == {"Dune 2021", "Avatar 2009"}
    assert len({item.work_group_id for item in grouped.items}) == 2


def test_pending_retry_remains_pending_even_for_vob() -> None:
    item = replace(
        _session().items[0],
        original_name="VTS_01_1.VOB",
        original_path=r"F:\Doramas\Goblin\VIDEO_TS\VTS_01_1.VOB",
        detected_category="dorama",
        review_reason="pending_normalization_retry",
    )

    assert enrichment_category(item) == "pending_retry"


def test_new_grouping_clears_previous_review_state_and_restores_vob_queue() -> None:
    service = LocalPreparationService()
    base_session = _session()
    reviewed = replace(
        base_session.items[0],
        original_name="VTS_01_1.VOB",
        original_path=r"F:\Novelas\La Madrastra\VIDEO_TS\VTS_01_1.VOB",
        detected_category="novela",
        classification_status="classified",
        clean_title="VTS 01 1",
        cleaning_status="cleaned",
        grouping_status="grouped",
        grouping_version="mce-work-grouping-v7",
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        warning="pendiente de revisión",
        enrichment_status="needs_human_review",
        review_reason="pending_normalization_retry",
        human_title_correction="La Madrastra",
        human_title_locked=True,
        providers_completed=("tmdb",),
        identification_query_fingerprints=("old-query",),
    )
    session = replace(base_session, items=(reviewed,))

    grouped, _ = service.group(session)
    item = grouped.items[0]

    assert enrichment_category(item) == "novela_vob"
    assert item.work_title == "La Madrastra"
    assert item.stage is ProcessingStage.READY_FOR_ENRICHMENT
    assert item.status is SessionItemStatus.PENDING
    assert item.enrichment_status == "pending_enrichment"
    assert item.review_reason is None
    assert item.human_title_correction is None
    assert not item.human_title_locked
    assert item.providers_completed == ()
    assert item.identification_query_fingerprints == ()
