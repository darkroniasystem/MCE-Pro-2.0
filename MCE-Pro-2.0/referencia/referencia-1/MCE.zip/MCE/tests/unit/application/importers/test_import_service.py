"""Política atómica, estricta y de resultados del servicio."""

import json
from datetime import UTC, datetime
from pathlib import Path

from mce.application.dto import ImportLimits, ImportRequest, ImportResultStatus
from mce.application.importers import ImportService
from mce.application.importers.local_services import InMemoryImportRegistry

FIXTURES = Path(__file__).parents[3] / "fixtures" / "msl"
NOW = datetime(2026, 7, 19, 15, tzinfo=UTC)


def test_valid_file_maps_phase_one_domain_without_content() -> None:
    result = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "valid_minimal_v1.json")
    )
    assert result.status is ImportResultStatus.COMPLETED
    assert result.package is not None
    assert len(result.package.domain_sources) == 1
    assert len(result.package.domain_files) == 1
    assert len(result.package.domain_subtitles) == 0
    assert not hasattr(result.package, "domain_contents")
    assert result.package.domain_files[0].scan_id == result.package.domain_scan.scan_id
    assert (
        result.package.domain_sources[0].installation_id
        == result.package.domain_scan.installation_id
    )


def test_normal_allows_warning_but_strict_rejects_same_document() -> None:
    normal = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "summary_mismatch.json")
    )
    strict = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "summary_mismatch.json", strict_mode=True)
    )
    assert normal.status is ImportResultStatus.COMPLETED_WITH_WARNINGS
    assert normal.package is not None
    assert strict.status is ImportResultStatus.REJECTED
    assert strict.package is None


def test_legacy_policy_and_unsupported_schema() -> None:
    allowed = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "legacy_without_version.json", allow_legacy=True)
    )
    rejected = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "legacy_without_version.json", allow_legacy=False)
    )
    unsupported = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "unsupported_version.json")
    )
    assert allowed.success
    assert rejected.status is ImportResultStatus.INCOMPATIBLE
    assert unsupported.status is ImportResultStatus.UNSUPPORTED_SCHEMA


def test_invalid_json_empty_and_size_limit_are_controlled(tmp_path: Path) -> None:
    service = ImportService(clock=lambda: NOW)
    invalid = service.import_file(ImportRequest(FIXTURES / "invalid_json.json"))
    empty = tmp_path / "empty.json"
    empty.touch()
    empty_result = service.import_file(ImportRequest(empty))
    too_large = service.import_file(
        ImportRequest(FIXTURES / "valid_minimal_v1.json", limits=ImportLimits(max_file_size_mb=0))
    )
    assert invalid.status is ImportResultStatus.INVALID_JSON
    assert empty_result.issues[0].code == "FILE_EMPTY"
    assert too_large.issues[0].code == "FILE_TOO_LARGE"


def test_duplicate_is_explicit_and_does_not_remap() -> None:
    registry = InMemoryImportRegistry()
    service = ImportService(registry=registry, clock=lambda: NOW)
    request = ImportRequest(FIXTURES / "valid_minimal_v1.json")
    assert service.import_file(request).success
    duplicate = service.import_file(request)
    assert duplicate.status is ImportResultStatus.DUPLICATE
    assert duplicate.package is None


def test_progress_reports_pipeline_stages() -> None:
    stages: list[str] = []
    result = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(FIXTURES / "valid_minimal_v1.json"), stages.append
    )
    assert result.success
    assert stages == [
        "reading",
        "hashing",
        "detecting_schema",
        "validating_structure",
        "validating_records",
        "mapping",
        "completed",
    ]


def test_generated_large_sample_hits_record_limit(tmp_path: Path) -> None:
    path = tmp_path / "large.json"
    payload = {
        "schema_version": "1.0",
        "sources": [],
        "files": [{"name": f"{index}.mkv", "relative_path": f"{index}.mkv"} for index in range(3)],
    }
    path.write_text(json.dumps(payload), encoding="utf-8")
    result = ImportService(clock=lambda: NOW).import_file(
        ImportRequest(path, limits=ImportLimits(max_total_records=2))
    )
    assert result.status is ImportResultStatus.REJECTED
    assert "RECORD_LIMIT_EXCEEDED" in {issue.code for issue in result.issues}
