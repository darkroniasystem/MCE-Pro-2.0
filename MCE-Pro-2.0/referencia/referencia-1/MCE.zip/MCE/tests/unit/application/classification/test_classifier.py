"""Clasificación conservadora, evidencia y conflictos."""

import pytest

from mce.application.classification import ClassificationPolicy, MediaClassifier
from mce.application.classification.models import MediaKind
from mce.application.normalization import FilenameNormalizationPipeline


def classify(name, path=None):
    analysis = FilenameNormalizationPipeline().analyze(name, original_path=path)
    return MediaClassifier().classify(analysis)


@pytest.mark.parametrize(
    ("name", "path", "kind"),
    [
        ("Avatar.2009.1080p.mkv", None, MediaKind.MOVIE),
        ("The.Boys.S03E05.mkv", None, MediaKind.EPISODE),
        ("Show.mkv", r"D:\Series\Temporada 1\Show.mkv", MediaKind.SEASON),
        ("Show.mkv", r"D:\Series\Show\Show.mkv", MediaKind.SERIES),
        ("Anime Ep 101.mkv", r"D:\Anime\Show", MediaKind.EPISODE),
        ("Frieren.S01E02.mkv", r"D:\Anime\Frieren", MediaKind.EPISODE),
        ("Amor Eterno S01E01.mkv", r"D:\Novelas", MediaKind.EPISODE),
        ("Crash Landing S01E01.mkv", r"D:\Doramas", MediaKind.EPISODE),
        ("Planet Earth 2020.mkv", r"D:\Documentales", MediaKind.DOCUMENTARY),
        ("Batman Special.mkv", None, MediaKind.SPECIAL),
        ("VIDEO_TS.IFO", r"E:\DVD\VIDEO_TS\VIDEO_TS.IFO", MediaKind.DVD_DISC),
    ],
)
def test_classification_types_include_evidence(name, path, kind):
    result = classify(name, path)
    assert result.kind is kind and result.confidence >= 60 and result.evidence


def test_insufficient_evidence_remains_unknown():
    result = classify("Vacaciones.mkv")
    assert result.kind is MediaKind.UNKNOWN and result.warnings


@pytest.mark.parametrize("name", ["Animexample.mkv", "Especialista.mkv", "Novelaciones.mkv"])
def test_filename_keywords_respect_word_boundaries(name):
    assert classify(name).kind is MediaKind.UNKNOWN


def test_close_anime_episode_signals_create_visible_conflict():
    result = classify("Serie.S01E01.mkv", r"D:\Anime\Serie")
    assert result.conflict is not None and result.alternatives


def test_policy_can_refuse_weak_movie_candidate():
    analysis = FilenameNormalizationPipeline().analyze("Film.2020.mkv")
    assert (
        MediaClassifier(ClassificationPolicy(minimum_confidence=80)).classify(analysis).kind
        is MediaKind.UNKNOWN
    )
