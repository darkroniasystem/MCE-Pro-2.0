"""Tipos de duplicado y evidencia conservadora."""

from mce.application.deduplication import FindDuplicateCandidates
from mce.application.deduplication.models import CatalogFile, DuplicateType


def file(identifier, **changes):
    values = dict(
        file_id=identifier,
        bank_id="b1",
        installation_id="i1",
        source_id="s1",
        path=f"E:/{identifier}.mkv",
        normalized_path=f"e:/{identifier}.mkv",
        name="Avatar.mkv",
        size_bytes=100,
    )
    values.update(changes)
    return CatalogFile(**values)


def detect(left, right):
    return FindDuplicateCandidates().execute((left, right))[0]


def test_exact_hash_and_path_are_strong_evidence():
    left = file("a", file_hash="x")
    right = file("b", file_hash="x", path=left.path, normalized_path=left.normalized_path)
    result = detect(left, right)
    assert result.duplicate_type is DuplicateType.DUPLICATE_PHYSICAL_FILE
    assert {"normalized_path", "full_hash"} <= {e.signal for e in result.evidence}


def test_same_path_in_different_banks_is_not_physical_duplicate():
    left = file("a")
    right = file("b", bank_id="b2", path=left.path, normalized_path=left.normalized_path)
    result = detect(left, right)
    assert result.duplicate_type is DuplicateType.METADATA_DUPLICATE


def test_same_content_distinguishes_file_and_version():
    same = detect(file("a", content_id="c"), file("b", content_id="c"))
    version = detect(
        file("a", content_id="c", resolution="1080p"),
        file("b", content_id="c", resolution="4k", edition="extended", language="latino"),
    )
    assert same.duplicate_type is DuplicateType.SAME_CONTENT_DIFFERENT_FILE
    assert version.duplicate_type is DuplicateType.SAME_CONTENT_DIFFERENT_VERSION


def test_same_title_with_different_size_is_only_probable():
    assert (
        detect(file("a", size_bytes=1), file("b", size_bytes=2)).duplicate_type
        is DuplicateType.PROBABLE_DUPLICATE
    )


def test_hash_across_banks_means_separate_files_with_matching_bytes():
    result = detect(file("a", file_hash="x"), file("b", bank_id="b2", file_hash="x"))
    assert result.duplicate_type is DuplicateType.HASH_DUPLICATE


def test_large_unrelated_catalog_does_not_require_all_pair_comparisons() -> None:
    files = tuple(
        file(
            f"file-{index}",
            name=f"Title {index}.mkv",
            normalized_path=f"e:/title-{index}.mkv",
            size_bytes=index,
        )
        for index in range(5_000)
    )
    assert FindDuplicateCandidates().execute(files) == ()
