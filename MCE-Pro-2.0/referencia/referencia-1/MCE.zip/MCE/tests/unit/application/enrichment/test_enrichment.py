"""Procedencia, conflictos, bloqueos, correcciones y revisión."""

from datetime import UTC, datetime

import pytest

from mce.application.enrichment import InMemoryReviewRepository, MetadataConsolidator, ReviewService
from mce.application.enrichment.models import (
    FieldLockState,
    MetadataField,
    ReviewItem,
    ReviewItemStatus,
)
from mce.domain.value_objects import ConfidenceScore, FieldProvenance, FieldSourceType

NOW = datetime(2026, 7, 20, tzinfo=UTC)


def provenance(source, name="source", confidence=80):
    return FieldProvenance(source, name, "record-1", NOW, ConfidenceScore(confidence))


def make_item():
    return ReviewItem(
        "r1",
        "candidate-1",
        {
            "title": MetadataField("Avatar", provenance(FieldSourceType.IMPORTED)),
            "release_year": MetadataField(2022, provenance(FieldSourceType.IMPORTED)),
            "aliases": MetadataField(("Avatar",), provenance(FieldSourceType.PROVIDER)),
        },
    )


@pytest.fixture
def review():
    repository = InMemoryReviewRepository()
    repository.save(make_item())
    return ReviewService(repository, lambda: NOW)


def test_field_provenance_and_partial_metadata_are_preserved():
    current = make_item()
    assert current.fields["title"].provenance.source_name == "source"
    assert "overview" not in current.fields


def test_provider_difference_creates_conflict_and_higher_priority_wins():
    merged = MetadataConsolidator().merge(
        make_item(),
        {"release_year": MetadataField(2021, provenance(FieldSourceType.PROVIDER, "tmdb", 95))},
    )
    assert merged.fields["release_year"].value == 2021
    assert merged.conflicts[0].options[0].value == 2022


def test_manual_lock_protects_field_from_automatic_provider():
    current = make_item()
    fields = dict(current.fields)
    fields["title"] = MetadataField(
        "Manual", provenance(FieldSourceType.MANUAL), FieldLockState.MANUAL_LOCKED
    )
    current = ReviewItem(current.review_id, current.candidate_reference, fields)
    merged = MetadataConsolidator().merge(
        current, {"title": MetadataField("Automatic", provenance(FieldSourceType.PROVIDER))}
    )
    assert merged.fields["title"].value == "Manual" and merged.conflicts


def test_lock_unlock_correction_and_reversion_are_audited(review):
    review.correct_metadata(
        "r1",
        "title",
        "Avatar corregido",
        provenance(FieldSourceType.MANUAL, "user", 100),
        "ana",
        "ortografía",
    )
    locked = review.lock_field("r1", "title", "ana")
    assert locked.fields["title"].lock_state is FieldLockState.MANUAL_LOCKED
    unlocked = review.unlock_field("r1", "title", "ana")
    assert unlocked.fields["title"].lock_state is FieldLockState.UNLOCKED
    reverted = review.revert_correction("r1", "title", "ana")
    assert reverted.fields["title"].value == "Avatar"
    assert [record.action for record in reverted.audit] == [
        "correct",
        "lock",
        "unlock",
        "revert_correction",
    ]


def test_approve_reject_list_and_details_are_explicit(review):
    assert review.list_pending_reviews()[0].review_id == "r1"
    assert review.get_review_details("r1").candidate_reference == "candidate-1"
    approved = review.approve_candidate("r1", "ana", "confirmado")
    assert approved.status is ReviewItemStatus.APPROVED
    with pytest.raises(ValueError):
        review.reject_candidate("r1", "ana")


def test_rejection_is_auditable():
    repo = InMemoryReviewRepository()
    repo.save(make_item())
    rejected = ReviewService(repo, lambda: NOW).reject_candidate("r1", "ana", "incorrecto")
    assert rejected.status is ReviewItemStatus.REJECTED and rejected.audit[-1].actor == "ana"


def test_conflict_resolution_must_select_existing_option(review):
    merged = MetadataConsolidator().merge(
        review.get_review_details("r1"),
        {"release_year": MetadataField(2021, provenance(FieldSourceType.PROVIDER))},
    )
    review.repository.save(merged)
    resolved = review.resolve_conflict("r1", "release_year", 2022, "ana", "confirmado")
    assert resolved.conflicts[0].resolution.actor == "ana"
    assert resolved.fields["release_year"].value == 2022
    with pytest.raises(ValueError):
        review.resolve_conflict("r1", "release_year", 2000, "ana")


def test_multiple_aliases_and_controlled_overview_correction(review):
    corrected = review.correct_metadata(
        "r1",
        "overview",
        "Sinopsis controlada",
        provenance(FieldSourceType.MANUAL, "ana", 100),
        "ana",
    )
    assert corrected.fields["overview"].value == "Sinopsis controlada"
    assert len(corrected.fields["aliases"].value) == 1


def test_bulk_approval_updates_five_hundred_reviews_in_one_operation() -> None:
    repository = InMemoryReviewRepository()
    items = tuple(
        ReviewItem(
            f"r{index}",
            f"candidate-{index}",
            {"title": MetadataField(f"Obra {index}", provenance(FieldSourceType.IMPORTED))},
        )
        for index in range(500)
    )
    repository.save_many(items)
    service = ReviewService(repository, lambda: NOW)

    decided = service.decide_many(
        tuple(item.review_id for item in items),
        ReviewItemStatus.APPROVED,
        "desktop-user",
    )

    assert len(decided) == 500
    assert all(item.status is ReviewItemStatus.APPROVED for item in decided)
    assert service.list_pending_reviews() == ()
