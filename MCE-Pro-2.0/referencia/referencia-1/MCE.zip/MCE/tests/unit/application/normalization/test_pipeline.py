"""Corpus representativo y reglas explicables del normalizador de Fase 4."""

import pytest

from mce.application.normalization import FilenameNormalizationPipeline
from mce.application.normalization.models import TokenKind
from mce.application.normalization.token_dictionary import TokenDictionary


@pytest.fixture(scope="module")
def pipeline():
    return FilenameNormalizationPipeline()


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("Avatar.2009.1080p.BluRay.x264.Latino.mkv", "Avatar"),
        ("The.Boys.S03E05.720p.WEB-DL.mkv", "The Boys"),
        ("Batman Begins (2005) ESP-LATINO.mp4", "Batman Begins"),
        ("John Wick 4 2023 1080p.mkv", "John Wick 4"),
        ("[SubsPlease] Sousou no Frieren - 12 [1080p].mkv", "Sousou no Frieren - 12"),
        ("ElNiñoYLaGarza.2023.1080p.mkv", "El Niño YLa Garza"),
        ("Брат.2.2000.DVDRip.avi", "Брат 2"),
        ("Crash Landing on You 2019 1080p.mkv", "Crash Landing on You"),
        ("Planet.Earth.II.S01E01.2160p.HDR.mkv", "Planet Earth II"),
        ("Toy.Story.1995.Dual.mkv", "Toy Story"),
        ("VIDEO_TS.IFO", "VIDEO TS"),
        ("película-mal_escrita 720p.mp4", "película-mal escrita"),
    ],
)
def test_realistic_names_produce_expected_candidate(pipeline, name, expected):
    assert pipeline.analyze(name).candidates[0].value == expected


def test_extracts_signals_and_explains_every_removal(pipeline):
    result = pipeline.analyze("Movie.2020.1080p.BluRay.x265.DTS.Latino.Extended.HDR.3D-GRP.mkv")
    kinds = {token.kind for token in result.tokens}
    assert {
        TokenKind.YEAR,
        TokenKind.RESOLUTION,
        TokenKind.SOURCE,
        TokenKind.VIDEO_CODEC,
        TokenKind.AUDIO_CODEC,
        TokenKind.LANGUAGE,
        TokenKind.EDITION,
        TokenKind.HDR,
    } <= kinds
    assert result.year.value == 2020 and result.resolution.value == "1080p"
    assert len(result.trace) == sum(token.removed for token in result.tokens)


@pytest.mark.parametrize("name", ["1917.mkv", "24.mkv", "2046.mkv"])
def test_numeric_titles_are_not_destroyed(pipeline, name):
    result = pipeline.analyze(name)
    assert result.candidates[0].value == name.rsplit(".", 1)[0]
    assert result.year is None


@pytest.mark.parametrize(
    ("name", "season", "start", "end"),
    [
        ("Show.S01E02.mkv", 1, 2, None),
        ("Show.2x07.mkv", 2, 7, None),
        ("Show.S03E05-E06.mkv", 3, 5, 6),
        ("Show T1 E9.mkv", 1, 9, None),
        ("Show Episodio 12.mkv", None, 12, None),
        ("Anime Cap 101-102.mkv", None, 101, 102),
    ],
)
def test_episode_patterns_are_hints_not_classification(pipeline, name, season, start, end):
    hint = pipeline.analyze(name).episode
    assert (hint.season, hint.episode_start, hint.episode_end) == (season, start, end)


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("Show Episodio 12.mkv", "Show"),
        ("Show Episode 12-13.mkv", "Show"),
        ("Show Capítulo 101.mkv", "Show"),
        ("Show T1 E9.mkv", "Show"),
    ],
)
def test_episode_signals_are_removed_as_a_complete_unit(pipeline, name, expected):
    result = pipeline.analyze(name)
    assert result.candidates[0].value == expected
    assert all(token.kind is TokenKind.EPISODE for token in result.tokens if token.removed)


def test_original_name_and_path_never_change(pipeline):
    name = "  Película.日本語.2024.1080p.mkv"
    path = r"E:\Películas\  Película.日本語.2024.1080p.mkv"
    result = pipeline.analyze(name, original_path=path)
    assert result.original_name == name and result.original_path == path


def test_rejects_null_characters_without_modifying_input(pipeline):
    with pytest.raises(ValueError, match="null characters"):
        pipeline.analyze("Movie\x00.2024.mkv")


def test_nfkc_view_is_stable_while_original_unicode_is_preserved(pipeline):
    name = (
        "\uff2d\uff4f\uff56\uff49\uff45\uff0e\uff12\uff10\uff12\uff14"
        "\uff0e\uff11\uff10\uff18\uff10\uff50.mkv"
    )
    first = pipeline.analyze(name)
    second = pipeline.analyze(name)
    assert first == second
    assert first.original_name == name
    assert first.normalized_text == "Movie 2024 1080p"
    assert first.candidates[0].value == "Movie"


def test_token_dictionary_copies_and_protects_custom_mapping():
    source = {"CUSTOM": TokenKind.NOISE}
    dictionary = TokenDictionary(source)
    source["CUSTOM"] = TokenKind.TITLE
    assert dictionary.classify("custom") is TokenKind.NOISE
    with pytest.raises(TypeError):
        dictionary.mapping["new"] = TokenKind.NOISE  # type: ignore[index]


def test_ambiguous_year_yields_multiple_candidates(pipeline):
    result = pipeline.analyze("It.2017.1080p.mkv")
    assert len(result.candidates) == 2 and result.candidates[0].value == "It"


def test_volume_part_quality_region_and_release_group_are_traced(pipeline):
    result = pipeline.analyze("Anime.Vol2.Part1.NTSC.WEB-DL.[Group].mkv")
    kinds = {token.kind for token in result.tokens}
    assert {
        TokenKind.VOLUME,
        TokenKind.PART,
        TokenKind.REGION,
        TokenKind.SOURCE,
        TokenKind.RELEASE_GROUP,
    } <= kinds


@pytest.mark.parametrize(
    ("name", "expected_title", "expected_year"),
    [
        ("Rambo 1 1990 HD H264 1080p.mkv", "Rambo 1", 1990),
        ("Rambo 1 (1990).mkv", "Rambo 1", 1990),
        ("Rambo 1 [1990].mkv", "Rambo 1", 1990),
        ("Rambo 1 - 1990.mkv", "Rambo 1", 1990),
        ("Matrix.1999.1080p.BluRay.mkv", "Matrix", 1999),
    ],
)
def test_contextual_year_is_extracted_without_becoming_part_of_title(
    pipeline, name, expected_title, expected_year
):
    result = pipeline.analyze(name)

    assert result.candidates[0].value == expected_title
    assert result.year is not None and result.year.value == expected_year


@pytest.mark.parametrize(
    "name",
    [
        "1984.mkv",
        "1917.mkv",
        "1899.mkv",
        "1923.mkv",
        "24.mkv",
        "300.mkv",
        "9-1-1.mkv",
        "2001 A Space Odyssey.mkv",
        "Blade Runner 2049.mkv",
        "2 Broke Girls.mkv",
        "3 Body Problem.mkv",
        "13 Reasons Why.mkv",
        "10 Things I Hate About You.mkv",
        "21 Jump Street.mkv",
        "50 First Dates.mkv",
    ],
)
def test_all_authorized_numeric_titles_are_preserved(pipeline, name):
    result = pipeline.analyze(name)

    assert result.candidates[0].value == name.rsplit(".", 1)[0]
    assert result.year is None


@pytest.mark.parametrize("name", ["Rambo 1.mkv", "Rambo 2.mkv", "Rocky 4.mkv", "Toy Story 3.mkv"])
def test_sequel_number_is_preserved(pipeline, name):
    assert pipeline.analyze(name).candidates[0].value == name.rsplit(".", 1)[0]


@pytest.mark.parametrize(
    ("name", "prefix", "title"),
    [
        ("1009-MAKE IT RIGHT THE SERIES", "1009", "MAKE IT RIGHT THE SERIES"),
        ("1009 - MAKE IT RIGHT THE SERIES", "1009", "MAKE IT RIGHT THE SERIES"),
        ("1009. MAKE IT RIGHT THE SERIES", "1009", "MAKE IT RIGHT THE SERIES"),
        ("0012_THE FLASH", "0012", "THE FLASH"),
        ("045 GAME OF THRONES", "045", "GAME OF THRONES"),
    ],
)
def test_order_prefix_is_structured_and_excluded_from_title(pipeline, name, prefix, title):
    result = pipeline.analyze(name)

    assert result.original_name == name
    assert result.order_prefix is not None and result.order_prefix.value == prefix
    assert result.candidates[0].value == title


@pytest.mark.parametrize(
    ("name", "season", "episode", "title"),
    [
        ("Show.S01E03.mkv", 1, 3, "Show"),
        ("Show.01x03.mkv", 1, 3, "Show"),
        ("Show Temp 2.mkv", 2, None, "Show"),
        ("Show Temporada 2.mkv", 2, None, "Show"),
        ("Show Cap 05.mkv", None, 5, "Show"),
    ],
)
def test_season_and_episode_signals_do_not_pollute_base_title(
    pipeline, name, season, episode, title
):
    result = pipeline.analyze(name)

    assert result.candidates[0].value == title
    assert (result.season.value if result.season else None) == season
    assert (result.episode.episode_start if result.episode else None) == episode


def test_frame_book_cover_is_detected_as_extra_without_losing_original(pipeline):
    name = "Everytime_We_Touch_-_Frame_Book_(Cover)(360p).mp4"
    result = pipeline.analyze(name)

    assert result.possible_extra
    assert result.original_name == name
