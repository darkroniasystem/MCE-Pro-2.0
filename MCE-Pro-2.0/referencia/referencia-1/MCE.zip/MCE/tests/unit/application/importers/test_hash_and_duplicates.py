"""Hash por bloques y registro en memoria."""

from pathlib import Path

from mce.application.importers.duplicate_import_checker import DuplicateImportChecker
from mce.application.importers.local_services import InMemoryImportRegistry, LocalSha256Calculator


def test_sha256_is_stable_and_changes_with_content(tmp_path: Path) -> None:
    path = tmp_path / "scan.json"
    calculator = LocalSha256Calculator(chunk_size=2)
    path.write_bytes(b"abc")
    first = calculator.calculate(path)
    assert first == calculator.calculate(path)
    path.write_bytes(b"abcd")
    assert calculator.calculate(path) != first


def test_in_memory_registry_detects_only_registered_hashes() -> None:
    registry = InMemoryImportRegistry()
    checker = DuplicateImportChecker(registry)
    assert not checker.is_duplicate("a" * 64)
    registry.add_hash("a" * 64)
    assert checker.is_duplicate("a" * 64)
