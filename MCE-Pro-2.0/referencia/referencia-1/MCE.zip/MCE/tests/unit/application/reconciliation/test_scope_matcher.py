"""Cobertura conservadora de escaneos completos y parciales."""

from mce.application.reconciliation import ScopeMatcher
from mce.domain.value_objects import ScanScopeType


def test_full_scope_covers_every_path_in_the_same_installation_query():
    matcher = ScopeMatcher(ScanScopeType.FULL)
    assert matcher.covers("source-a", r"D:\Media\Film.mkv")


def test_generic_partial_scope_never_asserts_absence():
    matcher = ScopeMatcher(ScanScopeType.PARTIAL, frozenset({"source-a"}))
    assert not matcher.covers("source-a", r"D:\Media\Absent.mkv")


def test_selected_sources_only_covers_declared_sources():
    matcher = ScopeMatcher(ScanScopeType.SELECTED_SOURCES, frozenset({"source-a"}))
    assert matcher.covers("source-a", r"D:\Media\Absent.mkv")
    assert not matcher.covers("source-b", r"E:\Other\Absent.mkv")


def test_selected_paths_uses_path_boundaries_not_prefixes():
    matcher = ScopeMatcher(
        ScanScopeType.SELECTED_PATHS,
        included_paths=(r"d:\media\shows",),
    )
    assert matcher.covers("source-a", r"D:\Media\Shows\One\Episode.mkv")
    assert not matcher.covers("source-a", r"D:\Media\Shows-old\Episode.mkv")
