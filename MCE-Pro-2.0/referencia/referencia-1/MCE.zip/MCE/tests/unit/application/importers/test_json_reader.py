"""Seguridad y decodificación del lector JSON."""

import json
from pathlib import Path

import pytest

from mce.application.dto import ImportLimits
from mce.application.exceptions import (
    ImportFileAccessError,
    ImportFileNotFoundError,
    ImportFileTooLargeError,
    InvalidJsonError,
)
from mce.application.importers.json_reader import SafeJsonReader


def test_reads_utf8_and_utf8_bom_object(tmp_path: Path) -> None:
    reader = SafeJsonReader()
    plain = tmp_path / "plain.json"
    bom = tmp_path / "bom.json"
    plain.write_text('{"title": "Amélie"}', encoding="utf-8")
    bom.write_text('{"title": "日本語"}', encoding="utf-8-sig")
    assert reader.read(plain, ImportLimits())["title"] == "Amélie"
    assert reader.read(bom, ImportLimits())["title"] == "日本語"


def test_rejects_missing_empty_wrong_extension_and_too_large(tmp_path: Path) -> None:
    reader = SafeJsonReader()
    with pytest.raises(ImportFileNotFoundError) as missing:
        reader.read(tmp_path / "missing.json", ImportLimits())
    assert missing.value.code == "FILE_NOT_FOUND"
    empty = tmp_path / "empty.json"
    empty.touch()
    with pytest.raises(InvalidJsonError) as empty_error:
        reader.read(empty, ImportLimits())
    assert empty_error.value.code == "FILE_EMPTY"
    wrong = tmp_path / "scan.txt"
    wrong.write_text("{}", encoding="utf-8")
    with pytest.raises(ImportFileAccessError):
        reader.read(wrong, ImportLimits())
    oversized = tmp_path / "large.json"
    oversized.write_text("{}", encoding="utf-8")
    with pytest.raises(ImportFileTooLargeError):
        reader.read(oversized, ImportLimits(max_file_size_mb=0))


def test_default_limit_supports_large_bank_inventories() -> None:
    assert ImportLimits().max_file_size_mb == 1024
    assert ImportLimits().max_file_size_bytes == 1024 * 1024 * 1024


@pytest.mark.parametrize("payload", ["{bad", "[]", '"text"'])
def test_rejects_malformed_or_non_object_root(tmp_path: Path, payload: str) -> None:
    path = tmp_path / "bad.json"
    path.write_text(payload, encoding="utf-8")
    with pytest.raises(InvalidJsonError):
        SafeJsonReader().read(path, ImportLimits())


def test_rejects_excessive_depth(tmp_path: Path) -> None:
    path = tmp_path / "deep.json"
    value: object = "leaf"
    for _ in range(6):
        value = {"child": value}
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(InvalidJsonError) as error:
        SafeJsonReader().read(path, ImportLimits(max_json_depth=5))
    assert error.value.code == "JSON_DEPTH_EXCEEDED"
