"""Validación estructural, semántica y clasificación multimedia."""

from mce.application.dto import DetectedMediaType, ImportLimits
from mce.application.importers.media_classifier import classify_media
from mce.application.importers.schema_validator import StructuralValidator
from mce.application.importers.semantic_validator import SemanticValidator, parse_timestamp


def test_classifies_video_subtitle_txt_dvd_and_unknown() -> None:
    assert classify_media("Film.MKV", ".mkv") is DetectedMediaType.VIDEO
    assert classify_media("Film.srt", ".srt") is DetectedMediaType.SUBTITLE
    assert classify_media("notes.txt", ".txt") is DetectedMediaType.SUBTITLE_PROBABLE
    assert classify_media("VIDEO_TS.IFO", ".ifo") is DetectedMediaType.DVD
    assert classify_media("VTS_01_1.VOB", ".vob") is DetectedMediaType.DVD
    assert classify_media("cover.jpg", ".jpg") is DetectedMediaType.UNKNOWN


def test_structural_validator_reports_containers_and_records() -> None:
    validator = StructuralValidator()
    issues = validator.validate(
        {"sources": {}, "files": [], "_sources_container_valid": False}, ImportLimits()
    )
    assert "INVALID_SOURCES_LIST" in {issue.code for issue in issues}
    issues = validator.validate(
        {"sources": [], "files": [{"name": "", "relative_path": "", "full_path": ""}]},
        ImportLimits(),
    )
    assert {"FILE_NAME_MISSING", "PATH_MISSING"} <= {issue.code for issue in issues}


def test_semantic_validator_reports_references_paths_media_and_summary() -> None:
    document = {
        "sources": [{"source_id": "s", "display_name": "D", "root_path": "D:\\"}],
        "files": [
            {
                "file_id": "f",
                "source_id": "missing",
                "name": "video.srt",
                "relative_path": "a\x00b",
                "extension": ".srt",
                "media_type": "video",
            }
        ],
        "scan": {
            "started_at": "2026-07-20T00:00:00Z",
            "finished_at": "2026-07-19T00:00:00Z",
            "scope": {"type": "full"},
        },
        "summary": {"total_files": 2},
    }
    codes = {issue.code for issue in SemanticValidator().validate(document, ImportLimits())}
    assert {
        "SOURCE_REFERENCE_NOT_FOUND",
        "PATH_CONTAINS_NULL",
        "INVALID_MEDIA_TYPE",
        "INVALID_SCAN_RANGE",
        "SUMMARY_MISMATCH",
    } <= codes


def test_timestamp_requires_timezone_and_normalizes_to_utc() -> None:
    assert parse_timestamp("2026-07-19T10:00:00-04:00").hour == 14  # type: ignore[union-attr]
    assert parse_timestamp("2026-07-19T10:00:00") is None
    assert parse_timestamp("bad") is None


def test_limits_sources_and_records() -> None:
    issues = StructuralValidator().validate(
        {"sources": [{}, {}], "files": [{}]},
        ImportLimits(max_sources=1, max_total_records=2),
    )
    assert {"SOURCE_LIMIT_EXCEEDED", "RECORD_LIMIT_EXCEEDED"} <= {issue.code for issue in issues}


def test_txt_is_reported_as_ambiguous_and_name_extension_wins() -> None:
    document = {
        "sources": [{"source_id": "s", "display_name": "D", "root_path": "D:\\"}],
        "files": [
            {
                "source_id": "s",
                "name": "notes.txt",
                "relative_path": "notes.txt",
                "extension": ".mkv",
                "media_type": "subtitle",
            }
        ],
        "scan": {"scope": {"type": "full"}},
        "summary": {"total_files": 1, "video_files": 0, "subtitle_files": 1},
        "generator": {"version": "1.0"},
        "bank": {"name": "B"},
        "installation": {"name": "I"},
    }
    codes = {issue.code for issue in SemanticValidator().validate(document, ImportLimits())}
    assert {"AMBIGUOUS_TEXT_FILE", "EXTENSION_MISMATCH"} <= codes


def test_import_limits_reject_invalid_configuration() -> None:
    import pytest

    with pytest.raises(ValueError):
        ImportLimits(max_json_depth=0)
