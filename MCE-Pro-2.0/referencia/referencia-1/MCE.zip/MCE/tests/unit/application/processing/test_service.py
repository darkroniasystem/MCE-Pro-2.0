from dataclasses import replace
from pathlib import Path

import pytest
from tests.fakes import FakeMetadataProvider
from tests.unit.application.identification.test_identification import candidate

from mce.application.ai_review import (
    AIReviewDecision,
    AIReviewResult,
    AIReviewState,
    EvidenceSource,
)
from mce.application.dto import (
    ImportRequest,
    ProcessingStage,
    SessionItemStatus,
    SessionStatus,
    Workspace,
)
from mce.application.enrichment import InMemoryReviewRepository
from mce.application.identification import IdentificationService
from mce.application.identification.models import SearchKind
from mce.application.importers import ImportService
from mce.application.processing import LocalPreparationService, SessionPipelineService
from mce.application.processing.service import (
    _catalog_metadata_level,
    _categories_compatible,
    _missing_catalog_metadata,
    _public_catalog_status,
    _useful_metadata,
)
from mce.application.workspaces import SessionService
from mce.application.workspaces.local_services import (
    InMemoryCheckpointStore,
    InMemorySessionRepository,
    InMemoryWorkspaceRepository,
    SystemClock,
    UuidGenerator,
)
from mce.domain.value_objects import PhysicalFileId
from mce.infrastructure.metadata import (
    RateLimitedMetadataProvider,
    UnavailableMetadataProvider,
)


def prepared(session):
    classified, _ = LocalPreparationService().classify(session)
    cleaned, _ = LocalPreparationService().clean(classified)
    grouped, _ = LocalPreparationService().group(cleaned)
    return grouped


def test_dorama_accepts_unambiguous_identity_with_partial_metadata() -> None:
    sparse = candidate(kind=SearchKind.SERIES, overview=None, genres=(), images=(), cast=())

    assert _missing_catalog_metadata(sparse, "dorama") == ()
    assert _catalog_metadata_level(sparse, "dorama") == "metadatos parciales"
    assert _public_catalog_status("dorama", "metadatos parciales") == "catalogado"
    assert _categories_compatible("series", "dorama")


def test_safe_identity_is_cataloged_and_completeness_remains_auditable() -> None:
    sparse = candidate(year=None, cast=(), director=None, overview=None, genres=(), images=())
    enough = candidate(year=2020, cast=("Actor",), director=None)

    assert _missing_catalog_metadata(sparse, "películas") == ()
    assert _missing_catalog_metadata(enough, "películas") == ()
    assert _public_catalog_status("películas", "metadatos parciales") == (
        "metadatos parciales"
    )


def test_requested_minimum_metadata_marks_series_complete() -> None:
    complete = candidate(
        kind=SearchKind.SERIES,
        year=2024,
        overview="Sinopsis verificada.",
        cast=("Actor principal",),
        director="Directora",
        season_count=2,
        ratings=(("web", "8.4"),),
    )

    assert _catalog_metadata_level(complete, "series") == "completo"
    assert {
        "año",
        "sinopsis",
        "reparto",
        "dirección",
        "temporadas",
        "valoración",
    } <= set(_useful_metadata(complete))


def test_pipeline_normalizes_classifies_and_routes_unidentified_to_review() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    workspace = Workspace(UuidGenerator().new_id(), "Prueba")
    workspaces.save(workspace)
    service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), UuidGenerator()
    )
    session = service.create(workspace.workspace_id, imported)
    running = prepared(service.transition(session.session_id, SessionStatus.RUNNING))
    progress: list[int] = []
    reviews = InMemoryReviewRepository()
    durable_groups = []
    result = SessionPipelineService(IdentificationService(FakeMetadataProvider()), reviews).process(
        running, progress=progress.append, persist_completed=durable_groups.append
    )
    assert result.review_rows
    assert result.catalog_rows == ()
    assert result.items[0].title
    assert result.items[0].identification_status == "not_found_confirmed"
    assert result.review_rows[0]["_candidate_approvable"] is False
    assert str(result.review_rows[0]["estado de identidad"]).startswith("sin identificaci")
    assert "manual incompleta" in str(result.review_rows[0]["aprobaci\u00f3n resultante"])
    assert progress[-1] == 100
    assert reviews.pending()[0].review_id == result.review_rows[0]["id"]
    assert durable_groups == [tuple(value.item for value in result.items)]


def test_pipeline_uses_ai_once_per_logical_work_after_providers_fail() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "IA por obra")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    running = prepared(
        service.transition(
            service.create(workspace.workspace_id, imported).session_id,
            SessionStatus.RUNNING,
        )
    )
    calls = []

    def review(item):
        calls.append(item)
        return AIReviewResult(
            "mce.ai-review.v1",
            AIReviewState.APPROVED,
            AIReviewDecision.APPROVE,
            item.title,
            item.category,
            item.year_hint,
            (),
            97.5,
            (
                EvidenceSource("https://example.com/work", item.title, "evidence", "test"),
                EvidenceSource("https://example.org/work", item.title, "evidence", "test"),
            ),
            reason="dos fuentes compatibles",
            model="fake-gemini",
        )

    result = SessionPipelineService(
        IdentificationService(FakeMetadataProvider()), ai_reviewer=review
    ).process(running)

    assert len(calls) == 1
    assert result.review_rows == ()
    assert result.catalog_rows
    assert result.items[0].identification_status == "identified"
    assert "mce-ai" in result.items[0].item.providers_completed


def test_pipeline_reports_detailed_realtime_progress() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    workspace = Workspace(UuidGenerator().new_id(), "Progreso")
    workspaces.save(workspace)
    service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), UuidGenerator()
    )
    running = prepared(
        service.transition(
            service.create(workspace.workspace_id, imported).session_id, SessionStatus.RUNNING
        )
    )
    snapshots = []

    SessionPipelineService(IdentificationService(FakeMetadataProvider())).process(
        running, progress_detail=snapshots.append
    )

    assert [item.stage for item in snapshots[:2]] == ["preparing", "enriching"]
    assert snapshots[-1].stage == "completed"
    assert snapshots[-1].processed == snapshots[-1].total == 1
    assert snapshots[-1].overall_percent == 100
    assert snapshots[-1].pending_review == 1


def test_generic_vob_collection_never_spends_provider_or_ai_calls() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "VOB aislado")
    workspaces.save(workspace)
    session_service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids
    )
    created = session_service.create(workspace.workspace_id, imported)
    fragment = replace(
        created.items[0],
        original_name="Part_1_1.vob",
        original_path=r"F:\Películas\Colección trilogía\Part_1_1.vob",
    )
    sessions.save(replace(created, items=(fragment,)))
    running = prepared(session_service.transition(created.session_id, SessionStatus.RUNNING))
    provider = FakeMetadataProvider((candidate(),))
    ai_calls = []

    result = SessionPipelineService(
        IdentificationService(provider), ai_reviewer=ai_calls.append
    ).process(running)

    assert provider.calls == 0
    assert ai_calls == []
    assert result.review_rows
    assert result.audit_rows[0]["identification_from_cache"] is True


def test_pipeline_skips_a_persisted_identical_query_on_later_retry() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    workspace = Workspace(UuidGenerator().new_id(), "Sin llamadas repetidas")
    workspaces.save(workspace)
    service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), UuidGenerator()
    )
    created = service.create(workspace.workspace_id, imported)
    running = prepared(service.transition(created.session_id, SessionStatus.RUNNING))
    provider = FakeMetadataProvider()
    pipeline = SessionPipelineService(IdentificationService(provider))

    first = pipeline.process(running)
    first_item = first.items[0].item
    assert provider.calls == 1
    assert first_item.identification_query_fingerprints

    retried_item = replace(
        first_item,
        stage=ProcessingStage.READY_FOR_ENRICHMENT,
        status=SessionItemStatus.PENDING,
        enrichment_status="pending_enrichment",
        review_reason="pending_normalization_retry",
    )
    retried = replace(running, items=(retried_item,))
    second = pipeline.process(retried)

    assert provider.calls == 1
    assert second.items[0].item.metadata_from_cache
    assert second.items[0].item.identification_query_fingerprints == (
        first_item.identification_query_fingerprints
    )


def test_pipeline_defers_instead_of_creating_reviews_when_provider_is_unavailable() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    workspace = Workspace(UuidGenerator().new_id(), "Prueba online")
    workspaces.save(workspace)
    service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), UuidGenerator()
    )
    session = service.create(workspace.workspace_id, imported)
    running = prepared(service.transition(session.session_id, SessionStatus.RUNNING))
    reviews = InMemoryReviewRepository()
    pipeline = SessionPipelineService(
        IdentificationService(UnavailableMetadataProvider("sin conexión")), reviews
    )

    result = pipeline.process(running)
    assert result.deferred_reason == "sin conexión"
    assert result.items == ()
    assert reviews.pending() == ()


def test_pipeline_reuses_identical_query_and_resumes_only_pending_items() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Prueba reanudable")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    original = created.items[0]
    duplicate = replace(
        original,
        item_id=ids.new_id(),
        physical_file_id=PhysicalFileId.new(),
        original_path="F:/copia/" + (original.original_name or "video.mkv"),
    )
    sessions.save(replace(created, items=(original, duplicate)))
    running = prepared(service.transition(created.session_id, SessionStatus.RUNNING))

    fake = FakeMetadataProvider((candidate(),))
    first = SessionPipelineService(IdentificationService(fake)).process(running)
    assert fake.calls == 1
    assert len(first.items) == 2

    limited = RateLimitedMetadataProvider(FakeMetadataProvider((candidate(),)), 1)
    distinct = prepared(
        replace(
            running,
            items=(
                original,
                replace(
                    duplicate,
                    original_name="Another.Movie.2020.mkv",
                    original_path="F:/Another.Movie.2020.mkv",
                ),
            ),
        )
    )
    partial = SessionPipelineService(IdentificationService(limited)).process(distinct)
    assert len(partial.items) == 1
    assert partial.deferred_reason
    changed = distinct.replace_all_items(
        (partial.items[0].item, distinct.items[1]), at=distinct.updated_at
    )
    resumed = SessionPipelineService(
        IdentificationService(FakeMetadataProvider((candidate(),)))
    ).process(changed)
    assert len(resumed.items) == 1
    assert resumed.items[0].item.item_id == distinct.items[1].item_id


def test_pipeline_identifies_a_series_folder_once_for_all_episodes() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Agrupación")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    first = replace(
        created.items[0],
        original_name="Mi.Serie.S01E01.mkv",
        original_path=r"F:\Series\Mi Serie\Temporada 1\Mi.Serie.S01E01.mkv",
    )
    second = replace(
        first,
        item_id=ids.new_id(),
        physical_file_id=PhysicalFileId.new(),
        original_name="Mi.Serie.S01E02.mkv",
        original_path=r"F:\Series\Mi Serie\Temporada 1\Mi.Serie.S01E02.mkv",
    )
    sessions.save(replace(created, items=(first, second)))
    running = prepared(service.transition(created.session_id, SessionStatus.RUNNING))
    series_candidate = candidate(
        title="Mi Serie",
        original_title="Mi Serie",
        translated_titles=("Mi Serie",),
        aliases=(),
        kind=SearchKind.SERIES,
        year=None,
    )
    fake = FakeMetadataProvider((series_candidate,))

    snapshots = []
    result = SessionPipelineService(IdentificationService(fake)).process(
        running, progress_detail=snapshots.append
    )

    assert fake.calls == 1
    assert snapshots[-1].processed == snapshots[-1].total == 1
    assert snapshots[-1].overall_percent == 100
    assert len(result.items) == 2
    assert len(result.review_rows) == 0
    assert result.catalog_rows
    assert len(result.catalog_rows) == 2
    assert all(row["título"] == "Mi Serie" for row in result.catalog_rows)


def test_five_physical_copies_of_one_movie_use_one_provider_call() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Copias")
    workspaces.save(workspace)
    session_service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids
    )
    created = session_service.create(workspace.workspace_id, imported)
    original = created.items[0]
    copies = tuple(
        replace(
            original,
            item_id=ids.new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_name="Dune.2021.mkv",
            original_path=rf"F:\Películas\Dune 2021\copia-{index}\Dune.2021.mkv",
        )
        for index in range(5)
    )
    sessions.save(replace(created, items=copies))
    running = prepared(session_service.transition(created.session_id, SessionStatus.RUNNING))
    fake = FakeMetadataProvider((candidate(title="Dune", year=2021),))

    result = SessionPipelineService(IdentificationService(fake)).process(running)

    assert fake.calls == 1
    assert len(result.items) == 5
    assert len({item.item.work_group_id for item in result.items}) == 1
    assert result.summary is not None
    assert result.summary["total_works"] == 1
    assert result.summary["completed_works"] == 1
    assert len(result.audit_rows) == 1


def test_twenty_dorama_episodes_use_one_online_identification() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Dorama")
    workspaces.save(workspace)
    session_service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids
    )
    created = session_service.create(workspace.workspace_id, imported)
    original = created.items[0]
    episodes = tuple(
        replace(
            original,
            item_id=ids.new_id(),
            physical_file_id=PhysicalFileId.new(),
            original_name=f"Goblin.S01E{number:02d}.mkv",
            original_path=(rf"F:\Doramas\Goblin\Temporada 1\Goblin.S01E{number:02d}.mkv"),
        )
        for number in range(1, 21)
    )
    sessions.save(replace(created, items=episodes))
    running = prepared(session_service.transition(created.session_id, SessionStatus.RUNNING))
    fake = FakeMetadataProvider((candidate(title="Goblin", kind=SearchKind.SERIES, year=None),))
    snapshots = []

    result = SessionPipelineService(IdentificationService(fake)).process(
        running, progress_detail=snapshots.append
    )

    assert fake.calls == 1
    assert len(result.items) == 20
    assert snapshots[-1].processed == snapshots[-1].total == 1
    assert snapshots[-1].overall_percent == 100


def test_pipeline_associates_subtitles_locally_without_provider_request() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Subtítulos")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    subtitle = replace(
        created.items[0],
        original_name="Avatar.es.srt",
        original_path=r"F:\Películas\Avatar (2009)\Avatar.es.srt",
    )
    sessions.save(replace(created, items=(subtitle,)))
    running = prepared(service.transition(created.session_id, SessionStatus.RUNNING))
    fake = FakeMetadataProvider((candidate(),))

    assert fake.calls == 0
    assert running.items[0].enrichment_status == "enrichment_complete"


def test_known_canonical_identity_skips_all_provider_calls() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Identidad conocida")
    workspaces.save(workspace)
    session_service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids
    )
    created = session_service.create(workspace.workspace_id, imported)
    known_item = replace(
        created.items[0],
        original_name="Game.of.Thrones.S03E01.mkv",
        original_path=r"F:\Series\Game of Thrones\Temp 3\Game.of.Thrones.S03E01.mkv",
    )
    sessions.save(replace(created, items=(known_item,)))
    running = prepared(session_service.transition(created.session_id, SessionStatus.RUNNING))
    known = candidate(
        provider="tmdb",
        external_id="1399",
        title="Game of Thrones",
        original_title="Game of Thrones",
        translated_titles=("Juego de Tronos",),
        aliases=(),
        kind=SearchKind.SERIES,
        year=2011,
    )
    fake = FakeMetadataProvider()

    result = SessionPipelineService(
        IdentificationService(fake),
        resolve_known_identity=lambda title, kind, bank_id: known,
    ).process(running)

    assert fake.calls == 0
    assert len(result.items) == 1
    assert result.items[0].identification_status == "identified"
    assert result.items[0].item.metadata_from_cache


def test_year_hint_is_only_used_after_clean_query_is_insufficient() -> None:
    class RecordingProvider(FakeMetadataProvider):
        def __init__(self):
            super().__init__()
            self.queries = []

        def search_movie(self, query):
            self.calls += 1
            self.queries.append(query)
            return (candidate(title="Rambo 1", year=1990),) if query.year == 1990 else ()

    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Consulta escalonada")
    workspaces.save(workspace)
    session_service = SessionService(
        workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids
    )
    created = session_service.create(workspace.workspace_id, imported)
    movie = replace(
        created.items[0],
        original_name="Rambo 1 1990 HD H264 1080p.mkv",
        original_path=r"F:\Peliculas\Rambo 1 1990 HD H264 1080p.mkv",
    )
    sessions.save(replace(created, items=(movie,)))
    running = prepared(session_service.transition(created.session_id, SessionStatus.RUNNING))
    provider = RecordingProvider()

    SessionPipelineService(IdentificationService(provider)).process(running)

    assert [query.year for query in provider.queries] == [None, 1990]
    assert [query.query_variant for query in provider.queries] == [
        "clean_title",
        "structured_year_hint",
    ]
    assert provider.queries[0].title == provider.queries[1].title == "Rambo 1"


def test_reprepare_keeps_work_inside_human_review() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Repreparación")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    sessions.save(replace(created, items=(reviewed,), status=SessionStatus.WAITING_REVIEW))

    changed = service.reprepare_review_items(
        created.session_id,
        (reviewed.item_id,),
        corrected_title="Cuentos de Terramar",
    )

    item = changed.items[0]
    assert item.clean_title == item.work_title == "Cuentos de Terramar"
    assert item.stage is ProcessingStage.REVIEWED
    assert item.status is SessionItemStatus.WARNING
    assert item.enrichment_status == "needs_human_review"
    assert item.review_reason == "locally_reprepared_in_review"


def test_bulk_reprepare_ignores_stale_review_item_ids() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Repreparación tolerante")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    sessions.save(replace(created, items=(reviewed,), status=SessionStatus.WAITING_REVIEW))

    changed = service.reprepare_review_items_bulk(
        created.session_id,
        {reviewed.item_id: "Título válido", "id-historico-obsoleto": "Obsoleto"},
    )

    assert changed.items[0].clean_title == "Título válido"
    assert changed.items[0].review_reason == "locally_reprepared_in_review"


def test_bulk_reprepare_accepts_review_from_completed_session() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Repreparación histórica")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    sessions.save(replace(created, items=(reviewed,), status=SessionStatus.COMPLETED))

    changed = service.reprepare_review_items_bulk(
        created.session_id, {reviewed.item_id: "Título histórico limpio"}
    )

    assert changed.status is SessionStatus.COMPLETED
    assert changed.items[0].clean_title == "Título histórico limpio"
    assert changed.items[0].stage is ProcessingStage.REVIEWED
    assert changed.items[0].review_reason == "locally_reprepared_in_review"


def test_review_resolution_accepts_pending_review_from_completed_session() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Resolución histórica")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    completed = replace(created, items=(reviewed,), status=SessionStatus.COMPLETED)
    sessions.save(completed)

    resolved = service.apply_review_resolution(
        created.session_id,
        (
            replace(
                reviewed,
                stage=ProcessingStage.CONSOLIDATED,
                status=SessionItemStatus.COMPLETED,
                enrichment_status="enrichment_complete",
            ),
        ),
    )

    assert resolved.status is SessionStatus.COMPLETED
    assert resolved.items[0].stage is ProcessingStage.CONSOLIDATED


@pytest.mark.parametrize(
    "historical_status",
    [SessionStatus.PAUSED, SessionStatus.WAITING_INTERNET, SessionStatus.FAILED],
)
def test_review_resolution_accepts_recoverable_inactive_session(historical_status) -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Resolución recuperable")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    sessions.save(replace(created, items=(reviewed,), status=historical_status))

    resolved = service.apply_review_resolution(
        created.session_id,
        (
            replace(
                reviewed,
                stage=ProcessingStage.CONSOLIDATED,
                status=SessionItemStatus.COMPLETED,
                enrichment_status="enrichment_complete",
            ),
        ),
    )

    assert resolved.status is historical_status
    assert resolved.items[0].stage is ProcessingStage.CONSOLIDATED


def test_revalidation_recovers_a_failed_historical_session() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Revalidacion historica")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        clean_title="Vagabond",
        work_title="Vagabond",
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
    )
    failed = replace(
        created,
        items=(reviewed,),
        status=SessionStatus.FAILED,
        failure_reason="historical provider failure",
    )
    sessions.save(failed)

    recovered = service.revalidate_review_items_bulk(
        created.session_id, {reviewed.item_id: "Vagabond"}
    )

    assert recovered.status is SessionStatus.READY
    assert recovered.failure_reason is None
    assert recovered.retry_count == failed.retry_count + 1
    assert recovered.items[0].stage is ProcessingStage.READY_FOR_ENRICHMENT
    assert recovered.items[0].status is SessionItemStatus.PENDING


def test_revalidation_can_consolidate_separate_review_groups_before_enrichment() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Consolidación canónica")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    first = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        detected_category="dorama",
        category_confidence=95.0,
        work_group_id="fragment-a",
        enrichment_status="needs_human_review",
    )
    second = replace(
        first,
        item_id=ids.new_id(),
        physical_file_id=PhysicalFileId.new(),
        original_path=r"F:\Doramas\Vincenzo\S01E02.mkv",
        work_group_id="fragment-b",
    )
    sessions.save(
        replace(
            created,
            items=(first, second),
            status=SessionStatus.WAITING_REVIEW,
        )
    )

    revalidated = service.revalidate_review_items_bulk(
        created.session_id,
        {first.item_id: "Vincenzo", second.item_id: "Vincenzo"},
        {first.item_id: "canonical-vincenzo", second.item_id: "canonical-vincenzo"},
    )

    assert {item.work_group_id for item in revalidated.items} == {"canonical-vincenzo"}
    assert all(item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in revalidated.items)
    fake = FakeMetadataProvider(
        (candidate(title="Vincenzo", kind=SearchKind.SERIES, year=2021),)
    )

    result = SessionPipelineService(IdentificationService(fake)).process(revalidated)

    assert fake.calls == 1
    assert len(result.items) == 2
    assert result.summary is not None
    assert result.summary["total_works"] == 1
    assert result.summary["completed_works"] == 1


def test_explicit_revalidation_bypasses_an_exhausted_query_only_once() -> None:
    fixture = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_minimal_v1.json"
    imported = ImportService().import_file(ImportRequest(fixture))
    workspaces = InMemoryWorkspaceRepository()
    sessions = InMemorySessionRepository()
    ids = UuidGenerator()
    workspace = Workspace(ids.new_id(), "Revalidación controlada")
    workspaces.save(workspace)
    service = SessionService(workspaces, sessions, InMemoryCheckpointStore(), SystemClock(), ids)
    created = service.create(workspace.workspace_id, imported)
    reviewed = replace(
        created.items[0],
        clean_title="Vagabond",
        work_title="Vagabond",
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        enrichment_status="needs_human_review",
        identification_query_fingerprints=("agotada",),
    )
    sessions.save(replace(created, items=(reviewed,), status=SessionStatus.WAITING_REVIEW))

    first = service.revalidate_review_items_bulk(
        created.session_id, {reviewed.item_id: "Vagabond"}
    )
    assert first.items[0].identification_query_fingerprints == ()
    assert "explicit_human_revalidation" in first.items[0].normalization_trace

    rereviewed = replace(
        first.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        identification_query_fingerprints=("segundo-intento",),
    )
    sessions.save(replace(first, items=(rereviewed,), status=SessionStatus.WAITING_REVIEW))
    second = service.revalidate_review_items_bulk(
        created.session_id, {reviewed.item_id: "Vagabond"}
    )
    assert second.items[0].identification_query_fingerprints == ("segundo-intento",)
