"""Equivalencia entre la lectura clásica e incremental."""

from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

from mce.application.dto import ImportRequest
from mce.application.importers import ImportService, json_reader

FIXTURE = Path(__file__).parents[3] / "fixtures" / "msl" / "valid_schema_v22.json"
NOW = datetime(2026, 7, 25, tzinfo=UTC)


def test_streaming_reader_preserves_complete_import_contract(monkeypatch) -> None:
    classic = ImportService(clock=lambda: NOW).import_file(ImportRequest(FIXTURE))
    monkeypatch.setattr(json_reader, "_STREAMING_THRESHOLD", 0)
    streamed = ImportService(clock=lambda: NOW).import_file(ImportRequest(FIXTURE))

    assert streamed.success == classic.success
    assert streamed.status == classic.status
    assert streamed.statistics == classic.statistics
    assert Counter(issue.code for issue in streamed.issues) == Counter(
        issue.code for issue in classic.issues
    )
    assert streamed.package is not None and classic.package is not None
    assert streamed.package.scan.declared_scan_id == classic.package.scan.declared_scan_id
    assert streamed.package.scan.schema_version == classic.package.scan.schema_version
    assert streamed.package.scan.scope.scope_type == classic.package.scan.scope.scope_type
    assert [source.declared_id for source in streamed.package.sources] == [
        source.declared_id for source in classic.package.sources
    ]
    assert [file.original_path for file in streamed.package.video_files] == [
        file.original_path for file in classic.package.video_files
    ]
    assert [file.original_path for file in streamed.package.subtitle_files] == [
        file.original_path for file in classic.package.subtitle_files
    ]
    assert [file.original_path for file in streamed.package.ignored_files] == [
        file.original_path for file in classic.package.ignored_files
    ]
