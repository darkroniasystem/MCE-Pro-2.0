from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from threading import Event, Lock

from mce.application.ai_review import (
    AIRateLimitDeferred,
    AIReviewDecision,
    AIReviewInput,
    AIReviewOrchestrator,
    AIReviewResult,
    AIReviewState,
    EvidenceSource,
    EvidenceValidator,
    sanitized_payload,
)


def proposal(*sources: EvidenceSource, score: float = 95) -> AIReviewResult:
    return AIReviewResult(
        schema_version="untrusted",
        state=AIReviewState.PENDING,
        decision=AIReviewDecision.HUMAN_REVIEW,
        canonical_title="Vagabond",
        media_type="dorama",
        year=2019,
        seasons=(),
        deterministic_score=score,
        sources=sources,
    )


def source(domain: str) -> EvidenceSource:
    return EvidenceSource(
        url=f"https://{domain}/work",
        title="Vagabond",
        snippet="Korean television series released in 2019",
        provider="test",
    )


def test_validator_accepts_one_canonical_public_source() -> None:
    validator = EvidenceValidator()

    item = AIReviewInput("group", "Vagabond", "dorama", 2019)
    one = validator.validate(item, proposal(source("example.com")))
    two = validator.validate(item, proposal(source("example.com"), source("example.org")))

    assert one.state is AIReviewState.APPROVED
    assert two.state is AIReviewState.APPROVED
    assert two.schema_version == "mce.ai-review.v1"


def test_validator_never_auto_approves_contradictions_or_private_sources() -> None:
    validator = EvidenceValidator()
    private = EvidenceSource("http://localhost/work", "x", "x", "test")
    result = validator.validate(
        AIReviewInput("group", "Vagabond", "dorama", 2019),
        replace(
            proposal(private, source("example.org"), score=100),
            contradictions=("year mismatch",),
        )
    )

    assert result.state is AIReviewState.HUMAN
    assert private not in result.sources


def test_validator_rejects_canonical_title_not_supported_by_two_sources() -> None:
    sources = (source("example.com"), source("example.org"))
    result = EvidenceValidator().validate(
        AIReviewInput("group", "0012 - Vagabond WEB-DL", "dorama", 2019),
        replace(proposal(*sources, score=100), canonical_title="0012 - Vagabond WEB-DL"),
    )

    assert result.state is AIReviewState.HUMAN
    assert result.decision is AIReviewDecision.HUMAN_REVIEW


def test_validator_never_promotes_partial_or_low_confidence_qwen_output() -> None:
    sources = (source("example.com"), source("example.org"))
    item = AIReviewInput("group", "Vagabond", "dorama", 2019)
    partial = EvidenceValidator().validate(
        item,
        replace(
            proposal(*sources),
            provider="ollama",
            model_confidence=99,
            analysis_status="partial_match",
            recommended_action="partial_accept",
        ),
    )
    low_confidence = EvidenceValidator().validate(
        item,
        replace(
            proposal(*sources),
            provider="ollama",
            model_confidence=60,
            analysis_status="matched",
            recommended_action="accept",
        ),
    )

    assert partial.decision is AIReviewDecision.HUMAN_REVIEW
    assert low_confidence.decision is AIReviewDecision.HUMAN_REVIEW


def test_validator_requires_groq_to_propose_approval_before_accepting() -> None:
    sources = (source("example.com"), source("example.org"))
    result = EvidenceValidator().validate(
        AIReviewInput("group", "Vagabond", "dorama", 2019),
        replace(
            proposal(*sources),
            provider="groq",
            model_confidence=99,
            decision=AIReviewDecision.HUMAN_REVIEW,
        ),
    )

    assert result.deterministic_score == 100
    assert result.decision is AIReviewDecision.HUMAN_REVIEW


class MemoryCache:
    def __init__(self) -> None:
        self.values = {}

    def get(self, key):
        return self.values.get(key)

    def put(self, key, value):
        self.values[key] = value


def test_orchestrator_caches_per_logical_query_and_skips_duplicate_calls() -> None:
    calls = {"search": 0, "analyze": 0, "quota": 0}

    class Search:
        def search(self, query):
            calls["search"] += 1
            return (source("example.com"), source("example.org"))

    class Analyzer:
        def analyze(self, item, sources):
            calls["analyze"] += 1
            return proposal(*sources)

    class Quota:
        def acquire(self, amount=1):
            calls["quota"] += amount
            return True

    orchestrator = AIReviewOrchestrator(
        Search(), Analyzer(), EvidenceValidator(), MemoryCache(), Quota()
    )
    item = AIReviewInput("group-1", "Vagabond", "dorama", 2019)

    assert orchestrator.review(item).state is AIReviewState.APPROVED
    assert orchestrator.review(item).state is AIReviewState.APPROVED
    assert calls == {"search": 1, "analyze": 1, "quota": 2}


def test_orchestrator_reuses_work_identity_across_episode_fragments() -> None:
    calls = {"search": 0, "analyze": 0}

    class Search:
        def search(self, query):
            calls["search"] += 1
            return (source("example.com"), source("example.org"))

    class Analyzer:
        def analyze(self, item, sources):
            calls["analyze"] += 1
            return proposal(*sources)

    class Quota:
        def acquire(self, amount=1):
            return True

    orchestrator = AIReviewOrchestrator(
        Search(), Analyzer(), EvidenceValidator(), MemoryCache(), Quota()
    )
    first = AIReviewInput(
        "group-1",
        "Vagabond",
        "dorama",
        2019,
        1,
        1,
        alternative_titles=("Vagabond S01E01",),
    )
    second = AIReviewInput(
        "group-2",
        "Vagabond",
        "dorama",
        2019,
        2,
        16,
        alternative_titles=("Vagabond episodio final",),
    )

    assert orchestrator.review(first).decision is AIReviewDecision.APPROVE
    assert orchestrator.review(second).cached
    assert calls == {"search": 1, "analyze": 1}


def test_orchestrator_coalesces_concurrent_reviews_of_the_same_work() -> None:
    entered = Event()
    release = Event()
    lock = Lock()
    calls = {"search": 0, "analyze": 0}

    class Search:
        def search(self, query):
            with lock:
                calls["search"] += 1
            return (source("example.com"), source("example.org"))

    class Analyzer:
        def analyze(self, item, sources):
            with lock:
                calls["analyze"] += 1
            entered.set()
            assert release.wait(2)
            return proposal(*sources)

    class Quota:
        def acquire(self, amount=1):
            return True

    orchestrator = AIReviewOrchestrator(
        Search(), Analyzer(), EvidenceValidator(), MemoryCache(), Quota()
    )
    item = AIReviewInput("group-1", "Vagabond", "dorama", 2019)

    with ThreadPoolExecutor(max_workers=2) as pool:
        first = pool.submit(orchestrator.review, item)
        assert entered.wait(2)
        second = pool.submit(orchestrator.review, item)
        release.set()
        results = (first.result(timeout=2), second.result(timeout=2))

    assert all(result.state is AIReviewState.APPROVED for result in results)
    assert sum(result.cached for result in results) == 1
    assert calls == {"search": 1, "analyze": 1}


def test_orchestrator_stops_before_providers_when_quota_is_exhausted() -> None:
    class Never:
        def search(self, query):
            raise AssertionError("provider should not run")

        def analyze(self, item, sources):
            raise AssertionError("model should not run")

    class EmptyCache:
        def get(self, key):
            return None

        def put(self, key, value):
            raise AssertionError("cache should not write")

    class NoQuota:
        def acquire(self, amount=1):
            return False

    orchestrator = AIReviewOrchestrator(
        Never(), Never(), EvidenceValidator(), EmptyCache(), NoQuota()
    )
    result = orchestrator.review(AIReviewInput("group", "Title", "movie"))
    assert result.state is AIReviewState.QUOTA_EXHAUSTED
    assert result.decision is AIReviewDecision.HUMAN_REVIEW


def test_orchestrator_marks_rate_limit_as_recoverable_and_does_not_cache_it() -> None:
    cache = MemoryCache()

    class Search:
        def search(self, query):
            return (source("example.com"),)

    class Limited:
        def analyze(self, item, sources):
            raise AIRateLimitDeferred("Groq", 300)

    class Quota:
        def acquire(self, amount=1):
            return True

    result = AIReviewOrchestrator(
        Search(), Limited(), EvidenceValidator(), cache, Quota()
    ).review(AIReviewInput("group", "Title", "movie"))

    assert result.state is AIReviewState.WAITING_RATE_LIMIT
    assert result.provider == "groq"
    assert cache.values == {}


def test_sanitizer_removes_paths_network_locations_and_secrets() -> None:
    item = AIReviewInput(
        "private-group",
        r"C:\Users\Darian\Videos\Vagabond api_key=hidden",
        "dorama",
        alternative_titles=(r"\\server\private\Vagabond", "Vagabond"),
    )

    payload = sanitized_payload(item)

    serialized = repr(payload)
    assert "Darian" not in serialized
    assert "server" not in serialized
    assert "hidden" not in serialized
    assert "private-group" not in serialized
    assert "Vagabond" in serialized
