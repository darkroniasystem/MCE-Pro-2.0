from pathlib import Path

import pytest

from mce.application.dto import ProcessingStage
from mce.presentation.presenters import ImportPresenter, SessionPresenter


class ImportServiceSpy:
    def __init__(self) -> None:
        self.request = None

    def import_file(self, request):
        self.request = request
        return "resultado"


def test_import_presenter_validates_extension_and_delegates() -> None:
    service = ImportServiceSpy()
    presenter = ImportPresenter(service)

    assert presenter.validate("scan.json") == "resultado"
    assert service.request.file_path == Path("scan.json")


@pytest.mark.parametrize("path", ["", "scan.txt", "scan.json.exe"])
def test_import_presenter_rejects_non_json(path: str) -> None:
    with pytest.raises(ValueError, match="JSON"):
        ImportPresenter(ImportServiceSpy()).validate(path)


def test_session_presenter_delegates_and_maps_row() -> None:
    session = type(
        "Session",
        (),
        {
            "session_id": "session-1",
            "status": type("Status", (), {"value": "ready"})(),
            "items": (
                type("Item", (), {"stage": ProcessingStage.IMPORTED})(),
                type("Item", (), {"stage": ProcessingStage.IMPORTED})(),
            ),
            "summary": type(
                "Summary",
                (),
                {"percent": 0.0, "completed": 0, "warning": 0, "failed": 0},
            )(),
            "import_id": "import-1",
            "bank_name": "Banco de prueba",
        },
    )()
    service = type(
        "Service",
        (),
        {"create": lambda self, workspace_id, result, bank_name=None: session},
    )()
    sessions = type(
        "Sessions", (), {"save": lambda self, value: None, "get": lambda self, value: session}
    )()
    checkpoints = type("Checkpoints", (), {"save": lambda self, value: Path("checkpoint")})()
    presenter = SessionPresenter(service, "workspace-1", sessions, checkpoints)
    assert presenter.create(object()) is session
    row = presenter.row(session)
    assert row["sesión"] == "session-1"
    assert row["estado"] == "ready"
    assert row["elementos"] == 2
    assert row["progreso"] == "0.0 %"

def test_enrichment_rows_uses_persisted_aggregates_without_focus() -> None:
    summaries = (
        {
            "session_id": "session-1",
            "bank": "bank-1",
            "category": "movie",
            "total": 5,
            "works": 2,
            "ready": 5,
            "uncertain": 1,
            "completed": 0,
            "rejected": 0,
            "reviews": 0,
        },
        {
            "session_id": "session-2",
            "bank": "bank-2",
            "category": "anime",
            "total": 20,
            "works": 1,
            "ready": 20,
            "uncertain": 0,
            "completed": 0,
            "rejected": 0,
            "reviews": 0,
        },
        {
            "session_id": "session-2",
            "bank": "bank-2",
            "category": "pending_retry",
            "total": 2,
            "works": 1,
            "ready": 2,
            "uncertain": 0,
            "completed": 0,
            "rejected": 0,
            "reviews": 0,
        },
    )
    sessions = type(
        "PersistedSessions",
        (),
        {"list_enrichment_summaries": lambda self: summaries},
    )()
    presenter = SessionPresenter(object(), "workspace-1", sessions, object())

    rows = presenter.enrichment_rows()

    assert len(rows) == 15
    assert [row["Categoría"] for row in rows] == [
        "Películas",
        "Películas VOB",
        "Series",
        "Series VOB",
        "Novelas",
        "Novelas VOB",
        "Doramas",
        "Doramas VOB",
        "Anime",
        "Anime VOB",
        "Concursos",
        "Concursos VOB",
        "Animados",
        "Animados VOB",
        "Pendientes",
    ]
    assert rows[0]["Listos"] == 5
    assert rows[0]["Sesiones incluidas"] == 1
    assert rows[0]["Preparación"] == "Guardada · 1 sesión(es)"
    assert rows[8]["Obras"] == 1
    assert rows[8]["AniList"] == 1
    assert rows[14]["TMDb"] == rows[14]["AniList"] == rows[14]["TVMaze"] == 1


def test_catalog_completion_uses_persisted_logical_work_summary() -> None:
    expected = {"total": 100, "processed": 60, "resolved": 40, "review": 20}
    sessions = type(
        "PersistedSessions",
        (),
        {"catalog_completion_summary": lambda self: expected},
    )()

    result = SessionPresenter(object(), "workspace-1", sessions, object()).catalog_completion()

    assert result == expected
