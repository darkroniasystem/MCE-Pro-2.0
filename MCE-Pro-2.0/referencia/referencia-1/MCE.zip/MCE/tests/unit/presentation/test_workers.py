from mce.application.workspaces import CancellationToken
from mce.presentation.workers import TaskRunnable


def test_worker_reports_result_progress_and_completion() -> None:
    events: list[object] = []
    worker = TaskRunnable(lambda: 42)
    worker.signals.progress.connect(lambda value: events.append(("progress", value)))
    worker.signals.result.connect(lambda value: events.append(("result", value)))
    worker.signals.finished.connect(lambda: events.append("finished"))

    worker.run()

    assert events == [("progress", 5), ("progress", 100), ("result", 42), "finished"]


def test_worker_reports_error_without_raising() -> None:
    errors: list[str] = []
    worker = TaskRunnable(lambda: (_ for _ in ()).throw(RuntimeError("fallo controlado")))
    worker.signals.error.connect(errors.append)
    worker.run()
    assert errors == ["fallo controlado"]


def test_cancelled_worker_does_not_start_operation() -> None:
    token = CancellationToken()
    token.cancel()
    called: list[bool] = []
    results: list[object] = []
    worker = TaskRunnable(lambda: called.append(True), token)
    worker.signals.result.connect(results.append)
    worker.run()
    assert called == []
    assert results == []


def test_cancellation_token_can_pause_resume_and_cancel() -> None:
    token = CancellationToken()
    token.pause()
    token.resume()
    token.wait_if_paused()
    assert not token.is_cancelled
    token.cancel()
    assert token.is_cancelled
