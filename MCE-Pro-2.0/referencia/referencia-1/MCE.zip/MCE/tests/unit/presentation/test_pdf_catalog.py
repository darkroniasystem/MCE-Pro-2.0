"""Exportación visual del catálogo maestro."""

from pathlib import Path

import pytest
from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication

from mce.presentation.pdf_catalog import PdfCatalogExporter, SafeArtworkCache


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def test_pdf_catalog_groups_all_supported_categories_without_mutating_rows(
    app,
    tmp_path: Path,
) -> None:
    cover = QImage(80, 120, QImage.Format.Format_RGB32)
    cover.fill(QColor("#2563eb"))
    rows = [
        {
            "título": "Akira",
            "tipo": "anime",
            "año": 1988,
            "géneros": "Animación",
            "sinopsis": "Neo-Tokyo.",
            "carátula": "https://images.example.test/akira.jpg",
        },
        {"título": "Amélie", "tipo": "movie", "año": 2001},
        {"título": "Capítulo 1", "tipo": "episode"},
        {"título": "Desconocido", "tipo": "unknown"},
    ]
    original = [dict(row) for row in rows]
    destination = tmp_path / "catalogo.pdf"

    count = PdfCatalogExporter(lambda _url: cover).export(rows, destination)

    assert count == 4
    assert destination.read_bytes().startswith(b"%PDF-")
    assert destination.stat().st_size > 1_000
    assert rows == original


def test_artwork_cache_rejects_non_https_and_private_destinations(tmp_path: Path) -> None:
    cache = SafeArtworkCache(tmp_path / "artwork")

    assert cache.load("http://example.com/poster.jpg") is None
    assert cache.load("https://127.0.0.1/poster.jpg") is None
