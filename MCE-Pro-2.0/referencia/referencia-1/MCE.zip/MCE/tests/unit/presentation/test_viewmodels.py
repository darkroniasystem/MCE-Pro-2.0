from mce.presentation.viewmodels import ScreenState, ScreenViewModel, TableViewModel


def test_table_view_model_filters_and_paginates() -> None:
    model = TableViewModel(
        rows=[{"name": f"Película {index}"} for index in range(55)], page_size=20
    )
    model.page = 3
    assert len(model.filtered) == 15
    assert model.total == 55

    model.query = "Película 1"
    model.page = 1
    assert model.total == 11
    assert all("1" in row["name"] for row in model.filtered)


def test_screen_view_model_exposes_stable_states() -> None:
    model = ScreenViewModel("Sesiones")
    model.loading()
    assert model.state is ScreenState.LOADING
    model.ready("Lista")
    assert (model.state, model.progress, model.message) == (ScreenState.READY, 100, "Lista")
    model.fail("fallo controlado")
    assert (model.state, model.message) == (ScreenState.ERROR, "fallo controlado")


def test_table_view_model_sorts_numeric_group_counts_descending() -> None:
    model = TableViewModel(
        rows=[
            {"grupo": "uno", "archivos agrupados": 1},
            {"grupo": "dieciseis", "archivos agrupados": 16},
            {"grupo": "siete", "archivos agrupados": 7},
        ],
        sort_column="archivos agrupados",
        sort_descending=True,
    )

    assert [row["archivos agrupados"] for row in model.matching] == [16, 7, 1]
