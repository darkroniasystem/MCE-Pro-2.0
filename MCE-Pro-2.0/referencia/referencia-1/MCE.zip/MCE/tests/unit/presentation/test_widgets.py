import os
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace

import pytest
from PySide6.QtCore import QSettings, QThreadPool
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox, QPushButton
from tests.fakes import FakeMetadataProvider

from mce.application.dto import (
    ImportRequest,
    ProcessingStage,
    SessionItemStatus,
    SessionStatus,
)
from mce.application.enrichment.models import MetadataField, ReviewItem
from mce.application.identification.models import ProviderCandidate, SearchKind
from mce.application.importers import ImportService
from mce.application.workspaces import CancellationToken
from mce.domain.value_objects import (
    ConfidenceScore,
    FieldProvenance,
    FieldSourceType,
    PhysicalFileId,
)
from mce.infrastructure.database.publication import PublicationResult
from mce.infrastructure.metadata import MetadataRuntime, ProviderUsage
from mce.infrastructure.metadata.browser_playwright import BrowserDiagnostic
from mce.infrastructure.operations import HealthCheck, StartupReport
from mce.presentation.main_window import (
    SECTIONS,
    CatalogCompletionPanel,
    DataPage,
    ImportPage,
    MainWindow,
    ProviderUsagePanel,
    SettingsPage,
    expand_grouped_review_rows,
    freeze_review_selection,
    group_identical_review_rows,
    migrate_web_priority_defaults,
    provider_status_is_available,
    safe_review_candidate,
)


def test_phase_p_migrates_only_legacy_web_priorities(tmp_path) -> None:
    settings = QSettings(str(tmp_path / "priorities.ini"), QSettings.Format.IniFormat)
    settings.setValue("web/tavily_priority", 10)
    settings.setValue("web/serper_priority", 7)
    settings.setValue("web/exa_priority", 30)

    migrate_web_priority_defaults(settings)

    assert settings.value("web/tavily_priority", type=int) == 30
    assert settings.value("web/serper_priority", type=int) == 7
    assert settings.value("web/exa_priority", type=int) == 10
    assert settings.value("web/priority_defaults_version", type=int) == 1


def test_phase_q_settings_persist_browser_and_ollama_controls(app, tmp_path) -> None:
    settings = QSettings(str(tmp_path / "phase-q.ini"), QSettings.Format.IniFormat)
    page = SettingsPage(settings)

    page.browser_enabled.setChecked(True)
    page.browser_headless.setChecked(False)
    page.browser_timeout.setValue(33.5)
    page.browser_concurrency.setValue(2)
    page.browser_delay_min.setValue(700)
    page.browser_delay_max.setValue(1_400)
    page.browser_max_results.setValue(7)
    page.ollama_timeout.setValue(90)
    page.ollama_concurrency.setValue(2)
    settings.sync()

    assert settings.value("browser/enabled", type=bool)
    assert not settings.value("browser/headless", type=bool)
    assert settings.value("browser/timeout", type=float) == 33.5
    assert settings.value("browser/max_concurrency", type=int) == 2
    assert settings.value("browser/delay_min_ms", type=int) == 700
    assert settings.value("browser/delay_max_ms", type=int) == 1_400
    assert settings.value("browser/max_results", type=int) == 7
    assert settings.value("ollama/timeout", type=float) == 90
    assert settings.value("ollama/max_concurrency", type=int) == 2
    page.close()


def test_phase_q_browser_status_names_missing_dependency(app, tmp_path) -> None:
    page = SettingsPage(
        QSettings(str(tmp_path / "status.ini"), QSettings.Format.IniFormat)
    )

    page.browser_status.setText(
        page.browser_status_text(
            BrowserDiagnostic(True, False, "Chrome no está instalado")
        )
    )

    assert "Playwright: OK" in page.browser_status.text()
    assert "Chromium: NO DISPONIBLE" in page.browser_status.text()
    assert "Chrome no está instalado" in page.browser_status.text()
    page.close()


def test_phase_q_applies_ui_settings_to_runtime_environment(
    app, tmp_path, monkeypatch
) -> None:
    for name in (
        "BROWSER_SEARCH_ENABLED",
        "BROWSER_HEADLESS",
        "BROWSER_TIMEOUT",
        "BROWSER_MAX_CONCURRENCY",
        "BROWSER_DELAY_MIN_MS",
        "BROWSER_DELAY_MAX_MS",
        "BROWSER_MAX_RESULTS",
        "OLLAMA_TIMEOUT",
        "LOCAL_LLM_MAX_CONCURRENCY",
    ):
        monkeypatch.setenv(name, "phase-q-original")
    settings = QSettings(str(tmp_path / "runtime.ini"), QSettings.Format.IniFormat)
    settings.setValue("browser/enabled", True)
    settings.setValue("browser/headless", False)
    settings.setValue("browser/timeout", 42.5)
    settings.setValue("browser/max_concurrency", 2)
    settings.setValue("browser/delay_min_ms", 2_000)
    settings.setValue("browser/delay_max_ms", 1_000)
    settings.setValue("browser/max_results", 9)
    settings.setValue("ollama/timeout", 75.0)
    settings.setValue("ollama/max_concurrency", 3)
    window = MainWindow(settings, metadata_runtime_builder=fake_metadata_runtime)

    window._apply_groq_settings_to_process()

    assert os.environ["BROWSER_SEARCH_ENABLED"] == "true"
    assert os.environ["BROWSER_HEADLESS"] == "false"
    assert os.environ["BROWSER_TIMEOUT"] == "42.5"
    assert os.environ["BROWSER_MAX_CONCURRENCY"] == "2"
    assert os.environ["BROWSER_DELAY_MIN_MS"] == "2000"
    assert os.environ["BROWSER_DELAY_MAX_MS"] == "2000"
    assert os.environ["BROWSER_MAX_RESULTS"] == "9"
    assert os.environ["OLLAMA_TIMEOUT"] == "75.0"
    assert os.environ["LOCAL_LLM_MAX_CONCURRENCY"] == "3"
    window.close()


def test_identical_review_titles_group_by_normalized_title_and_type() -> None:
    rows = (
        {"id": "a", "tipo": "dorama", "título candidato": " Vincenzo ", "archivos agrupados": 1},
        {"id": "b", "tipo": "DORAMA", "título candidato": "vincenzo", "archivos agrupados": 15},
        {"id": "c", "tipo": "movie", "título candidato": "Vincenzo", "archivos agrupados": 1},
    )

    grouped = group_identical_review_rows(rows)

    assert len(grouped) == 2
    assert grouped[0]["archivos agrupados"] == 16
    assert grouped[0]["obras agrupadas"] == 2
    assert {row["id"] for row in expand_grouped_review_rows(grouped)} == {"a", "b", "c"}


def fake_metadata_runtime(path, cancelled):
    return MetadataRuntime(FakeMetadataProvider(), True, False, "proveedor falso de prueba")


def test_safe_review_candidate_requires_convergent_external_identity() -> None:
    tmdb = ProviderCandidate(
        "tmdb", "100", SearchKind.SERIES, "Mi serie", external_ids=(("imdb", "tt123"),)
    )
    tvmaze_same = ProviderCandidate(
        "tvmaze", "200", SearchKind.SERIES, "My Series", external_ids=(("imdb", "tt123"),)
    )
    tvmaze_other = ProviderCandidate(
        "tvmaze", "201", SearchKind.SERIES, "Otra serie", external_ids=(("imdb", "tt999"),)
    )

    assert safe_review_candidate({"_candidates": (tmdb,)}) is tmdb
    assert safe_review_candidate({"_candidates": (tmdb, tvmaze_same)}) in {
        tmdb,
        tvmaze_same,
    }
    assert safe_review_candidate({"_candidates": (tmdb, tvmaze_other)}) is None
    assert safe_review_candidate({"_candidates": ()}) is None


def test_safe_review_candidate_recovers_strong_historical_ai_approval() -> None:
    row = {
        "título candidato": "Vagabond",
        "tipo": "dorama",
        "año pista": 2019,
        "_ai_review_state": "approved_by_ai",
        "_ai_score": 100,
        "_ai_sources": ("https://example.test/one", "https://example.test/two"),
        "_ai_contradictions": (),
    }

    candidate = safe_review_candidate(row)

    assert candidate is not None
    assert candidate.provider == "mce-ai"
    assert candidate.title == "Vagabond"
    assert candidate.year == 2019


def test_safe_review_candidate_accepts_validated_single_source_history() -> None:
    candidate = safe_review_candidate(
        {
            "título candidato": "Vagabond",
            "tipo": "dorama",
            "_ai_review_state": "approved_by_ai",
            "_ai_score": 100,
            "_ai_sources": ("https://example.test/only-one",),
            "_ai_contradictions": (),
        }
    )

    assert candidate is not None
    assert candidate.title == "Vagabond"


def test_provider_usage_panel_shows_calls_limits_cache_and_rate(app) -> None:
    panel = ProviderUsagePanel()
    panel.begin()
    panel.update_usage(
        (
            ProviderUsage(
                "Groq IA",
                calls=4,
                limit=1000,
                remaining=996,
                successes=3,
                errors=1,
                rate_limited=1,
                cache_hits=2,
                tokens_remaining=7227,
                detail="fallbacks: 0",
                cooldown_seconds=125,
                cooldown_known=True,
            ),
        )
    )

    assert panel.table.rowCount() == 1
    assert panel.table.item(0, 0).text() == "Groq IA"
    assert panel.table.item(0, 1).text() == "4"
    assert panel.table.item(0, 6).text() == "996"
    assert panel.table.item(0, 7).text() == "7,227"
    assert "Evitadas por caché: 2" in panel.summary.text()
    assert panel.groq_status.text().startswith("Groq: esperar 02:0")


def test_provider_usage_panel_does_not_invent_unknown_groq_reset(app) -> None:
    panel = ProviderUsagePanel()
    panel.update_usage(
        (
            ProviderUsage(
                "Groq IA",
                rate_limited=1,
                cooldown_seconds=60,
                cooldown_known=False,
            ),
        )
    )

    assert panel.groq_status.text() == (
        "Groq: límite desconocido · espera de seguridad activa"
    )


def test_startup_report_enters_safe_mode_and_blocks_session_creation(app, tmp_path) -> None:
    report = StartupReport(
        (
            HealthCheck("postgresql", "ok", "disponible"),
            HealthCheck("tables", "error", "faltan tablas"),
        )
    )
    window = MainWindow(
        QSettings(str(tmp_path / "safe.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
        startup_report=report,
    )
    window.create_session(None)  # type: ignore[arg-type]
    assert window.safe_mode
    assert "Modo seguro" in window.activity_badge.text()
    assert not window.pages["Importaciones"].create_session.isEnabled()
    assert {
        "Crear backup",
        "Restaurar backup",
        "Generar paquete",
    }.issubset({button.text() for button in window.pages["Diagnóstico"].action_buttons})
    window.close()


def test_diagnostic_button_creates_zip_through_worker(app, tmp_path, monkeypatch) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "diagnostic.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    target = tmp_path / "mce-diagnostic.zip"
    monkeypatch.setattr(window, "_select_diagnostic_destination", lambda _default: target)
    window.navigate_to("Diagnóstico")
    button = next(
        button
        for button in window.pages["Diagnóstico"].action_buttons
        if button.text() == "Generar paquete"
    )
    button.click()
    assert QThreadPool.globalInstance().waitForDone(10000)
    app.processEvents()
    assert target.is_file()
    assert "Paquete diagnóstico creado" in window.activity_badge.text()
    window.close()


def test_provider_badge_counts_descriptive_credentialless_status() -> None:
    assert provider_status_is_available("disponible sin credenciales")
    assert provider_status_is_available("disponible sin credenciales · alias, IDs y respaldo")
    assert provider_status_is_available("configurada")
    assert not provider_status_is_available("no configurada")


@pytest.mark.parametrize("review_count", [10, 100, 1_000])
def test_bulk_review_runs_in_worker_and_restores_controls(
    app, tmp_path, review_count
) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "bulk.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    provenance = FieldProvenance(
        FieldSourceType.IMPORTED,
        "test",
        "bulk",
        datetime.now(UTC),
        ConfidenceScore(80),
    )
    reviews = tuple(
        ReviewItem(
            f"bulk-{index}",
            f"file-{index}",
            {"title": MetadataField(f"Obra {index}", provenance)},
        )
        for index in range(review_count)
    )
    rows = [{"id": item.review_id} for item in reviews]
    window.review_repository.save_many(reviews)
    window.review_rows = rows
    window.pages["Pendientes de revisión"].set_rows(rows)

    window.start_bulk_review("Rechazar", tuple(rows))

    assert window.review_worker is not None
    assert not any(
        button.isEnabled() for button in window.pages["Pendientes de revisión"].action_buttons
    )
    assert QThreadPool.globalInstance().waitForDone(10000)
    app.processEvents()
    assert window.review_worker is None
    assert all(
        button.isEnabled() for button in window.pages["Pendientes de revisión"].action_buttons
    )
    assert window.review_rows == []
    assert window.review_repository.pending() == ()
    window.close()


def test_approve_all_uses_every_filtered_work_not_only_visible_page(
    app, tmp_path, monkeypatch
) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "approve-all.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    rows = [
        {"id": f"work-{index}", "grupo": "incluida" if index < 105 else "otra"}
        for index in range(125)
    ]
    page = window.pages["Pendientes de revisión"]
    page.set_rows(rows)
    page.search.setText("incluida")
    captured = {}

    def capture(action, selected_records):
        captured["action"] = action
        captured["records"] = selected_records

    monkeypatch.setattr(window, "start_bulk_review", capture)
    window.handle_review_action("Aprobar todas", [])

    assert captured["action"] == "Aprobar"
    assert len(captured["records"]) == 105
    assert len(page.model.filtered) == page.model.page_size == 50
    window.close()


def test_group_identical_works_reduces_visible_reviews_and_expands_actions(
    app, monkeypatch
) -> None:
    settings_path = Path.cwd() / ".group-identical-button-test.ini"
    window = MainWindow(
        QSettings(str(settings_path), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    rows = [
        {"id": "a", "tipo": "dorama", "título candidato": "VINCENZO", "archivos agrupados": 1},
        {"id": "b", "tipo": "dorama", "título candidato": "vincenzo", "archivos agrupados": 15},
        {"id": "c", "tipo": "dorama", "título candidato": "Goblin", "archivos agrupados": 16},
    ]
    page = window.pages["Pendientes de revisión"]
    window.review_rows = rows
    page.set_rows(rows)

    window.handle_review_action("Agrupar obras idénticas", [])

    assert len(window.review_rows) == 2
    assert window.review_rows[0]["archivos agrupados"] == 16
    assert any(
        button.text() == "Agrupar obras idénticas" for button in page.action_buttons
    )
    captured: dict[str, object] = {}
    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda *_args, **_kwargs: QMessageBox.StandardButton.Yes,
    )
    monkeypatch.setattr(
        window,
        "start_review_repair",
        lambda records, revalidate: captured.update(
            {"ids": {row["id"] for row in records}, "revalidate": revalidate}
        ),
    )

    window.handle_review_action("Revalidar y completar", [0])

    assert captured == {"ids": {"a"}, "revalidate": True}
    monkeypatch.setattr(
        window,
        "start_bulk_review",
        lambda action, records: captured.update(
            {"delete_action": action, "deleted_ids": {row["id"] for row in records}}
        ),
    )

    window.handle_review_action("Eliminar seleccionado", [0])

    assert captured["delete_action"] == "Rechazar"
    assert captured["deleted_ids"] == {"a", "b"}
    assert any(button.text() == "Eliminar seleccionado" for button in page.action_buttons)
    window.close()
    settings_path.unlink(missing_ok=True)


def test_bulk_review_freezes_each_logical_work_only_once() -> None:
    repeated = ({"id": "same-work"}, {"id": "same-work"})
    assert freeze_review_selection(repeated) == ({"id": "same-work"},)


def test_grouped_review_revalidation_unifies_members_as_one_canonical_work(
    app, tmp_path
) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    window = MainWindow(
        QSettings(str(tmp_path / "canonical-review.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    created = window.session_presenter.create(
        ImportService().import_file(ImportRequest(fixture))
    )
    first = replace(
        created.items[0],
        stage=ProcessingStage.REVIEWED,
        status=SessionItemStatus.WARNING,
        detected_category="dorama",
        clean_title="Vincenzo",
        work_title="Vincenzo",
        work_group_id="old-group-a",
        enrichment_status="needs_human_review",
    )
    second = replace(
        first,
        item_id=str(PhysicalFileId.new()),
        physical_file_id=PhysicalFileId.new(),
        original_path=r"F:\Doramas\Vincenzo\S01E02.mkv",
        original_name="S01E02.mkv",
        work_group_id="old-group-b",
    )
    reviewed = replace(
        created,
        items=(first, second),
        status=SessionStatus.WAITING_REVIEW,
    )
    window.session_presenter.sessions.save(reviewed)
    rows = (
        {
            "id": first.item_id,
            "tipo": "dorama",
            "título candidato": "Vincenzo",
            "archivo": first.original_name,
            "ruta": first.original_path,
            "archivos agrupados": 1,
            "_item_ids": [first.item_id],
        },
        {
            "id": second.item_id,
            "tipo": "dorama",
            "título candidato": "Vincenzo",
            "archivo": second.original_name,
            "ruta": second.original_path,
            "archivos agrupados": 1,
            "_item_ids": [second.item_id],
        },
    )
    grouped = group_identical_review_rows(rows)[0]
    window.review_sessions = {
        first.item_id: created.session_id,
        second.item_id: created.session_id,
    }

    result = window._run_review_repair((grouped,), True)
    revalidated = window.session_presenter.sessions.get(created.session_id)

    assert result["updated"] == {
        first.item_id: "Vincenzo",
        second.item_id: "Vincenzo",
    }
    assert revalidated is not None
    assert len({item.work_group_id for item in revalidated.items}) == 1
    assert all(
        item.stage is ProcessingStage.READY_FOR_ENRICHMENT for item in revalidated.items
    )
    window.close()


def test_bulk_progress_reaches_one_hundred_only_after_decisions(app, tmp_path) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "bulk-progress.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    provenance = FieldProvenance(
        FieldSourceType.IMPORTED,
        "test",
        "bulk-progress",
        datetime.now(UTC),
        ConfidenceScore(80),
    )
    reviews = tuple(
        ReviewItem(
            f"progress-{index}",
            f"file-{index}",
            {"title": MetadataField(f"Obra {index}", provenance)},
        )
        for index in range(2)
    )
    window.review_repository.save_many(reviews)
    progress = []

    window._run_bulk_review(
        "Rechazar",
        tuple({"id": item.review_id} for item in reviews),
        progress.append,
    )

    assert progress == [45, 90, 100]
    assert window.review_repository.pending() == ()
    window.close()


def test_bulk_review_restores_controls_after_worker_error(app, tmp_path, monkeypatch) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "bulk-error.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )

    def fail(*_args):
        raise RuntimeError("fallo controlado")

    monkeypatch.setattr(window, "_run_bulk_review", fail)
    window.start_bulk_review("Rechazar", ({"id": "one"}, {"id": "two"}))

    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    assert window.review_worker is None
    assert all(
        button.isEnabled() for button in window.pages["Pendientes de revisión"].action_buttons
    )
    assert "No se pudo completar" in window.activity_badge.text()
    window.close()


def test_catalog_publication_runs_in_worker_and_restores_controls(
    app, tmp_path, monkeypatch
) -> None:
    class PublicationStub:
        @staticmethod
        def publish():
            return PublicationResult(
                "publication-1",
                1,
                "active",
                12,
                {"valid": True, "errors": []},
            )

    monkeypatch.setattr(
        QMessageBox,
        "question",
        lambda *_args, **_kwargs: QMessageBox.StandardButton.Yes,
    )
    window = MainWindow(
        QSettings(str(tmp_path / "publication.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
        publication_service=PublicationStub(),
    )

    window.start_catalog_publication()

    assert window.publication_worker is not None
    assert not any(
        button.isEnabled() for button in window.pages["Finalización"].action_buttons
    )
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    assert window.publication_worker is None
    assert all(button.isEnabled() for button in window.pages["Finalización"].action_buttons)
    assert "versión 1" in window.activity_badge.text()
    assert "12 disponibilidades" in window.activity_badge.text()
    window.close()


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def test_main_window_has_complete_navigation_and_restores_theme(app, tmp_path) -> None:
    settings = QSettings(str(tmp_path / "mce.ini"), QSettings.Format.IniFormat)
    settings.setValue("dark_mode", True)
    window = MainWindow(settings)

    assert window.navigation.count() == len(SECTIONS) + 1  # cabecera de marca + secciones
    assert set(window.pages) == set(SECTIONS)
    window.navigate_to("Duplicados")
    assert window.stack.currentWidget() is window.pages["Duplicados"]
    assert window.current_section.text() == "Duplicados"
    assert window.navigation.item(1).icon().isNull() is False
    assert "Resumen" in window.navigation.item(1).toolTip()
    assert window.navigation.item(SECTIONS.index("Importaciones") + 1).text() == "1  Importación"
    assert (
        window.navigation.item(SECTIONS.index("Sesiones") + 1).text()
        == "2  Clasificación y limpieza local"
    )
    assert "vista previa" in window.navigation.item(SECTIONS.index("Catálogo") + 1).text()
    assert window.navigation.item(SECTIONS.index("Finalización") + 1).text().startswith("5")
    for hidden in (
        "Importaciones",
        "Sesiones",
        "Enriquecimiento",
        "Catálogo",
        "Finalización",
        "Configuración",
    ):
        assert window.navigation.item(SECTIONS.index(hidden) + 1).isHidden()
    assert set(window.workflow_buttons) == {
        "Importaciones",
        "Sesiones",
        "Enriquecimiento",
        "Catálogo",
        "Finalización",
    }
    window.settings_button.click()
    assert window.stack.currentWidget() is window.pages["Configuración"]
    assert "tema" in window.theme_button.toolTip().lower()
    assert "sin comprobar" not in window.database_badge.text()
    assert window.metadata_badge.text().startswith("Proveedores ·")
    assert "#182230" in app.styleSheet()
    assert "QListWidget#navigation" in app.styleSheet()
    window.close()
    assert settings.contains("geometry")


def test_finalization_summarizes_catalog_categories(app, tmp_path) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "final.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    window.catalog_rows = [
        {"título": "Akira", "tipo": "anime"},
        {"título": "Amélie", "tipo": "movie"},
        {"título": "Otra", "tipo": "movie"},
        {"título": "Capítulo", "tipo": "episode"},
    ]
    window.refresh_finalization()

    rows = window.pages["Finalización"].model.rows
    assert {row["categoría"] for row in rows} == {"Anime", "Películas", "Episodios"}
    assert next(row for row in rows if row["categoría"] == "Películas")["elementos"] == 2
    assert {row["estado"] for row in rows} == {"aprobado · pendiente de publicación"}
    window.navigate_to("Finalización")
    assert window.current_section.text() == "5  Finalización"
    window.close()


def test_data_page_filters_pages_and_reports_selection(app) -> None:
    page = DataPage("Catálogo", ("Detalles",))
    page.model.page_size = 2
    page.set_rows([])
    assert page.empty_state.isVisible() is False  # no se muestra hasta que el widget sea visible
    page.set_rows([{"title": "Alien"}, {"title": "Aliens"}, {"title": "Matrix"}])
    assert page.table.rowCount() == 2
    assert page.next.isEnabled()
    page.change_page(1)
    assert page.table.item(0, 0).text() == "Matrix"
    page.search.setText("Alien")
    assert page.table.rowCount() == 2
    page.table.selectRow(0)
    actions: list[tuple[str, object]] = []
    page.action_requested.connect(lambda action, rows: actions.append((action, rows)))
    page.request_action("Detalles")
    assert actions == [("Detalles", [0])]
    assert page.table.alternatingRowColors()
    assert "title: Alien" in page.details.text()


def test_data_page_hides_technical_columns_but_keeps_them_in_details(app) -> None:
    page = DataPage("Revisión", visible_columns=("grupo", "Coincidencia"))
    page.set_rows(
        [
            {
                "id": "technical-id",
                "grupo": "Vagabond",
                "Coincidencia": "Sin coincidencias",
                "proveedor candidato": "—",
            }
        ]
    )

    assert [page.table.horizontalHeaderItem(index).text() for index in range(2)] == [
        "grupo",
        "Coincidencia",
    ]
    page.table.selectRow(0)
    assert "technical-id" in page.details.text()
    assert "proveedor candidato" in page.details.text()


def test_catalog_completion_panel_distinguishes_coverage_from_resolved(app) -> None:
    panel = CatalogCompletionPanel()
    panel.update_summary({"total": 100, "processed": 60, "resolved": 40, "review": 20})

    assert panel.percent.text() == "40.0 %"
    assert panel.progress.value() == 400
    assert "Cobertura de enriquecimiento: 60.0 %" in panel.detail.text()
    assert "En revisión: 20" in panel.detail.text()
    assert "Sin procesar: 40" in panel.detail.text()


def test_destructive_action_requires_confirmation(app, monkeypatch) -> None:
    page = DataPage("Duplicados", ("Combinar",))
    emitted: list[str] = []
    page.action_requested.connect(lambda action, rows: emitted.append(action))
    monkeypatch.setattr(QMessageBox, "question", lambda *args: QMessageBox.StandardButton.No)
    page.request_action("Combinar")
    assert emitted == []
    monkeypatch.setattr(QMessageBox, "question", lambda *args: QMessageBox.StandardButton.Yes)
    page.request_action("Combinar")
    assert emitted == ["Combinar"]


def test_import_page_summarizes_result_and_enables_session(app) -> None:
    page = ImportPage(presenter=SimpleNamespace())
    result = SimpleNamespace(
        success=True,
        status=SimpleNamespace(value="completed"),
        package=SimpleNamespace(
            detected_schema_version="2.2",
            scan=SimpleNamespace(bank_data=(("nombre", "Banco Central"),)),
        ),
        issues=(),
        statistics=SimpleNamespace(video_files=2, subtitle_files=1),
    )
    requested: list[tuple[object, str]] = []
    page.session_creation_requested.connect(
        lambda payload, bank_name: requested.append((payload, bank_name))
    )
    page.show_result(result)
    page.request_session_creation()
    assert "Esquema: 2.2" in page.summary.text()
    assert page.create_session.isEnabled()
    assert requested == [(result, "Banco Central")]
    assert page.bank_name.text() == "Banco Central"
    assert page.result_values["Videos"].text() == "2"
    assert page.step_labels[2].property("state") == "success"


def test_import_page_explains_rejected_result(app) -> None:
    page = ImportPage(presenter=SimpleNamespace())
    issue = SimpleNamespace(code="FILE_TOO_LARGE", message="Supera el límite configurado")
    result = SimpleNamespace(
        success=False,
        status=SimpleNamespace(value="rejected"),
        package=None,
        issues=(issue, issue),
        statistics=SimpleNamespace(
            video_files=0, subtitle_files=0, warnings=0, errors=1, fatal_errors=0
        ),
    )
    page.show_result(result)
    assert "FILE_TOO_LARGE" in page.summary.text()
    assert "límite configurado" in page.summary.text()
    assert "2 x FILE_TOO_LARGE" in page.summary.text()
    assert not page.create_session.isEnabled()
    assert page.step_labels[1].property("state") == "error"


def test_buttons_explain_their_actions_with_tooltips(app) -> None:
    import_page = ImportPage(presenter=SimpleNamespace())
    tooltips = {button.text(): button.toolTip() for button in import_page.findChildren(QPushButton)}
    assert "inventario JSON" in tooltips["Seleccionar JSON"]
    assert "estructura" in tooltips["Validar"]
    data_page = DataPage("Sesiones", ("Pausar", "Cancelar"))
    actions = {button.text(): button.toolTip() for button in data_page.findChildren(QPushButton)}
    assert "progreso" in actions["Pausar"]
    assert "confirmación" in actions["Cancelar"]


def test_import_page_cancel_is_cooperative(app) -> None:
    page = ImportPage(presenter=SimpleNamespace())
    from mce.application.workspaces import CancellationToken

    page.token = CancellationToken()
    page.cancel_work()
    assert page.token.is_cancelled
    assert "Cancelación" in page.summary.text()


def test_main_window_creates_session_and_lists_it(app, tmp_path) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    window = MainWindow(
        QSettings(str(tmp_path / "session.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    window.create_session(result)
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    assert len(window.session_rows) == 1
    assert window.session_rows[0]["estado"] == "ready"
    assert window.session_rows[0]["banco"] == "Banco A"
    assert window.pages["Sesiones"].table.rowCount() == 1
    assert window.current_section.text() == "2  Clasificación y limpieza local"
    window.pages["Sesiones"].table.selectRow(0)
    window.handle_session_action("Preparar local", [0])
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    window.handle_session_action("Enriquecer online", [0])
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    assert window.session_rows[0]["estado"] == "waiting_review"
    assert window.pages["Pendientes de revisión"].table.rowCount() > 0
    assert not window.session_progress_panel.isHidden()
    assert not window.enrichment_progress_panel.isHidden()
    assert window.session_progress_panel.overall.value() == 1000
    assert window.enrichment_progress_panel.overall.value() == 1000
    assert window.session_progress_panel.processed.text() == "Lote actual: 1 / 1 obras"
    assert window.enrichment_progress_panel.processed.text() == "Lote actual: 1 / 1 obras"
    assert "Pendientes: 1" in window.session_progress_panel.results.text()
    assert window.activity_badge.text() == "Sin tareas activas"
    window.handle_review_action("Bloquear", [0])
    protected = window.session_presenter.sessions.get(str(window.session_rows[0]["sesión"]))
    assert protected is not None
    assert protected.items[0].human_title_locked
    assert protected.items[0].human_decision_at is not None
    window.handle_review_action("Aprobar", [0])
    assert window.pages["Pendientes de revisión"].table.rowCount() == 0
    assert window.pages["Catálogo"].table.rowCount() == 1
    assert window.session_rows[0]["estado"] == "completed"
    assert window.session_presenter.enrichment_rows()[0]["Estado"] == "Completada"
    window.close()


def test_rejected_review_completes_category_without_catalog_entry(app, tmp_path) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    window = MainWindow(
        QSettings(str(tmp_path / "reject.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    created = window.session_presenter.create(result)
    window.session_rows = [window.session_presenter.row(created)]
    window.pages["Sesiones"].set_rows(window.session_rows)
    window.session_presenter.prepare_local(created.session_id)
    window.start_session_processing(created.session_id)
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()

    window.handle_review_action("Rechazar", [0])

    assert window.pages["Pendientes de revisión"].table.rowCount() == 0
    assert window.pages["Catálogo"].table.rowCount() == 0
    assert window.session_presenter.enrichment_rows()[0]["Estado"] == "completada"
    assert window.session_rows[0]["estado"] == "completed"
    window.close()


def test_missing_online_credential_waits_without_mass_review(app, tmp_path, monkeypatch) -> None:
    for credential in (
        "TMDB_API_KEY",
        "FANART_API_KEY",
        "TAVILY_API_KEY",
        "SERPER_API_KEY",
        "EXA_API_KEY",
        "GROQ_API_KEY",
    ):
        monkeypatch.delenv(credential, raising=False)
    monkeypatch.setenv("OLLAMA_ENABLED", "false")
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    window = MainWindow(QSettings(str(tmp_path / "offline.ini"), QSettings.Format.IniFormat))
    created = window.session_presenter.create(result)
    window.session_rows = [window.session_presenter.row(created)]
    window.pages["Sesiones"].set_rows(window.session_rows)

    window.session_presenter.prepare_local(created.session_id)
    window.start_session_processing(created.session_id)
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()

    assert window.session_rows[0]["estado"] == "waiting_internet"
    assert window.review_rows == []
    assert "espera" in window.activity_badge.text().casefold()
    window.metadata_runtime_builder = fake_metadata_runtime
    window.handle_session_action("Reanudar", [0])
    assert QThreadPool.globalInstance().waitForDone(5000)
    app.processEvents()
    assert window.session_rows[0]["estado"] == "waiting_review"
    window.close()


def test_resume_from_enrichment_keeps_selected_category(app, tmp_path, monkeypatch) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    window = MainWindow(
        QSettings(str(tmp_path / "resume-category.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    created = window.session_presenter.create(result)
    prepared, _summary = window.session_presenter.prepare_local(created.session_id)
    running = window.session_presenter.transition(prepared.session_id, SessionStatus.RUNNING)
    waiting = window.session_presenter.transition(
        running.session_id, SessionStatus.WAITING_INTERNET
    )
    rows = window.session_presenter.enrichment_rows()
    window.pages["Enriquecimiento"].set_rows(rows)
    window.navigate_to("Enriquecimiento")
    captured: list[tuple[str, frozenset[str] | None, int | None]] = []
    monkeypatch.setattr(
        window,
        "start_session_processing",
        lambda session_id, selected=None, **options: captured.append(
            (session_id, selected, options.get("prepared_total"))
        ),
    )
    monkeypatch.setattr(
        window.session_presenter.sessions,
        "get",
        lambda _session_id: pytest.fail("resume must not load a full session on the UI thread"),
    )

    window.handle_session_action("Reanudar", [0])

    assert captured == [
        (
            waiting.session_id,
            frozenset({str(rows[0]["_categoría"])}),
            0,
        )
    ]
    window.close()


def test_pause_active_batch_does_not_persist_on_ui_thread(app, tmp_path, monkeypatch) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    window = MainWindow(
        QSettings(str(tmp_path / "pause-responsive.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    created = window.session_presenter.create(result)
    window.session_rows = [window.session_presenter.row(created)]
    window.pages["Sesiones"].set_rows(window.session_rows)
    window.processing_session_id = created.session_id
    window.processing_token = CancellationToken()
    window.processing_worker = SimpleNamespace()  # type: ignore[assignment]
    monkeypatch.setattr(
        window.session_presenter,
        "transition",
        lambda *_args, **_kwargs: pytest.fail("pause persisted synchronously"),
    )

    window.handle_session_action("Pausar", [0])

    assert "pausado" in window.activity_badge.text().casefold()
    window.processing_token.cancel()
    window.processing_worker = None
    window.close()


def test_enrichment_refresh_retries_when_invalidated_during_load(
    app, tmp_path, monkeypatch
) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "refresh-pending.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    window.enrichment_worker = SimpleNamespace()  # type: ignore[assignment]
    window.invalidate_enrichment_rows()
    calls: list[bool] = []
    monkeypatch.setattr(window, "refresh_enrichment_rows", lambda: calls.append(True))

    window.enrichment_rows_finished()

    assert calls == [True]
    window.close()


def test_session_checkpoint_is_recovered_on_next_start(app, tmp_path) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    checkpoint_dir = tmp_path / "checkpoints"
    first = MainWindow.build_session_presenter(checkpoint_dir)
    created = first.create(result)
    second = MainWindow.build_session_presenter(checkpoint_dir)
    restored = second.all()
    assert len(restored) == 1
    assert restored[0] == created
    assert restored[0].bank_name == "Banco A"


def test_large_checkpoint_is_not_materialized_during_safe_startup(tmp_path) -> None:
    checkpoint_dir = tmp_path / "checkpoints"
    checkpoint_dir.mkdir()
    checkpoint = checkpoint_dir / "00000000-0000-0000-0000-000000000001.json"
    checkpoint.write_bytes(b"{" + (b" " * (8 * 1024 * 1024)) + b"}")

    presenter = MainWindow.build_session_presenter(checkpoint_dir)

    assert len(presenter.all()) == 0


def test_main_window_archives_inactive_session_and_preserves_checkpoint(app, tmp_path) -> None:
    fixture = Path(__file__).parents[2] / "fixtures" / "msl" / "valid_minimal_v1.json"
    result = ImportService().import_file(ImportRequest(fixture))
    checkpoint_dir = tmp_path / "checkpoints"
    presenter = MainWindow.build_session_presenter(checkpoint_dir)
    created = presenter.create(result)
    window = MainWindow(
        QSettings(str(tmp_path / "delete.ini"), QSettings.Format.IniFormat),
        session_presenter=presenter,
        metadata_runtime_builder=fake_metadata_runtime,
    )
    window.session_progress_panel.begin(10)

    window.pages["Sesiones"].table.selectRow(0)
    window.handle_session_action("Borrar sesión", [0])

    assert presenter.sessions.get(created.session_id).status is SessionStatus.ARCHIVED
    assert (checkpoint_dir / f"{created.session_id}.json").exists()
    assert window.session_rows == []
    assert window.session_progress_panel.isHidden()
    assert window.pages["Sesiones"].table.rowCount() == 0
    assert window.activity_badge.text() == "Sesión archivada"
    window.close()


def test_main_window_exports_catalog_and_refreshes_health(app, tmp_path, monkeypatch) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "operations.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    destination = tmp_path / "catalog.json"
    monkeypatch.setattr(
        QFileDialog,
        "getSaveFileName",
        lambda *args, **kwargs: (str(destination), "JSON (*.json)"),
    )
    window.catalog_rows = [{"título": "Amélie", "tipo": "movie"}]
    window.pages["Catálogo"].set_rows(window.catalog_rows)

    window.handle_operational_action("Catálogo", "Exportar JSON")

    assert destination.is_file()
    assert "Exportados 1" in window.activity_badge.text()
    window.handle_operational_action("Diagnóstico", "Actualizar")
    assert window.pages["Diagnóstico"].table.rowCount() >= 5
    window.close()


def test_main_window_exports_visual_pdf_catalog(app, tmp_path, monkeypatch) -> None:
    window = MainWindow(
        QSettings(str(tmp_path / "pdf.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    destination = tmp_path / "catalog.pdf"
    monkeypatch.setattr(
        QFileDialog,
        "getSaveFileName",
        lambda *args, **kwargs: (str(destination), "PDF (*.pdf)"),
    )
    window.catalog_rows = [
        {"título": "Akira", "tipo": "anime", "año": 1988},
        {"título": "Amélie", "tipo": "movie", "año": 2001},
    ]

    window.handle_operational_action("Finalización", "Exportar PDF")

    assert destination.read_bytes().startswith(b"%PDF-")
    assert "PDF generado" in window.activity_badge.text()
    window.close()


def test_reviews_from_multiple_sessions_are_kept_separate(app, tmp_path) -> None:
    fixtures = Path(__file__).parents[2] / "fixtures" / "msl"
    window = MainWindow(
        QSettings(str(tmp_path / "multi.ini"), QSettings.Format.IniFormat),
        metadata_runtime_builder=fake_metadata_runtime,
    )
    created = [
        window.session_presenter.create(
            ImportService().import_file(ImportRequest(fixtures / filename))
        )
        for filename in ("valid_minimal_v1.json", "valid_unicode_v1.json")
    ]
    window.session_rows = [window.session_presenter.row(session) for session in created]
    window.pages["Sesiones"].set_rows(window.session_rows)

    for session in created:
        window.session_presenter.prepare_local(session.session_id)
        window.start_session_processing(session.session_id)
        assert QThreadPool.globalInstance().waitForDone(5000)
        app.processEvents()

    first_count = sum(
        session_id == created[0].session_id for session_id in window.review_sessions.values()
    )
    second_count = sum(
        session_id == created[1].session_id for session_id in window.review_sessions.values()
    )
    assert first_count > 0
    assert second_count > 0

    visible = window.pages["Pendientes de revisión"].model.filtered
    first_row = next(
        index
        for index, row in enumerate(visible)
        if window.review_sessions[str(row["id"])] == created[0].session_id
    )
    window.handle_review_action("Aprobar", [first_row])
    assert created[1].session_id in window.review_sessions.values()
    window.close()

def test_enrichment_action_is_only_available_in_stage_three(app, tmp_path) -> None:
    window = MainWindow(QSettings(str(tmp_path / "actions.ini"), QSettings.Format.IniFormat))

    session_actions = {button.text() for button in window.pages["Sesiones"].action_buttons}
    enrichment_actions = {
        button.text() for button in window.pages["Enriquecimiento"].action_buttons
    }

    assert "Enriquecer online" not in session_actions
    assert "Enriquecer online" in enrichment_actions
    window.close()
