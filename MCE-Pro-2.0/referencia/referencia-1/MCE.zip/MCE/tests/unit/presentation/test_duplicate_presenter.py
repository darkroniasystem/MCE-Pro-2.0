from mce.presentation.duplicate_presenter import DuplicatePresenter


def catalog_row(file_id: str, path: str) -> dict[str, object]:
    return {
        "título": "Alien",
        "año": 1979,
        "banco": "bank-1",
        "ruta": path,
        "_file_id": file_id,
        "_content_id": f"content:{file_id}",
        "_source_id": "source-1",
        "_installation_id": "installation-1",
        "_original_name": "Alien.mkv",
        "_size_bytes": 100,
        "_file_hash": "a" * 64,
    }


def test_duplicate_presenter_detects_combines_and_reverts() -> None:
    presenter = DuplicatePresenter()
    presenter.register_catalog_row(catalog_row("file-1", "E:/Alien.mkv"))
    presenter.register_catalog_row(catalog_row("file-2", "F:/Alien.mkv"))

    rows = presenter.rows()
    assert len(rows) == 1
    candidate_id = str(rows[0]["id"])
    assert rows[0]["estado"] == "pendiente"
    assert "hash completo" in str(rows[0]["evidencia"])

    presenter.decide(candidate_id, "Combinar")
    assert presenter.rows()[0]["estado"] == "combinado"
    presenter.decide(candidate_id, "Separar")
    assert presenter.rows()[0]["estado"] == "separado"


def test_duplicate_presenter_records_non_destructive_decisions() -> None:
    presenter = DuplicatePresenter()
    presenter.register_catalog_row(catalog_row("file-1", "E:/Alien.mkv"))
    presenter.register_catalog_row(catalog_row("file-2", "F:/Alien.mkv"))
    candidate_id = str(presenter.rows()[0]["id"])

    presenter.decide(candidate_id, "Posponer")
    assert presenter.rows()[0]["estado"] == "pospuesto"
    presenter.decide(candidate_id, "Ignorar")
    assert presenter.rows()[0]["estado"] == "ignorado"
