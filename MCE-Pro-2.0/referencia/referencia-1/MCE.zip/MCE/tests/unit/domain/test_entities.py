"""Construcción e invariantes de las entidades centrales."""

from datetime import UTC, datetime

import pytest

from mce.domain.entities import (
    Availability,
    Bank,
    Collection,
    Content,
    ContentVersion,
    Correction,
    Episode,
    FieldLock,
    Installation,
    PhysicalFile,
    ReviewDecision,
    Scan,
    Season,
    Source,
    Subtitle,
)
from mce.domain.exceptions import DomainValidationError, InvalidContentRelationshipError
from mce.domain.value_objects import (
    AvailabilityId,
    AvailabilityStatus,
    BankId,
    CollectionId,
    ContentId,
    ContentType,
    ContentVersionId,
    CorrectionId,
    EpisodeId,
    FieldLockId,
    FileFingerprint,
    ImportId,
    InstallationId,
    LifecycleStatus,
    LockType,
    NormalizedPath,
    PhysicalFileId,
    PhysicalFileStatus,
    ReviewDecisionId,
    ReviewDecisionType,
    ScanId,
    ScanScope,
    ScanScopeType,
    ScanStatus,
    SeasonId,
    SourceId,
    SourceType,
    SubtitleId,
    Title,
)

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)


def test_bank_installation_and_source_hierarchy() -> None:
    bank = Bank(BankId.new(), "Banco Ñ", NOW)
    installation = Installation(InstallationId.new(), bank.bank_id, "PC principal", NOW)
    source = Source(
        SourceId.new(),
        installation.installation_id,
        SourceType.NETWORK_SHARE,
        "Películas",
        NormalizedPath("\\\\PC2\\Peliculas"),
    )
    assert bank.deactivate().status is LifecycleStatus.INACTIVE
    assert source.installation_id == installation.installation_id
    with pytest.raises(DomainValidationError):
        Source(SourceId.new(), None, SourceType.UNKNOWN, "x", NormalizedPath("D:\\"))  # type: ignore[arg-type]


def test_scan_is_not_import_and_scope_is_explicit() -> None:
    scan = Scan(
        ScanId.new(),
        InstallationId.new(),
        NOW,
        NOW,
        ScanScope(ScanScopeType.PARTIAL, (SourceId.new(),)),
        ScanStatus.COMPLETED,
        "2.2.0",
        "2.2",
    )
    assert not scan.scope.is_complete
    assert ImportId.new() != scan.scan_id


def test_content_version_file_and_optional_metadata_are_separate() -> None:
    content = Content(ContentId.new(), ContentType.MOVIE, Title("Titanic"))
    version = ContentVersion(ContentVersionId.new(), content.content_id, "Director's Cut")
    file = PhysicalFile(
        PhysicalFileId.new(),
        ScanId.new(),
        SourceId.new(),
        "Titanic 1080p x264.mkv",
        "Titanic\\Titanic 1080p x264.mkv",
        NormalizedPath("Titanic\\Titanic 1080p x264.mkv"),
        "mkv",
        FileFingerprint(),
        PhysicalFileStatus.PRESENT,
        content.content_id,
        version.version_id,
    )
    assert content.release_year is None
    assert file.identified
    assert version.name == "Director's Cut"
    assert version.edition_type is None


def test_movie_cannot_have_season_and_season_zero_is_valid_for_series() -> None:
    with pytest.raises(InvalidContentRelationshipError):
        Content(ContentId.new(), ContentType.MOVIE, Title("Avatar"), season_ids=(SeasonId.new(),))
    season = Season(SeasonId.new(), ContentId.new(), ContentType.SERIES, 0)
    assert season.season_number == 0
    with pytest.raises(ValueError):
        Season(SeasonId.new(), ContentId.new(), ContentType.SERIES, -1)


def test_episode_supports_specials_absolute_number_and_no_title() -> None:
    episode = Episode(
        EpisodeId.new(), ContentId.new(), ContentType.ANIME, 0, absolute_number=220, special=True
    )
    assert episode.title is None
    assert episode.absolute_number == 220
    with pytest.raises(InvalidContentRelationshipError):
        Episode(EpisodeId.new(), ContentId.new(), ContentType.MOVIE, 1)


def test_remaining_entities_construct_and_keep_concepts_separate() -> None:
    content_id = ContentId.new()
    file_id = PhysicalFileId.new()
    subtitle = Subtitle(SubtitleId.new(), file_id, content_id, language=None)
    collection = Collection(CollectionId.new(), "Harry Potter", content_ids=(content_id,))
    availability = Availability(
        AvailabilityId.new(),
        BankId.new(),
        InstallationId.new(),
        SourceId.new(),
        file_id,
        content_id,
        AvailabilityStatus.AVAILABLE,
        NOW,
        NOW,
        ScanId.new(),
    )
    correction = Correction(
        CorrectionId.new(), "content", str(content_id), "title", "Avatr", "Avatar", NOW
    )
    lock = FieldLock(FieldLockId.new(), "content", str(content_id), "title", LockType.MANUAL, NOW)
    decision = ReviewDecision(
        ReviewDecisionId.new(),
        "content",
        str(content_id),
        ReviewDecisionType.ACCEPT_CANDIDATE,
        NOW,
    )
    assert subtitle.language is None
    assert collection.content_ids == (content_id,)
    assert availability.bank_id is not None
    assert type(correction) is not type(decision)
    assert lock.lock_type is LockType.MANUAL


def test_availability_requires_bank_and_target() -> None:
    common = (InstallationId.new(), SourceId.new(), PhysicalFileId.new(), None)
    with pytest.raises(DomainValidationError):
        Availability(
            AvailabilityId.new(),
            None,
            *common,
            AvailabilityStatus.UNKNOWN,
            NOW,
            NOW,
            ScanId.new(),  # type: ignore[arg-type]
        )
    with pytest.raises(DomainValidationError, match="physical file or content"):
        Availability(
            AvailabilityId.new(),
            BankId.new(),
            InstallationId.new(),
            SourceId.new(),
            None,
            None,
            AvailabilityStatus.UNKNOWN,
            NOW,
            NOW,
            ScanId.new(),
        )
