"""El dominio no puede depender de infraestructura ni presentación."""

import ast
from pathlib import Path

FORBIDDEN = {
    "sqlalchemy",
    "psycopg",
    "sqlite3",
    "pydantic",
    "PySide6",
    "httpx",
    "reportlab",
    "openpyxl",
}


def test_domain_has_no_forbidden_imports() -> None:
    domain_root = Path(__file__).parents[3] / "src" / "mce" / "domain"
    violations: list[str] = []
    for path in domain_root.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            names: list[str] = []
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                names = [node.module]
            for name in names:
                if name.split(".", 1)[0] in FORBIDDEN:
                    violations.append(f"{path}: {name}")
    assert not violations, "\n".join(violations)


def test_public_domain_classes_and_functions_have_docstrings() -> None:
    """Mantiene documentada la API pública del dominio."""
    domain_root = Path(__file__).parents[3] / "src" / "mce" / "domain"
    missing: list[str] = []
    for path in domain_root.rglob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if (
                isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
                and not node.name.startswith("_")
                and ast.get_docstring(node) is None
            ):
                missing.append(f"{path}:{node.lineno}:{node.name}")
    assert not missing, "\n".join(missing)
