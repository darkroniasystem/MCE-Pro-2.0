"""Objetos de valor obligatorios de la Fase 1 ampliada."""

from datetime import UTC, datetime

import pytest

from mce.domain.exceptions import (
    InvalidConfidenceError,
    InvalidIdentifierError,
    InvalidScanScopeError,
    InvalidYearError,
)
from mce.domain.value_objects import (
    BankId,
    ConfidenceCategory,
    ConfidenceScore,
    ConflictSeverity,
    FieldProvenance,
    FieldSourceType,
    FileFingerprint,
    MatchEvidence,
    MetadataConflict,
    NormalizedPath,
    ReleaseYear,
    ScanScope,
    ScanScopeType,
    SourceId,
    Title,
)

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)


def test_identifier_is_hashable_and_rejects_empty() -> None:
    identifier = BankId.new()
    assert {identifier: "bank"}[identifier] == "bank"
    with pytest.raises(InvalidIdentifierError):
        BankId("")


def test_title_preserves_unicode_and_original_input() -> None:
    title = Title("  El niño y la garza 日本語  ")
    assert title.value == "El niño y la garza 日本語"
    assert title.original_value.startswith("  ")


def test_year_and_confidence_boundaries_and_categories() -> None:
    assert ReleaseYear(1878).value == 1878
    assert ConfidenceScore(100).category is ConfidenceCategory.SAFE
    assert ConfidenceScore(75).category is ConfidenceCategory.PROBABLE
    assert ConfidenceScore(50).category is ConfidenceCategory.UNCERTAIN
    assert ConfidenceScore(49).category is ConfidenceCategory.LOW
    with pytest.raises(InvalidYearError):
        ReleaseYear(1500)
    with pytest.raises(InvalidConfidenceError):
        ConfidenceScore(-1)
    with pytest.raises(InvalidConfidenceError):
        ConfidenceScore(101)


def test_windows_paths_compare_without_file_system_access() -> None:
    assert NormalizedPath("C:/Películas/Avatar.mkv") == NormalizedPath("c:\\PELÍCULAS\\avatar.mkv")
    unc = NormalizedPath("\\\\PC2\\Peliculas\\Avatar.mkv")
    assert unc.normalized.startswith("\\\\pc2")


def test_fingerprint_accepts_missing_size_and_hash() -> None:
    assert FileFingerprint(SourceId.new()).cryptographic_hash is None
    with pytest.raises(ValueError, match="SHA-256"):
        FileFingerprint(cryptographic_hash="bad")


def test_scan_scope_validates_selected_sources_and_paths() -> None:
    source_id = SourceId.new()
    full = ScanScope(ScanScopeType.FULL)
    selected = ScanScope(ScanScopeType.SELECTED_SOURCES, (source_id,))
    path_scope = ScanScope(
        ScanScopeType.SELECTED_PATHS,
        included_paths=(NormalizedPath("D:\\Series"),),
    )
    assert full.is_complete
    assert selected.contains(source_id)
    assert path_scope.contains(source_id, NormalizedPath("d:\\series\\show\\e01.mkv"))
    with pytest.raises(InvalidScanScopeError):
        ScanScope(ScanScopeType.SELECTED_SOURCES)
    with pytest.raises(InvalidScanScopeError):
        ScanScope(ScanScopeType.SELECTED_PATHS)


def test_provenance_evidence_and_conflict_are_pure_values() -> None:
    manual = FieldProvenance(FieldSourceType.MANUAL, "operator", None, NOW, ConfidenceScore(100))
    provider = FieldProvenance(
        FieldSourceType.PROVIDER, "catalog", "tt123", NOW, ConfidenceScore(80)
    )
    evidence = MatchEvidence("exact_title", "Título exacto", 80, "catalog")
    conflict = MetadataConflict(
        "release_year", 2000, 2001, manual, provider, ConflictSeverity.HIGH, "Años distintos"
    )
    assert evidence.weight == 80
    assert conflict.current_value == 2000
