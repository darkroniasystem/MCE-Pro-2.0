"""Prioridad de campos y reglas de disponibilidad."""

from datetime import UTC, datetime, timedelta

import pytest

from mce.domain.entities import Availability, PhysicalFile
from mce.domain.exceptions import FieldLockedError, InvalidAvailabilityTransitionError
from mce.domain.rules.availability_rules import (
    can_mark_not_available,
    can_publish_available,
    record_seen,
)
from mce.domain.rules.field_priority import decide_field_update
from mce.domain.value_objects import (
    AvailabilityId,
    AvailabilityStatus,
    BankId,
    ConfidenceScore,
    FieldSourceType,
    FileFingerprint,
    LockType,
    NormalizedPath,
    PhysicalFileId,
    PhysicalFileStatus,
    ScanId,
    ScanScope,
    ScanScopeType,
    SourceId,
)

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)


def test_manual_correction_outranks_inference_and_ai() -> None:
    assert not decide_field_update(FieldSourceType.MANUAL, FieldSourceType.INFERRED).allowed
    assert not decide_field_update(FieldSourceType.IMPORTED, FieldSourceType.AI_GENERATED).allowed
    assert decide_field_update(FieldSourceType.INFERRED, FieldSourceType.PROVIDER).allowed


def test_manual_lock_blocks_automatic_update() -> None:
    decision = decide_field_update(
        FieldSourceType.IMPORTED,
        FieldSourceType.PROVIDER,
        lock_type=LockType.MANUAL,
    )
    assert not decision.allowed
    with pytest.raises(FieldLockedError):
        decide_field_update(
            FieldSourceType.IMPORTED,
            FieldSourceType.PROVIDER,
            lock_type=LockType.MANUAL,
            raise_on_manual_lock=True,
        )


def test_equal_priority_uses_confidence() -> None:
    assert decide_field_update(
        FieldSourceType.PROVIDER,
        FieldSourceType.PROVIDER,
        current_confidence=ConfidenceScore(70),
        candidate_confidence=ConfidenceScore(90),
    ).allowed


def test_partial_scan_cannot_mark_out_of_scope_file_absent() -> None:
    included = SourceId.new()
    excluded = SourceId.new()
    scope = ScanScope(ScanScopeType.SELECTED_SOURCES, (included,))
    assert can_mark_not_available(scope, included, NormalizedPath("D:\\a.mkv"))
    assert not can_mark_not_available(scope, excluded, NormalizedPath("E:\\b.mkv"))


def test_excluded_file_cannot_be_published_and_seen_dates_are_preserved() -> None:
    file = PhysicalFile(
        PhysicalFileId.new(),
        ScanId.new(),
        SourceId.new(),
        "x.mkv",
        "x.mkv",
        NormalizedPath("x.mkv"),
        ".mkv",
        FileFingerprint(),
        PhysicalFileStatus.EXCLUDED,
    )
    assert not can_publish_available(file)
    availability = Availability(
        AvailabilityId.new(),
        BankId.new(),
        None,
        None,
        file.file_id,
        None,
        AvailabilityStatus.UNKNOWN,
        NOW,
        NOW,
        ScanId.new(),
    )
    later = NOW + timedelta(days=1)
    seen = record_seen(availability, later)
    assert seen.first_seen_at == NOW
    assert seen.last_seen_at == later

    archived = availability.transition_to(AvailabilityStatus.ARCHIVED)
    with pytest.raises(InvalidAvailabilityTransitionError):
        record_seen(archived, later)
