"""Transiciones centrales de trabajo, importación y disponibilidad."""

from datetime import UTC, datetime

import pytest

from mce.domain.entities import Availability, ProcessingJob, ScanImport
from mce.domain.exceptions import InvalidStateTransitionError
from mce.domain.value_objects import (
    AvailabilityId,
    AvailabilityStatus,
    BankId,
    ImportId,
    ImportStatus,
    JobId,
    JobStatus,
    PhysicalFileId,
    ScanId,
)

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)
HASH = "a" * 64


def test_job_pause_resume_fail_retry_and_complete() -> None:
    pending = ProcessingJob(JobId.new(), ImportId.new(), NOW)
    running = pending.transition_to(JobStatus.RUNNING, at=NOW).with_progress(50, "grouping")
    paused = running.transition_to(JobStatus.PAUSED)
    resumed = paused.transition_to(JobStatus.RUNNING)
    failed = resumed.transition_to(JobStatus.FAILED, failure_reason="offline")
    assert failed.prepare_retry().status is JobStatus.PENDING
    completed = pending.transition_to(JobStatus.RUNNING, at=NOW).transition_to(
        JobStatus.COMPLETED, at=NOW
    )
    assert completed.progress == 100
    with pytest.raises(InvalidStateTransitionError):
        completed.transition_to(JobStatus.RUNNING)


@pytest.mark.parametrize("progress", [-1, 101])
def test_job_rejects_invalid_progress(progress: float) -> None:
    with pytest.raises(ValueError, match="progress"):
        ProcessingJob(JobId.new(), ImportId.new(), NOW, progress=progress)


def test_import_validation_failure_completion_and_reversion() -> None:
    received = ScanImport(ImportId.new(), ScanId.new(), BankId.new(), "scan.json", HASH, NOW)
    invalid = received.transition_to(ImportStatus.VALIDATING).transition_to(ImportStatus.INVALID)
    assert invalid.status is ImportStatus.INVALID
    completed = (
        received.transition_to(ImportStatus.VALIDATING)
        .transition_to(ImportStatus.VALID)
        .transition_to(ImportStatus.PROCESSING)
        .transition_to(ImportStatus.COMPLETED)
    )
    reverted = completed.transition_to(ImportStatus.REVERTED, at=NOW)
    with pytest.raises(InvalidStateTransitionError):
        reverted.transition_to(ImportStatus.PROCESSING)


def test_duplicate_import_is_explicit_and_keeps_record() -> None:
    received = ScanImport(ImportId.new(), ScanId.new(), BankId.new(), "scan.json", HASH, NOW)
    duplicate = received.transition_to(ImportStatus.DUPLICATE)
    assert duplicate.is_duplicate
    assert duplicate.import_id == received.import_id


def test_archived_availability_requires_explicit_restore() -> None:
    availability = Availability(
        AvailabilityId.new(),
        BankId.new(),
        None,
        None,
        PhysicalFileId.new(),
        None,
        AvailabilityStatus.UNKNOWN,
        NOW,
        NOW,
        ScanId.new(),
    )
    archived = availability.transition_to(AvailabilityStatus.ARCHIVED)
    with pytest.raises(InvalidStateTransitionError):
        archived.transition_to(AvailabilityStatus.AVAILABLE)
    assert (
        archived.transition_to(AvailabilityStatus.AVAILABLE, explicit_restore=True).status
        is AvailabilityStatus.AVAILABLE
    )
