"""Pruebas unitarias ampliadas del dominio."""
