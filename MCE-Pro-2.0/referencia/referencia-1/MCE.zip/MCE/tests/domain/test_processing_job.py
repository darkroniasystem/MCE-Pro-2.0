"""Pruebas conservadas de transiciones de trabajos."""

from datetime import UTC, datetime

import pytest

from mce.domain.entities import ProcessingJob
from mce.domain.exceptions import InvalidStateTransitionError
from mce.domain.value_objects import ImportId, JobId, JobStatus

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)


def test_pause_resume_fail_and_retry_are_explicit() -> None:
    pending = ProcessingJob(JobId.new(), ImportId.new(), NOW)
    running = pending.transition_to(JobStatus.RUNNING, at=NOW)
    paused = running.transition_to(JobStatus.PAUSED)
    resumed = paused.transition_to(JobStatus.RUNNING)
    failed = resumed.transition_to(JobStatus.FAILED, failure_reason="provider down")

    assert failed.prepare_retry().status is JobStatus.PENDING


def test_completed_job_cannot_resume() -> None:
    job = ProcessingJob(JobId.new(), ImportId.new(), NOW)
    completed = job.transition_to(JobStatus.RUNNING, at=NOW).transition_to(
        JobStatus.COMPLETED, at=NOW
    )
    with pytest.raises(InvalidStateTransitionError):
        completed.transition_to(JobStatus.RUNNING)
