"""Pruebas de compatibilidad del dominio iniciadas en la primera entrega."""
