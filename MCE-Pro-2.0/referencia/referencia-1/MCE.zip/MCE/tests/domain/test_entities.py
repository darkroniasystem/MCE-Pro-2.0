"""Pruebas conservadas y adaptadas al contrato ampliado de Fase 1."""

import json
from datetime import UTC, datetime

import pytest

from mce.domain.entities import Bank, Content, ContentVersion, PhysicalFile
from mce.domain.exceptions import InvalidContentRelationshipError
from mce.domain.value_objects import (
    BankId,
    ContentId,
    ContentType,
    ContentVersionId,
    FileFingerprint,
    PhysicalFileId,
    ScanId,
    SeasonId,
    SourceId,
    Title,
)
from mce.domain.value_objects.paths import NormalizedPath

NOW = datetime(2026, 7, 19, 12, tzinfo=UTC)


def test_work_version_and_file_are_distinct_entities() -> None:
    content_id = ContentId.new()
    content = Content(content_id, ContentType.MOVIE, Title("Avatar"))
    version = ContentVersion(ContentVersionId.new(), content_id, "Extended Edition")
    file = PhysicalFile(
        PhysicalFileId.new(),
        ScanId.new(),
        SourceId.new(),
        "Avatar Extended 1080p.mkv",
        "Movies\\Avatar Extended 1080p.mkv",
        NormalizedPath("Movies\\Avatar Extended 1080p.mkv"),
        ".mkv",
        FileFingerprint(),
        content_id=content_id,
        content_version_id=version.version_id,
    )

    assert content.content_id == version.content_id == file.content_id
    assert type(content) is not type(file)
    assert json.loads(json.dumps(content.to_dict()))["main_title"]["value"] == "Avatar"


def test_bank_name_and_movie_season_invariant() -> None:
    with pytest.raises(ValueError):
        Bank(BankId.new(), " ", NOW)
    with pytest.raises(InvalidContentRelationshipError):
        Content(
            ContentId.new(),
            ContentType.MOVIE,
            Title("Arrival"),
            season_ids=(SeasonId.new(),),
        )
