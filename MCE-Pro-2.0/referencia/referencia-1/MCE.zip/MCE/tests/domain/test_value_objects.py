"""Pruebas conservadas de objetos de valor."""

import pytest

from mce.domain.value_objects import (
    BankId,
    ConfidenceCategory,
    ConfidenceScore,
    ContentId,
    ReleaseYear,
    Title,
)


def test_identifier_is_canonical_and_nominal() -> None:
    bank_id = BankId("550E8400-E29B-41D4-A716-446655440000")
    assert str(bank_id) == "550e8400-e29b-41d4-a716-446655440000"
    assert bank_id != ContentId(str(bank_id))


def test_title_year_and_confidence_contracts() -> None:
    title = Title("  Amélie  ")
    assert title.value == "Amélie"
    assert title.original_value == "  Amélie  "
    assert ReleaseYear(2001).value == 2001
    assert ConfidenceScore(90).category is ConfidenceCategory.SAFE


@pytest.mark.parametrize("score", [-0.1, 100.1])
def test_confidence_rejects_values_outside_percentage(score: float) -> None:
    with pytest.raises(ValueError):
        ConfidenceScore(score)
