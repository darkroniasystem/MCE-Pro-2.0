"""Pruebas live explícitas y excluibles de la suite normal."""
