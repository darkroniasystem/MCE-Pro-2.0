"""Smokes reales y limitados de la pila web, navegador y analizadores de MCE."""

from __future__ import annotations

import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread

import pytest

from mce.application.ai_review import AIReviewInput, EvidenceSource
from mce.application.identification.service import ProviderRateLimitError
from mce.infrastructure.ai_review import GroqStructuredAnalyzer, create_groq_client
from mce.infrastructure.local_ai import OllamaQwenAnalyzer, UrllibOllamaTransport
from mce.infrastructure.metadata.browser_playwright import (
    PlaywrightBrowserAutomationBackend,
)
from mce.infrastructure.metadata.browser_search import (
    BrowserSearchSettings,
    BrowserSearchStatus,
)
from mce.infrastructure.metadata.http_transport import UrllibJsonTransport
from mce.infrastructure.metadata.web_search import (
    ExaWebSearchProvider,
    SerperWebSearchProvider,
    TavilyWebSearchProvider,
)

pytestmark = pytest.mark.live_providers


def credential(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        pytest.skip(f"{name}: no configurada")
    return value


@pytest.mark.parametrize("provider_name", ["tavily", "serper", "exa"])
def test_general_web_provider_real_search(provider_name: str) -> None:
    if provider_name == "tavily":
        provider = TavilyWebSearchProvider(
            credential("TAVILY_API_KEY"),
            UrllibJsonTransport("https://api.tavily.com", provider_name="Tavily"),
        )
    elif provider_name == "serper":
        provider = SerperWebSearchProvider(
            credential("SERPER_API_KEY"),
            UrllibJsonTransport("https://google.serper.dev", provider_name="Serper"),
        )
    else:
        provider = ExaWebSearchProvider(
            credential("EXA_API_KEY"),
            UrllibJsonTransport("https://api.exa.ai", provider_name="Exa"),
        )

    try:
        result = provider.search("Vagabond Korean drama 2019 cast director", limit=3)
    except ProviderRateLimitError as exc:
        assert provider_name == "tavily"
        assert getattr(exc, "quota_exhausted", False) is True
        return

    assert result
    assert all(item.source_url.startswith("https://") for item in result)
    assert all(item.provider == provider_name for item in result)


def _evidence() -> tuple[EvidenceSource, ...]:
    return (
        EvidenceSource(
            "https://one.example/vagabond",
            "Vagabond",
            "Korean television drama released in 2019",
            "phase-n",
            2019,
            "dorama",
        ),
        EvidenceSource(
            "https://two.example/vagabond",
            "Vagabond",
            "2019 South Korean television series",
            "phase-n",
            2019,
            "dorama",
        ),
    )


def test_ollama_qwen_real_diagnostic_and_strict_json() -> None:
    analyzer = OllamaQwenAnalyzer(
        UrllibOllamaTransport(),
        model="qwen2.5:3b",
        timeout=120,
    )
    diagnostic = analyzer.diagnose()
    assert diagnostic.connected and diagnostic.model_present and diagnostic.inference_ok

    result = analyzer.analyze(
        AIReviewInput("phase-n", "001 - Vagabond WEB-DL", "dorama", 2019),
        _evidence(),
    )

    assert result.model == "qwen2.5:3b"
    assert not result.hallucinated_source
    assert {source.url for source in result.sources} <= {
        source.url for source in _evidence()
    }


def test_groq_real_structured_fallback_contract() -> None:
    analyzer = GroqStructuredAnalyzer(
        create_groq_client(credential("GROQ_API_KEY"), timeout=45),
        min_interval_seconds=0,
        rate_limit_retries=0,
    )

    result = analyzer.analyze(
        AIReviewInput("phase-n", "Vagabond", "dorama", 2019),
        _evidence(),
    )

    assert result.provider == "groq"
    assert result.model in {"openai/gpt-oss-120b", "openai/gpt-oss-20b"}
    assert not result.hallucinated_source
    assert {source.url for source in result.sources} <= {
        source.url for source in _evidence()
    }


class _LocalSearchPage(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        body = b"""<!doctype html><html><body><main>
        <li class='b_algo'><h3><a href='https://example.test/vincenzo'>Vincenzo</a></h3>
        <div class='b_caption'><p>Dorama de 2021. Temporadas: 1.</p></div></li>
        </main></body></html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: object) -> None:
        return


def _browser_settings() -> BrowserSearchSettings:
    return BrowserSearchSettings(
        enabled=True,
        headless=True,
        timeout_seconds=30,
        max_concurrency=1,
        delay_min_ms=0,
        delay_max_ms=0,
        max_results=3,
        max_page_text_chars=4_000,
    )


def test_playwright_chrome_real_launch_navigation_extraction_and_close() -> None:
    server = ThreadingHTTPServer(("127.0.0.1", 0), _LocalSearchPage)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    backend = PlaywrightBrowserAutomationBackend(
        channel="chrome",
        search_url_template=f"http://127.0.0.1:{server.server_port}/?q={{query}}",
    )
    try:
        result = backend.search("Vincenzo dorama 2021", limit=3, settings=_browser_settings())
    finally:
        backend.close()
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)

    assert result.status is BrowserSearchStatus.SUCCESS
    assert result.hits[0].title == "Vincenzo"
    assert result.hits[0].year == 2021
    assert result.hits[0].media_type == "dorama"


def test_browser_real_public_search_reports_evidence_or_explicit_block() -> None:
    backend = PlaywrightBrowserAutomationBackend(channel="chrome")
    try:
        result = backend.search("Vincenzo dorama 2021", limit=3, settings=_browser_settings())
    finally:
        backend.close()

    assert result.status not in {
        BrowserSearchStatus.UNAVAILABLE,
        BrowserSearchStatus.TIMEOUT,
    }
    assert result.status in {
        BrowserSearchStatus.SUCCESS,
        BrowserSearchStatus.PARTIAL,
        BrowserSearchStatus.NO_EVIDENCE,
        BrowserSearchStatus.BLOCKED,
        BrowserSearchStatus.CAPTCHA,
        BrowserSearchStatus.RATE_LIMITED,
    }
