"""Smoke tests reales, limitados y sin persistencia de proveedores."""

import os

import pytest

from mce.application.identification.models import IdentificationQuery, SearchKind
from mce.infrastructure.metadata.external_providers import (
    AniListMetadataProvider,
    FanartMetadataProvider,
    TvMazeMetadataProvider,
)
from mce.infrastructure.metadata.http_transport import UrllibJsonTransport
from mce.infrastructure.metadata.providers import TmdbMetadataProvider
from mce.infrastructure.metadata.wikidata import (
    WikidataClient,
    WikidataProviderConfig,
    WikidataSearchProvider,
)

pytestmark = pytest.mark.live_providers


def credential(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        pytest.skip(f"{name}: no configurada")
    return value


def test_tmdb_live_movie_series_details_and_external_ids() -> None:
    provider = TmdbMetadataProvider(
        credential("TMDB_API_KEY"),
        UrllibJsonTransport("https://api.themoviedb.org/3", provider_name="TMDb"),
    )
    movie = provider.search_movie(IdentificationQuery("Avatar", SearchKind.MOVIE, 2009))[0]
    movie_detail = provider.get_movie_details(movie.external_id)
    series = provider.search_series(
        IdentificationQuery("Game of Thrones", SearchKind.SERIES, 2011)
    )[0]
    series_detail = provider.get_series_details(series.external_id)
    assert movie_detail.title and ("imdb", "tt0499549") in movie_detail.external_ids
    assert series_detail.title and any(key == "thetvdb" for key, _ in series_detail.external_ids)


def test_fanart_live_movie_art() -> None:
    provider = FanartMetadataProvider(
        credential("FANART_API_KEY"),
        UrllibJsonTransport("https://webservice.fanart.tv", provider_name="Fanart.tv"),
    )
    assert provider.get_images("550", SearchKind.MOVIE)


def test_anilist_live_graphql_anime() -> None:
    provider = AniListMetadataProvider(
        UrllibJsonTransport("https://graphql.anilist.co", provider_name="AniList")
    )
    result = provider.search_series(IdentificationQuery("Attack on Titan", SearchKind.ANIME, 2013))[
        0
    ]
    assert result.kind is SearchKind.ANIME and result.external_id


def test_tvmaze_live_search_and_imdb_lookup() -> None:
    provider = TvMazeMetadataProvider(
        UrllibJsonTransport("https://api.tvmaze.com", provider_name="TVMaze")
    )
    result = provider.search_series(
        IdentificationQuery("Game of Thrones", SearchKind.SERIES, 2011)
    )[0]
    exact = provider.lookup(imdb="tt0944947")
    assert result.title and exact.external_id == result.external_id


def test_wikidata_live_action_api_aliases_and_external_ids() -> None:
    config = WikidataProviderConfig(max_candidates=5, max_search_variants=1)
    provider = WikidataSearchProvider(
        WikidataClient(
            UrllibJsonTransport("https://www.wikidata.org", provider_name="Wikidata"),
            config,
        ),
        config,
    )

    results = provider.search_movie(IdentificationQuery("The Old Guard 2", SearchKind.MOVIE, 2025))

    assert results
    assert results[0].external_id.startswith("Q")
    assert ("wikidata", results[0].external_id) in results[0].external_ids
