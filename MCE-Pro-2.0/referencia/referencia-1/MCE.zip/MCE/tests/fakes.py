"""Dobles reutilizables que nunca forman parte del runtime de MCE."""

from typing import Any

from mce.application.enrichment.models import LanguageModelSuggestion
from mce.application.identification.models import IdentificationQuery, ProviderCandidate
from mce.infrastructure.language_models import (
    InvalidLanguageModelResponseError,
    LanguageModelUnavailableError,
)


class FakeMetadataProvider:
    name = "fake"

    def __init__(
        self,
        results: tuple[ProviderCandidate, ...] = (),
        error: Exception | None = None,
    ) -> None:
        self.results = tuple(results)
        self.error = error
        self.calls = 0

    def _search(self) -> tuple[ProviderCandidate, ...]:
        self.calls += 1
        if self.error:
            raise self.error
        return self.results

    def search_movie(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search()

    def search_series(self, query: IdentificationQuery) -> tuple[ProviderCandidate, ...]:
        return self._search()

    def get_movie_details(self, external_id: str) -> ProviderCandidate:
        return next(item for item in self.results if item.external_id == external_id)

    get_series_details = get_movie_details

    def get_season_details(self, external_id: str, season: int) -> dict[str, object]:
        return {"id": external_id, "season": season}

    def get_episode_details(self, external_id: str, season: int, episode: int) -> dict[str, object]:
        return {"id": external_id, "season": season, "episode": episode}


class FakeLanguageModelProvider:
    def __init__(self, response: Any = None, unavailable: bool = False) -> None:
        self.response = response
        self.unavailable = unavailable

    def suggest(self, task: str, payload: dict[str, object]) -> LanguageModelSuggestion:
        if self.unavailable:
            raise LanguageModelUnavailableError("proveedor desconectado")
        data = self.response
        if (
            not isinstance(data, dict)
            or set(data) != {"task", "value", "explanation"}
            or not all(isinstance(data[key], str) and data[key].strip() for key in data)
        ):
            raise InvalidLanguageModelResponseError("respuesta de IA inválida")
        if data["task"] != task:
            raise InvalidLanguageModelResponseError("tarea de IA inesperada")
        return LanguageModelSuggestion(data["task"], data["value"], data["explanation"])
