# Arquitectura

## Proveedores Wikidata

`infrastructure.metadata.wikidata` separa configuración, cliente Action API,
parser, mapeador, puntuación, limitador y adaptador. El administrador conserva
prioridad, estados y fusión; aplicación y presentación no realizan HTTP.

## Estilo

MCE utiliza capas inspiradas en Clean Architecture y Ports and Adapters. La
separación busca sustituibilidad y pruebas; no justifica crear abstracciones sin
una responsabilidad real.

```text
Presentation  ──►  Application  ──►  Domain
                         ▲              ▲
                         └─ Infrastructure
```

## Domain

Contendrá entidades, objetos de valor, reglas puras, eventos, excepciones y
puertos. No importará PySide6, SQLAlchemy, Pydantic, httpx, ReportLab ni código
de infraestructura.

La Fase 1 materializa esta capa con `entities`, `value_objects`, `rules`,
`exceptions` y un paquete `ports` deliberadamente vacío. Las relaciones usan
identificadores tipados en lugar de referencias circulares. Estados y reglas de
transición viven en módulos centrales y las entidades devuelven nuevas
instancias inmutables.

## Application

Coordinará comandos, consultas, DTO, transacciones y el pipeline. Dependerá de
contratos del dominio y recibirá adaptadores mediante inyección de dependencias.

La Fase 2 implementa:

```text
src/mce/application/
├── dto/        # solicitud, incidencias, paquete, resultado y estadísticas
├── ports/      # lector, hash y registro de importaciones
└── importers/  # lector seguro, esquema, validadores, mapper y servicio
```

La dirección es exclusivamente `application → domain`. Las implementaciones
locales de SHA-256 y registro en memoria no contienen persistencia.

Los contratos externos se despachan mediante `MslSchemaAdapterRegistry`.
`MslSchema10Adapter`, `MslSchema22Adapter` y `LegacyMslSchemaAdapter` declaran
las diferencias permitidas antes de entrar al normalizador canónico. Un
`schema_version` desconocido, futuro o malformado no obtiene adaptador y nunca
se interpreta silenciosamente. El adaptador 2.2 habilita de forma explícita los
subtítulos anidados; el legado solo se usa cuando la solicitud lo autoriza.

La Fase 3 agrega `application/workspaces`, modelos de sesión en `dto` y puertos
para repositorios, reloj, identidades, progreso y checkpoints. Los repositorios
en memoria son adaptadores locales. `infrastructure/checkpoints` implementa el
almacenamiento JSON versionado y depende de los contratos de aplicación.

La Fase 5 agrega `application/normalization`: un pipeline puro que recibe texto
y devuelve valores derivados. No depende de persistencia, proveedores ni
presentación y no modifica entidades importadas.

La Fase 6 agrega `application/classification`, que consume resultados de
normalización y devuelve candidatos y asociaciones preliminares. Sigue siendo
pura y no conoce SQLAlchemy, internet ni interfaz gráfica.

La Fase 7 define `MetadataProvider` en aplicación. Los adaptadores externos
viven en `infrastructure/metadata`; caché, transporte y resiliencia se inyectan,
por lo que dominio y casos de uso no conocen una API concreta.

La Fase 8 agrega `application/enrichment`, que reutiliza procedencia y prioridad
del dominio. `infrastructure/language_models` contiene adaptadores opcionales;
ninguno escribe directamente en PostgreSQL ni decide revisiones.

La Fase 9 agrega `application/deduplication`. Sus modelos separan identidad
lógica, versión editorial, observación física y disponibilidad. Las operaciones
son auditables, reversibles y no acceden al sistema de archivos.

## Infrastructure

Implementará persistencia SQLite/PostgreSQL, carga y almacenamiento de JSON,
proveedores HTTP, caché, configuración, logging y exportadores. Sus detalles no
se filtrarán hacia el dominio.

## Presentation

PySide6 traduce acciones a presentadores y casos de uso y muestra sus resultados.
Los trabajadores `QThreadPool` mantienen importación y procesamiento fuera del hilo
visual. Los widgets no validan reglas de negocio, consultan SQL ni llaman APIs de
metadatos directamente.

## Límites operativos

- PostgreSQL guarda el catálogo definitivo.
- SQLite guarda trabajos, progreso, caché y estado operativo recuperable.
- El JSON recibido se archiva de forma inmutable antes del procesamiento.
- Las tareas pesadas se ejecutan fuera del hilo visual.
- Las sincronizaciones son transaccionales y admiten vista previa.
- La ausencia solo se calcula dentro del alcance confirmado de un escaneo total.

## Estructura actual

```text
src/mce/domain/
├── entities/       # identidad y relaciones de negocio
├── value_objects/  # IDs, rutas, alcance, confianza y procedencia
├── rules/          # transiciones, prioridad y disponibilidad
├── exceptions/     # errores específicos del dominio
└── ports/          # reservado; sin repositorios ni proveedores en Fase 1
```

`infrastructure` contiene adaptadores PostgreSQL, checkpoints, metadatos y modelos
de lenguaje. `presentation` contiene la composición PySide6, presentadores,
ViewModels y trabajadores de la Fase 10.

## Dependencias

Las dependencias de producción actuales son SQLAlchemy, Alembic, psycopg y PySide6.
Pytest, pytest-cov, Ruff y mypy permanecen como herramientas de desarrollo.

## Runtime y distribución de la Fase 12

`infrastructure/runtime` resuelve recursos empaquetados y datos mutables sin
depender del directorio de trabajo. Los recursos viajan dentro de `dist\MCE` y
se consideran de solo lectura. Los datos se crean bajo `%LOCALAPPDATA%\MCE Desktop`:

```text
data/         estado local
cache/        caché SQLite acotada
checkpoints/  sesiones recuperables
exports/      destino sugerido de exportación
backups/      destino sugerido de respaldo
config/       preferencias INI
logs/         logs rotativos y privados del usuario
```

`MCE_DATA_DIR` solo sirve para aislar pruebas y diagnósticos controlados. El
arranque importa archivos heredados sin sobrescribir los existentes. PyInstaller
usa formato `onedir`; todos los archivos del directorio son parte del producto.
# Capa de presentación PySide6

La presentación se divide en widgets, presentadores, ViewModels puros y trabajadores.
La dependencia permanece `presentation → application → domain`; ningún widget llama
SQLAlchemy ni proveedores externos. Las tareas costosas usan `QThreadPool` y señales.
