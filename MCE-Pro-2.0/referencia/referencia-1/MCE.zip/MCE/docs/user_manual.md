# Manual de usuario de MCE Desktop

## Inicio

Ejecute `MCE.exe` desde la carpeta completa `dist\MCE`. No mueva solamente el
EXE: la distribución `onedir` necesita su carpeta `_internal`.

MCE guarda datos mutables en `%LOCALAPPDATA%\MCE Desktop`, separados en:

- `config`: preferencias locales;
- `logs`: registros rotativos y archivo de diagnóstico;
- `cache`: respuestas temporales de proveedores;
- `checkpoints`: sesiones recuperables;
- `exports`: JSON, CSV y PDF creados por el usuario;
- `backups`: destino recomendado para copias PostgreSQL.

## Flujo habitual

1. Abra **Importaciones** y seleccione un JSON producido por MSL.
2. Pulse **Validar** y revise avisos y errores.
3. Confirme o corrija el **Nombre del banco** propuesto desde el JSON.
4. Pulse **Crear sesión** si la validación fue satisfactoria.
5. En **Sesiones**, inicie el procesamiento. Puede pausarlo, reanudarlo o cancelarlo.
6. Resuelva las propuestas en **Pendientes de revisión**.
7. Revise **Duplicados** antes de combinar o separar contenidos.
8. Consulte y exporte **Catálogo**, **Bancos**, **Fuentes** o **Historial**.
9. Use **Diagnóstico** para comprobar base, migraciones, caché y directorios.

El nombre visible queda unido al `bank_id` técnico declarado por MSL, se conserva
en el checkpoint y se utiliza en el catálogo y PostgreSQL. Cambiar el nombre no
altera la identidad del banco ni mezcla datos de bancos diferentes.

MCE nunca abre ni ejecuta archivos indicados por MSL y nunca mueve, renombra o
elimina archivos multimedia.

Mientras una sesión está activa, el panel de progreso muestra la etapa real
(normalización, clasificación, enriquecimiento o guardado), porcentaje general y
de etapa, elementos procesados, velocidad, tiempo transcurrido, tiempo restante
aproximado y contadores de encontrados, pendientes y errores. La estimación puede
variar según Internet, caché, cuotas y tiempos de respuesta de los proveedores.

MCE recorre cada archivo para conservar su ruta, versión, tamaño y relación con
subtítulos, pero consulta proveedores por obra o carpeta agrupada. Los episodios
de una misma serie y temporada reutilizan la identificación; los subtítulos se
asocian localmente y no consumen solicitudes de proveedores.

## Sesiones

Los checkpoints se guardan después de cada cambio importante. Una interrupción
permite recuperar la sesión en el siguiente inicio. **Borrar sesión** elimina
su checkpoint local, no el catálogo ni los archivos multimedia.

## Exportaciones

JSON utiliza el contrato `mce.export.v1`. CSV se genera en UTF-8 y neutraliza
celdas que una hoja de cálculo podría interpretar como fórmulas. Ninguna
exportación incluye contraseñas, tokens ni URL privadas de la base.

**Exportar PDF** crea un catálogo A4 agrupado en anime, novelas, películas,
series, temporadas, episodios y otros. Incluye los metadatos disponibles y
carátulas obtenidas únicamente desde direcciones HTTPS públicas; si una imagen no
está disponible, se usa un marcador legible sin impedir la exportación.

## Privacidad

Las claves de proveedores y PostgreSQL se leen del entorno. No se muestran en
la interfaz ni deben copiarse a configuraciones, respaldos o informes.
