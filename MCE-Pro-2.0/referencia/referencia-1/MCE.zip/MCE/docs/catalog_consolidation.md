# Deduplicación y consolidación

La Fase 9 mantiene separados `CatalogContent`, `CatalogVersion`, `CatalogFile`
y `AvailabilityRecord`. El detector compara pares mediante hash completo, banco,
fuente, ruta normalizada, tamaño, contenido identificado, edición, idioma y
resolución. El título por sí solo nunca demuestra un movimiento o una fusión.

Los resultados distinguen archivo físico duplicado, mismo contenido en otro
archivo o versión, duplicado probable, de ruta, hash y metadatos. Rutas iguales
en bancos distintos siguen siendo archivos físicos independientes.

`CatalogConsolidationService` implementa combinar, separar, adjuntar, desprender,
crear versión, resolver candidato, aplicar disponibilidad y revertir fusiones.
Las fusiones guardan instantáneas y auditoría; ningún caso de uso borra archivos
de los discos.

Un escaneo parcial nunca cambia registros fuera de alcance. Incluso un escaneo
completo requiere `confirm_missing` antes de marcar ausencias y conserva el
estado anterior en historial. Movimiento, renombrado, cambio de fuente y
reemplazo exigen evidencia criptográfica y de ruta.

La implementación de esta fase es un catálogo operativo en memoria. La Fase 10
conecta su interfaz de gestión con el detector y con las operaciones reversibles.
La búsqueda usa índices por hash, identidad, ruta y nombre para evitar comparar
todos los archivos entre sí cuando no comparten ninguna señal.
