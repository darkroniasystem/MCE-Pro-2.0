# Proveedor Wikidata

MCE usa `https://www.wikidata.org/w/api.php` mediante MediaWiki Action API, sin
scraping HTML. `wbsearchentities` localiza QID por variantes controladas y
`wbgetentities` obtiene `labels`, `descriptions`, `aliases`, `sitelinks` y
`claims` para los idiomas configurados.

La entidad se acepta únicamente si `P31` indica una obra audiovisual compatible.
Se extraen QID, año, títulos, alias, Wikipedia e IDs IMDb, TMDb, TVMaze y AniList.

Variables: `MCE_WIKIDATA_ENABLED`, `MCE_WIKIDATA_COMPLEMENTARY`,
`MCE_WIKIDATA_FALLBACK`, `MCE_WIKIDATA_MAX_CANDIDATES` y
`MCE_WIKIDATA_MAX_SEARCH_VARIANTS`. El proveedor reutiliza timeout, reintentos,
cancelación, presupuesto y caché persistente del resto del sistema.
