# Configuración del motor Web, Browser y Ollama

## Orden del flujo

MCE intenta primero los proveedores especializados y la caché. Si la identidad
sigue sin resolverse, usa las API web activadas por prioridad. Browser queda como
último recurso y Ollama/Qwen analiza únicamente la evidencia ya obtenida. Groq es
el fallback final cuando la política de evidencia permite escalar.

## Configuración visual

La página **Configuración** permite ajustar Web, Browser y Ollama sin editar
archivos. Los cambios se guardan localmente y se aplican al iniciar el siguiente
lote.

Browser puede ejecutarse en modo Headless o visible. Sus pausas, concurrencia y
cantidad de resultados son límites operativos, no mecanismos para eludir bloqueos.
Ante CAPTCHA, bloqueo o navegador ausente, MCE registra la causa y continúa según
la estrategia configurada; no intenta evadir protecciones.

El botón **Probar navegador** valida por separado Playwright y Chrome/Chromium. El
botón **Probar Ollama y Qwen** valida servidor, presencia del modelo e inferencia.

## Secretos

Las claves Tavily, Serper, Exa y Groq continúan leyéndose mediante el mecanismo de
entorno seguro existente. La interfaz solo indica si están configuradas y nunca
las copia a preferencias, logs, capturas, documentación o paquetes de diagnóstico.

## Componentes externos

- Playwright es una dependencia de ejecución de MCE.
- Chrome o Chromium debe estar disponible en el equipo; no se empaqueta dentro de
  MCE en esta fase.
- Ollama y `qwen2.5:3b` se administran fuera de MCE y tampoco se empaquetan.
