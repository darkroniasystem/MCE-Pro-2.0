# Validación real de Serper y Exa - Fase F

Fecha: 2026-08-14

## Alcance

Se ejecutó una consulta pública y aislada por proveedor mediante los adaptadores
reales de MCE. No se inició MCE, no se usó su caché persistente y no se accedió
a PostgreSQL ni a sesiones existentes.

Consulta de control: `Vagabond Korean drama 2019 cast director`.

## Resultados

| Proveedor | Solicitudes | Estado | Latencia | Resultados | HTTPS | Año detectado |
|---|---:|---|---:|---:|---:|---|
| Serper | 1 | Correcto | 1,446.4 ms | 3 | 3/3 | 2019 en 3/3 |
| Exa | 1 | Correcto | 2,940.4 ms | 3 | 3/3 | 2019 en 3/3 |

Serper devolvió resultados coherentes de IMDb, Wikipedia y AsianWiki. Exa
devolvió tres resultados coherentes para la misma obra. Los adaptadores
produjeron evidencia estructurada válida en todos los resultados aceptados.

## Seguridad y errores

- No aparecieron errores HTTP, timeouts, 429 ni cuota agotada.
- No se imprimió ni registró el valor de ninguna API key.
- Todos los enlaces aceptados utilizaron HTTPS.
- No se conservaron cuerpos de respuesta completos ni se crearon archivos de
  caché para esta verificación.

## Veredicto

Serper y Exa funcionan realmente con las credenciales configuradas y los
adaptadores actuales de MCE. Esta prueba valida conectividad y contrato básico;
los benchmarks amplios de exactitud, p50/p95, throughput y consumo corresponden
a fases posteriores y no deben inferirse de una sola consulta.
