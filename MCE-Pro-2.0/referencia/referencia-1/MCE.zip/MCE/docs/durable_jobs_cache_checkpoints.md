# Caché, trabajos persistentes y checkpoints

## Alcance de la Fase 9

Los trabajos de sesión son autoritativos en PostgreSQL mediante
`processing_jobs`, `processing_session_items` y `processing_checkpoints`. Los
checkpoints JSON locales continúan disponibles para repositorios locales y
pruebas, pero no sustituyen el ledger PostgreSQL de producción.

## Checkpoints PostgreSQL

Cada checkpoint conserva etapa, lote, último elemento, cantidad procesada,
datos mínimos de reanudación y SHA-256 canónico. Al reiniciar:

- Un trabajo activo con checkpoint válido pasa a interrumpido y su sesión queda
  pausada y recuperable.
- Un trabajo activo sin checkpoint puede reiniciarse desde el estado persistido
  de sus elementos.
- Un checkpoint referenciado pero ausente, incoherente o con checksum inválido
  hace fallar la sesión de forma cerrada con `checkpoint_invalid`; nunca se
  reanuda usando datos dudosos.

## Checkpoints JSON

`JsonCheckpointStore` conserva el contrato explícito `format_version: 1` y añade
un checksum SHA-256 sobre la sesión canónica. Los documentos antiguos sin
checksum siguen siendo legibles y se actualizan al siguiente guardado.

La escritura utiliza un temporal único, `fsync` y reemplazo atómico. Un JSON
sintácticamente válido que haya sido modificado se rechaza por checksum. No se
usa `pickle` ni se ejecuta contenido del archivo.

## Caché SQLite

`SqliteMetadataCache` es persistente y acotada por LRU. Usa WAL,
`synchronous=FULL`, TTL, versión de formato y checksum SHA-256 del payload
comprimido. Una entrada alterada se elimina sin afectar las demás. Una base
SQLite ilegible se conserva con sufijo `.corrupt-<fecha>` y se crea una caché
nueva.

## Límite de fase

Esta fase garantiza durabilidad y detección de corrupción. Los comandos de
detener, continuar, cancelar y borrar desde la interfaz pertenecen a la Fase 10.

