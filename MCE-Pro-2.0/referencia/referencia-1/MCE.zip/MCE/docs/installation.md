# Instalación y distribución

## Distribución profesional

Copie la carpeta completa `dist\MCE` al equipo de destino y ejecute `MCE.exe`.
La aplicación contiene Python y sus dependencias; el equipo de destino no
necesita una instalación independiente de Python.

Requisitos externos:

- Windows 10 u 11 de 64 bits;
- PostgreSQL accesible por red o localmente;
- Microsoft Visual C++ Runtime que requiera Qt/Python en el Windows utilizado;
- `pg_dump` y `pg_restore` en `PATH` para backup y restauración.
- Chrome o Chromium instalado si se activa el proveedor Browser. Playwright se
  incluye con MCE, pero el navegador no se empaqueta;
- Ollama y el modelo `qwen2.5:3b` si se activa el análisis local. Ambos se
  instalan y administran fuera de MCE.

## Configuración

Durante el desarrollo se usa exclusivamente `MCE_TEST_DATABASE_URL` y la base
exacta `mce_test`. Las claves de TMDb, Fanart.tv, Tavily, Serper, Exa y Groq se
configuran como variables de entorno. AniList, TVMaze y Wikidata no requieren
clave. Consulte `.env.example` para los nombres, sin copiar ese archivo ni sus
valores junto al ejecutable.

No guarde secretos junto al EXE. Reinicie MCE después de cambiar variables de
entorno para que el proceso nuevo pueda heredarlas.

## Construcción

```powershell
.\build_release.ps1
```

El resultado principal es `dist\MCE\MCE.exe`. `onefile` no es una distribución
soportada en esta versión.

La distribución es una carpeta indivisible: copie `dist\MCE` completa. No
incluye Chrome/Chromium, Ollama, modelos Qwen ni claves API. El informe de la
construcción candidata actual está en `docs/PHASE_R_RELEASE_REPORT.md`.

## Actualización y desinstalación

Para actualizar, cierre MCE y sustituya la carpeta de instalación completa. Los
datos permanecen en `%LOCALAPPDATA%\MCE Desktop`. Para desinstalar, elimine la
carpeta de instalación; elimine los datos locales solo si ya no necesita
preferencias, logs, caché, checkpoints o exportaciones.
