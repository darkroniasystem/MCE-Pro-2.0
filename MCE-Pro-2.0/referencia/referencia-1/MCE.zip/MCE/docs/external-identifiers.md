# Identificadores externos

Wikidata persiste QID y puede aportar IMDb, TMDb, TVMaze y AniList. El origen es
el candidato Wikidata y su QID. Los IDs confirman coincidencias y evitan
búsquedas repetidas. El orquestador no reencadena Wikidata desde un ID, evitando
bucles.
