# Informe de Fase Q: UI y configuración

Fecha: 2026-08-20

## Alcance implementado

La página **Configuración** conserva el estilo y los componentes existentes, pero
ahora se desplaza verticalmente para que todos los controles sigan disponibles en
ventanas pequeñas.

### Web

- Tavily, Serper y Exa conservan sus interruptores y prioridades editables.
- Se mantiene el orden predeterminado optimizado en Fase P: Exa, Serper, Tavily y
  Browser.
- La UI solo informa si una clave está guardada; nunca muestra su valor.

### Browser

- Activado/desactivado.
- Modo Headless o visible.
- Tiempo máximo.
- Concurrencia máxima.
- Espera mínima y máxima.
- Resultados máximos.
- Botón **Probar navegador**.
- Estado independiente para Playwright y Chrome/Chromium, modo usado y causa
  concreta cuando el navegador no puede iniciarse.

La prueba del botón solo abre y cierra el navegador local. No ejecuta una búsqueda,
no consulta proveedores y no publica datos.

### Ollama/Qwen

- Activado/desactivado.
- URL local.
- Modelo.
- Tiempo máximo.
- Concurrencia máxima.
- Botón **Probar Ollama y Qwen**.
- Estado estructurado de servidor, modelo e inferencia.

### Groq

La configuración existente se conserva sin cambios funcionales: activación,
modelo principal, fallback, modo de prueba, límite diario y comprobación de
conexión.

## Integración con el runtime

Las preferencias se guardan en `QSettings` y se aplican al construir el runtime de
un lote. La espera máxima de Browser nunca se transmite por debajo de la espera
mínima. No se guardan secretos en `QSettings`, código, logs, documentación ni
pruebas.

## Validación

- Pruebas nuevas de persistencia de controles, aplicación al runtime y estados
  concretos de Browser.
- Pruebas nuevas del diagnóstico Playwright/Chrome con dobles aislados.
- Ruff: sin incidencias.
- mypy: 171 archivos fuente sin incidencias.
- Regresión local, excluyendo pruebas reales y PostgreSQL: 559 aprobadas, cero
  fallos, en 230.80 segundos.

## Aislamiento

No se conectó, migró ni modificó PostgreSQL real, el catálogo maestro ni las siete
sesiones existentes. No se ejecutaron búsquedas reales ni se usaron credenciales
durante esta fase.

## Límite de fase

Fase Q queda completada. Fase R (release, reconstrucción y prueba del ejecutable)
no se inició y requiere autorización separada.
