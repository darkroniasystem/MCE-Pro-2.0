# Importación idempotente e incremental

## Alcance de la Fase 7

La importación distingue tres conceptos:

- El hash SHA-256 evita procesar dos veces el mismo JSON original.
- `scan_id` identifica un escaneo MSL y no puede producir dos sesiones.
- `catalog_file_identities` representa el mismo archivo lógico observado a
  través de escaneos diferentes.

La identidad lógica utiliza `bank_id`, la fuente PostgreSQL resuelta y la ruta
normalizada. De este modo una ruta igual en dos bancos no se fusiona.

## Observaciones incrementales

Cada escaneo conserva su propia fila en `physical_files`, enlazada mediante
`catalog_file_id` a la identidad estable. El identificador de la observación se
deriva de `scan_id`, fuente y ruta, por lo que un ID externo de MSL repetido no
colisiona con otro escaneo.

Para cada sesión se registran contadores:

- `inserted_count`: identidad lógica vista por primera vez.
- `updated_count`: identidad existente cuyo nombre, tamaño o hash cambió.
- `duplicate_count`: identidad existente sin cambios observables.

Estos contadores describen la comparación incremental; no eliminan la evidencia
histórica de cada escaneo.

## Atomicidad

Escaneo, importación, sesión, trabajo, staging, identidades y observaciones se
escriben en una sola transacción PostgreSQL. Un `scan_id` repetido se rechaza de
forma explícita y no deja filas parciales. La copia inmutable direccionada por
contenido puede quedar disponible para reutilización segura, igual que en la
Fase 3.

## Límite de fase

La Fase 7 no marca archivos ausentes ni interpreta que una ruta fuera del JSON
haya desaparecido. La diferencia entre alcance parcial y completo pertenece a
la Fase 8 y se documenta en `scope_availability.md`.
