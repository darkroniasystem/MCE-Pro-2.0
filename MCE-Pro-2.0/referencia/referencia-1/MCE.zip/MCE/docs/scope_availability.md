# Disponibilidad según alcance de escaneo

## Alcance de la Fase 8

La reconciliación se ejecuta dentro de la misma transacción que la importación y
opera sobre `catalog_file_identities`. Cada cambio queda registrado en
`availability_events` con escaneo, estado anterior, estado nuevo, razón y fecha.

## Reglas

- `full`: puede marcar ausentes todas las identidades no observadas de la misma
  instalación y banco.
- `partial`: nunca afirma ausencia, aunque el JSON enumere una fuente. Solo
  actualiza como presentes los archivos realmente observados.
- `selected_sources`: puede marcar ausencias exclusivamente dentro de las
  fuentes declaradas.
- `selected_paths`: puede marcar ausencias exclusivamente en la ruta declarada y
  sus descendientes, respetando límites de ruta.

Una identidad observada vuelve a `present` desde cualquier alcance. La primera
ausencia guarda `missing_since_scan_id`; escaneos posteriores que confirmen la
misma ausencia no duplican eventos. Ninguna reconciliación atraviesa el límite
de banco o instalación.

## Persistencia

`catalog_file_identities` conserva el estado actual, el último control y el
escaneo desde el que falta. `availability_events` conserva la historia
inmutable de transiciones `present → missing` y `missing → present`.

Las observaciones de `physical_files` no se borran ni se reescriben como
ausentes: son evidencia histórica de escaneos anteriores.

## Límite de fase

Esta fase no implementa ejecución diferida, caché, pausa, reanudación ni nuevos
checkpoints. Esas responsabilidades pertenecen a la Fase 9.

