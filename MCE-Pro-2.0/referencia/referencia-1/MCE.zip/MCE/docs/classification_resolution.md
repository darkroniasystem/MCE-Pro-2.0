# Resolución de clasificación (Fase 13)

`ClassificationResolver` combina por obra lógica las señales locales, resultados
estructurados, evidencia web y correcciones humanas. Normaliza equivalencias como
`tv`, `episode`, `season`, `dorama` y `novela` sin alterar la evidencia original.

Una categoría automática solo se resuelve cuando coinciden al menos dos señales
fiables independientes. Tavily tiene peso auxiliar y nunca puede decidir por sí
solo. Las contradicciones entre la clasificación local y los proveedores, entre
proveedores o entre decisiones humanas producen `requires_review`; ninguna se
sobrescribe silenciosamente.

Cada elemento de sesión conserva:

- categoría final, si existe;
- estado de resolución;
- explicación completa;
- códigos de conflicto;
- señales y procedencias visibles en la revisión.

Una corrección humana prevalece sobre inferencias y proveedores. Si está bloqueada,
las actualizaciones automáticas posteriores se rechazan; dos decisiones humanas
incompatibles vuelven a revisión en lugar de elegir una arbitrariamente.

La interfaz masiva de revisión pertenece a la Fase 14 y no se amplía aquí.
