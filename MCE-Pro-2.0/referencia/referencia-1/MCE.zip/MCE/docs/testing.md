# Estrategia de pruebas

Las pruebas unitarias usan fixtures JSON sin red, incluido `The Old Guard 2` con
variantes inglesas, españolas y romanas. PostgreSQL exige exactamente
`MCE_TEST_DATABASE_URL` con base `mce_test` y comprueba migraciones,
transacciones, claves, búsqueda y aislamiento por banco. `live_providers` es
optativo y limitado.
