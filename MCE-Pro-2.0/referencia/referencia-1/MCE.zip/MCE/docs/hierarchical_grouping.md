# Agrupación jerárquica provisional

## Alcance de la Fase 6

`HierarchyGrouper` convierte las evidencias locales ya calculadas en candidatos
provisionales con esta forma:

```text
obra
├── temporada
│   └── episodio
│       ├── archivo de video
│       └── subtítulo
└── archivo independiente
```

La salida no crea todavía entidades editoriales definitivas ni consulta
proveedores. Conserva identificadores de archivos físicos y marca cada obra como
`provisional`.

## Reglas

- Una carpeta `Season`, `Temporada`, `Temp` o `S` seguida de número aporta la
  temporada y su carpeta padre aporta el título de obra.
- Una temporada ausente en una señal episódica se representa como temporada 0;
  nunca se inventa la temporada 1.
- Varios archivos pueden representar el mismo episodio.
- Un subtítulo exacto puede vincularse al episodio aunque existan dos archivos de
  video equivalentes. Una coincidencia realmente ambigua permanece sin enlazar.
- El emparejamiento de subtítulos y las claves de obra están aislados por
  `bank_id`.
- IFO, VOB y BUP bajo `VIDEO_TS` forman un candidato de disco DVD y no obras
  independientes.
- La salida es determinista para la misma entrada y rechaza identificadores de
  archivo duplicados.

## Límites

La Fase 6 no modifica el importador, no decide disponibilidad incremental, no
publica catálogo y no fusiona obras entre bancos. La idempotencia e importación
incremental pertenecen a la Fase 7.

