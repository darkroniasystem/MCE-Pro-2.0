# Fase O — Benchmark real de proveedores web e IA

Fecha: 2026-08-20

## Estado

Benchmark ejecutado y reproducido con un lote controlado de cinco obras. Esta
fase solo midió el comportamiento existente: no cambió el orden de proveedores,
la concurrencia, los umbrales ni las reglas de aprobación.

No se conectó ni modificó PostgreSQL, el catálogo maestro o las siete sesiones
reales. Las consultas externas fueron de lectura; Qwen se ejecutó localmente.

## Método

- Obras: Vincenzo, Parasite, Spirited Away, Dark y Money Heist.
- Ejecución secuencial, concurrencia 1.
- Máximo de tres resultados por buscador.
- Detención inmediata cuando un proveedor confirmó cuota agotada.
- Exactitud web: al menos uno de los tres primeros resultados contiene el título
  canónico o un alias esperado.
- Falso positivo web: hubo evidencia, pero ninguna de las tres primeras entradas
  coincidió. Esto describe calidad de evidencia y no significa que MCE publicara
  esa obra.
- Falso positivo IA: el analizador aprobó un título incorrecto o citó una fuente
  que no pertenecía a la evidencia entregada.
- RAM: pico del proceso Python. En Browser no incluye los procesos hijos de
  Chrome.
- VRAM: observación total de la GPU NVIDIA del sistema; no puede atribuirse a un
  proveedor concreto.

## Resultado reproducido

| Proveedor | Éxito | Exactitud | Falsos positivos | Media | p50 | p95 | Intentos/min | RAM pico |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Tavily | 0/1 | no medible | 0 | 404 ms | 404 ms | 404 ms | 148.44 | 39.04 MiB |
| Serper | 5/5 | 100 % | 0 | 1,174 ms | 1,177 ms | 1,390 ms | 51.09 | 39.47 MiB |
| Exa | 5/5 | 100 % | 0 | 835 ms | 769 ms | 1,258 ms | 71.83 | 40.32 MiB |
| Browser/Bing | 5/5 | 20 % | 4 lotes de evidencia | 11,358 ms | 10,166 ms | 14,832 ms | 5.28 | 49.68 MiB* |
| Qwen 2.5 3B | 5/5 JSON válido | 40 % | 0 aprobaciones falsas | 8,130 ms | 7,364 ms | 12,520 ms | 7.38 | 49.87 MiB* |
| Groq | 5/5 JSON válido | 100 % título | 1 aprobación insegura | 2,460 ms | 2,053 ms | 4,022 ms | 24.39 | 60.21 MiB |

\* La RAM de Browser no incluye Chrome y la RAM de Qwen no incluye Ollama. La
observación máxima de VRAM del sistema fue aproximadamente 2.8 GiB durante la
ventana de IA local, pero no es una medición aislada de Qwen.

## Métricas específicas de Browser

- Navegación media: 10,663 ms.
- Extracción media: 411 ms.
- Parser con evidencia: 100 %.
- Knowledge panel detectado: 0 %.
- Lotes con algún campo estructurado útil: 60 %.
- Resolución completa: 1/5.
- Enriquecimiento parcial: 4/5.
- Sin mejora: 0/5.
- CAPTCHA, bloqueo, timeout y error: 0.

Browser funcionó técnicamente, pero su evidencia fue lenta y poco precisa para
cuatro de las cinco consultas. Es un fallback operativo, no una fuente que deba
autorizar publicación por sí sola con estos resultados.

## Hallazgos de IA

- Qwen respondió siempre con JSON válido. Identificó exactamente 2/5 títulos y
  envió los cinco casos a revisión humana, por lo que no produjo aprobaciones
  falsas. En una respuesta señaló una fuente no entregada, pero su decisión
  conservadora evitó una aprobación automática.
- Groq obtuvo el título correcto en 5/5 y aprobó los cinco. En Spirited Away
  también declaró una fuente no incluida en la evidencia, por lo que el
  benchmark contabilizó 1/5 aprobación insegura. La primera corrida no había
  reproducido esta anomalía; la segunda demuestra que es intermitente y debe
  endurecerse antes de confiar en aprobación automática.

## Límites y bloqueos externos

- Tavily respondió con límite de plan/cuota en ambas corridas. MCE detuvo los
  intentos de Tavily correctamente, pero no fue posible medir su calidad con
  resultados hasta reponer la cuota.
- La muestra de cinco obras es deliberadamente pequeña para evitar consumo
  innecesario. Sirve como línea base y detector de regresiones, no como estudio
  estadístico definitivo del catálogo completo.

## Evidencia

- Datos íntegros y sanitizados: `docs/phase_o_benchmark_2026-08-20.json`.
- Ejecutor reproducible: `tools/benchmark_phase_o.py`.
- Pruebas del instrumento: `tests/unit/tools/test_benchmark_phase_o.py`.

## Puerta de fase

La Fase O queda ejecutada y documentada. La Fase P no se inicia sin autorización
separada. Sus entradas principales son la aprobación insegura intermitente de
Groq, la baja precisión y latencia de Browser, la variabilidad de Qwen y la cuota
externa de Tavily.
