# Estrategia de pruebas

## Principios

- Las pruebas verifican comportamiento y contratos, no detalles accidentales.
- Ninguna fase se completa con pruebas relacionadas fallidas.
- Los defectos corregidos reciben una prueba de regresión.
- No se eliminan ni debilitan pruebas para aprobar una fase.
- Datos externos y condiciones de fallo tienen casos explícitos.

## Niveles

### Unitarias

Reglas puras: normalización, clasificación, puntuación, estados, agrupación y
disponibilidad. Deben ser rápidas, deterministas y no usar red ni bases reales.

### Contrato

JSON de MSL, DTO, proveedores y exportaciones. Usarán fixtures anonimizados y
comprobarán compatibilidad hacia atrás dentro de las versiones soportadas.

### Integración

SQLite, PostgreSQL, repositorios, migraciones, caché y exportadores. PostgreSQL
usará una base de prueba separada y transacciones aisladas.

### Extremo a extremo

Cubrirán el flujo `JSON → procesamiento → revisión → PostgreSQL → exportación`
cuando sus fases existan, incluyendo reanudación y reversión.

## Matriz mínima de riesgos

Se probarán JSON corrupto, versión incompatible, proveedor caído, desconexión de
PostgreSQL, interrupción, importación repetida, escaneo total/parcial, rutas
largas, Unicode, miles de episodios y exportaciones grandes.

## Herramientas y comandos

```powershell
python -m pytest
python -m pytest --cov=mce --cov-report=term-missing
python -m ruff check .
python -m mypy
```

`mypy` aplica modo estricto a todo `src`; pytest es el verificador ejecutable de
los contratos de prueba. Ruff analiza tanto `src` como `tests`.

La cobertura orienta la revisión pero no reemplaza los casos significativos.
Cada entrega informará el comando, intérprete, resultado y limitaciones.

En Windows, pytest utiliza `.test-runtime/tmp` como `basetemp` y
`.test-runtime/cache` como caché. `tests/conftest.py` alinea además `TMPDIR`,
`TEMP` y `TMP` con `.test-runtime/system-temp`. Esto evita depender de ACL
externas del perfil de Windows y mantiene todos los artefactos efímeros fuera
del código y excluidos de control de versiones. Las pruebas deben continuar
usando `tmp_path` o `tmp_path_factory`, nunca rutas temporales codificadas.

### Persistencia rápida y PostgreSQL real

`tests/integration/database` usa SQLite en memoria para feedback rápido sobre
mappers y transacciones. No sustituye la verificación del motor de producción.

`tests/integration/postgresql` exige `MCE_TEST_DATABASE_URL`, comprueba motor
PostgreSQL y nombre exacto `mce_test`, y rechaza cualquier otro destino antes de
limpiar datos. Sus fixtures truncan tablas con `CASCADE` entre casos, pero nunca
eliminan la base, usuarios ni permisos. La base futura del catálogo maestro no
se usa durante el desarrollo.

## Fase 6

Las pruebas unitarias cubren tipos, umbral `unknown`, evidencia, conflictos,
episodios simples/dobles/continuos, subtítulos exactos/probables/ambiguos/sin
pareja, DVD y grupos provisionales. La prueba integrada conecta el resultado
inmutable de la Fase 5 con la clasificación y confirma que no se crea identidad
de contenido ni una relación definitiva.

## Fase 7

Todas las respuestas externas son falsas o controladas. Se prueban coincidencia
exacta, alias, traducción, original, conflicto de año, ambigüedad, sin resultados,
errores, timeout, 429/5xx, límite local, caché, TTL, offline, cancelación,
puntuación, evidencia y umbrales sin realizar llamadas a internet.

La composición de producción tiene pruebas adicionales que impiden usar
`FakeMetadataProvider`, validan el transporte HTTPS con respuestas grabadas,
comprueban que los errores no revelen la credencial y verifican persistencia,
caducidad y límite de la caché SQLite. La suite nunca necesita una clave real.

## Fase 8

Se prueban procedencia, metadatos parciales, conflictos, prioridad, bloqueo de
sistema/manual, corrección, reversión, aprobación, rechazo, resolución,
auditoría, alias, sinopsis y respuestas de IA válidas, inválidas y desconectadas.

## Fase 9

Se prueban hashes, rutas, bancos, fuentes, metadatos, versiones, idiomas,
resoluciones, escaneos completos/parciales, ausencias, movimientos, renombrados,
reemplazos, fusiones, separaciones, reversión, disponibilidad, episodios, DVD y
subtítulos. Las pruebas confirman que ningún archivo físico se elimina.

## Fase 0

La prueba inicial solo confirma que el paquete es importable, publica una versión
y respeta el rango de Python declarado. No pretende probar lógica inexistente.

## Fase 3

Las pruebas unitarias cubren transiciones, elementos, estadísticas, progreso,
cancelación y reintento. Las pruebas integradas parten de fixtures MSL reales de
la Fase 2 y verifican la creación de sesiones, preservación de identidades, rutas
y alcance, unicidad por paquete y roundtrip de checkpoints. También corrompen de
forma controlada documentos temporales para comprobar el rechazo de JSON y
versiones incompatibles.
# Interfaz de escritorio

Las pruebas de presentación usan `QT_QPA_PLATFORM=offscreen`. Cubren estados,
paginación, presentadores, resultados, errores, progreso, cancelación, navegación,
filtros, selección, confirmaciones y preferencias. La comprobación visual manual se
documenta en `docs/desktop_interface.md`.

Las pruebas manuales de carga usan inventarios temporales seleccionados mediante
la interfaz, nunca una ruta fija ni datos empaquetados con MCE. Deben completar
importación y pipeline sin bloquear el hilo visual. El objetivo de memoria es
1 GiB; la prueba de equivalencia impide aprobar una reducción de memoria que
pierda datos. Los inventarios reales temporales se eliminan antes de publicar la
distribución y ninguna prueba automatizada activa puede depender de ellos.

## Pruebas live de proveedores

`tests/live/` queda excluido de la suite normal. Se ejecuta explícitamente con:

```powershell
.\.venv\Scripts\python.exe -m pytest -m live_providers tests\live
```

Las pruebas realizan pocas llamadas, no escriben en PostgreSQL y no imprimen
claves. Los dobles y respuestas controladas permanecen exclusivamente en tests.

## Fase 11

Las pruebas unitarias cubren JSON, CSV, Unicode, conjuntos iterables grandes,
exclusión de secretos, fórmulas CSV, contrato del bot, backup y restauración
simulados, diagnóstico, caché, archivado y detección de sesiones interrumpidas.
PostgreSQL real verifica `audit_events`, paginación, reversión atómica, rollback
sin datos parciales y columnas estables de `bot_catalog_v1`.

## Fase 12

`tools/benchmark_phase12.py` genera cargas deterministas de 10.000, 100.000,
500.000 y 1.000.000 de elementos. Registra tiempo, rendimiento, memoria pico y
tamaño de exportación; los resultados medidos se interpretan en
`docs/performance.md` y no se convierten en umbrales frágiles de pytest.

Las pruebas de runtime verifican aislamiento de datos, importación heredada,
escape de recursos, redacción de logs, correlación, enlaces simbólicos y
recuperación de caché corrupta. El cierre exige además construir `dist\MCE`,
arrancarlo con un `PATH` sin Python y repetir la validación en una PC limpia.
