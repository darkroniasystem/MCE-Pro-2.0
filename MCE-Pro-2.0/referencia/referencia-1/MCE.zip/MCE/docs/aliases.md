# Alias y búsqueda

Se conservan por separado título bruto del banco, limpio, original, español,
inglés y preferido. Cada alias mantiene forma visible, clave normalizada, idioma,
país, tipo, proveedor, entidad, indicador manual, confianza y procedencia.

La normalización ignora caja, tildes y puntuación y equipara números romanos
básicos con arábigos. La deduplicación incluye la obra y no mezcla obras por
semejanza. Los alias locales/manuales y la disponibilidad respetan `bank_id`.
