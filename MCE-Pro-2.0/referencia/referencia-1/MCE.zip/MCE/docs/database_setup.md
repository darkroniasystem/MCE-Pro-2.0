# Configuración de PostgreSQL

MCE separa dos conexiones. `MCE_TEST_DATABASE_URL` apunta exclusivamente a
`mce_test`; `MCE_DATABASE_URL` apunta exclusivamente al catálogo maestro `mce`.
`.env.example` solo contiene marcadores y nunca credenciales reales.

```powershell
$env:MCE_DATABASE_URL=[Environment]::GetEnvironmentVariable('MCE_DATABASE_URL','User')
alembic upgrade head
```

Alembic administra el esquema de pruebas; `Base.metadata.create_all()` queda
limitado a pruebas aisladas. Las pruebas PostgreSQL usan `MCE_TEST_DATABASE_URL` y
una base identificada inequívocamente como prueba. Nunca se crea ni elimina
automáticamente una base desconocida.

## Pruebas PostgreSQL

La Fase 4 fue verificada sobre la base exclusiva `mce_test`. Las fixtures
rechazan cualquier nombre diferente, limpian solamente las tablas migradas y no
eliminan la base. La URL permanece en `MCE_TEST_DATABASE_URL`; no se guarda ni
se imprime la contraseña. SQLite continúa como prueba rápida aislada, no como
sustituto de PostgreSQL.

Las migraciones `0002` y `0003` añaden persistencia normalizada de la Fase 10 y
permiten que bancos distintos referencien una misma identidad externa sin mezclar
sus catálogos. Las pruebas solo escriben si `MCE_TEST_DATABASE_URL` apunta
exactamente a PostgreSQL `mce_test`. El runtime normal prefiere
`MCE_DATABASE_URL` cuando apunta exactamente a `mce` y rechaza cualquier nombre
ambiguo o administrativo.

## Backup y restauración

Los asistentes de la Fase 11 invocan `pg_dump` y `pg_restore` sin guardar ni
mostrar contraseñas. Los destinos simbólicos se rechazan y el directorio sugerido
es `%LOCALAPPDATA%\MCE Desktop\backups`. Toda restauración debe validarse primero
y requiere confirmación explícita. `mce_test` está permitida para ensayos;
restaurar `mce` exige además la autorización explícita `allow_master=True`.
El procedimiento completo está en `docs/backup_restore.md`.
