# Contrato de entrada de MediaScan Local

## Propósito y estado

Este documento define el límite de entrada de MCE. La Fase 2 lo contrastó con
un archivo real MSL 2.2 y materializó un validador ejecutable en memoria.

MCE acepta únicamente un objeto JSON UTF-8. El archivo recibido se conserva byte
por byte antes de cualquier transformación. Nunca se reescribe ni se reemplaza.

## Versiones

- `schema_version` pertenece a MSL, no a MCE. Su ausencia se trata como legado y
  requiere una política explícita.
- MCE mantiene una lista explícita de versiones compatibles.
- Las versiones compatibles iniciales son 1.0 y 2.2.
- Cada versión compatible se resuelve mediante un adaptador registrado antes de
  normalizar: `MslSchema10Adapter` o `MslSchema22Adapter`.
- El formato sin versión usa `LegacyMslSchemaAdapter` únicamente cuando
  `allow_legacy` está habilitado.
- Una versión mayor desconocida se rechaza con `MCE-IMP-002`.
- Una versión desconocida, futura o malformada nunca se deriva hacia el
  adaptador más cercano.
- Campos adicionales de una versión compatible se conservan y no deben causar
  pérdida de datos; su interpretación requiere soporte explícito.

## Encabezado requerido

La entrada debe proporcionar, con los nombres definidos por el esquema MSL
vigente:

- versión del esquema y versión de la aplicación emisora;
- identificador único del escaneo;
- identidad estable del banco;
- identidad estable de la instalación que produjo el escaneo;
- fecha y hora del escaneo con zona horaria;
- alcance `full` o `partial`;
- una o más fuentes incluidas en el alcance;
- colección de registros de archivos encontrados.

Los nombres de campo definitivos y sus tipos se fijarán contra el JSON Schema de
MSL durante la Fase 2. MCE no deducirá identidades ausentes a partir de nombres,
rutas o equipos.

## Registros físicos mínimos

Cada archivo deberá estar asociado a una fuente y exponer suficiente evidencia
técnica para identificar el registro sin leer ni modificar el medio: ruta,
nombre, extensión, tamaño y marcas temporales disponibles. Los campos opcionales
se distinguen de valores vacíos; `null`, ausencia y cadena vacía no se equiparan
automáticamente.

MCE distingue siempre la obra lógica del archivo físico. Varios registros pueden
representar copias, versiones o episodios relacionados sin crear una obra nueva
por cada archivo.

## Reglas de validación

1. El archivo debe existir, ser legible, JSON válido y tener un objeto raíz.
2. Identificadores, versión, alcance y colecciones requeridas deben estar.
3. Identificadores estables no se regeneran silenciosamente.
4. Rutas se tratan como datos no confiables y nunca se ejecutan.
5. Un escaneo parcial solo informa sobre sus fuentes y rutas declaradas.
6. Un error bloqueante no crea una importación parcialmente aprobada.
7. Los errores incluyen ubicación del campo sin exponer secretos.

## Idempotencia e integridad

La huella SHA-256 del JSON original y el identificador del escaneo permiten
detectar reimportaciones. Se calcula por bloques y no implica calcular hashes
del contenido multimedia.

## Evolución y evidencia pendiente

Las pruebas incluyen fixtures anonimizadas para:

- un escaneo completo válido;
- un escaneo parcial válido;
- un archivo corrupto;
- una versión incompatible;
- casos con rutas largas y caracteres Unicode.

Cualquier diferencia entre esta especificación y el esquema oficial de MSL se
resolverá mediante una modificación documentada del contrato y pruebas de
compatibilidad, nunca mediante tolerancia silenciosa.
