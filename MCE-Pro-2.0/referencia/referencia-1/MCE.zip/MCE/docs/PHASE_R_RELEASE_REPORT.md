# Informe de Fase R: release

Fecha: 2026-08-20

## Resultado

Se construyó una nueva distribución candidata PyInstaller `onedir` y se verificó
el ejecutable real en un entorno local aislado. La Fase R queda completada para
la entrega candidata local; la calificación comercial en una PC limpia continúa
pendiente.

## IMPLEMENTADO

- Distribución completa en `dist\MCE` mediante `build_release.ps1` y `MCE.spec`.
- Inclusión de la aplicación, migraciones, configuración pública, Playwright y
  los módulos de Groq y PostgreSQL requeridos en ejecución.
- Exclusión de navegadores, Ollama, modelos Qwen y secretos del paquete.
- Documentación de instalación y diagnóstico para Browser, Ollama/Qwen y cuotas.
- Orden de ejemplo alineado con la optimización vigente: Exa 10, Serper 20,
  Tavily 30 y Browser como último recurso configurable.

## PROBADO CON MOCK

- 198 pruebas focalizadas cubrieron importación, agrupamiento por obra lógica,
  enriquecimiento, checkpoints y reanudación, validación, revisión humana,
  cadena Qwen/Groq, identidad canónica y controles de publicación.
- La regresión local completa, excluyendo proveedores reales y PostgreSQL,
  aprobó 559 pruebas en 230.80 segundos.
- Ruff, mypy sobre 171 archivos fuente y `compileall` terminaron sin incidencias.

## PROBADO REALMENTE

- `dist\MCE\MCE.exe` arrancó como aplicación compilada y mostró la ventana real
  con las cinco etapas del flujo. La interfaz respondió mediante su árbol de
  accesibilidad.
- El arranque usó un directorio de datos aislado, una URL SQLite deliberadamente
  rechazada por la política de producción y credenciales externas vacías. No
  abrió conexiones de red ni cargó sesiones reales.
- La suite PostgreSQL aprobó 34 de 34 pruebas sobre la base exacta `mce_test`, ya
  migrada de la revisión 0020 a la 0022. Cubrió conexión, importación,
  persistencia, reanudación, multibanco, revisión, publicación atómica, rollback
  y aislamiento.
- Al finalizar, `processing_sessions`, `processing_jobs`,
  `processing_session_items`, `catalog_publications`,
  `catalog_publication_entries` y `ai_review_runs` quedaron en cero en
  `mce_test`.
- El catálogo maestro `mce` no se conectó, migró, truncó ni modificó. Las siete
  sesiones existentes quedaron fuera de las pruebas.

## Artefacto

- Ejecutable: `dist\MCE\MCE.exe`.
- Tamaño del ejecutable: 15.000.333 bytes.
- Tamaño total de la distribución: 263.396.748 bytes en 1.023 archivos.
- SHA-256: `86B85A6BCC18B3D94C3C04B642CDE6E42ABFA0341369D8B3EB0006E70D52D0A0`.
- Fecha local de construcción: 2026-08-20 02:31:47.

La inspección recursiva no encontró valores reales de las credenciales
configuradas ni de `MCE_DATABASE_URL`. Los nombres relacionados con Chrome que
aparecen dentro de Playwright son scripts auxiliares de instalación; no existe
un binario `chrome.exe` o `chromium.exe` empaquetado.

## PENDIENTE DE PERMISO

No se ejecutó la distribución contra PostgreSQL productivo ni se publicó el
catálogo real, porque el alcance prohíbe modificarlo durante las pruebas. Esa
acción requiere una autorización operativa separada y un procedimiento de
backup/rollback.

## Pendiente de entorno/manual

- Copiar la carpeta `dist\MCE` a una PC limpia sin Python y comprobar inicio,
  navegación y cierre.
- Repetir esa comprobación específicamente en Windows 11.
- Confirmar visualmente la página completa de Configuración. La captura directa
  de la ventana local falló por una incompatibilidad de la API de captura de
  Windows; el arranque y el contenido accesible sí quedaron comprobados.

Estos pendientes no invalidan la compilación candidata, pero impiden llamarla
todavía distribución comercial verificada en una PC limpia.

## Incidencias encontradas y resueltas

1. Una primera ejecución de PyInstaller terminó por un fallo transitorio del
   subproceso que inspeccionaba `sqlite3`; la repetición limpia construyó la
   distribución correctamente.
2. `mce_test` estaba en la revisión 0020 y no contenía `ai_review_runs`. Se
   verificó explícitamente el nombre de la base, se migró solo `mce_test` a 0022
   y las 34 integraciones aprobaron.
3. Pytest no pudo limpiar una carpeta temporal del proyecto después de una
   prueba que endurece permisos. La suite se repitió en un temporal aislado de
   Windows y aprobó completa.
4. `.env.example` conservaba prioridades web antiguas. Se alineó con el orden
   validado de Fase P.

## Límite de fase

Fase R finalizada. No se inicia ninguna fase posterior sin autorización expresa.
