# Validación de JSON reales mediante la interfaz — 2026-07-31

## Alcance

Los siete archivos fueron seleccionados manualmente mediante **Seleccionar JSON**
y el selector real de Windows. MCE no recorrió automáticamente `samples`, no se
configuró esa ruta como origen y no se usó una importación directa desde código.

Todos los archivos tenían esquema 2.2, pertenecían al mismo `bank_id` declarado
por MSL (`bank_dccd7b23723d1533`) y eran escaneos parciales con
`actualiza_disponibilidad=false`.

## Resultados

| Categoría | Tamaño (bytes) | `scan_id` | Fuentes | Videos | Subtítulos | Avisos UI | Errores UI | Validación | Memoria observada |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|
| doramas | 9.784.799 | `scan_9da530ab306ee330` | 1 | 5.253 | 862 | 863 | 0 | 1,586 s | 1.184 MiB |
| animado | 16.470.576 | `scan_77113450b49ae870` | 1 | 9.116 | 465 | 466 | 0 | 1,391 s | 1.196 MiB |
| combos | 18.877.737 | `scan_6c81d15c383cc5d4` | 2 | 10.291 | 698 | 699 | 0 | 2,275 s | 1.204 MiB |
| concursos | 17.806.388 | `scan_c894d252e29e2065` | 2 | 14.399 | 153 | 154 | 0 | 1,952 s | 1.213 MiB |
| peliculas | 43.489.478 | `scan_86c8f2ecf3163df3` | 7 | 29.570 | 8.002 | 8.003 | 0 | 5,576 s | 1.265 MiB |
| novelas | 145.908.102 | `scan_cf51c8ae7e225c80` | 6 | 112.853 | 683 | 684 | 0 | 34,544 s | 1.376 MiB |
| serie | 158.395.260 | `scan_1484be2cc691a866` | 8 | 110.573 | 21.771 | 21.772 | 0 | 41,483 s | 1.476 MiB |

Los errores declarados por MSL se trataron como incidencias no bloqueantes. Las
validaciones terminaron como `completed_with_warnings` y la ventana respondió al
final de cada operación. Los SHA-256 calculados antes y después coincidieron para
los siete originales.

## Sesiones y checkpoints

| Categoría | Sesión | Elementos | Checkpoint (bytes) |
|---|---|---:|---:|
| doramas | `c5b2a877-5538-4496-b7f6-072f73ac978a` | 6.115 | 8.667.760 |
| animado | `7119d08d-bbc1-4263-acfe-70593b561dc6` | 9.581 | 14.157.984 |
| combos | `35049c2f-b3b9-42c2-8934-5fa7d22c90f6` | 10.989 | 15.848.245 |
| concursos | `57b0d205-bdfb-4a1b-b366-8ff6e3b2afc6` | 14.552 | 20.845.515 |
| peliculas | `dbf2a629-1d4d-4ce7-af7e-6a8f0960d2db` | 37.572 | 54.042.508 |
| novelas | `94162a01-c7cf-41d4-b52b-d102ef799247` | 113.536 | 164.467.194 |
| serie | `c95f41dd-abaa-4b6c-bf89-ad36e42acbd4` | 132.344 | 191.031.464 |

Las siete sesiones quedaron `ready`. La reimportación de `doramas` y `serie`
produjo `duplicate`, deshabilitó **Crear sesión** y no creó sesiones adicionales.
La interfaz oficial usa selección de un solo archivo; no se probó selección
múltiple.

## Defectos confirmados

1. **Identidad del banco:** el `bank_id` estable de MSL se rechaza por no ser UUID.
   Cada importación genera un UUID interno diferente, por lo que siete escaneos
   del mismo banco quedan con siete identidades internas distintas.
2. **Persistencia PostgreSQL:** después de crear las siete sesiones, ninguna
   apareció en `processing_sessions`; tampoco se crearon sus bancos o
   importaciones durante este flujo. El estado quedó únicamente en memoria y
   checkpoints locales.
3. **Memoria:** los inventarios grandes superaron el objetivo documentado de
   1 GiB. Tras la última sesión el proceso alcanzó aproximadamente 1.504 MiB
   residentes y 1.467 MiB privados.
4. **Logs insuficientes:** registran nombre genérico, esquema, cantidad y estado,
   pero no `scan_id`, `bank_id`, hash, sesión ni causa final explícita para todos
   los intentos duplicados.

## Conclusión

La selección, validación, conservación del original, creación de checkpoints y
detección de duplicados funcionan desde la interfaz. La Fase 1 no puede
declararse completa ni MCE estable mientras persistan los defectos de identidad,
PostgreSQL, memoria y auditabilidad descritos arriba.

No se eliminaron `samples`, `build`, `dist` ni las cachés finales.

## Continuación correctiva

Estado al cierre de la primera iteración de correcciones:

- El `bank_id` externo se mapea de forma determinista a un UUID5 interno.
- La migración `0009` añade `banks.external_bank_id` con índice único.
- La resolución PostgreSQL usa `ON CONFLICT DO NOTHING`, por lo que dos
  importaciones concurrentes convergen en el mismo banco.
- El repositorio local de sesiones dejó de retener simultáneamente todos los
  árboles de archivos: conserva índices pequeños y carga checkpoints bajo
  demanda. La vista de sesiones también itera de forma perezosa.
- Cada importación abre una correlación propia y registra eventos estructurados,
  duración total, duración de etapas, estado, cantidades y memoria RSS.
- Verificación: `312 passed, 5 deselected`; suite PostgreSQL autorizada:
  `8 passed`.

Pendiente antes de repetir los siete JSON:

- convertir PostgreSQL en autoridad efectiva de sesiones, trabajos y
  checkpoints (los checkpoints JSON todavía son la autoridad);
- añadir y ejecutar la consolidación explícita de identidades históricas;
- reiniciar MCE con el código corregido y repetir la medición desde la interfaz.

Por estas pendientes, la Fase 1 continúa abierta.

## Persistencia PostgreSQL y cobertura restaurada

La cifra anterior de 13 pruebas correspondía a toda la carpeta
`tests/integration/postgresql` antes de añadir las correcciones:

- `test_phase4_postgresql.py`: conexión/esquema/índices/FK; roundtrip de bancos;
  rollback; restricciones únicas/FK; aislamiento y hash duplicado; alcance
  parcial; reversión controlada.
- `test_phase10_metadata.py`: metadatos idempotentes y aislados; rollback de
  metadatos; persistencia del grafo aprobado.
- `test_phase11_operations.py`: auditoría/reversión; rollback de reversión;
  contrato estable de la vista para bot.

El resultado de 8 pruebas fue una ejecución limitada explícitamente a
`test_phase4_postgresql.py`. No hubo archivos eliminados, renombrados o
sustituidos, ni un marcador pytest que excluyera los cinco casos restantes.
El filtro global continúa siendo `-m 'not live_providers'`; los casos PostgreSQL
no usan el marcador `live_providers`.

La ejecución actual de la carpeta completa contiene 18 pruebas:

- las 13 anteriores;
- identidad externa estable y única;
- sesión/job/checkpoint recuperados desde una instancia nueva;
- duplicado detectado desde PostgreSQL tras reiniciar;
- consolidación histórica con referencias conservadas;
- rollback completo de una consolidación fallida.

Resultado actual: `18 passed` en PostgreSQL real y `316 passed, 5 deselected`
en la regresión general.

### Ledger `0010`

La migración `0010` amplía `processing_sessions` y `processing_jobs`, y crea
`processing_checkpoints` y `bank_consolidations`. En la ejecución de escritorio,
PostgreSQL se selecciona explícitamente como autoridad; los checkpoints JSON
quedan como caché secundaria y no se usan para reconstruir sesiones cuando el
ledger está disponible.

La migración `0011` extrae cada elemento a `processing_session_items`. Los jobs
guardan solamente la referencia al formato de almacenamiento; los estados se
insertan y actualizan en lotes de 500. La pantalla inicial consulta
exclusivamente los contadores de sesión/job. Ya no materializa todos los
inventarios para construir la tabla ni el panel de enriquecimiento.

La creación confirmada escribe transaccionalmente banco, instalación, fuentes,
escaneo, importación, sesión, job y archivos físicos. Las transiciones actualizan
sesión y job y crean checkpoints con checksum. Al iniciar, un job que permanecía
`running` se marca `interrupted`, su sesión pasa a `paused` y queda
`recoverable=true`. Los detalles se reconstruyen bajo demanda desde el payload
del job; la lista solo conserva identificadores.

La detección por SHA-256 consulta `scan_imports` en PostgreSQL, por lo que
persiste entre procesos.

### Consolidación histórica

`BankConsolidationService` exige:

- dry-run previo;
- elección determinista por `created_at` y después UUID;
- prioridad del UUID estable calculado para `external_bank_id` cuando ya existe,
  y solo después antigüedad/UUID para legados que aún no tengan esa identidad;
- referencia obligatoria a backup o punto de restauración;
- bloqueo `FOR UPDATE`;
- nueva comprobación de identidad y conflictos dentro de la transacción;
- reasignación de claves foráneas directas;
- eventos de auditoría por tabla;
- baja lógica de identidades fusionadas;
- registro en `bank_consolidations`;
- rollback total ante cualquier fallo.

Los conflictos de instalaciones con el mismo `machine_identifier` se reportan
como no fusionables automáticamente y bloquean la ejecución.

### Pendientes de validación manual

Todavía falta cerrar completamente MCE, abrir la versión corregida y repetir los
siete JSON mediante el selector oficial. Hasta completar esa prueba no existen
mediciones posteriores a `0010` de memoria por JSON, recuperación visual ni
duplicados visuales tras reinicio.

Por ello:

- Fase 1: **en progreso**.
- Estabilidad: **no aprobada**.

El primer arranque de la versión fuente con `0011` mostró aproximadamente
160 MiB RSS y 119 MiB privados antes de seleccionar un JSON. PostgreSQL estaba
disponible y la interfaz mostró cero sesiones activas sin cargar el inventario
histórico local. La base contenía un banco legado (`TROCADERO363`) sin
`external_bank_id` y una sesión antigua sin job; no se modificaron porque aún
falta correlacionarlos mediante el dry-run después de la primera importación
real.

### Primera tentativa manual posterior a `0011`

La primera selección de `doramas` validó 6.116 registros en 930 ms, con 863
advertencias y cero errores. No creó sesión ni job en PostgreSQL: una segunda
validación dentro del mismo proceso devolvió `duplicate` porque
`PostgresImportRegistry.add_hash()` conservaba el hash antes de que el usuario
confirmara **Crear sesión**. Esta tentativa se registra como fallo de orden
transaccional, no como importación completada.

Se corrigió el contrato: el registro PostgreSQL ignora `add_hash()` durante la
mera validación y considera un hash confirmado únicamente cuando `seed()` ha
insertado `scan_imports` junto con la sesión y el job.

### Doramas confirmado con el ledger corregido

La validación definitiva se realizó en la versión fuente, no en el ejecutable
obsoleto de `dist`:

- tamaño: 9.784.799 bytes;
- registros declarados por el pipeline: 6.116;
- elementos persistidos: 6.115;
- videos: 5.253;
- subtítulos: 862;
- advertencias: 863;
- errores: 0;
- duración de validación: 1.038 s;
- hash: `08eefad282c1c247b74b09bcbf73087e3068f71e7e161b3d91a3dbde69fa29aa`;
- `scan_id` MSL: `scan_9da530ab306ee330`;
- sesión: `9bd9c3b4-d9f9-4d1a-8fc0-430e014cbf5b`;
- job: `20b75b85-b404-5b92-bd83-dda240ecc60d`;
- banco externo: `bank_dccd7b23723d1533`;
- UUID interno: `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- estado: `ready`, etapa `imported`;
- memoria: ~158 MiB al arrancar, ~183 MiB antes de validar,
  ~205 MiB máxima observada y ~207 MiB después de crear la sesión.

PostgreSQL contiene 6.115 `physical_files` y 6.115
`processing_session_items`. No existe checkpoint todavía porque el trabajo no
ha iniciado **Preparar local**; esto es coherente con el estado `ready`.

### Consolidación histórica ejecutada

El dry-run propuso el UUID estable como canónico y encontró 581 referencias:
1 instalación, 1 importación, 193 contenidos y 386 alias; no detectó conflictos.

Antes de modificar datos se creó y verificó el respaldo:

`backups/mce-before-bank-consolidation-20260731-041758.dump`

Es un archivo custom de PostgreSQL 18.4 con 216 entradas de catálogo. La
consolidación `4e6c2a8f-3352-4031-a6e5-4766b648996e` reasignó las 581
referencias, produjo cuatro eventos de auditoría y dejó cero referencias al
UUID legado. `TROCADERO363` quedó archivado lógicamente; no se eliminó.

### Primera tentativa de animado

Animado validó 9.582 registros, 466 advertencias y cero errores en 1,428 s.
La creación se ejecutó en `TaskRunnable`, pero la interfaz pareció congelada
mientras Python preparaba los lotes. La transacción hizo rollback y no dejó
sesión, job, checkpoint ni elementos parciales.

El reintento mostró `the import package already has a session`: la sesión
provisional había quedado en `_pending` pese al rollback. Además, las identidades
externas de instalación y fuente aún se convertían a UUID aleatorio, lo que
podía chocar con las restricciones después de consolidar.

Correcciones:

- UUID5 determinista para toda identidad externa no UUID;
- resolución de instalación por `(bank_id, machine_identifier)`;
- resolución de fuente por `(installation_id, normalized_root_path)`;
- descarte explícito de `_pending` cuando `seed()` falla;
- almacenamiento de los IDs realmente resueltos en cada elemento.

La regresión dirigida posterior aprobó 16 pruebas, además de Ruff y mypy.

### Animado confirmado después de la corrección

- tamaño: 16.470.576 bytes;
- registros: 9.582;
- elementos persistidos: 9.581;
- advertencias: 466;
- errores: 0;
- duración: 1,647 s;
- sesión: `6a68e8b5-201a-4a41-ae2a-5e3055c686da`;
- job: `fe145dea-0d8a-5267-913d-11365323a8bc`;
- `scan_id` MSL: `scan_77113450b49ae870`;
- hash: `c305100a99ebc269a4f90066623669d5619b7535623da5000ba9380c1576f5bb`;
- UUID interno: `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- estado/etapa: `ready` / `imported`;
- memoria: ~159 MiB al reiniciar, ~184 MiB antes de validar,
  ~218 MiB máxima durante validación y ~220 MiB después de crear.

PostgreSQL contiene dos sesiones y dos jobs, 15.696 elementos y archivos, un
solo `bank_id` y cero checkpoints, coherente con trabajos todavía no iniciados.

### Combos confirmado desde la interfaz

La tercera selección individual se realizó con el selector oficial de Windows.
La interfaz permaneció operativa, terminó sin tareas activas y mostró la nueva
fila en estado `ready`, etapa `imported`, con 10.989 elementos y cero errores.

- archivo: `media_scan.json` de `combos`;
- tamaño: 18.877.737 bytes;
- `schema_version`: `2.2`;
- registros validados: 10.991;
- videos declarados: 10.291;
- subtítulos asociados e importados: 698;
- fuentes: 2;
- advertencias: 699;
- errores de importación: 0;
- errores declarados por MSL tratados sin fallo fatal: 19;
- duración de validación: 1,837 s;
- hash antes/después:
  `c4ee81b69eb2cfa45ed3137b5dc8f41f2183ded59a66b31d75d35ad124a517fd`;
- `scan_id` MSL: `scan_6c81d15c383cc5d4`;
- UUID interno del scan: `8bc5ca70-3b58-534f-9367-e788c9e6a722`;
- sesión: `57d620a3-dab1-47cc-90a7-07fa5f2d35db`;
- job: `74f112f0-1a87-5c93-b771-1ae593bca966`;
- UUID de banco:
  `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- memoria del proceso: 215,6 MiB al iniciar la validación, máximo registrado
  durante la validación 227,9 MiB, 224,7 MiB después de crear la sesión; el
  pico de vida del proceso era 329,9 MiB.

PostgreSQL contiene exactamente 10.989 `processing_session_items` y 10.989
`physical_files` para este scan, dos fuentes y cero checkpoints. Las tres
sesiones creadas con el ledger nuevo comparten un único `bank_id`. La cuarta
fila global de `processing_sessions` es la sesión histórica del 25 de julio,
anterior al ledger nuevo: no tiene job, scan enlazado ni elementos propios. No
es residuo de las pruebas actuales y se conserva como dato legado auditable.

### Concursos confirmado desde la interfaz

La cuarta selección individual terminó con la interfaz operativa y sin tareas
activas. La tabla mostró la sesión en `ready`, etapa `imported`, 14.552
elementos y cero errores.

- archivo: `media_scan.json` de `concursos`;
- tamaño: 17.806.388 bytes;
- `schema_version`: `2.2`;
- registros validados: 14.554;
- videos declarados e importados: 14.399;
- subtítulos asociados e importados: 153;
- subtítulos detectados por MSL, incluidos los no asociados: 166;
- fuentes: 2;
- advertencias: 154;
- errores de importación: 0;
- errores declarados por MSL tratados como no fatales: 6;
- duración de validación: 2,489 s;
- hash antes/después:
  `c19285b3e9fa79bf1f9d0f990e644cf58580a5c1c080f99aad5aefab8f97bc13`;
- `scan_id` MSL: `scan_c894d252e29e2065`;
- UUID interno del scan: `a05cfd9b-e587-50b3-9160-69e8f4625024`;
- sesión: `38e8b15c-385e-4431-a75c-105999fcc529`;
- job: `4159833f-1e6f-5617-a181-ca291617d7ea`;
- UUID de banco:
  `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- memoria: 225,2 MiB al iniciar, 228,4 MiB al terminar la validación y
  231,7 MiB después de crear la sesión; pico de vida del proceso 394,9 MiB.

PostgreSQL contiene 14.552 filas tanto en `processing_session_items` como en
`physical_files` para este scan, dos fuentes y cero checkpoints. El acumulado
del ledger nuevo es cuatro sesiones, cuatro jobs, 41.237 elementos y un solo
`bank_id`.

### Películas confirmado desde la interfaz

La quinta selección individual finalizó sin bloqueo de la interfaz. MCE volvió
a mostrar «Sin tareas activas» y añadió una fila `ready` / `imported` con
37.572 elementos y cero errores.

- archivo: `media_scan.json` de `peliculas`;
- tamaño: 43.489.478 bytes;
- `schema_version`: `2.2`;
- registros validados: 37.579;
- videos declarados e importados: 29.570;
- subtítulos asociados e importados: 8.002;
- subtítulos detectados por MSL, incluidos los no asociados: 15.754;
- fuentes: 7;
- advertencias: 8.003;
- errores de importación: 0;
- errores declarados por MSL tratados como no fatales: 25;
- duración de validación: 5,935 s;
- hash antes/después:
  `df1c9e4eb6ee2cd0e680899130397c040db8a55f3c4f1aa394d8719ec9c57d57`;
- `scan_id` MSL: `scan_86c8f2ecf3163df3`;
- UUID interno del scan: `61fb41a0-a455-5356-9927-6518d16ef4f0`;
- sesión: `168aca08-271a-4c0c-aa53-3bc672d295b8`;
- job: `af795d06-324a-5e6f-84d9-24dd87ba79f9`;
- UUID de banco:
  `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- memoria: 233,0 MiB al iniciar, 291,3 MiB al terminar la validación y
  294,9 MiB después de crear la sesión; pico de vida del proceso 652,5 MiB.

PostgreSQL contiene exactamente 37.572 `processing_session_items` y 37.572
`physical_files` para este scan, siete fuentes y cero checkpoints. El acumulado
del ledger nuevo es cinco sesiones, cinco jobs y 78.809 elementos, todos
aislados bajo el mismo `bank_id`.

### Novelas confirmado desde la interfaz

La sexta selección individual, de 145,9 MB, terminó y la interfaz recuperó
«Sin tareas activas». La tabla mostró la sesión `ready` / `imported`, con
113.536 elementos y cero errores. La creación del ledger tardó
aproximadamente 80 segundos después de la validación, pero se ejecutó fuera del
hilo de interfaz y no dejó una sesión parcial.

- archivo: `media_scan.json` de `novelas`;
- tamaño: 145.908.102 bytes;
- `schema_version`: `2.2`;
- registros validados: 113.542;
- videos declarados e importados: 112.853;
- subtítulos asociados e importados: 683;
- subtítulos detectados por MSL, incluidos los no asociados: 701;
- fuentes: 6;
- advertencias: 684;
- errores de importación: 0;
- errores declarados por MSL tratados como no fatales: 14;
- duración de validación: 37,925 s;
- hash antes/después:
  `466b73d78fc960c742a9927320a8177f1952aa0aafba3bf4d591c5d616c6f190`;
- `scan_id` MSL: `scan_cf51c8ae7e225c80`;
- UUID interno del scan: `a5afbafa-dbff-5885-99eb-a2c3c0d23fda`;
- sesión: `c1a15419-c5bc-489d-9513-789b5bccdd50`;
- job: `bfcd8514-087f-5bed-a2f9-9e88bc65b8aa`;
- UUID de banco:
  `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- memoria: 256,0 MiB al iniciar, 411,7 MiB al terminar la validación y
  429,0 MiB después de crear la sesión; pico de vida del proceso 1.206,9 MiB.

PostgreSQL contiene exactamente 113.536 `processing_session_items` y 113.536
`physical_files` para este scan, seis fuentes y cero checkpoints. El acumulado
del ledger nuevo es seis sesiones, seis jobs y 192.345 elementos, con un único
`bank_id`.

### Serie confirmado desde la interfaz

La séptima selección individual, de 158,4 MB, terminó y la interfaz recuperó
«Sin tareas activas». La tabla mostró la sesión `ready` / `imported`, con
132.344 elementos y cero errores. La creación transaccional del ledger tardó
aproximadamente 87,5 segundos después de validar.

- archivo: `media_scan.json` de `serie`;
- tamaño: 158.395.260 bytes;
- `schema_version`: `2.2`;
- registros validados: 132.352;
- videos declarados e importados: 110.573;
- subtítulos asociados e importados: 21.771;
- subtítulos detectados por MSL, incluidos los no asociados: 23.309;
- fuentes: 8;
- advertencias: 21.772;
- errores de importación: 0;
- errores declarados por MSL tratados como no fatales: 17;
- duración de validación: 37,744 s;
- hash antes/después:
  `650d119c2ae6bc1c31a55e239868d6a8308216da99fb2a89ee91a0f67760343b`;
- `scan_id` MSL: `scan_1484be2cc691a866`;
- UUID interno del scan: `fe93915b-cbf6-5f9e-98e2-538241490abe`;
- sesión: `5c363977-033b-4fc3-bcab-061f44337a6c`;
- job: `106e2eab-8a65-510c-8771-065748d67abc`;
- UUID de banco:
  `7676eca2-6aa2-5d08-83d9-762e9bc9fd13`;
- memoria: 280,2 MiB al iniciar, 460,3 MiB al terminar la validación y
  465,1 MiB después de crear la sesión; pico de vida del proceso 1.325,2 MiB.

PostgreSQL contiene exactamente 132.344 `processing_session_items` y 132.344
`physical_files` para este scan, ocho fuentes y cero checkpoints. El acumulado
del ledger nuevo es siete sesiones, siete jobs y 324.689 elementos/archivos,
todos bajo un único `bank_id`.

Los siete JSON reales quedaron procesados individualmente mediante el botón y
el selector oficial. La implementación usa `QFileDialog.getOpenFileName`, no
`getOpenFileNames`; por tanto, la selección múltiple no es una función oficial
de esta interfaz y no corresponde ejecutar esa variante.

### Reimportación duplicada confirmada

Se volvió a seleccionar `doramas/media_scan.json` mediante la interfaz después
de completar las siete sesiones. MCE respondió en 319 ms con estado
`duplicate`, una incidencia `DUPLICATE_IMPORT`, cero archivos y el botón
**Crear sesión** deshabilitado. La interfaz permaneció operativa.

El hash detectado fue nuevamente
`08eefad282c1c247b74b09bcbf73087e3068f71e7e161b3d91a3dbde69fa29aa`.
PostgreSQL conservó exactamente siete sesiones del ledger, siete jobs, 324.689
elementos/archivos y una sola importación confirmada para ese hash. No se creó
scan, job, sesión ni checkpoint adicional. La memoria bajó a 293,3 MiB después
del rechazo; el pico de vida no cambió.

### Persistencia verificada después de reiniciar

Un primer intento de reinicio abrió por error `dist/MCE/MCE.exe`, compilación
anterior a las correcciones. Esa versión mostró nueve filas reconstruidas desde
datos legados: ocho importadas, una cancelada y un duplicado aparente de 6.115
elementos. PostgreSQL permaneció intacto; no se borró ni modificó ninguna fila.

Después de cerrar esa compilación y ejecutar el entry point de la versión
fuente, MCE mostró exactamente las siete sesiones autoritativas. Los IDs,
estados, elementos, advertencias y errores visibles coinciden con PostgreSQL;
no aparece la cancelada histórica ni el duplicado aparente. La interfaz estaba
operativa, sin tareas activas, y el proceso consumía 160,6 MiB tras el arranque.

Esto confirma persistencia real y carga resumida desde PostgreSQL para la
versión corregida. También confirma que el `dist` actual está obsoleto y no
puede considerarse distribución final válida.

## Reconstrucción y validación de la distribución

### Preparación y compilación limpia

El `dist` anterior era obsoleto porque se había generado antes del ledger
PostgreSQL autoritativo y reconstruía filas desde datos legados. Antes de
recompilar se confirmó:

- migraciones `0010` y `0011` presentes;
- `MCE.spec` en modo `onedir`;
- cinco configuraciones públicas explícitas;
- migraciones y assets activos incluidos;
- `samples`, JSON reales, bases, logs, cachés y secretos fuera del spec.

Se retiró del spec la inclusión completa de `docs`, porque el informe de
validación contiene deliberadamente la ruta temporal de `samples`. Se añadió
un evento de arranque con versión y marca `compiled` para distinguir el EXE.
Se cerró MCE fuente y se eliminaron únicamente `build` y `dist` obsoletos.
`samples`, pruebas, logs, base, informes y evidencias se conservaron.

`build_release.ps1 -SkipInstall` fue bloqueado por la política de ejecución de
PowerShell. Se ejecutó directamente su comando de compilación equivalente:

```powershell
.\.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm MCE.spec
```

Datos de compilación:

- fecha/hora: 2026-07-31 05:07:57 -04:00;
- versión MCE: `0.12.0`;
- Python: `3.12.10`;
- PyInstaller: `6.21.0`;
- spec: `MCE.spec`;
- estado Git: no existe metadata de repositorio en este checkout;
- hash del manifiesto fuente:
  `066155a0c70397dc8851330b1d96e8ce5a034f42df485c8580c9221876940e7a`;
- distribución: 855 archivos, 136.325.995 bytes (130,01 MiB);
- SHA-256 de `MCE.exe`:
  `1c4732761e8734f6ccae2546a87d5acd02a737cb28d7c037960c5a606893cd11`.

Las advertencias fueron imports opcionales de otros sistemas operativos o
drivers no usados (`pwd`, `grp`, `fcntl`, drivers SQL distintos de psycopg,
etc.). PySide6, psycopg binario, SQLAlchemy y Alembic quedaron resueltos.

### Inspección inicial de `dist`

La carpeta completa contiene las migraciones `0001` a `0011`, `alembic.ini`,
el asset activo y exactamente las cinco configuraciones públicas. No contiene
carpeta `samples`, `media_scan.json`, fixtures, `.env`, bases de prueba, logs,
cachés, checkpoints ni `identity.json`. Tampoco contiene la ruta absoluta de
`samples\msl`. Los proveedores activos se documentan en README.

### Primer arranque del EXE nuevo

Se inició únicamente `dist\MCE\MCE.exe`. Abrió correctamente, mostró
PostgreSQL configurado, siete sesiones pendientes y cero errores recientes.
PostgreSQL reportó Alembic `0011` y exactamente los siete IDs reales. El log
registró:

`event=application_started version=0.12.0 compiled=True executable=MCE.exe`

El proceso estaba respondiendo con 140,2 MiB RSS iniciales, cercano a los
160,6 MiB de la versión fuente.

### Duplicado y reinicio del EXE en `dist`

Desde el selector oficial del EXE nuevo se seleccionó manualmente el JSON de
doramas. MCE devolvió `duplicate` con `DUPLICATE_IMPORT` en 427 ms, dejó
**Crear sesión** deshabilitado y no bloqueó la interfaz. El proceso partió de
165,6 MiB, alcanzó un pico de 204,3 MiB y quedó alrededor de 173,1 MiB.

PostgreSQL conservó siete sesiones, siete jobs, 324.689 elementos/archivos, un
solo banco y una sola importación confirmada del hash de doramas. Después de
cerrar y reabrir el mismo EXE volvieron a aparecer siete sesiones,
PostgreSQL disponible y cero errores; la memoria regresó a 140,0 MiB.

### Prueba desde ubicación independiente

Se copió la carpeta `onedir` completa a `C:\MCE_RELEASE_TEST`. La copia contiene
los mismos 855 archivos, 136.325.995 bytes y el mismo SHA-256 del ejecutable:

`1c4732761e8734f6ccae2546a87d5acd02a737cb28d7c037960c5a606893cd11`

`C:\MCE_RELEASE_TEST\MCE.exe` abrió sin usar el repositorio, `build`, `.venv` ni
`samples`. Mostró PostgreSQL disponible, siete sesiones y cero errores, con
140,2 MiB iniciales. La selección manual de doramas devolvió `duplicate` en
377 ms, sin modificar PostgreSQL. Se detectaron dos instancias portátiles
abiertas simultáneamente durante la interacción manual; ambas se cerraron y se
repitió el reinicio con una sola instancia. La instancia limpia volvió a
mostrar siete sesiones y quedó respondiendo con 141,2 MiB RSS.

### Verificaciones técnicas finales posteriores al build

- suite general: 316 aprobadas, 5 excluidas, 47,35 s;
- PostgreSQL real: 18 de 18 aprobadas, 16,61 s;
- Ruff: limpio;
- mypy: limpio sobre 144 archivos fuente;
- compileall: limpio;
- pip check: sin dependencias rotas.

Una ejecución inicial en paralelo de las dos suites produjo dos fallos no
válidos por limpieza concurrente de la misma base `mce_test`. Se descartó ese
resultado y ambas suites se repitieron secuencialmente con los resultados
anteriores.

### Estado de cierre

La distribución nueva reproduce el comportamiento de la versión fuente:
exactamente siete sesiones reales, IDs y conteos autoritativos, Alembic `0011`,
un solo banco, persistencia tras reinicio, carga resumida, memoria de reposo
controlada, selector oficial, duplicado persistente y funcionamiento fuera del
repositorio. No reaparecen la sesión cancelada ni el duplicado aparente de
6.115 elementos.

- Fase 1: **completada**.
- Distribución: **validada**.
- Estabilidad de la Fase 1: **aprobada**.

`samples`, logs, pruebas, informes y evidencias se conservan conforme a la
instrucción; no se realizó la limpieza final general.

## Fase 2 — Adaptadores y validación MSL

La Fase 2 auditó el pipeline existente sin entrar en conservación/staging de
la Fase 3. El lector UTF-8, límites, SHA-256, detector, validación estructural,
validación semántica, mapper, incidencias estables y contratos 1.0/2.2 ya
estaban implementados y cubiertos por pruebas.

La brecha encontrada era arquitectónica: `MslNormalizer` diferenciaba 2.2 con
un condicional, pero no existían adaptadores explícitos por versión. Se añadió:

- `MslSchema10Adapter` para 1.0;
- `MslSchema22Adapter` para 2.2 y subtítulos anidados;
- `LegacyMslSchemaAdapter` para ausencia de versión autorizada;
- `MslSchemaAdapterRegistry` con rechazo explícito de versiones desconocidas,
  futuras o malformadas.

No se añadieron staging, copia del JSON, normalización de títulos,
clasificación, agrupación ni funciones de fases posteriores.

Validación:

- pruebas dirigidas de importadores: 47 aprobadas;
- suite general: 322 aprobadas, 5 excluidas;
- PostgreSQL: 18 de 18 aprobadas;
- Ruff: limpio;
- mypy: limpio sobre 145 archivos fuente;
- compileall: limpio;
- pip check: sin dependencias rotas;
- Alembic: `0011 (head)`;
- interfaz fuente: abrió, PostgreSQL disponible, siete sesiones resumidas y
  sin tareas activas.

- Fase 2: **completada**.
- Fase 3: **no iniciada**.
