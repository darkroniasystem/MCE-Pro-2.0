# Confianza de coincidencias

Wikidata puntúa título/alias, año, tipo e IDs externos. Un tipo incompatible se
excluye antes de puntuar y un año distinto reduce la confianza. Resultados
cercanos o insuficientes pasan a revisión; el primer resultado nunca se aprueba
solo por su posición.
