# Revisión humana

La revisión recibe candidatos ambiguos, de baja confianza, sin categoría
publicable o con proveedor principal pendiente. Conciertos, cursos y karaoke no
son categorías finales. La UI muestra motivo, confianza, proveedor, ID y títulos
alternativos sin exponer JSON crudo.

Las decisiones masivas se procesan fuera del hilo de Qt. MCE bloquea temporalmente
las acciones de la página, muestra el porcentaje, aplica la decisión masiva y
actualiza revisión, catálogo y sesiones una sola vez cuando el trabajador termina.

## Limpiar y reintentar

Una obra con `not_found_confirmed` o sin candidato estructurado no se aprueba como
si estuviera enriquecida. La acción **Limpiar y reintentar** propone automáticamente
un título mediante la preparación local, permite confirmarlo o editarlo, conserva
nombre y ruta originales, registra la corrección humana y
devuelve solamente los elementos del grupo seleccionado a
`ready_for_enrichment`. El grupo aparece en Enriquecimiento selectivo bajo la
categoría virtual **Pendientes**. Su categoría de contenido real no cambia y
continúa determinando qué proveedores se consultan. Los grupos ya consolidados
permanecen intactos.

El reintento se registra con `review_reason = pending_normalization_retry`, limpia
los resultados transitorios de proveedores y genera una consulta nueva a partir
del título corregido. La corrección queda bloqueada contra sobrescrituras
automáticas posteriores.

Cada obra conserva las huellas de las consultas ya ejecutadas. Si vuelve a
Pendientes con el mismo título, tipo, año y variante, el pipeline marca esa
consulta como agotada y continúa con la siguiente obra sin llamar otra vez a
los proveedores. Una corrección que cambie realmente la consulta produce una
huella nueva y sí puede enriquecerse.

Las categorías enriquecibles de contenido son exactamente: Películas, Series,
Novelas, Doramas, Anime, Concursos y Animados. `Combo` es un origen mixto y no una
identidad de contenido; cada obra de un combo conserva su categoría real.
