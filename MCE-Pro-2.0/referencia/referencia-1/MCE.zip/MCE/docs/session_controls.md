# Controles durables de sesiones (Fase 10)

Los procesos largos se controlan de forma cooperativa y fuera del hilo visual.
Esto incluye tanto **Preparar local** como el procesamiento posterior. La sesión se
marca `running` antes de lanzar el trabajador para que una pausa inmediata no pueda
adelantarse a la persistencia del estado. Al reanudar, la etapa guardada decide si
continúa la preparación local o el procesamiento posterior.

- **Pausar** termina el elemento o grupo activo, persiste sus resultados y escribe un
  checkpoint antes de esperar. El trabajo queda recuperable.
- **Reanudar** parte de los elementos que todavía están pendientes. Los grupos ya
  confirmados y las respuestas persistidas no vuelven a consultarse.
- **Cancelar** conserva resultados confirmados, checkpoints y caché global. Los
  elementos pendientes pasan a `cancelled`; no se eliminan archivos multimedia.
- **Borrar sesión** requiere confirmación visual y significa archivado lógico. La
  sesión desaparece de las listas activas, pero su registro, checkpoint, importación,
  catálogo y caché permanecen. Una sesión activa debe cancelarse antes.

PostgreSQL es el ledger autoritativo. Las sesiones `archived` se excluyen de
`list_ids` y `list_summaries`, aunque siguen disponibles por identificador para una
restauración explícita. En el modo local de contingencia se aplica la misma semántica
y los checkpoints archivados no reaparecen al reiniciar MCE.

La restauración devuelve una sesión completamente terminada a `completed`; cualquier
otra vuelve a `ready`, manteniendo los elementos que ya tenían resultado terminal.
