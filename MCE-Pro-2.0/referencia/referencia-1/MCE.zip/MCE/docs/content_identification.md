# Identificación de contenido y proveedores

La Fase 7 define el puerto `MetadataProvider` y un motor que puntúa candidatos
sin acoplar dominio ni casos de uso a TMDb. `FakeMetadataProvider` controla las
pruebas; `TmdbMetadataProvider` recibe credencial y transporte por inyección y
no realiza red implícita.

La puntuación registra evidencia individual: título, alias, título original,
año, tipo, país, reparto, director y duración. Los umbrales viven en
`MatchPolicy`: aceptación 75, revisión 60, rechazo 35 y distancia ambigua 5.

La caché usa una clave SHA-256 estable que incorpora proveedor, operación y
parámetros, fecha, versión y TTL. El modo offline solo devuelve caché vigente.
Los adaptadores de resiliencia ofrecen timeout visible, reintentos limitados,
espera exponencial, tratamiento de 429/5xx, cancelación y límite local de
solicitudes. Errores 4xx o respuestas inválidas no se ocultan.

La clave TMDb procede de `TMDB_API_KEY`; nunca se almacena ni registra. Esta fase
no incluye aceptación humana, enriquecimiento completo, IA, deduplicación ni
publicación del catálogo.

## Composición de escritorio

La aplicación real construye `TmdbMetadataProvider` sobre un transporte HTTPS,
reintentos acotados, límite de solicitudes y `CachedMetadataProvider`. El proveedor
falso se usa exclusivamente en pruebas. Si falta la credencial, falla la conexión
o el proveedor limita solicitudes, la sesión pasa a `waiting_internet`: esos casos
no generan revisiones humanas falsas.

La caché persistente reside en `data/metadata_cache.sqlite3`, separada de
PostgreSQL. Guarda candidatos compactos comprimidos, tiene TTL y conserva como
máximo 5.000 entradas de forma predeterminada. No almacena imágenes, respuestas
HTTP completas ni una copia del catálogo de TMDb.

Las búsquedas de películas usan `primary_release_year` y las de series usan `year`,
según la API oficial. Referencias: [Search Movies](https://developer.themoviedb.org/reference/search-movie),
[Search TV](https://developer.themoviedb.org/reference/search-tv) y
[autenticación de aplicación](https://developer.themoviedb.org/docs/authentication-application).

## Arquitectura mult proveedor

`UrllibJsonTransport` centraliza HTTPS, User-Agent, timeouts, JSON, cancelación y
errores seguros. Cada adaptador transforma su respuesta a `ProviderCandidate`;
ninguna capa superior conoce el JSON externo. `MetadataProviderManager` consulta
solo proveedores compatibles: TMDb para películas, TMDb/TVMaze para series,
AniList como principal de anime y Wikidata como fuente auxiliar. Fanart solo se
consulta cuando ya existe un ID TMDb, IMDb o TheTVDB compatible.

Los detalles se solicitan después de puntuar candidatos. La fusión conserva el
proveedor principal, completa campos vacíos, ignora `N/A`, deduplica colecciones y
prioriza Fanart para arte. Un fallo temporal nunca se transforma en `NOT_FOUND`.

Los resultados confirmados se guardan en transacciones cortas mediante
`external_identifiers`, `content_aliases`, `normalized_metadata` y
`provider_queries`. Cada campo conserva fuente, referencia, confianza y fecha.

## Atribución y licencias

La interfaz debe atribuir las fuentes usando sus enlaces guardados. TVMaze publica
su API bajo CC BY-SA; TMDb, Fanart.tv, AniList y Wikidata tienen requisitos
propios. Esta descripción es técnica, no asesoría legal.

**Pendiente de revisión de licencias para distribución comercial:** comprobar los
términos y la presentación de atribuciones vigentes antes de distribuir MCE.
