# Migraciones

La revisión 0008 añade `preferred_display_title` y en `content_aliases`:
`provider`, `provider_entity_id`, `is_manual` y `confidence`, más índices de
proveedor, entidad, idioma y clave normalizada. La unicidad queda ligada a
contenido+banco+alias. No elimina alias ni identificadores.
