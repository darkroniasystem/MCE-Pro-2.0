# Preparación local y enriquecimiento selectivo

El flujo queda dividido en cinco pasos:

1. Importación y validación MSL.
2. Clasificación y limpieza local.
3. Enriquecimiento online selectivo.
4. Revisión humana y vista previa.
5. Finalización y exportación.

La etapa local conserva nombre, ruta, `bank_id` e identidad del archivo. Produce
categoría, confianza, reglas coincidentes, título limpio, año, temporada,
episodio y etiquetas técnicas. No construye proveedores ni realiza llamadas de
red.

El enriquecimiento solo acepta elementos `ready_for_enrichment`. Un proveedor
devuelve un resultado explícito: resultados, búsqueda completa sin resultados,
límite temporal, timeout, indisponibilidad, autenticación incorrecta o respuesta
inválida. Los estados temporales permanecen pendientes y no se envían a revisión.
`not_found_confirmed` requiere que los proveedores aplicables hayan terminado.

La migración `0005_split_preparation_enrichment` añade los estados persistentes,
reintentos y tablas de sesiones de etapa. Puede probarse en `mce_test`. Para
`mce`, primero debe ejecutarse el dry-run:

```powershell
.\.venv\Scripts\python.exe tools\dry_run_pipeline_reclassification.py
```

El script exige la base exacta `mce`, abre una transacción de solo lectura y
genera `.test-runtime\dry-run\pipeline-reclassification.json`. No existe modo
apply implícito: la migración y la reclasificación requieren autorización
explícita.

## Agrupación previa

Después de limpiar, MCE agrupa los archivos en obras lógicas mediante una clave
determinista que incluye `bank_id`, categoría y título de obra. Cien episodios
ubicados bajo la misma carpeta de serie producen una obra y una búsqueda de la
obra, conservando sus cien archivos físicos. La pantalla de enriquecimiento
muestra archivos, obras únicas y una estimación separada para TMDb, AniList y
TVMaze antes de solicitar confirmación.

Al iniciar, MCE congela el conjunto de obras seleccionadas. Ese número es el
total del progreso: cada obra incrementa una sola unidad y el porcentaje no se
recalcula aunque una obra contenga cientos de episodios. La persistencia final
continúa generando disponibilidad por cada archivo, ruta y `bank_id`.

Las confianzas de categoría, agrupación, identificación y calidad de metadatos
son independientes. La migración `0006` prepara además estados de publicación,
reglas de corrección propuestas y lotes reversibles.
