# Modelo de dominio de MCE

## Obra, versión, archivo y disponibilidad

`Content` representa una obra única, como *Avatar*. Puede existir sin año,
proveedor o archivo. `ContentVersion` representa una edición editorial, como
*Extended Edition* o doblaje latino. Resolución, códec y contenedor no convierten
automáticamente un archivo en una versión editorial.

`PhysicalFile` conserva nombre y ruta originales del elemento observado por MSL.
Puede permanecer sin identificar y su huella puede carecer de tamaño o hash.
Cuando está confirmado posee como máximo un `content_id` principal.

`Availability` expresa que ese archivo u obra está localizado en un banco,
instalación y fuente. No duplica títulos ni metadatos universales.

## Banco, instalación y fuente

Un `Bank` es el cliente o banco de copia y puede desactivarse sin eliminación.
Una `Installation` es un equipo con MSL perteneciente al banco. Una `Source` es
el volumen, directorio o recurso de red escaneado por esa instalación; una
instalación no es un disco.

## Escaneo e importación

`Scan` describe el proceso ejecutado por MSL, sus versiones, fechas y alcance.
`ScanImport` registra cuándo MCE recibió el archivo, su nombre y SHA-256 ya
calculado externamente. La Fase 1 solo valida la representación de la huella: no
abre el JSON ni calcula hashes.

La detección de duplicado conserva el registro y usa el estado `duplicate`. Una
importación completada puede pasar a `reverted`; una revertida no puede volver
directamente a procesamiento.

## Alcance completo y parcial

`ScanScope` distingue `full`, `partial`, `selected_sources` y `selected_paths`.
Los alcances seleccionados exigen sus fuentes o rutas. Las reglas puras solo
permiten marcar ausencia dentro del alcance declarado; un escaneo parcial nunca
representa toda la instalación.

## Procedencia, prioridad y confianza

`FieldProvenance` registra tipo de fuente, nombre, referencia, fecha y confianza
opcional. `ConfidenceScore` usa 0–100 y clasifica `safe`, `probable`, `uncertain`
o `low`. `MatchEvidence` conserva razones ponderadas y `MetadataConflict`
representa contradicciones sin resolverlas automáticamente.

La prioridad es: bloqueo manual, corrección manual, regla del banco, alias
confirmado, proveedor, importación, inferencia e IA. La función pura de prioridad
considera procedencia, bloqueo y confianza sin realizar enriquecimiento.

## Bloqueos, correcciones y revisión

`FieldLock` impide que una actualización automática sobrescriba un campo
bloqueado manualmente. `Correction` registra un cambio de valor. Una
`ReviewDecision` registra acciones como aceptar candidato, excluir, fusionar o
separar; aceptar no implica necesariamente corregir un campo.

## Relaciones

```text
Bank
└── Installation
    └── Source
        └── PhysicalFile

Scan
└── ScanScope

ScanImport
└── Scan

Content
├── ContentVersion
├── Season
│   └── Episode
└── PhysicalFile link

Availability
├── Bank
├── Installation
├── Source
├── PhysicalFile
└── Content
```

Las relaciones se almacenan mediante identificadores tipados para evitar ciclos.
Una obra episódica admite temporadas y episodios; una película no. Temporada 0
y episodio 0 permiten representar especiales.

## Estados principales

Los estados se centralizan en `value_objects/states.py`. Las transiciones de
trabajo, importación y disponibilidad se centralizan en
`rules/state_transitions.py`. Pausar, reanudar, preparar reintento, revertir y
restaurar son operaciones explícitas e inmutables.

## No implementado todavía

La Fase 1 no contiene lectura o validación de JSON, cálculo SHA-256, Pydantic,
SQLite, PostgreSQL, repositorios, proveedores, internet, caché, identificación,
limpieza, exportaciones, CLI, PySide6 ni sincronización.
