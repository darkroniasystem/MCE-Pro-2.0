# Conservación del JSON original y staging

## Alcance de la Fase 3

Después de que el usuario selecciona un JSON desde la interfaz, la validación
termina correctamente y confirma **Crear sesión**, MCE conserva una copia exacta
del archivo antes de iniciar las escrituras PostgreSQL. Esta fase no normaliza
títulos, no clasifica contenido y no ejecuta proveedores.

MCE no vigila ni recorre carpetas de muestras. La ruta elegida por el usuario no
se configura como origen y la aplicación no depende de `samples`.

## Archivo inmutable

Los originales se almacenan bajo el directorio de datos de ejecución:

```text
originals/<dos primeros caracteres SHA-256>/<SHA-256>.json
```

La copia se hace por bloques, conserva los bytes sin decodificar ni reescribir,
calcula SHA-256 durante la copia, fuerza la escritura a disco y publica mediante
reemplazo atómico. Si el archivo seleccionado cambió después de validarse, se
rechaza la creación de la sesión antes de insertar datos en PostgreSQL. Una copia
ya existente se vuelve a leer y verificar antes de reutilizarse.

## Persistencia PostgreSQL

La migración `0012` añade:

- `original_jsons`: hash, referencia interna, nombre original, tamaño, versión de
  esquema y fechas de verificación.
- `import_staging_documents`: manifiesto validado ligado uno a uno a
  `scan_imports`, con cabecera MSL, cantidades y resultado de validación.

El JSON completo no se duplica dentro de PostgreSQL: la fuente auditable y exacta
es el archivo direccionado por contenido. El staging conserva solo el manifiesto
necesario para relacionar y auditar la importación.

## Atomicidad y compatibilidad

La sesión, el `scan`, la importación, el staging y los registros se insertan en
una única transacción PostgreSQL. Un fallo revierte todas esas filas. Una copia
direccionada por contenido que quede sin referencia tras un rollback es inocua y
puede verificarse y reutilizarse posteriormente.

Las ocho importaciones existentes antes de `0012` se conservan sin cambios y no
se rellenan leyendo ubicaciones históricas. Solo una nueva importación confirmada
por el usuario crea filas en las tablas de Fase 3.

## Evidencia automatizada

- Conservación byte a byte y reutilización por hash.
- Detección de modificación posterior a la validación.
- Creación conjunta del original y manifiesto de staging.
- Ausencia de escrituras PostgreSQL cuando falla la conservación.
- Suite completa: 326 aprobadas y 5 excluidas intencionalmente el 31 de julio de
  2026.

