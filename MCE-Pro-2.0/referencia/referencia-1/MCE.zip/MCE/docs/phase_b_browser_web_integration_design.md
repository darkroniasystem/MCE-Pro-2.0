# Fase B: diseño mínimo de integración web y navegador

Estado: DISEÑADO, NO IMPLEMENTADO.

Este diseño amplía la arquitectura existente. No reemplaza proveedores,
identificación, caché, sesiones, validadores, procedencia ni publicación.

## Flujo objetivo

1. Preparación y agrupación local existente por `work_group_id`.
2. Identidad canónica y caché existentes.
3. Proveedores especializados existentes.
4. Evidencia web acumulativa: Tavily, Serper y Exa, por prioridad.
5. Navegador solo si la evidencia acumulada continúa siendo insuficiente.
6. Qwen local como analizador de evidencia.
7. Validador determinista de MCE.
8. Groq solo cuando Qwen falla o el validador solicita escalamiento.
9. Revisión humana si no existe evidencia suficiente.

La unidad de trabajo, caché, progreso y reanudación es siempre una obra lógica,
nunca un archivo o episodio individual.

## Cambios mínimos por componente

### Evidencia web acumulativa

`SequentialWebSearchProvider` seguirá administrando prioridades y fallos, pero
acumulará evidencia útil de cada proveedor. La suficiencia se evaluará sobre el
conjunto deduplicado acumulado, no únicamente sobre la última respuesta.

La deduplicación usará URL normalizada como identidad primaria. Una misma URL no
podrá consumir dos posiciones ni aparentar dos fuentes independientes.

El registro de intentos conservará, por proveedor:

- identificador, prioridad y estado;
- resultados nuevos y resultados acumulados;
- error seguro, timeout, rate limit, cuota o circuito abierto;
- llamadas, éxitos, fallos, caché y enfriamiento disponibles.

### Contrato común de evidencia

Se ampliará el DTO existente sin romper sus consumidores. Una evidencia podrá
incluir opcionalmente campos estructurados, manteniendo título, URL, snippet,
proveedor, puntuación, consulta y fecha actuales.

Campos opcionales previstos:

- año, tipo, temporadas y episodios conocidos;
- géneros, reparto, director y plataformas;
- títulos alternativos;
- panel enriquecido;
- versión del extractor;
- estado de recolección;
- confianza y procedencia por campo.

La ausencia de un campo significa desconocido. Nunca se inferirá un valor vacío.

### BrowserSearchProvider

Implementará el puerto actual de búsqueda web mediante un adaptador separado.
Playwright quedará aislado en infraestructura; aplicación y dominio no lo
importarán.

Responsabilidades:

- comprobar Playwright y Chromium con mensajes diferenciados;
- iniciar un navegador reutilizable y concurrencia inicial igual a uno;
- crear y cerrar una página por tarea;
- navegar mediante DOM, roles, texto y varios selectores candidatos;
- detectar CAPTCHA, tráfico inusual, consentimiento bloqueante y rate limit;
- no evadir protecciones;
- limitar resultados y texto visible;
- cerrar contexto y navegador incluso ante error o cancelación;
- reciclar el proceso de forma controlada, sin pestañas o procesos huérfanos.

El buscador inicial será configurable detrás del proveedor. No se fijará una
estructura de selectores en aplicación o dominio.

### Caché de navegación

Se reutilizará SQLite mediante una tabla o almacén separado y versionado. La
clave incluirá `logical_work_id`, consulta normalizada, buscador, versión del
extractor y límites que alteren el resultado.

Se guardará evidencia compacta, nunca HTML completo por defecto:

- consulta y URL de búsqueda;
- resultados y panel estructurados;
- evidencia visible compacta;
- proveedor, buscador, versión y fecha;
- estado OK, parcial, vacío, bloqueado, CAPTCHA o timeout;
- indicador de caché.

Las entradas exitosas y parciales podrán reutilizarse. Estados transitorios
caducarán con TTL corto y no se convertirán en evidencia válida.

### Enriquecimiento parcial y procedencia

Se reutilizarán `MetadataField`, `FieldProvenance` y las reglas de prioridad ya
existentes. El resultado IA incorporará `partial_match` y `partial_accept` sin
dar autoridad de publicación al modelo.

Cada campo aceptado deberá:

- tener una fuente suministrada y pública;
- superar el umbral determinista específico del campo;
- conservar valor, fuente, confianza y fecha;
- respetar bloqueos manuales y prioridades existentes.

Los campos no demostrados permanecerán ausentes. Una identidad parcial no podrá
crear una identidad canónica definitiva si título, tipo o evidencia mínima no
son suficientes.

### Qwen y Groq

Qwen continuará siendo la primera ruta y dispondrá de un único reintento por
JSON inválido. Solo recibirá evidencia compacta.

El validador comprobará esquema, URLs, correspondencia de fuentes, conflictos y
reglas por campo. Una URL no suministrada marcará `hallucinated_source` e
impedirá aceptar tanto el resultado completo como sus campos parciales.

Groq se llamará únicamente ante indisponibilidad, timeout, JSON inválido,
ambigüedad, evidencia insuficiente o rechazo del validador. No se llamará tras
una aceptación completa o parcial suficiente de Qwen.

### Backpressure y reanudación

El navegador y Qwen tendrán colas acotadas y concurrencia inicial igual a uno.
No se permitirá producir evidencia ilimitada por delante del analizador.

El checkpoint conservará la etapa pendiente por obra lógica. Al reanudar se
consultará primero identidad aceptada y cachés antes de cualquier llamada o
navegación. Una interrupción no podrá marcar una obra como completada.

### Métricas e interfaz

Las métricas nuevas serán contadores por obra lógica y latencias por etapa. Los
p50/p95 se calcularán a partir de muestras reales, distinguiendo procesamiento
activo de espera por cuota.

La sección Configuración conservará WEB y OLLAMA/GROQ y añadirá BROWSER con:

- activación, modo visible/headless, timeout y concurrencia;
- demoras mínima/máxima, resultados y límite de texto;
- estado independiente de Playwright y Chromium;
- botón de diagnóstico sin instalación automática.

Los secretos seguirán fuera de QSettings, logs, documentación y ejecutable.

## Secuencia de implementación y puertas de validación

- Fase C: evidencia acumulativa y telemetría común, con pruebas unitarias.
- Fase D: completar Serper/Exa hasta el límite de credenciales.
- Fase E: comprobar disponibilidad de claves sin mostrar sus valores.
- Fase F: pruebas reales aisladas de las tres APIs, previa autorización.
- Fases G-I: proveedor navegador, diagnóstico y extractor.
- Fase J: aceptación parcial por campo.
- Fases K-L: cadena Qwen, validador y Groq.
- Fase M: caché, reanudación e idempotencia.
- Fases N-P: pruebas, benchmarks y optimización basada en mediciones.
- Fases Q-S: interfaz, release y documentación final.

Cada fase termina con pruebas proporcionales, Ruff y mypy. No se inicia la fase
siguiente si la actual deja una regresión, una validación real pendiente o un
permiso obligatorio sin resolver.

## Acciones que requieren pausa y autorización

- instalar Playwright o Chromium;
- arrancar/controlar un navegador real;
- efectuar búsquedas web reales;
- probar APIs reales con Tavily, Serper o Exa;
- probar Ollama/Qwen o Groq contra servicios reales;
- ejecutar integración contra PostgreSQL, incluso `mce_test`;
- reconstruir o ejecutar el artefacto PyInstaller.

No se modificarán las sesiones reales ni el catálogo maestro durante pruebas.

