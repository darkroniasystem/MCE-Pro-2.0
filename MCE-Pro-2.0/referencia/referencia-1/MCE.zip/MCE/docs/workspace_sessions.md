# Espacios de trabajo y sesiones

La Fase 3 convierte un `ImportResult` exitoso de la Fase 2 en una sesión de
trabajo reanudable. No limpia títulos, no clasifica obras y no modifica el
catálogo.

## Flujo

```text
ImportResult válido
    -> Workspace
    -> ProcessingSession (ready)
    -> SessionItem por cada PhysicalFile importado
    -> cambios y progreso
    -> checkpoint JSON
    -> restauración
```

`SessionService` es el caso de uso. Recibe repositorios, reloj, generador de IDs,
almacenamiento de checkpoints y un reportador opcional por inyección. Los
adaptadores temporales `InMemoryWorkspaceRepository` e
`InMemorySessionRepository` no sobreviven al cierre del proceso.

## Estados y reglas

Las sesiones usan `created`, `ready`, `running`, `paused`, `waiting_review`,
`waiting_internet`, `cancelled`, `completed`, `failed` y `archived`. Una sesión completada no vuelve a ejecutarse;
cancelar también cancela elementos pendientes o activos. Un fallo fatal detiene
la sesión y solo vuelve a `ready` mediante `prepare_retry`.

Cada elemento conserva `ImportId`, `SourceId`, `PhysicalFileId` y la ruta
original. Los fallos individuales quedan en el elemento y pueden coexistir con
la finalización de la sesión. Las estadísticas se derivan del estado real para
evitar contadores divergentes.

Desde la Fase 10, `SessionPipelineService` coordina las etapas implementadas de
normalización, clasificación, identificación, revisión y consolidación. Si no hay
evidencia suficiente, el elemento termina en revisión y nunca se inventa una
identidad de catálogo.

## Checkpoints

`JsonCheckpointStore` usa documentos UTF-8 con `format_version: 1`, valida
identidades, enums, fechas, alcance e integridad básica, y escribe mediante un
archivo temporal seguido de reemplazo atómico. Nunca usa `pickle`. Un formato
dañado produce `InvalidCheckpointError`; una versión distinta produce
`IncompatibleCheckpointError`.

Desde la Fase 9, tanto el documento local como los checkpoints PostgreSQL usan
SHA-256 canónico y rechazan alteraciones antes de permitir recuperación. Véase
`durable_jobs_cache_checkpoints.md`.

La aplicación de escritorio utiliza `data/session_checkpoints`. Al arrancar,
recupera los documentos válidos e ignora de forma segura un checkpoint ilegible.
Los repositorios de ejecución siguen en memoria, pero el estado completo de cada
sesión sobrevive al cierre mediante estos archivos JSON.

## Verificación manual

1. Importe un fixture MSL válido con `ImportService`.
2. Cree un `Workspace` y guárdelo en el repositorio en memoria.
3. Llame `SessionService.create` y compruebe estado `ready` y las rutas.
4. Guarde un checkpoint, cree un repositorio de sesiones nuevo y restáurelo.
5. Compruebe que sesión, alcance, IDs, rutas, estados y estadísticas coinciden.

## Limitaciones

- Los resultados identificados y las decisiones manuales confirmadas se persisten
  en PostgreSQL `mce_test`; la publicación real utiliza exclusivamente `mce`.
- TMDb y Fanart usan sus variables específicas; AniList, TVMaze y Wikidata son
  públicos. La ausencia de un proveedor opcional no cierra MCE. Si ningún
  proveedor compatible está disponible, la sesión queda en `waiting_internet`.
- Un lote detenido conserva los elementos ya procesados y al reanudarse omite esas
  consultas. Las consultas idénticas se resuelven una sola vez por lote y mediante
  la caché persistente entre ejecuciones.
