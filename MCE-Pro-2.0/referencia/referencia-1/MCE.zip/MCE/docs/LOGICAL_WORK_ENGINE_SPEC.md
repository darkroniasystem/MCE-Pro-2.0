Actúa como arquitecto de software sénior y corrige de forma integral, segura y verificable el subsistema de **preparación local, limpieza, agrupamiento, identificación y reutilización de obras lógicas de MCE**.

Esta es una de las partes más delicadas del proyecto porque debe reducir al mínimo las llamadas a proveedores sin provocar agrupamientos falsos. No hagas una corrección superficial basada solamente en expresiones regulares. Primero inspecciona la implementación actual, sus modelos, migraciones, caché, flujo de importación, agrupamiento, enriquecimiento, revisión humana y pruebas. Después implementa una solución coherente con la arquitectura existente.

No avances a una fase nueva ni modifiques módulos ajenos a este problema. No reescribas componentes estables sin necesidad.

# Objetivo general

MCE debe reconocer que numerosos archivos, carpetas, temporadas, episodios, subtítulos y extras pueden pertenecer a una sola obra lógica, aunque:

* estén distribuidos en carpetas diferentes;
* tengan nombres escritos de formas distintas;
* incluyan prefijos numéricos de organización;
* contengan año, resolución, códec, idioma o etiquetas técnicas;
* aparezcan en escaneos distintos;
* se importen en momentos diferentes;
* estén disponibles en bancos de copia diferentes;
* la preparación local no consiga agruparlos correctamente durante el primer intento.

La preparación local debe realizar la mayor cantidad posible de trabajo antes de consultar proveedores.

Los proveedores estructurados deben utilizarse principalmente para:

* confirmar la identidad propuesta;
* resolver ambigüedades;
* devolver identificadores canónicos;
* obtener metadatos oficiales;
* corregir agrupamientos locales incompletos;
* impedir duplicados definitivos.

El principio central debe ser:

```text
Preparación local robusta
→ agrupamiento provisional
→ búsqueda en identidades ya conocidas
→ reutilización local cuando sea segura
→ consulta externa solo cuando sea necesaria
→ confirmación mediante identificador canónico
→ consolidación idempotente
```

# Invariantes obligatorios

La implementación debe respetar siempre estas reglas:

1. Nunca renombrar, mover, eliminar ni modificar físicamente archivos o carpetas.
2. Conservar íntegros los nombres y rutas originales para trazabilidad.
3. Separar nombre original, título limpio y señales extraídas.
4. No considerar cada carpeta como una obra diferente.
5. No considerar cada temporada como una obra diferente.
6. No considerar cada episodio como una obra diferente.
7. No consultar proveedores una vez por archivo, episodio, temporada o carpeta.
8. Consultar, como máximo, por obra lógica única cuando la identidad todavía no sea conocida.
9. Reutilizar primero identidades y metadatos ya confirmados.
10. No fusionar automáticamente obras ambiguas.
11. Mantener separada la identidad canónica de la disponibilidad por banco.
12. No duplicar obras, temporadas, episodios, archivos ni metadatos durante reimportaciones.
13. No sobrescribir decisiones humanas confirmadas.
14. No permitir que una caché negativa creada con un título contaminado bloquee una nueva consulta limpia.
15. Conservar compatibilidad con reanudación, idempotencia, concurrencia y publicación atómica.

# Modelo conceptual requerido

El sistema debe distinguir claramente estos niveles:

## Identidad canónica

Representa la obra real confirmada:

* película;
* serie;
* novela;
* dorama;
* anime;
* concurso;
* animado;
* combo, cuando corresponda al modelo del proyecto.

Debe contener los identificadores oficiales y metadatos compartidos.

## Obra lógica local

Representa el grupo provisional construido a partir de nombres, carpetas y archivos locales antes o durante la identificación.

## Temporada

Debe estar relacionada con una sola obra lógica o canónica.

## Episodio

Debe estar relacionado con su temporada y obra.

## Archivo físico

Debe conservar:

* ruta;
* nombre original;
* banco;
* escaneo;
* relación con episodio, temporada, extra u obra;
* demás datos de trazabilidad existentes.

## Disponibilidad por banco

La misma identidad canónica puede existir en varios bancos, pero cada banco debe conservar por separado:

* rutas;
* archivos;
* temporadas disponibles;
* episodios disponibles;
* subtítulos;
* extras;
* estado de disponibilidad.

Nunca mezcles físicamente inventarios de bancos diferentes.

# Campos y trazabilidad

Adapta los nombres a los modelos existentes, pero la solución debe representar conceptualmente al menos:

* `nombre_original`
* `ruta_original`
* `titulo_original_grupo`
* `titulo_base_obra`
* `titulo_normalizado`
* `titulo_busqueda`
* `prefijo_orden`
* `anio_pista`
* `temporada_pista`
* `episodio_pista`
* `tipo_contenido_pista`
* `es_posible_extra`
* `etiquetas_tecnicas_extraidas`
* `transformaciones_aplicadas`
* `confianza_agrupamiento`
* `motivo_agrupamiento`
* `obra_logica_id`
* `obra_canonica_id`
* identificadores externos confirmados
* `bank_id`
* `scan_id`
* versión o huella de la lógica de normalización

No crees campos duplicados si ya existen equivalentes. Reutiliza o migra correctamente el modelo actual.

# Separación entre título limpio y señales locales

El título limpio debe contener únicamente el nombre que resulte útil para identificar la obra.

Los elementos eliminados no deben perderse. Deben conservarse como señales estructuradas para:

* desambiguación;
* auditoría;
* reintentos;
* revisión humana;
* explicación de decisiones.

Ejemplo:

```text
Original:
rambo 1 1990 hd h264 1080p ultrak

Título limpio:
rambo 1

Año pista:
1990

Etiquetas técnicas:
hd
h264
1080p
ultrak
```

El año local no es el año oficial. Puede estar equivocado. Los proveedores deben determinar el año definitivo.

# Tratamiento de años

El año debe eliminarse del título limpio cuando exista evidencia contextual suficiente de que fue añadido como metadato local.

Ejemplos claros:

* `Rambo 1 (1990)`
* `Rambo 1 [1990]`
* `Rambo 1 - 1990`
* `Rambo 1 1990 HD H264 1080p`
* `Matrix.1999.1080p.BluRay`
* `Serie X Temporada 2 2021 WEB-DL`

Resultado esperado:

```text
titulo_base_obra = Rambo 1
anio_pista = 1990
```

El año debe conservarse como pista separada y no formar parte permanente de:

* `titulo_normalizado`
* `titulo_base_obra`
* `titulo_busqueda` principal

## Estrategia escalonada de consulta

Primer intento:

```text
título limpio sin año
```

Ejemplo:

```text
Rambo 1
```

Si el proveedor devuelve una coincidencia clara, no realizar una segunda búsqueda innecesaria.

Usar el año cuando:

* no haya resultados;
* los resultados sean ambiguos;
* existan varias obras con el mismo título;
* ningún candidato supere el umbral requerido;
* el año ayude a ordenar o desambiguar candidatos.

Si el proveedor admite un filtro estructurado de año, utilizar:

```text
title = Rambo 1
year_hint = 1990
```

No concatenar el año al texto cuando exista un parámetro específico.

Solo en proveedores que no admitan filtro estructurado puede usarse una variante textual:

```text
Rambo 1 1990
```

La pista de año:

* puede bonificar una coincidencia compatible;
* puede penalizar una diferencia importante;
* nunca debe reemplazar el análisis total;
* nunca debe considerarse automáticamente correcta;
* no debe descartar una coincidencia muy fuerte únicamente porque el año local sea incorrecto.

# Números que forman parte del título

No elimines agresivamente números iniciales, finales o de cuatro cifras.

Deben conservarse títulos como:

* `1984`
* `1917`
* `1899`
* `1923`
* `24`
* `300`
* `9-1-1`
* `2001 A Space Odyssey`
* `Blade Runner 2049`
* `2 Broke Girls`
* `3 Body Problem`
* `13 Reasons Why`
* `10 Things I Hate About You`
* `21 Jump Street`
* `50 First Dates`

También deben conservarse inicialmente números de entrega o secuela:

* `Rambo 1`
* `Rambo 2`
* `Rocky 4`
* `Avatar 2`
* `Toy Story 3`
* `John Wick 4`

Nunca permitas que la extracción de un supuesto año deje el título vacío.

Ejemplos obligatorios:

```text
1984
→ titulo_base_obra = 1984
→ anio_pista = null
```

```text
1917
→ titulo_base_obra = 1917
→ anio_pista = null
```

```text
2001 A Space Odyssey
→ conservar 2001
```

```text
Blade Runner 2049
→ conservar 2049
```

En situaciones ambiguas, conserva ambas interpretaciones internamente:

1. número como parte del título;
2. número como posible año.

No destruyas ninguna variante antes de comparar evidencia.

# Prefijos numéricos de orden o catálogo

Detecta prefijos que representen organización local y no pertenezcan a la obra.

Ejemplos:

* `1009-MAKE IT RIGHT THE SERIES`
* `1009 - MAKE IT RIGHT THE SERIES`
* `1009. MAKE IT RIGHT THE SERIES`
* `0012_THE FLASH`
* `045 GAME OF THRONES`

Resultado esperado para el caso principal:

```text
titulo_original_grupo = 1009-MAKE IT RIGHT THE SERIES
prefijo_orden = 1009
titulo_base_obra = MAKE IT RIGHT THE SERIES
titulo_busqueda = Make It Right The Series
```

El valor `1009` debe conservarse solamente para trazabilidad.

No debe enviarse a:

* TMDb;
* TVmaze;
* Wikidata;
* Wikipedia;
* AniList;
* Fanart.tv;
* proveedor web;
* otros proveedores de identificación.

No elimines automáticamente cualquier número inicial. Debe existir evidencia de que es un índice de orden, como:

* separador posterior;
* longitud o relleno con ceros;
* patrón repetido en otras carpetas del mismo conjunto;
* presencia de un título textual completo después del número;
* contexto de catálogo o clasificación;
* otras señales consistentes.

Cuando exista duda, sé conservador.

# Temporadas y episodios

Extrae de manera estructurada, sin mantenerlos dentro del título base:

* `S01E03`
* `S1E3`
* `01x03`
* `T01E03`
* `Season 2`
* `Temporada 2`
* `Temp 2`
* `T2`
* `Episode 5`
* `Episodio 5`
* `Capítulo 5`
* `Capitulo 5`
* `Cap 05`

Considera variaciones razonables de mayúsculas, minúsculas, espacios, puntos, guiones y guiones bajos.

Ejemplo:

```text
La.Casa.Del.Dragon.Temp.3.1080p
```

Debe producir:

```text
titulo_base_obra = LA CASA DEL DRAGON
temporada_pista = 3
```

La temporada y el episodio no deben formar parte de la clave principal de la obra.

# Agrupamiento de series distribuidas

La estructura física no define la cantidad de obras.

## Ejemplo: The Walking Dead

Si existe:

```text
The Walking Dead/
    Temporada 1/  → 22 videos
    Temporada 2/  → 22 videos
    ...
    Temporada 10/ → 22 videos
```

El resultado debe ser:

```text
1 obra lógica
10 temporadas
220 episodios o archivos principales
```

No deben crearse 10 obras ni realizarse 10 enriquecimientos independientes.

## Ejemplo: La Casa del Dragón distribuida

Si existe:

```text
Series/La Casa del Dragon/Temp 1
Series/La Casa del Dragon/Temp 2
Nuevas/La Casa del Dragon Temp 3
Estrenos/La.Casa.Del.Dragon.Temp.4.1080p
```

El resultado provisional esperado es:

```text
1 obra lógica:
La Casa del Dragon

Temporadas detectadas:
1, 2, 3 y 4
```

Las carpetas pueden encontrarse:

* bajo padres diferentes;
* en rutas separadas;
* en escaneos posteriores;
* en dispositivos distintos;
* con nombres localizados o normalizados de manera diferente.

El agrupamiento debe basarse en la identidad probable de la obra, no en compartir una carpeta padre.

# Comparación local de títulos

Antes de consultar proveedores, compara grupos mediante varias señales:

* coincidencia exacta del título base;
* normalización Unicode;
* diferencias de acentos;
* mayúsculas y minúsculas;
* espacios, guiones, puntos y guiones bajos;
* artículos opcionales cuando sea seguro;
* alias locales ya confirmados;
* títulos alternativos guardados;
* palabras distintivas;
* tipo de contenido;
* año pista;
* temporadas detectadas;
* episodios detectados;
* estructura de directorios;
* clasificación física de origen;
* similitud textual;
* identidad canónica ya conocida;
* decisiones humanas anteriores.

No bases la decisión en una sola métrica de similitud.

Las reglas y ponderaciones deben:

* ser explicables;
* estar centralizadas;
* ser configurables cuando corresponda;
* evitar números mágicos dispersos;
* registrar por qué se realizó o rechazó una unión.

# Agrupamiento conservador

La limpieza puede ser agresiva eliminando ruido técnico, pero la fusión de obras debe ser conservadora.

No fusiones automáticamente obras diferentes como:

* `The Walking Dead`
* `Fear the Walking Dead`
* `The Walking Dead: Daryl Dixon`
* `The Walking Dead: Dead City`
* `Tales of the Walking Dead`

Tampoco:

* `CSI`
* `CSI Miami`
* `CSI New York`

Ni:

* `Narcos`
* `Narcos Mexico`

Las palabras distintivas no son ruido y no deben eliminarse.

Si la similitud no es suficientemente segura:

* mantén grupos separados;
* consulta identidades conocidas;
* consulta proveedores si es necesario;
* o envía el posible agrupamiento a revisión humana.

Es preferible una consulta adicional a fusionar dos obras distintas y contaminar decenas o cientos de archivos.

# Obras con el mismo título

El año no debe permanecer dentro del título limpio, pero debe ayudar a evitar fusiones incorrectas entre remakes o producciones homónimas.

Ejemplo:

```text
Título X (1990)
Título X (2024)
```

Ambos pueden compartir:

```text
titulo_base_obra = Título X
```

Pero no deben fusionarse automáticamente si los años pista son claramente incompatibles.

Reglas orientativas:

* mismo título y años compatibles: posible misma obra;
* mismo título y una entrada sin año: posible unión, pero debe evaluarse;
* mismo título y años incompatibles: mantener separados provisionalmente;
* mismo título y tipo de contenido distinto: no fusionar;
* misma identidad externa confirmada: consolidar;
* identificadores externos diferentes: mantener separados siempre.

# Limpieza técnica

Extrae o elimina del título de búsqueda, cuando exista evidencia suficiente:

* extensiones;
* resolución: `360p`, `480p`, `720p`, `1080p`, `2160p`, `4K`;
* códec: `x264`, `x265`, `H264`, `H265`, `HEVC`, `AV1`;
* fuente: `WEB-DL`, `WEBRip`, `BluRay`, `BDRip`, `HDTV`, `DVDRip`;
* audio e idioma cuando estén claramente etiquetados;
* grupos de release;
* bitrate u otras etiquetas técnicas conocidas;
* marcadores de copia local;
* palabras técnicas configuradas por el proyecto.

No borres una palabra legítima del título solamente porque coincida parcialmente con una etiqueta técnica.

La lista de etiquetas debe estar centralizada y probada. No disperses reemplazos ad hoc por el código.

# Extras y archivo representativo

Detecta posibles extras mediante señales como:

* `cover`
* `frame book`
* `trailer`
* `teaser`
* `sample`
* `preview`
* `intro`
* `opening`
* `ending`
* `theme`
* `music video`
* `behind the scenes`
* resoluciones, tamaños o duraciones atípicas respecto al grupo

Un extra puede asociarse a la obra, pero:

* no debe definir la identidad del grupo;
* no debe utilizarse como representante si existen episodios o archivos principales mejores;
* no debe contaminar el título de búsqueda;
* no debe provocar que una canción o portada animada reemplace el nombre de la serie.

Para el caso:

```text
Everytime_We_Touch_-_Frame_Book_(Cover)(360p).mp4
```

dentro del grupo:

```text
1009-MAKE IT RIGHT THE SERIES
```

el archivo puede conservarse como posible extra asociado, pero la consulta debe basarse en:

```text
Make It Right The Series
```

La elección del archivo representativo debe priorizar:

1. episodios o archivos principales;
2. archivos sin señales de extra;
3. nombres con mayor similitud respecto al título de la obra;
4. archivos representativos de la mayoría del grupo;
5. estabilidad determinista entre reimportaciones.

# Búsqueda local antes de proveedores

Antes de llamar a cualquier proveedor, buscar en la base de datos de MCE:

* identidad canónica por identificador;
* título oficial;
* título localizado;
* títulos alternativos;
* alias confirmados;
* variantes normalizadas;
* decisiones humanas;
* consultas anteriores;
* asociaciones de temporadas y episodios.

Ejemplo:

Si ya existe:

```text
obra_canonica_id = ...
titulo_oficial = House of the Dragon
alias:
- La Casa del Dragón
- La Casa del Dragon
- House of the Dragon
```

y aparece posteriormente:

```text
La Casa del Dragon Temp 3
```

MCE debe vincular la temporada y los archivos a la obra existente sin volver a descargar innecesariamente:

* reparto;
* sinopsis;
* géneros;
* imágenes;
* país;
* títulos alternativos;
* otros metadatos ya confirmados.

# Corrección cuando la preparación local deja escapar una carpeta

La preparación local no tiene que acertar el 100 % de los casos para que el sistema sea estable.

Si durante el primer procesamiento una carpeta queda separada y se consulta posteriormente:

1. el proveedor puede devolver el mismo identificador externo que ya tiene otra obra;
2. MCE debe reconocer que ambas representan la misma identidad;
3. debe consolidarlas de forma segura;
4. debe vincular las nuevas temporadas, episodios y archivos;
5. no debe crear una segunda ficha canónica;
6. no debe duplicar metadatos;
7. no debe sobrescribir información válida;
8. la operación debe ser idempotente.

Idealmente, la búsqueda local debe evitar esa segunda llamada. Pero si la llamada ocurre, el identificador externo debe funcionar como red de seguridad definitiva.

# Identidad canónica y deduplicación

Una vez que una obra tenga un identificador externo confirmado, ese identificador debe tener prioridad sobre el texto local.

Ejemplo conceptual:

```text
tmdb_id confirmado
→ una identidad canónica
→ múltiples títulos y alias
→ múltiples temporadas
→ múltiples rutas
→ múltiples bancos con disponibilidad independiente
```

Define restricciones de unicidad coherentes con los proveedores y tipos de contenido existentes.

No dependas exclusivamente de:

* título escrito;
* ruta;
* archivo representativo;
* número de temporada;
* número de episodio;
* carpeta padre.

# Caché

Implementa o ajusta al menos dos niveles de reutilización:

## Caché de consulta

Evita repetir la misma solicitud externa.

La clave debe tener en cuenta, según corresponda:

* proveedor;
* título limpio;
* tipo de contenido;
* año pista utilizado o no;
* idioma;
* variante de consulta;
* versión del normalizador;
* parámetros relevantes.

Las consultas:

```text
Rambo 1
```

y:

```text
Rambo 1 + year_hint 1990
```

deben distinguirse.

## Identidad canónica persistente

Evita enriquecer de nuevo una obra ya conocida aunque aparezca con otro nombre, ruta, temporada, escaneo o banco.

La identidad canónica es más importante que la caché textual.

# Caché negativa y cambios de normalización

Un resultado negativo obtenido con:

```text
1009-MAKE IT RIGHT THE SERIES series
```

no debe bloquear una nueva consulta con:

```text
Make It Right The Series
```

Cuando cambie de forma significativa:

* el título limpio;
* la variante de consulta;
* el tipo de contenido;
* el año pista utilizado;
* la versión del normalizador;

debe generarse una clave diferente o invalidarse selectivamente el resultado negativo afectado.

No borres toda la caché válida.

Conserva:

* trazabilidad;
* consulta anterior;
* motivo del fallo;
* versión de normalización;
* fecha;
* proveedor;
* relación con el nuevo reintento.

# Política de llamadas externas

El flujo debe intentar:

1. agrupamiento local;
2. búsqueda en identidades conocidas;
3. reutilización de alias y caché;
4. proveedor estructurado principal;
5. proveedores estructurados de respaldo;
6. búsqueda web únicamente como último recurso, conforme a la arquitectura ya definida.

La búsqueda web no debe consultar todo el catálogo y no debe sustituir a los proveedores estructurados.

Debe operar:

* por obra lógica única;
* solo después del fallo o insuficiencia de los proveedores principales;
* reutilizando caché;
* conservando evidencia;
* sin inventar metadatos.

# Revisión humana

La interfaz debe diferenciar claramente:

## Identidad estructurada disponible

Se puede aprobar y vincular:

* identificadores;
* título oficial;
* año oficial;
* reparto;
* sinopsis;
* géneros;
* imágenes;
* demás metadatos disponibles.

## Evidencia web sin candidato estructurado

Mostrar:

```text
Evidencia web encontrada; identificación pendiente
```

Debe presentar:

* consulta usada;
* título limpio;
* año pista;
* proveedor web;
* títulos detectados;
* fragmentos;
* referencias;
* puntuación o evidencia;
* motivo por el que no se creó candidato;
* acción para modificar el título y volver a consultar.

Una acción útil sería:

```text
Usar título sugerido y volver a consultar proveedores
```

## Sin identificación externa

Mostrar:

```text
Sin identificación externa
```

No presentar “Aprobar” como si fuera equivalente a completar una ficha enriquecida.

Si se permite una aprobación manual sin candidato, debe quedar registrado que:

* es una identificación manual;
* faltan metadatos oficiales;
* no existe identificador externo confirmado;
* la ficha puede requerir enriquecimiento posterior.

La aprobación por lotes no debe bloquear la interfaz ni aceptar silenciosamente grupos sin candidato como fichas completas.

# Multibanco

La identidad de una obra puede reutilizarse globalmente, pero la disponibilidad debe quedar aislada por `bank_id`.

Ejemplo:

```text
Identidad canónica:
The Walking Dead

Banco A:
temporadas 1–5

Banco B:
temporadas 1–10

Banco C:
temporadas 8–10
```

No repitas metadatos innecesariamente, pero nunca mezcles rutas ni disponibilidad de bancos diferentes.

Respeta todos los requisitos multibanco existentes del proyecto.

# Reimportación, reanudación e idempotencia

Importar nuevamente los mismos datos o encontrar contenido ya registrado no debe:

* duplicar obras;
* duplicar temporadas;
* duplicar episodios;
* duplicar archivos;
* duplicar alias;
* repetir llamadas innecesarias;
* perder decisiones humanas;
* cambiar identificadores canónicos;
* degradar una ficha confirmada;
* mezclar bancos;
* romper una operación reanudada.

La consolidación debe ser transaccional y segura frente a concurrencia.

Cuando dos procesos detecten simultáneamente la misma identidad, la base de datos debe impedir duplicados y permitir recuperar el registro canónico existente.

# Compatibilidad

Antes de modificar modelos o migraciones:

* inspecciona el esquema actual;
* reutiliza estructuras existentes;
* crea migraciones seguras;
* conserva datos;
* evita columnas o tablas redundantes;
* no rompas bases existentes;
* documenta cualquier cambio de esquema.

No sustituyas identificadores estables existentes sin una estrategia de migración.

# Pruebas obligatorias

Añade pruebas unitarias, de integración y de regresión que reproduzcan exactamente estos escenarios.

## Prefijos de orden

* `1009-MAKE IT RIGHT THE SERIES`
* extracción de `1009`;
* exclusión de `1009` de todas las consultas externas;
* conservación del original;
* reintento con título limpio.

## Años

* `Rambo 1 1990 HD H264 1080p`;
* título limpio `Rambo 1`;
* `anio_pista = 1990`;
* primera búsqueda sin año;
* segunda búsqueda con año solo cuando sea necesario;
* proveedor con filtro estructurado;
* proveedor sin filtro estructurado;
* año local incorrecto sin descartar automáticamente una coincidencia fuerte.

## Títulos numéricos

Verifica que no se dañen:

* `1984`
* `1917`
* `1899`
* `1923`
* `24`
* `300`
* `9-1-1`
* `2001 A Space Odyssey`
* `Blade Runner 2049`
* `2 Broke Girls`
* `3 Body Problem`
* `13 Reasons Why`
* `10 Things I Hate About You`
* `21 Jump Street`
* `50 First Dates`

## Secuelas

* `Rambo 1`;
* `Rambo 2`;
* `Rocky 4`;
* `Toy Story 3`;
* conservación del número;
* variantes de búsqueda controladas sin pérdida del original.

## Temporadas y episodios

* formatos `S01E03`, `01x03`, `Temp 2`, `Temporada 2`, `Cap 05`;
* extracción estructurada;
* eliminación del título base;
* asociación correcta con obra y temporada.

## Series distribuidas

Construye un caso de prueba donde:

* una serie tenga 10 carpetas de temporada;
* cada temporada tenga 22 videos;
* el resultado sea una obra lógica;
* existan 10 temporadas;
* no se realicen 10 enriquecimientos independientes.

Construye otro caso donde:

* temporadas 1 y 2 estén bajo una carpeta principal;
* temporada 3 esté en otra ruta;
* temporada 4 esté en una tercera ruta;
* todas terminen vinculadas a la misma obra.

## Spin-offs y títulos parecidos

Comprueba que no se fusionen:

* `The Walking Dead`;
* `Fear the Walking Dead`;
* `The Walking Dead: Daryl Dixon`;
* `The Walking Dead: Dead City`;
* `Tales of the Walking Dead`.

También:

* `CSI`;
* `CSI Miami`;
* `CSI New York`;
* `Narcos`;
* `Narcos Mexico`.

## Homónimos y remakes

* mismo título con años diferentes;
* mismo título y tipos de contenido diferentes;
* identificadores externos diferentes;
* prohibición de fusión automática.

## Identidad ya conocida

* identificar una obra;
* importar posteriormente otra temporada con alias diferente;
* encontrarla localmente;
* vincularla sin repetir enriquecimiento completo.

## Red de seguridad del proveedor

* crear dos grupos locales separados;
* hacer que ambos proveedores devuelvan el mismo identificador externo;
* consolidarlos en una sola identidad;
* conservar todos los archivos;
* no duplicar metadatos;
* repetir la operación y comprobar idempotencia.

## Extras

* archivo `Everytime_We_Touch_-_Frame_Book_(Cover)(360p).mp4`;
* detección como posible extra;
* no elección como representante cuando existan episodios;
* no contaminación del título de búsqueda;
* asociación correcta con la obra principal.

## Caché

* reutilización de consulta positiva;
* reutilización de identidad canónica;
* separación entre consulta sin año y consulta con año;
* invalidación selectiva de caché negativa contaminada;
* conservación de entradas válidas;
* cambio de versión del normalizador;
* ausencia de llamadas repetidas por archivo o temporada.

## Multibanco

* misma identidad en varios bancos;
* metadatos canónicos reutilizados;
* disponibilidad y rutas separadas;
* ninguna mezcla de inventarios.

## Revisión humana

* evidencia web visible;
* fila sin candidato estructurado claramente diferenciada;
* aprobación manual registrada como manual;
* “Aprobar todas” estable;
* ninguna ficha incompleta presentada como enriquecida;
* ausencia de bloqueo de interfaz.

## Estabilidad

* reimportación;
* reanudación;
* concurrencia;
* transacciones;
* restricciones de unicidad;
* publicación atómica;
* ausencia de duplicados;
* ausencia de regresiones.

# Pruebas con JSON reales

Los JSON reales de MSL utilizados temporalmente estarán en:

```text
samples/msl
```

Reglas obligatorias:

* MCE siempre debe importarlos desde la interfaz mediante el selector de archivos.
* No hagas que MCE lea automáticamente `samples/msl`.
* No conviertas esa carpeta en una fuente de producción.
* Úsalos únicamente durante pruebas controladas.
* Realiza pruebas intensivas de importación, limpieza, agrupamiento, enriquecimiento, reanudación, idempotencia, concurrencia y estabilidad.
* Antes de entregar la versión estable, elimina por completo:

  * `samples`;
  * copias derivadas de los JSON;
  * cachés de prueba;
  * fixtures temporales;
  * bases de datos temporales;
  * logs de prueba;
  * checkpoints;
  * archivos intermedios;
  * cualquier dato real residual.

No elimines fixtures sintéticos permanentes necesarios para la suite automatizada.

# Caso real que debe quedar corregido

Entrada:

```text
Grupo:
1009-MAKE IT RIGHT THE SERIES

Archivo representativo actual:
Everytime_We_Touch_-_Frame_Book_(Cover)(360p).mp4

Archivos agrupados:
28
```

Resultado esperado:

```text
titulo_original_grupo:
1009-MAKE IT RIGHT THE SERIES

prefijo_orden:
1009

titulo_base_obra:
MAKE IT RIGHT THE SERIES

titulo_busqueda:
Make It Right The Series
```

El archivo `Frame Book (Cover)` debe considerarse posible extra y no debe determinar la identidad de la obra.

MCE debe:

1. invalidar solamente el fallo negativo asociado a la consulta contaminada;
2. volver a ejecutar el flujo usando el título limpio;
3. buscar primero una identidad ya conocida;
4. consultar proveedores estructurados por obra única si sigue siendo necesario;
5. reutilizar el resultado para los 28 archivos;
6. conservar la trazabilidad completa;
7. no renombrar ningún archivo;
8. no duplicar la obra;
9. mostrar evidencia web si todavía no se obtiene candidato estructurado;
10. impedir que una aprobación sin candidato parezca una ficha enriquecida completa.

# Criterios de aceptación

La corrección no estará terminada hasta demostrar que:

* una serie distribuida se agrupa como una obra lógica;
* las temporadas no generan obras independientes;
* los episodios no generan llamadas independientes;
* los números legítimos de los títulos se conservan;
* los años se extraen sin perderse;
* el año se usa solo como pista;
* los prefijos de orden no llegan a los proveedores;
* los extras no determinan la identidad;
* las identidades conocidas se reutilizan;
* una segunda detección de la misma obra no duplica nada;
* un mismo identificador externo consolida grupos locales separados;
* los bancos mantienen inventarios aislados;
* la caché negativa contaminada no bloquea consultas limpias;
* la revisión humana explica claramente el estado;
* no se renombra ningún archivo físico;
* no se introducen regresiones;
* toda la suite permanece estable.

# Validaciones finales obligatorias

Ejecuta y reporta:

* pruebas unitarias nuevas;
* pruebas de integración nuevas;
* pruebas de regresión;
* suite completa de `pytest`;
* Ruff;
* mypy;
* pruebas de migración;
* pruebas de idempotencia;
* pruebas de concurrencia;
* pruebas de reanudación;
* prueba real del grupo de 28 archivos;
* prueba de serie con 10 temporadas y 220 archivos;
* prueba de temporadas distribuidas en varias rutas;
* prueba de reutilización de identidad ya confirmada;
* prueba multibanco;
* comprobación de ausencia de archivos temporales o datos reales residuales.

No reduzcas ni relajes las pruebas existentes para conseguir resultados verdes.

# Informe de entrega

Al finalizar, entrega un informe preciso con:

1. causa raíz confirmada;
2. comportamiento anterior;
3. comportamiento nuevo;
4. archivos modificados;
5. migraciones añadidas;
6. modelos o restricciones modificados;
7. reglas de normalización implementadas;
8. estrategia de números y años;
9. estrategia de agrupamiento;
10. estrategia para series distribuidas;
11. estrategia de identidad canónica;
12. estrategia de caché;
13. estrategia de consolidación;
14. comportamiento multibanco;
15. comportamiento actualizado de revisión humana;
16. ejemplos antes y después;
17. pruebas añadidas;
18. número y resultado de todas las pruebas;
19. resultado de Ruff;
20. resultado de mypy;
21. resultado concreto del grupo de 28 archivos;
22. confirmación de que no se renombraron archivos físicos;
23. confirmación de que no se fusionaron spin-offs;
24. confirmación de que los títulos numéricos siguen funcionando;
25. confirmación de limpieza completa de datos reales y temporales.

No afirmes que la corrección está terminada solamente porque las pruebas antiguas pasan. Debes añadir pruebas nuevas que reproduzcan cada uno de los fallos y escenarios descritos.

Si durante la inspección descubres que alguna parte ya está implementada, no la dupliques. Verifica su comportamiento, refuérzala cuando sea necesario y añade las pruebas que demuestren que cumple todos estos requisitos.
