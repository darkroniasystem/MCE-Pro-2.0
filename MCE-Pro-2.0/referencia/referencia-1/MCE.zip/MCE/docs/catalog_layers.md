# Capas del catálogo

Cada obra persistida declara exactamente una capa mediante `contents.catalog_stage`:

- `staging`: candidatos, datos provisionales y resultados aún no confirmados;
- `approved`: obras y metadatos aceptados por revisión humana;
- `published`: datos habilitados para consumidores futuros.

PostgreSQL restringe la columna a esos tres valores y la indexa. Las lecturas usan
`CatalogLayerRepository`, que expone métodos separados y no combina capas. El flujo
de aprobación solo promueve de staging a aprobado. La Fase 16 no contiene ninguna
operación capaz de promover a publicado.

La pantalla Catálogo representa aprobados. Finalización los identifica como
`aprobado · pendiente de publicación`; no afirma que ya sean el catálogo activo de
los futuros bots. La creación y activación atómica de una versión publicada pertenece
exclusivamente a la Fase 17.
