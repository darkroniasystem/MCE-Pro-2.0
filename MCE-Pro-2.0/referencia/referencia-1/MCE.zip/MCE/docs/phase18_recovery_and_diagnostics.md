# Fase 18: recuperación e integridad

Al abrir MCE se ejecuta una inspección de solo lectura antes de construir los
repositorios PostgreSQL. Comprueba conexión, revisión de Alembic, tablas
esenciales, referencias básicas, unicidad de la versión activa, configuración,
espacio, caché, checkpoints y presencia de credenciales opcionales sin mostrar
sus valores.

Si falla PostgreSQL, el esquema, la integridad o la configuración, MCE abre en
**modo seguro**. La navegación, exportación, backup, restauración y diagnóstico
siguen disponibles, pero se bloquean importaciones persistentes, sesiones,
revisiones, decisiones de duplicados y publicaciones. Así no se escribe sobre
una base incompatible.

## Backup y restauración

La página **Diagnóstico** permite crear dumps PostgreSQL en formato custom. Las
credenciales se pasan a las herramientas oficiales mediante el entorno y nunca
forman parte de la línea de comandos ni de los logs.

Antes de restaurar, MCE:

1. valida el archivo seleccionado con `pg_restore --list`;
2. crea un dump nuevo `mce-before-restore-<fecha>.dump` del destino actual;
3. valida ese punto de restauración;
4. solo entonces ejecuta la restauración con parada ante el primer error.

Si no puede crear o validar el punto previo, el destino permanece intacto. Una
restauración de la base principal requiere la confirmación explícita mostrada
por la interfaz.

## Paquete de diagnóstico

**Generar paquete** crea atómicamente un ZIP con contrato
`mce.diagnostic.v1`, versión de MCE y Windows, etapa, identificadores de sesión
y escaneo cuando existan, `bank_id` anonimizado, error, traceback, proveedor,
estadísticas, migración y versiones de clasificador/reglas. Incluye como máximo
los últimos 200 000 caracteres de logs.

Se redactan claves API, contraseñas, tokens, secretos y credenciales incluidas
en URL. El paquete no incluye archivos de configuración, bases, cachés,
originales ni inventarios JSON.
