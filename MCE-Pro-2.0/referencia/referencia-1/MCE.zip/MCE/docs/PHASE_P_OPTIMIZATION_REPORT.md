# Fase P — Optimización guiada por benchmark

Fecha: 2026-08-20

## Alcance

Esta fase cambió únicamente decisiones justificadas por la Fase O. No aumentó
la concurrencia, no relajó umbrales de aprobación y no añadió llamadas.

## Optimizaciones aplicadas

### Orden de proveedores web

El orden predeterminado pasa a:

1. Exa, prioridad 10.
2. Serper, prioridad 20.
3. Tavily, prioridad 30.
4. Browser, prioridad 40.

Exa y Serper lograron 5/5 coincidencias exactas. Exa fue el más rápido en la
corrida reproducida: 835 ms de media frente a 1,174 ms de Serper. Tavily no
pudo medir calidad porque confirmó cuota agotada en ambas corridas.

Con la línea base medida, el camino habitual cambia de Tavily limitado más
Serper, aproximadamente 1,578 ms y dos intentos, a Exa, aproximadamente 835 ms
y un intento cuando su evidencia sea suficiente. Es una reducción estimada de
47 % en ese camino, sin paralelismo ni consumo duplicado.

Las prioridades siguen siendo configurables. La interfaz migra una sola vez los
antiguos valores predeterminados; no pisa valores que el usuario haya
personalizado.

### Seguridad de Qwen y Groq

Los decodificadores de ambos analizadores degradan inmediatamente una propuesta
`approve` a revisión humana si cita alguna URL que no estaba en la evidencia
entregada. El validador determinista final permanece como una segunda barrera.

La validación real de Groq volvió a reproducir la anomalía de Spirited Away:
citó una fuente no suministrada. Después de la corrección, el título quedó en
revisión humana. Resultado del lote real: 5/5 JSON válidos, 5/5 títulos exactos,
cuatro aprobaciones seguras, una revisión humana y cero aprobaciones inseguras.

### Browser

Browser sigue desactivado por defecto, con concurrencia uno y exclusivamente al
final de las APIs. Ahora:

- descarta resultados cuyo título y descripción no comparten términos
  distintivos con la consulta;
- exige dos coincidencias para consultas largas o multilingües;
- elimina términos genéricos de medio, reparto y dirección;
- resuelve las redirecciones de Bing hacia la URL pública real antes de crear
  evidencia;
- convierte un lote completamente ajeno en `no_evidence` en lugar de pasarlo a
  Qwen o Groq.

La comprobación real combinada sobre las cinco obras dejó una coincidencia útil
para Dark y descartó los cuatro lotes ajenos. Money Heist fue reprobado después
del segundo endurecimiento y devolvió cero evidencia. Los falsos positivos de
evidencia Browser pasaron de 4/5 a 0/5 en este lote.

La navegación continúa siendo lenta, entre aproximadamente 8.6 y 20.2 segundos
en la validación posterior. No se intentó ocultar esa latencia con concurrencia:
la optimización consiste en evitar Browser cuando Exa o Serper ya resolvieron y
en no propagar evidencia incorrecta cuando llegue a usarse.

## Decisiones que no se cambiaron

- Concurrencia web: 1.
- Concurrencia Browser: 1.
- Concurrencia Qwen: 1.
- Umbral y validación determinista de aprobación: sin relajación.
- Número máximo de resultados Browser: sin cambio.
- Modelo y límite de salida Qwen: sin cambio por falta de evidencia suficiente
  para reducirlos sin riesgo de perder información.
- Tavily permanece disponible y configurable; solo cambió su prioridad por
  defecto.

## Aislamiento

No se conectó ni modificó PostgreSQL real, el catálogo maestro ni las siete
sesiones. Las pruebas usaron memoria, SQLite temporal, dobles y consultas web de
solo lectura expresamente limitadas.

## Puerta de fase

La Fase P termina después de la regresión definitiva. La Fase Q corresponde a
UI y no se inicia sin autorización separada.
