# Continuidad: motor de obra logica

## Autoridad y objetivo

La especificacion autorizada y completa esta en docs/LOGICAL_WORK_ENGINE_SPEC.md. Debe cumplirse integramente, sin reducir el trabajo a _clean_bank_noise() ni a un cambio de GROUPING_VERSION.

## Estado actual

En curso: endurecimiento posterior a la prueba real de Doramas. El lote termino
158/158, pero MCE permanece en modo de prueba hasta resolver y validar las diez
correcciones siguientes con datos aislados.

## Plan activo de diez correcciones

1. Informe exacto y auditable por obra y resumen final de lote.
2. Limites Groq persistentes, motivo de cuota y renovacion real o conservadora.
3. Menor dependencia de Groq mediante identidad, cache y saltos seguros.
4. Consultas escalonadas con alias y parada temprana por coincidencia segura.
5. Qwen estructurado con evidencia suficiente y razones de escalamiento.
6. Aprendizaje seguro para reglas locales, sin alterar originales.
7. Repreparacion local en revision humana, sin sacar obras de revision antes de tiempo.
8. Telemetria completa de llamadas, rutas, cache, tiempos y resultados.
9. Recuperacion de PostgreSQL y degradacion segura de consultas informativas.
10. Validacion integral aislada y puerta explicita para salir del modo de prueba.

Las diez correcciones quedaron implementadas en codigo fuente y pasan la puerta
automatizada aislada descrita al final de este documento. MCE permanece cerrado al
PostgreSQL real durante esta validacion; la salida definitiva del modo de prueba
requiere todavia un lote real pequeno y observado, no una suposicion basada en tests.

## Resultado de las diez correcciones - 2026-08-13

1. Cada obra emite `enrichment_work_audit` sin rutas privadas y cada lote termina
   con `enrichment_batch_summary`: totales, resultados, llamadas, cache, rutas IA,
   tiempo activo, restantes y motivo de espera.
2. Groq conserva el bloqueo en SQLite entre reinicios, lee los reinicios de
   solicitudes y tokens, distingue plazo autoritativo de espera conservadora y
   aumenta esta ultima ante 429 repetidos. Enriquecer/Reanudar no inicia mientras
   el bloqueo persistido siga vigente.
3. La identidad canonica local y sus alias se prueban antes de proveedores; las
   huellas ya agotadas y la cache siguen evitando llamadas duplicadas.
4. La consulta limpia transporta alias locales en un unico intento, se detiene ante
   identificacion segura y solo agrega el ano estructurado cuando hace falta
   desambiguar. La busqueda web queda reservada al ultimo escalon.
5. Qwen recibe alias y evidencia estructurada. El validador admite sufijos inocuos
   de una fuente (tipo o ano), pero conserva 95 puntos, dos dominios, ausencia de
   contradicciones y URLs publicas. Sin dos dominios, no se gasta Groq porque el
   modelo remoto no puede inventar una segunda fuente independiente.
6. Las repreparaciones confirmadas dejan una senal auditable en
   `normalization_trace`; no cambian reglas automaticamente ni tocan originales.
7. Revision humana incorpora `Repreparar localmente`, incluso para varias filas:
   limpia y guarda el titulo, pero conserva `REVIEWED`, `WARNING` y
   `needs_human_review`. `Limpiar y reintentar` continua siendo la accion explicita
   que envia el grupo a Pendientes.
8. La interfaz registra el resumen final del lote en Historial y la telemetria de
   Groq muestra tipo de cuota, procedencia del plazo, omitidas, latencia y ruta
   Qwen-Groq.
9. La carga de Enriquecimiento reintenta una lectura desconectada una vez y degrada
   a la ultima instantanea visible. Un fallo de la metrica de completitud ya no
   oculta las categorias y se registra de forma breve, sin un traceback masivo.
10. Validacion aislada: 33 pruebas de procesamiento/Qwen/orquestacion/Groq
    aprobadas; persistencia del bloqueo verificada creando, reabriendo y
    retirando una SQLite temporal; Ruff, mypy y compileall limpios. La prueba que
    usa `tmp_path` sigue bloqueada por el ACL WinError 5 externo a MCE. No se conecto
    ni modifico PostgreSQL real ni las sesiones existentes.

La especificacion fue copiada byte por byte desde el adjunto autorizado:

- longitud: 32948 bytes;
- SHA-256: B9197DF50B9E99D7A24F4FAA89E8C51948AD0B69FE9F258C97751C308AE5DC2B;
- origen y destino: identicos.

## Salvaguardas obligatorias

- No conectar, migrar ni modificar PostgreSQL real.
- No modificar las siete sesiones existentes.
- No renombrar, mover, eliminar ni modificar archivos fisicos inventariados.
- Las pruebas con persistencia usaran solo dobles, datos sinteticos o bases aisladas y descartables.
- No ejecutar herramientas de provision, reparacion, restauracion, importacion real ni migracion contra el entorno real.
- No relajar pruebas existentes.
- No declarar terminada la correccion hasta demostrar todos los criterios de aceptacion.

## Plan por bloques verificables

### Bloque 0 - Auditoria y matriz de brechas (completado)

- Modelos, migraciones, restricciones, importacion y preparacion auditados.
- Agrupamiento, proveedores, cache, identidad, multibanco y revision auditados.
- Matriz de reutilizacion y brechas registrada abajo.

### Bloque 1 - Normalizacion y senales estructuradas (en curso)

- Preservar originales y separar titulo, prefijo, ano, temporada, episodio, extras y etiquetas.
- Proteger titulos numericos y secuelas.
- Centralizar reglas, version y explicaciones.
- Completar persistencia y pruebas del documento.

### Bloque 2 - Agrupamiento conservador y series distribuidas (en curso)

- Agrupar sin depender de carpeta padre, temporada o episodio.
- Evitar fusiones de spin-offs, homonimos, anos incompatibles, tipos o IDs distintos.
- Elegir representante estable evitando extras.
- Cubrir 10 temporadas/220 archivos y temporadas distribuidas.

### Bloque 3 - Reutilizacion local, consulta escalonada y cache (en curso)

- Buscar primero identidades, alias y decisiones conocidas.
- Consultar una vez por obra; usar ano solo para desambiguar.
- Separar claves por proveedor, variante, tipo, idioma, ano y version.
- Invalidar negativos contaminados selectivamente.

### Bloque 4 - Identidad canonica, consolidacion y multibanco (pendiente)

- Consolidar por identificador externo de forma idempotente y transaccional.
- Impedir duplicados bajo concurrencia.
- Reutilizar metadatos manteniendo rutas y disponibilidad aisladas por bank_id.
- Preservar reimportacion, reanudacion y publicacion atomica.

### Bloque 5 - Revision humana (en curso)

- Diferenciar candidato estructurado, evidencia web y ausencia de identificacion.
- Registrar aprobacion manual como manual e incompleta.
- Mantener estable y no bloqueante la aprobacion por lotes.
- Implementado Limpiar y reintentar para devolver solo el grupo corregido a
  ready_for_enrichment, preservando originales y resultados consolidados.
- Definidas siete categorias enriquecibles: peliculas, series, novelas, doramas,
  anime, concursos y animados. Combo permanece como origen mixto.

### Bloque 6 - Validacion integral y limpieza (pendiente)

- Ejecutar pruebas unitarias, integracion, regresion, migracion aislada, idempotencia, concurrencia y reanudacion.
- Ejecutar suite completa, Ruff, mypy, compilacion y salud de dependencias.
- Validar grupo de 28 archivos, serie 10x22, rutas distribuidas, identidad conocida y multibanco.
- Confirmar ausencia de muestras reales y residuos temporales.
- Preparar el informe de entrega con los 25 apartados requeridos.

## Matriz de auditoria inicial

### Reutilizable y confirmado

- FilenameNormalizationPipeline ya conservaba original, tokens, pistas, candidatos y trazas.
- LocalPreparationService ya separaba clasificacion, limpieza y agrupamiento sin proveedores.
- SessionPipelineService ya congelaba grupos y hacia una consulta por work_group_id por ejecucion.
- La cache SQLite ya separaba consultas mediante IdentificationQuery.
- Ya existen alias, IDs externos, metadatos, disponibilidad por banco, reanudacion y publicacion atomica.
- La revision por lotes ya es asincrona y no debe reescribirse.

### Brechas confirmadas

- El ano local se enviaba en la primera consulta.
- Faltaban senales de prefijo, temporada sin episodio, extra y version del normalizador.
- El agrupamiento episodico dependia demasiado de la carpeta.
- El primer archivo podia ser representante aunque fuera extra.
- contents se deriva por bank_id aunque availabilities ya aisla inventarios.
- El ORM no expresa claramente la unicidad global pretendida por la migracion 0003.
- Falta busqueda local previa a proveedores.
- Falta persistir nueva trazabilidad y probar la migracion aislada.
- La revision necesita estados explicitos para evidencia web, ausencia de candidato y manual incompleta.

## Resultados verificados

- Todos los titulos numericos y secuelas exigidos estan protegidos.
- Los anos contextuales se extraen de parentesis, corchetes, guion o ruido tecnico.
- El prefijo de orden es conservador y trazable.
- Temporadas sin episodio y extras se detectan.
- La consulta usa variante y version explicitas.
- El primer intento no usa ano; el segundo usa pista estructurada solo si hace falta.
- El respaldo web no se ejecuta antes del reintento con ano.
- El representante prioriza archivos no extra.
- 67 passed: normalizacion.
- 27 passed: preparacion y pipeline aislado.
- 52 passed: identificacion y cache.
- 8 passed: servicio de procesamiento.
- Suite final no-PostgreSQL: 420 passed, 5 deselected.
- La regresion waiting_review/waiting_internet fue corregida y verificada.
- Las pruebas PostgreSQL no se ejecutaron: la URL de prueba fue eliminada de forma explicita para proteger el entorno real.
- Alembic: 0021 es el unico head.
- Ruff: limpio.
- mypy: limpio en 157 archivos.
- Migracion 0021 creada pero no ejecutada contra PostgreSQL.
- canonical_works proporciona identidad estable compartida sin mezclar inventarios por banco.
- La busqueda local reutiliza identidad y alias confirmados antes de proveedores.
- El grupo sintetico de 28 archivos, la serie 10x22 y las temporadas distribuidas pasan.
- Las aprobaciones sin candidato quedan manual_unverified y bloqueadas para publicacion automatica.
- 45 passed: preparacion local y sesiones aisladas tras agregar concurso y
  pending_normalization_retry.
- Ruff: limpio tras los cambios de categorias y revision humana.
- La validacion amplia de widgets intento consultar el PostgreSQL configurado y
  fallo en SELECT por ausencia de canonical_works; no hubo escritura. No repetir
  UI hasta provisionar un entorno PostgreSQL aislado.

## Registro

- 2026-08-08: punto de continuidad creado sin tocar PostgreSQL real ni sesiones.
- 2026-08-08: especificacion recibida, leida y guardada con identidad byte por byte.
- 2026-08-08: Bloque 0 auditado.
- 2026-08-08: primera parte del Bloque 1 y consulta escalonada implementadas con datos sinteticos.
- 2026-08-08: siete categorias enriquecibles y Limpiar y reintentar implementados;
  pruebas de dominio aisladas en verde sin modificar las siete sesiones.
- 2026-08-08: distribucion PyInstaller reconstruida desde MCE.spec; 2 pruebas de
  paquete aprobadas, 875 archivos verificados, sin secretos ni samples. EXE
  SHA-256 C5F2C278A30E1852DAF146166575C51E583BBBE4EC7ADDB37E95ECCD22CB80F2.
- 2026-08-08: backup real validado antes de migrar:
  mce-phase18-20260808-073400.dump, 51.656.234 bytes, SHA-256
  5E34F48E7B1C3EEE0E968FF1450637245A99BD56129D62B37AB503C5957A90E5.
- 2026-08-08: catalogo maestro unico configurado en localhost:5432/mce migrado
  transaccionalmente de 0020 a 0021. Se conservaron 26 sesiones, las siete
  operativas y 206 contenidos; 206 identidades canonicas vinculadas, cero
  duplicados por proveedor/tipo/id externo.
- 2026-08-08: revision humana restaurada desde PostgreSQL al reiniciar mediante
  consulta resumida: 7 sesiones, 33 filas de enriquecimiento y 71 obras
  pendientes visibles. El caso MAKE IT RIGHT conserva sus 28 item_ids.
- 2026-08-08: EXE definitivo SHA-256
  6ECE07A022623117D4646FD8DD392E7C4F230E91BCB29664E05E6C3B0DE07E7A;
  arranque verificado con safe_mode=false.
- 2026-08-08: Limpiar y reintentar propone automaticamente el titulo normalizado
  antes de confirmarlo. Las reglas de etiquetas operativas finales se validaron
  contra los casos Manga/Ghibli y protegen numeros y titulos legitimos.
- 2026-08-08: distribucion reconstruida y verificada (875 archivos, sin secretos
  ni dependencia de samples); 50 pruebas aisladas aprobadas. EXE SHA-256
  641494963A43448B37369F1110A06839DAF1F33A72C545389B70CFC2AD11BEEA.
- 2026-08-08: los grupos confirmados mediante Limpiar y reintentar se separan
  como categoria virtual Pendientes en Enriquecimiento selectivo, conservando
  su categoria real para elegir proveedores e identidad canonica.
- 2026-08-08: 51 pruebas aisladas aprobadas; distribucion verificada con 875
  archivos, sin secretos ni samples. EXE SHA-256
  A9EBC337FB4994DE5DDF74FEAB03B6DEAE2C99C6BCB34A8B80AA80F110117C6D.
- 2026-08-08: se agrego un historial persistente de huellas de consulta por
  obra. Pendientes omite titulo/tipo/ano/variante ya agotados, incluidos
  resultados vacios, y solo consulta de nuevo cuando la correccion cambia.
- 2026-08-08: 56 pruebas aisladas aprobadas; distribucion verificada con 875
  archivos. EXE SHA-256
  89314288074B3437705BA067CA8B2D6744880BD354536325E0380F67B95BB665.

## Proximo paso

### Interfaz panoramica aprobada: bloque implementado

- Ventana inicial 1600x900, minimo adaptable 1280x720 y navegacion lateral de 210 px.
- Clasificacion muestra solo banco, estado, progreso y contadores operativos; sesion,
  etapa e importacion siguen disponibles en Detalles.
- Enriquecimiento presenta exactamente siete categorias fijas mas Pendientes; las
  sesiones, bancos y presupuestos por proveedor permanecen en Detalles.
- Revision humana oculta ID e identificacion redundante y muestra grupo, titulo,
  archivos agrupados, ruta, tipo, confianza y Coincidencia.
- Detalles conserva todos los campos publicos y permite copiarlos.
- Verificacion aislada: 6 pruebas de presentadores y 3 pruebas de widgets aprobadas;
  Ruff limpio. No se conecto PostgreSQL real.

### Fase 12: revision automatica mediante IA y busqueda web

- Especificacion adjunta leida completamente antes de implementar.
- Documentacion oficial actual verificada para google-genai, Google Search grounding
  y tavily-python.
- Dependencias declaradas en pyproject; la instalacion local agoto el tiempo y no
  instalo paquetes, por lo que aun no hay llamadas reales ni claves configuradas.
- Creado el nucleo application/ai_review con contratos versionados, estados,
  orquestador por obra unica, huella estable, puertos, cache/cuota sustituibles y
  validador determinista independiente del modelo.
- La autoaprobacion exige score >=95, dos dominios publicos independientes, titulo y
  tipo presentes, y cero contradicciones. Una sola fuente nunca autoaprueba.
- 4 pruebas sinteticas aprobadas: fuentes, contradicciones, URL privada, cache,
  idempotencia y cuota previa a proveedores. Ruff limpio.
- SDK instalados y verificados: google-genai 1.75.0, tavily-python 0.7.27 y
  pydantic 2.13.4.
- Tavily real aprobado con una busqueda basic de un resultado.
- Gemini real responde 400 FAILED_PRECONDITION porque la ubicacion del usuario no
  esta admitida por Google. La clave no se mostro y no se guardo en el proyecto.
- Pipeline integrado opcionalmente despues de proveedores insuficientes, una vez por
  obra logica, con procedencia mce-ai, sanitizacion, JSON estricto, cache y cuota
  persistentes en SQLite.
- Fallos, cuota o restriccion de Gemini degradan a revision humana; nunca aprueban ni
  hacen fallar toda la sesion.
- 26 regresiones de runtime/pipeline aprobadas y 8 pruebas especificas de integracion
  y degradacion IA aprobadas. PostgreSQL real no fue consultado ni modificado.
- Groq sustituye a Gemini como analizador principal. Modelos configurados:
  openai/gpt-oss-120b y fallback finito openai/gpt-oss-20b; Qwen queda opcional.
- La conexion y disponibilidad de los tres modelos se verificaron sin generar
  contenido. Una prueba real aislada con GPT-OSS 120B produjo JSON estricto,
  dos fuentes verificadas y fue validada por MCE sin publicar ni persistir en
  PostgreSQL.
- Gemini se conserva como adaptador deshabilitado por defecto debido al bloqueo
  regional ya observado.
- La interfaz incluye activacion Groq, modelo principal, fallback, modo de prueba,
  limite diario y diagnostico de conexion que no consume una generacion.
- La huella de cache incluye proveedor de busqueda, proveedor/modelo IA, prompt,
  esquema y senales locales. Solicitudes concurrentes identicas comparten un solo
  trabajo y las siguientes reutilizan cache.
- La trazabilidad IA se conserva en el estado reanudable de la sesion. Se creo la
  migracion 0022 para auditoria persistente, pero no se aplico a PostgreSQL real.
- Verificacion focalizada Groq/pipeline: 20 pruebas aprobadas; Ruff y mypy limpios.
- Validacion final sin PostgreSQL: 445 pruebas aprobadas y 5 deseleccionadas.
  Ruff limpio y mypy limpio en 166 archivos fuente.
- Esquema ai_review_runs creado y eliminado correctamente en SQLite descartable.
- La suite PostgreSQL no se ejecuto: el entorno exponia mce_test en revision 0021
  y fue excluido sin migrarlo ni modificar el catalogo real o las siete sesiones.
- Distribucion reconstruida: 908 archivos; modulos Groq confirmados dentro del PYZ,
  clave GROQ real no embebida y arranque aislado correcto con PostgreSQL y Groq
  deshabilitados. SHA-256 del EXE:
  0C8FC5F167CEB1F059E30C196AED2D536FEA82779EFB922E28ECB224FF531B8D.
- Prueba real controlada completada con obra sintetica Vagabond 2019: Tavily y
  openai/gpt-oss-120b respondieron, cinco fuentes fueron verificadas y MCE calculo
  100/100. El Modo de prueba bloqueo la autoaprobacion y envio el resultado a
  revision humana. El segundo intento reutilizo cache con la misma huella. La base
  SQLite temporal fue eliminada; PostgreSQL y las sesiones no se tocaron.
- 2026-08-09: antes de habilitar 0022 se creo y valido el respaldo
  mce-phase18-20260809-060837.dump, 51.831.654 bytes, SHA-256
  7E90028AF3177BB573232123772FD9D2C83712D0F8882E1B60CDC8B0B8758D08.
- La migracion real 0021 -> 0022 se aplico de forma transaccional con autorizacion
  explicita. Se conservaron 26 sesiones, 206 contenidos y 324.715 elementos de
  sesion; cero referencias huerfanas y cero filas iniciales en ai_review_runs.
- El ejecutable se reinicio con Modo de prueba IA: migrations=ok, integrity=ok,
  safe_mode=false y tres credenciales opcionales detectadas sin mostrar valores.
- 2026-08-09: el primer lote real de Doramas termino 400/400: 100 obras
  enrichment_complete y 300 needs_human_review. Al final Groq produjo rafagas 429
  y el SDK/fallback multiplicaba intentos sobre la misma obra.
- Corregido el control Groq: max_retries ocultos del SDK desactivados, ritmo minimo
  preventivo, lectura de limites restantes, espera de Retry-After y un solo reintento
  sobre el mismo modelo. Un 429 nunca consume el fallback.
- Verificacion: 22 pruebas focalizadas y 447 pruebas no-PostgreSQL aprobadas;
  5 deseleccionadas. Ruff y mypy limpios. Distribucion reconstruida, EXE SHA-256
  3EC83CA8D28F2D1B30A3B725BA55B787F619AADB5AF53882A159E61E655122BF.
- 2026-08-09: Enriquecimiento muestra telemetria en vivo por proveedor para
  TMDb, AniList, TVMaze, Wikidata, Fanart.tv, Tavily web y Groq IA: llamadas
  HTTP reales, exitos, errores, respuestas 429, aciertos de cache, cupo restante,
  tokens restantes cuando el proveedor los informa y ritmo medio por minuto.
- Los contadores distinguen cache de llamadas externas. En Groq tambien se
  registra el uso del fallback y los reintentos por limite cuentan como intentos
  independientes, sin ocultarlos en el SDK.
- La seleccion consolidada de una categoria ahora crea una cola por sesion y
  procesa solamente categorias que aun conservan obras ready_for_enrichment.
  Esto evita que la fila visual consolidada use solo la primera sesion y deja
  fuera sesiones/categorias ya procesadas.
- Validacion aislada: 32 pruebas de widgets aprobadas; 448 pruebas sin PostgreSQL
  aprobadas y 5 deseleccionadas. Ruff limpio y mypy limpio en 166 archivos.
- Distribucion reconstruida con 908 archivos. SHA-256 del ejecutable:
  D349A10AF5014DA230146BD4A365B1A53734CA48EDAFAC35B50CD7A78F56772C.
- La ejecucion inicial con el marcador not postgres revelo que 32 pruebas de
  integracion PostgreSQL no tienen ese marcador y que mce_test sigue en 0021;
  fallaron en preparacion por ausencia de ai_review_runs. No se migro, trunco ni
  modifico PostgreSQL durante esta validacion; la repeticion excluyo explicitamente
  tests/integration/postgresql.
- 2026-08-09: se verifico en PostgreSQL real mediante una transaccion de solo
  lectura que la preparacion local permanece guardada: 6 sesiones con elementos
  listos, 286.775 archivos y 31.116 obras; cero sesiones listas con resumen vacio.
- Enriquecimiento ahora muestra una columna Preparacion con Guardada y la cantidad
  de sesiones incluidas. Las categorias sin datos se identifican como No preparada.
- Preparar local detecta una sesion ya preparada, refresca sus agregados y muestra
  Preparacion ya guardada sin volver a clasificar, limpiar o agrupar sus archivos.
- Se repararon los textos UTF-8 del panel de proveedores. Validacion final:
  39 pruebas focalizadas y 448 pruebas sin PostgreSQL aprobadas, 5 deseleccionadas;
  Ruff y mypy limpios. EXE SHA-256:
  BFE2164B3326705A22731B0B3E731CF0E0D669115633BD6D2F753726346E20F2.

### Completitud real del catalogo

- Finalizacion incluye un panel con porcentaje estricto por obra logica.
- Formula principal: obras resueltas / total de obras elegibles. Las pendientes de
  revision no elevan el porcentaje hasta resolverse; los rechazos humanos cuentan
  como resueltos porque ya no pertenecen al catalogo publicable.
- Se muestra aparte la cobertura de enriquecimiento, obras en revision y obras sin
  procesar. El Panel general muestra el mismo porcentaje.
- La lectura PostgreSQL es agregada y de solo lectura sobre processing_session_items;
  no materializa archivos fisicos ni modifica las sesiones.
- 4 pruebas aisladas del calculo y el widget aprobadas; Ruff y mypy limpios en los
  modulos modificados. La consulta PostgreSQL real no se ejecuto.

## Proximo paso

Validar visualmente que la columna Preparacion muestra Guardada en las categorias
con datos y No preparada en las vacias. Iniciar despues un lote pequeno en Modo de
prueba IA y comprobar que los contadores de Tavily y Groq coinciden con el registro.

### Motor web multiproveedor y Qwen local - 2026-08-10

IMPLEMENTADO:

- Adaptadores Serper y Exa junto al Tavily existente.
- Gestor secuencial configurable Tavily -> Serper -> Exa que se detiene al reunir
  evidencia suficiente y salta timeout, 429, circuito abierto o respuesta inutil.
- Cache web compartida v2 independiente del proveedor, con reutilizacion de cache
  Tavily anterior y trazabilidad del proveedor original.
- Cliente Ollama local opcional, diagnostico, limite de concurrencia 1, contexto
  acotado, JSON Pydantic estricto y un solo retry de formato.
- Cadena Qwen -> validador MCE -> Groq, con Groq omitido cuando Qwen es aceptado.
- Deteccion explicita de URLs inventadas para Qwen y Groq.
- Interfaz para activar/priorizar los tres proveedores y probar Ollama/Qwen.

PROBADO REALMENTE:

- Una consulta aislada identica por proveedor, sin PostgreSQL ni sesiones:
  Tavily 3 resultados/3 dominios en 1.707 ms; Serper 3/3 en 4.593 ms;
  Exa 3/3 en 2.470 ms.

PROBADO CON SIMULACION:

- Prioridad, parada temprana, fallback, cache compartida, parse Qwen, retry,
  fuente inventada y omision/uso correcto de Groq.
- 29 pruebas focalizadas del nucleo y 45 de integracion visual/IA aprobadas;
  Ruff y mypy limpios en 167 archivos antes del ajuste final de aliases.

CIERRE DE VALIDACION:

- Ollama y qwen2.5:3b instalados: diagnostico e inferencia reales correctos.
- Flujo real aislado: Tavily se detuvo con evidencia suficiente, Serper/Exa no
  recibieron llamadas; Qwen resolvio el caso fuerte y Groq recibio 0 llamadas.
- Un caso no aceptado por Qwen escalo correctamente a Groq y la segunda consulta
  reutilizo cache sin otra llamada externa.
- Benchmark v2 de 50 variantes dificiles: 0 errores, 0 URLs inventadas, 56 % de
  titulo canonico exacto, 2 aprobaciones estrictas y 0 aprobaciones incorrectas;
  media 12.447 ms, p50 12.299 ms, p95 15.514 ms.
- Se agrego respaldo obligatorio del titulo canonico por dos dominios, circuito
  Ollama, cooldown y conteo de timeouts. Los casos inciertos escalan; no se
  autoaprueban por confianza del modelo.
- Regresion final: 457 pruebas sin PostgreSQL aprobadas y 5 pruebas externas
  deseleccionadas. Ruff limpio y mypy limpio en 168 archivos.
- Interfaz aislada: ventana 1600x900, controles Tavily, Serper, Exa, Ollama y
  Probar Ollama y Qwen presentes; 36 pruebas de interfaz aprobadas.
- Distribucion final reconstruida con 908 archivos, sin secretos ni muestras.
  El modulo mce.infrastructure.local_ai esta incluido y el EXE arranco con rutas
  aisladas y PostgreSQL desactivado.
- SHA-256 de dist/MCE/MCE.exe:
  3A31FB5FC4BA7C2D29B2D5C9E5E38FFCC65EB1099AB2D7FBC6FC7F403E26C740.
- PostgreSQL real y las sesiones existentes no fueron abiertos ni modificados.

PENDIENTE OPERATIVO:

- Hacer el primer lote pequeno en Modo de prueba IA y confirmar visualmente la
  mezcla real Qwen/Groq antes de desactivar ese modo para publicación definitiva.

### Prueba de optimizacion Qwen - 2026-08-10

- Se compararon los mismos 50 casos con 400 tokens/4.000 caracteres contra la
  referencia productiva de 800 tokens/8.000 caracteres.
- La candidata produjo 2 errores, redujo la exactitud canonica de 56 % a 54 % y
  el lote total aumento de 622 a 701 segundos. La media por respuesta bajo solo
  de 12.447 a 12.007 ms, una mejora insuficiente frente a la perdida de calidad.
- Optimizacion rechazada. MCE conserva 800 tokens y 8.000 caracteres para no
  perder informacion del catalogo. El ejecutable final anterior sigue vigente.

### Correccion posterior al primer lote vigilado - 2026-08-10

- El lote observado proceso 8 obras mediante 8 respuestas Groq 200 OK, pero no
  dejo evidencia de llamadas Qwen. La preferencia de Ollama tenia un valor
  predeterminado desactivado; ahora Qwen queda habilitado por defecto cuando el
  usuario aun no ha guardado una eleccion. Una desactivacion explicita se respeta.
- La cadena Qwen -> Groq registra por obra una de tres rutas: Qwen aceptado,
  Qwen insuficiente -> Groq o Qwen fallo -> Groq. Los errores se limitan a un
  mensaje seguro y nunca incluyen claves ni rutas privadas.
- La telemetria muestra siempre la fila Qwen. Si esta desactivado lo dice de
  forma explicita; si esta activo muestra llamadas, aceptadas, escaladas a Groq,
  timeouts, circuito y latencia media. Groq muestra latencia media y distingue
  respaldo entre modelos de escalado procedente de Qwen.
- El progreso visible se denomina ahora Lote actual y registra al inicio el total
  congelado de obras y las categorias seleccionadas. Esto evita confundir el
  contador de un lote nuevo con el acumulado ya guardado de la sesion/categoria.
- Se asignaron alturas minimas al panel de progreso y a la tabla de proveedores
  para que sus metricas no desaparezcan al repartirse el espacio vertical.
- Validacion aislada: 11 pruebas de Qwen/Groq/telemetria y 12 pruebas del servicio
  de procesamiento aprobadas; Ruff y mypy limpios en los cinco modulos tocados.
  La regresion amplia alcanzo el codigo restante, pero pytest no pudo completar
  ni resumir los casos que usan tmp_path por un WinError 5 del directorio temporal.
  No se conecto ni modifico PostgreSQL real y no se abrieron las sesiones.

PENDIENTE OPERATIVO:

- Abrir la version fuente o reconstruir la distribucion y ejecutar un lote de
  2 a 5 obras en modo de prueba. Confirmar visualmente llamadas Qwen > 0 y que
  Groq solo aumente cuando la fila Qwen indique escalado.

DISTRIBUCION:

- Distribucion reconstruida correctamente con PyInstaller. SHA-256 de
  dist/MCE/MCE.exe:
  3BC6174B980F98F724F54579A072B03A489844A26D79C2F0AC39598CD4ECA9F1.
- El ejecutable no se abrio durante esta validacion para evitar cualquier
  conexion accidental al PostgreSQL real o reanudacion de sesiones existentes.
### Endurecimiento Qwen y limite Groq - 2026-08-10

- La observacion real del lote de doramas confirmo persistencia estable y checkpoints,
  pero detecto respuestas JSON/esquema invalidas de Qwen y una secuencia de 429 de
  Groq que bloqueaba cada obra entre 5 y 12 minutos.
- Qwen ahora recupera JSON rodeado por texto o cercas Markdown, tolera campos
  accesorios, reconoce alias comunes y completa campos opcionales de forma
  conservadora. Conserva un unico reintento local cuando el contenido no es
  recuperable y nunca relaja el validador determinista de dos dominios.
- El prompt local indica de forma explicita cuando aceptar, escalar o mantener en
  revision. La version sube a `mce.ai-review.prompt.v3` para no reutilizar decisiones
  de cache producidas con el comportamiento anterior.
- Groq ya no duerme ni reintenta dentro de una obra ante 429. Registra el tiempo de
  enfriamiento, abre una espera local, omite nuevas llamadas durante ese periodo y
  devuelve `ai_waiting_rate_limit`. El servicio deja la obra sin procesar y finaliza
  el lote como `waiting_internet`, de modo que Reanudar continua desde el checkpoint
  sin enviar la obra a revision humana ni perderla.
- La telemetria de Groq muestra enfriamiento restante y llamadas omitidas localmente.
- Validacion aislada: 30 pruebas de Qwen, Groq, orquestacion y procesamiento aprobadas;
  Ruff limpio y mypy sin errores en 11 archivos. La suite amplia de interfaz sigue
  afectada por el problema previo de permisos de `.test-runtime`, no por fallos de
  estas rutas. No se conecto ni modifico PostgreSQL real ni las sesiones existentes.
- Distribucion reconstruida en `dist/MCE/MCE.exe`; SHA-256
  `05E132922A2B7F1EDE9CDE26FEC1F29BE18ED3B9336B8F967C4FDA3E0CCD908E`.
  Los modulos corregidos se confirmaron dentro del archivo PyInstaller y el arranque
  aislado sin PostgreSQL respondio correctamente antes de cerrar solo esa instancia.

### Temporizador visible de disponibilidad Groq - 2026-08-11

- El panel de proveedores incluye ahora un estado independiente de Groq que se
  actualiza cada segundo aunque el lote esté detenido.
- Cuando Groq entrega un tiempo de reinicio fiable muestra `Esperar mm:ss` (o
  `hh:mm:ss`) y al finalizar indica que ya se puede reanudar.
- Si el 429 no incluye un tiempo fiable, MCE muestra `Límite desconocido` y una
  espera de seguridad, sin inventar una hora exacta.
- Validación aislada: 7 pruebas de interfaz y Groq aprobadas; Ruff y mypy limpios
  en los módulos modificados. La suite amplia conserva el bloqueo previo de
  permisos de `.test-runtime`. No se conectó ni modificó PostgreSQL ni sesiones.
- Pendiente operativo: reconstruir la distribución cuando la instancia de MCE
  esté cerrada y comprobar visualmente el indicador en un próximo 429 real.

### Corrección de reanudación, pausa y carga de etapa 3 - 2026-08-11

- El registro confirmó que `Reanudar` desde Doramas perdía la selección y abría
  un lote con `categories=all`; por eso mostraba 1,381 aunque Doramas tenía 756
  obras. La reanudación conserva ahora la categoría elegida y su checkpoint.
- Pausar y continuar un trabajador activo ya no persiste una sesión grande en el
  hilo visual. El token cooperativo detiene o libera el trabajador inmediatamente
  y mantiene el checkpoint existente, evitando congelar la ventana.
- Enriquecimiento se precarga al iniciar con el runtime real. Si una preparación
  invalida los agregados mientras todavía se están leyendo, MCE conserva una
  recarga pendiente y la ejecuta al terminar; la pestaña 3 deja de depender de
  preparar otra sección para mostrar las categorías guardadas.
- Validación aislada: 16 pruebas de interfaz y procesamiento aprobadas; Ruff y
  mypy limpios. No se conectó ni modificó PostgreSQL real durante las pruebas.
- Pendiente operativo: cerrar la instancia abierta, reconstruir la distribución
  y validar visualmente pausa/reanudación con un lote pequeño.

### Recuperación limitada al arranque - 2026-08-12

- La ejecución real de las 158 obras restantes de Doramas confirmó que el lote
  comenzaba correctamente con `categories=dorama`, pero el refresco periódico
  de la tabla llamó a `recover_interrupted()` y marcó como abandonado el trabajo
  vivo después de la primera respuesta 200 de Groq.
- `list_summaries()` es ahora estrictamente de lectura. La recuperación de
  trabajos abandonados permanece en `list_ids()`, ejecutado al construir el
  presenter durante la apertura inicial de MCE.
- Se añadió una regresión PostgreSQL aislada que exige que consultar resúmenes
  conserve tanto la sesión como su job en estado `running`.
- Validación disponible: 8 pruebas unitarias simuladas aprobadas, Ruff y mypy
  limpios. La prueba PostgreSQL protegida no pudo iniciar porque `mce_test` tiene
  el esquema antiguo y carece de `ai_review_runs`; el catálogo real no se tocó.
- MCE se abrió desde código (`compiled=False`) y responde correctamente. No se
  reconstruirá la distribución hasta completar la prueba real de Doramas.

### Reanudación sin bloquear la interfaz - 2026-08-12

- El diagnóstico en tiempo real confirmó tres cargas síncronas antes de iniciar:
  selección de destinos, transición de estado y una segunda materialización de
  la sesión dentro de `start_session_processing()`.
- La fila consolidada conserva ahora estado, banco y disponibilidad por sesión;
  `Reanudar` prioriza la sesión pausada sin abrir sus miles de elementos.
- La transición, carga del checkpoint, validación y agrupación se ejecutan dentro
  del trabajador. La interfaz entrega el control inmediatamente y recibe después
  el total exacto de obras agrupadas, sin confundir archivos con obras.
- Validación estática completada: Ruff, mypy y compilación de `src/mce` sin
  errores. La prueba Qt continúa bloqueada por los permisos heredados de las
  carpetas temporales de pytest. No se conectó ni modificó PostgreSQL real.
- MCE queda cerrado. Próximo paso: abrir desde código, pulsar una sola vez
  `Reanudar` sobre Doramas y confirmar en el log `batch_total=158 categories=dorama`.
# Continuidad — revisión humana simplificada (2026-08-13)

- La barra de revisión humana queda reducida a `Rechazar`, `Repreparar todos` y
  `Revalidar y completar`; se retiraron de la interfaz las aprobaciones manuales,
  corrección aislada, bloqueo y el antiguo reintento.
- `Repreparar todos` trabaja sobre todas las obras del filtro actual, reconstruye
  títulos desde nombre/ruta cuando el título es solo un episodio y guarda una vez
  por sesión. Las obras permanecen en revisión y no consumen proveedores.
- `Revalidar y completar` exige selección y confirmación, repara los títulos,
  limpia las huellas de consulta del intento anterior y reabre únicamente esos
  grupos en la categoría virtual `Pendientes`.
- Una obra revalidada solo puede llegar a la vista previa del catálogo si conserva
  identidad externa, sinopsis, géneros, reparto, carátula y director o creador/
  estudio según su tipo. Si falta algo vuelve a revisión con el faltante indicado.
- Este botón no publica el catálogo maestro. La publicación atómica sigue siendo
  una decisión separada en Finalización.
- Validación aislada: Ruff y mypy limpios; 56 pruebas unitarias aprobaron. La suite
  visual completa quedó impedida por ACL de los directorios temporales de pytest,
  no por un fallo funcional de las pruebas ejecutadas.

## Endurecimiento posterior y política por categoría

- Doramas, anime, animados y concursos aceptan una identidad externa inequívoca
  aunque los metadatos complementarios sean parciales. No se bloquean por reparto,
  sinopsis, dirección o carátula ausentes.
- Películas, series y novelas exigen identidad inequívoca y al menos dos datos
  útiles entre año, sinopsis, reparto, dirección/creadores, géneros y carátula.
- La vista previa distingue `completo` y `metadatos parciales`; la publicación del
  catálogo maestro continúa siendo un paso independiente en Finalización.
- Una consulta idéntica ya agotada conserva sus huellas, omite proveedores e IA y
  vuelve a revisión como revalidación agotada. Solo un título modificado abre una
  consulta nueva.
- `Resolver coincidencia` permite elegir uno de los candidatos conservados por el
  lote actual y aprovechar esa evidencia sin ejecutar nuevamente el enriquecimiento.
- La restauración solo muestra elementos cuyo estado persistido continúa en etapa
  `reviewed`; los ya consolidados no reaparecen como revisiones activas.
- Las sesiones `waiting_review` pasan explícitamente a `running` antes de guardar
  resultados, corrigiendo el `InvalidSessionTransitionError` observado.
- El indicador de PostgreSQL diferencia conexión comprobada, configuración sin
  conexión y ausencia de configuración.
- El resumen de lote separa aprobadas completas, aprobadas parciales, ambiguas,
  sin identidad y revalidaciones agotadas. La repreparación informa referencias
  históricas omitidas.
- Cada entrada conserva internamente `_metadata_completeness` con `completo` o
  `metadatos parciales`. En doramas, anime, animados y concursos el estado visible
  es simplemente `catalogado`: el bot puede reconocer que faltan detalles sin
  comunicar esa limitación al usuario. Películas, series y novelas mantienen la
  distinción visible por ser las categorías prioritarias.
- La resolución acepta equivalencias semánticas (`dorama`, `novela` y `concurso`
  pertenecen a la familia `series`), evitando que una identidad aprobada por IA
  vuelva a revisión solo por el nombre interno de la categoría.
- `Repreparar todos` registra un resumen local verificable con procesadas,
  modificadas, sin cambios, sin título y referencias históricas; declara cero
  llamadas externas y no inicia enriquecimiento.
- `Revalidar y completar` permite omitir una consulta negativa agotada una sola
  vez por obra mediante una marca persistente. Repetirlo sin cambiar el título
  conserva la huella y evita consumir nuevamente los proveedores.

## Validación visual aislada - 2026-08-13

- Se comprobó acceso efectivo en `.test-runtime` y `.isolated-ui-test` creando,
  modificando y eliminando un archivo temporal en cada directorio.
- Pasaron individualmente las pruebas críticas de navegación y restauración de
  tema, disponibilidad del enriquecimiento únicamente en la etapa 3 y pausa de
  un lote activo sin persistencia bloqueante en el hilo de interfaz.
- La primera ejecución completa de `test_widgets.py` excedió 120 segundos porque
  la suite necesita alrededor de tres minutos y una expectativa conservaba el
  texto antiguo `Procesados`. La expectativa se actualizó al contrato visible
  vigente `Lote actual: 1 / 1 obras`.
- Validación final: las 36 pruebas de `test_widgets.py` aprobaron en 199.02 s.
  No existe una espera secundaria pendiente. No se abrió MCE real ni se conectó
  o modificó PostgreSQL o las sesiones existentes durante la validación.

## Repreparación de revisiones históricas - 2026-08-13

- La prueba real de `Repreparar todos` reveló que una revisión perteneciente a
  una sesión ya completada era rechazada por la regla general que solo admitía
  sesiones `ready` o `waiting_review`.
- La repreparación exclusivamente local usa ahora una operación de dominio
  separada: permite actualizar títulos en sesiones históricas sin cambiar su
  estado, pero continúa prohibida mientras la sesión esté `running`.
- La revalidación, publicación y demás decisiones humanas conservan sus reglas
  de transición anteriores. La corrección no añade llamadas a proveedores o IA
  ni publica en PostgreSQL.
- Validación aislada: 18 pruebas aprobadas, incluida una regresión con sesión
  `completed`; Ruff y mypy sin errores.

## Resolución masiva segura de coincidencias - 2026-08-13

- `Resolver coincidencias seguras` acepta una selección múltiple y utiliza solo
  candidatos ya conservados; no consulta proveedores ni IA.
- Una obra se resuelve automáticamente únicamente si tiene un solo candidato o
  si todos los candidatos comparten el mismo identificador externo fuerte. No se
  comparan ni fusionan obras solo por parecido de título.
- Antes de ejecutar, la interfaz informa seleccionadas, identidades inequívocas
  y casos dudosos omitidos. Estos últimos permanecen en Revisión humana.
- Las filas multilingües con la misma identidad externa convergen en la identidad
  canónica existente; la publicación del catálogo sigue reservada a Finalización.
- Las revisiones pendientes de sesiones `completed` pueden resolverse sin cambiar
  el estado histórico. Los estados activos, fallidos, cancelados y archivados
  conservan el bloqueo.
- Validación aislada final: 23 pruebas aprobadas; Ruff y mypy sin errores.

### Corrección de restauración histórica

- La primera prueba con 625 revisiones devolvió cero porque las filas restauradas
  descartaban `_candidates` y mostraban siempre `sin coincidencias`, aunque el
  lote original hubiera conservado una aprobación fuerte de IA.
- La restauración conserva ahora estado, puntuación, fuentes y contradicciones de
  IA. También intenta resolver, mediante lectura local del catálogo, un alias que
  ya tenga una identidad canónica única.
- Una aprobación histórica de IA se reconstruye como candidata únicamente con
  estado `approved_by_ai`, puntuación mínima 95, dos o más fuentes y ninguna
  contradicción. No se convierte evidencia débil o ambigua en aprobación.
- El botón opera sobre todas las obras del filtro actual, incluidas las 13 páginas,
  y no depende de la selección visible de una sola página.
- Validación aislada adicional: 4 pruebas aprobadas; Ruff y mypy sin errores.
- La primera resolución de tres coincidencias reveló que sus sesiones estaban en
  estados históricos inactivos. Las decisiones humanas admiten ahora `paused`,
  `waiting_internet` y `failed`, conservando ese estado al consolidar una
  coincidencia segura; siguen prohibidos `running`, `cancelled` y `archived`.
- Si una obra de una sesión `failed` se envía a `Revalidar y completar`, MCE
  ejecuta primero la recuperación explícita `failed -> ready`, limpia la causa de
  fallo, conserva el checkpoint e incrementa el contador de reintentos. La
  repreparación exclusivamente local no reactiva la sesión.
- Validación de estados y revalidación histórica: 36 pruebas aprobadas; Ruff y
  mypy sin errores.

## Agrupación de obras idénticas en Revisión humana - 2026-08-14

- El botón anterior de descarte fue reemplazado por `Agrupar obras idénticas`.
- MCE reúne visualmente registros del mismo tipo cuyo título candidato coincide
  después de normalizar mayúsculas y espacios.
- La fila resultante suma `archivos agrupados` y conserva internamente cada ID,
  sesión, ruta y registro original. Las obras de tipos distintos nunca se unen.
- Repreparar, revalidar, resolver o rechazar una obra agrupada expande primero
  todos sus miembros, evitando registros huérfanos o pérdida de archivos.
- La agrupación es local y visual: no borra archivos, no llama proveedores o IA,
  no publica y no modifica el catálogo maestro PostgreSQL.
- Validación aislada: 3 pruebas específicas y 29 pruebas del motor de sesiones
  aprobadas; Ruff y mypy sin errores.
- Revisión humana incorpora `Eliminar seleccionado`: retira la obra marcada y,
  si es una agrupación visual, todos sus registros originales. Solicita
  confirmación y registra el rechazo auditable sin borrar archivos físicos ni
  modificar el catálogo maestro PostgreSQL.

## Motor web y navegador - Fase B - 2026-08-14

### IMPLEMENTADO

- Ningún comportamiento de producción nuevo en esta fase. Se conserva intacta
  la arquitectura auditada de proveedores, obra lógica, caché, Qwen/Groq,
  checkpoints, procedencia, revisión y publicación.

### DISEÑADO

- Integración mínima documentada en `docs/phase_b_browser_web_integration_design.md`.
- Evidencia acumulativa Tavily -> Serper -> Exa sin perder resultados útiles.
- Puerto compatible para BrowserSearchProvider, caché compacta y diagnóstico.
- Enriquecimiento parcial por campo reutilizando procedencia existente.
- Backpressure, reanudación, métricas, interfaz y puertas de seguridad.

### PENDIENTE

- Fases C-S: implementación, pruebas reales, benchmarks, interfaz y release.
- Playwright y Chromium no están instalados/comprobados en el entorno de MCE.

### PENDIENTE DE PERMISO

- Instalación y ejecución real de Playwright/Chromium.
- Pruebas reales de APIs, navegador, Ollama/Qwen, Groq, PostgreSQL y EXE.

### PENDIENTE DE API KEY

- Ninguna solicitud nueva en Fase B. La presencia de credenciales se verificará
  sin exponer valores en la puerta E antes de realizar pruebas reales.

### VALIDACIÓN DE FASE B

- 21 pruebas aisladas de arquitectura, motor web y cadena Qwen/Groq aprobadas.
- Contrato documental obligatorio comprobado.
- Ruff limpio y mypy limpio sobre los 167 archivos fuente.
- Sin llamadas externas, navegador, PostgreSQL ni sesiones reales.

## Motor web multiproveedor - Fase C - 2026-08-14

### IMPLEMENTADO

- Tavily, Serper y Exa conservan y acumulan evidencia útil en orden de prioridad.
- La suficiencia se evalúa sobre el conjunto acumulado y el flujo se detiene en
  cuanto dos dominios aportan evidencia utilizable.
- Las URLs equivalentes se deduplican tras normalizar esquema, host, puerto,
  barra final y fragmento. La primera evidencia conserva la prioridad del
  proveedor que la encontró.
- El límite final selecciona primero dominios distintos y después completa los
  espacios restantes, evitando perder diversidad por resultados repetitivos.
- Los intentos registran resultados recibidos, resultados realmente nuevos,
  total acumulado y caché.
- Los proveedores controlados exponen telemetría común: identidad, activación,
  prioridad, timeout conocido, reintentos, fallos consecutivos, enfriamiento,
  circuito, último error/éxito, solicitudes, éxitos, fallos, rate limits, cuota
  local agotada y caché.
- La UI de uso de proveedores consume esta telemetría sin inventar métricas
  remotas no disponibles.

### PROBADO CON MOCK

- Acumulación Tavily -> Serper con parada antes de Exa.
- Continuación a Exa cuando Serper solo repite la URL de Tavily.
- Preservación de diversidad de dominios con límite reducido.
- Circuito abierto, estado half-open y telemetría común.
- Integración con fallback web, Qwen/Groq y procesamiento por obra lógica.

### PENDIENTE

- Fase D: completar la integración Serper/Exa y sus pruebas de errores/cuota
  hasta alcanzar la puerta de credenciales.
- BrowserSearchProvider, enriquecimiento parcial, benchmarks, UI Browser y
  release continúan en fases posteriores.

### VALIDACIÓN DE FASE C

- 46 pruebas aisladas aprobadas: 7 específicas del motor web y 39 de integración
  con identificación, Qwen/Groq y procesamiento.
- 3 pruebas adicionales del runtime aprobaron; una prueba basada en `tmp_path`
  quedó bloqueada por permisos del directorio temporal de pytest, no por una
  regresión funcional.
- Ruff limpio y mypy limpio sobre los 167 archivos fuente.
- Sin llamadas externas, Playwright, PostgreSQL ni sesiones reales.

## Integración defensiva Serper y Exa - Fase D - 2026-08-14

### IMPLEMENTADO

- Serper limita ahora sus fragmentos con el mismo máximo configurable que Exa,
  compacta espacios y conserva la fecha del resultado para inferir el año aun
  cuando el fragmento de texto alcance el límite.
- Exa admite resultados sin `text`, reutiliza `highlights`, incorpora
  `publishedDate` a la identificación y omite filas malformadas o URLs no HTTPS.
- Ambos adaptadores devuelven un conjunto vacío ante respuestas válidas sin
  resultados y rechazan estructuras incompatibles mediante errores sanitizados.
- Un 429 ya no se reintenta de inmediato contra el mismo proveedor: se registra
  y el coordinador continúa con el siguiente, evitando llamadas duplicadas.
- El transporte distingue de forma interna un rate limit temporal de una cuota
  agotada examinando solo marcadores del cuerpo remoto. El cuerpo, la consulta y
  las credenciales nunca se propagan a la interfaz ni a los registros.
- La telemetría diferencia `rate_limit` y `quota_exhausted`; el agotamiento del
  límite local también queda visible como último estado.

### PROBADO CON MOCK

- Mapeo defensivo y límite de contenido de Serper.
- Fallback de Exa a highlights y fecha publicada.
- 429 sin reintento inmediato y continuación Serper -> Exa.
- Clasificación sanitaria de cuota remota sin filtrar el cuerpo de error.
- Integración con fallback web, revisión IA y procesamiento por obra lógica.

### PENDIENTE

- Fase E: puerta de credenciales antes de cualquier prueba real de Serper/Exa.
- Fases F-S: pruebas reales autorizadas, BrowserSearchProvider, enriquecimiento
  parcial, benchmarks, interfaz, documentación final y release.

### VALIDACIÓN DE FASE D

- 54 pruebas aisladas aprobadas sin red ni datos reales.
- Ruff limpio y mypy limpio sobre los 167 archivos fuente.
- Sin llamadas externas, Playwright, PostgreSQL ni sesiones reales.

## Puerta de credenciales web - Fase E - 2026-08-14

### VERIFICADO

- `SERPER_API_KEY` está configurada en el proceso actual.
- `EXA_API_KEY` está configurada en el proceso actual.
- `MCE_SERPER_ENABLED` y `MCE_EXA_ENABLED` no las desactivan; ambos proveedores
  usan el estado predeterminado activado.
- La fábrica de MCE registra Serper y Exa como `configurada` cuando recibe las
  credenciales, sin incluir los valores en mensajes ni diagnósticos.

### VALIDACIÓN DE FASE E

- 1 prueba aislada nueva aprobada con caché sustituida por dobles sin disco.
- Ruff limpio; no se crearon bases persistentes ni quedaron archivos temporales.
- No se hicieron solicitudes externas y no se tocó PostgreSQL ni sesiones reales.

### PUERTA SIGUIENTE

- Fase F requiere autorización expresa para realizar consultas reales y
  controladas a Serper y Exa. Las claves no deben copiarse en la conversación.

## Pruebas reales Serper y Exa - Fase F - 2026-08-14

### VALIDADO REALMENTE

- Se ejecutó exactamente una consulta aislada a Serper y una a Exa usando los
  adaptadores de producción de MCE.
- Serper respondió correctamente en 1,446.4 ms con 3 resultados válidos, todos
  HTTPS y con el año 2019 detectado.
- Exa respondió correctamente en 2,940.4 ms con 3 resultados válidos, todos
  HTTPS y con el año 2019 detectado.
- No hubo 429, cuota agotada, timeout, respuesta vacía ni error de contrato.
- Las claves no se mostraron y las respuestas completas no se persistieron.

### AISLAMIENTO

- No se inició la interfaz de MCE.
- No se usó la caché persistente de producción.
- No se conectó ni modificó PostgreSQL y no se tocaron sesiones existentes.

### EVIDENCIA

- Informe: `docs/phase_f_real_api_validation_2026-08-14.md`.

### PENDIENTE

- Fase G: integrar `BrowserSearchProvider` sin instalar todavía Playwright ni
  Chromium y preservando el orden Tavily -> Serper -> Exa -> Browser.

## Integración BrowserSearchProvider - Fase G - 2026-08-14

### IMPLEMENTADO

- Nuevo contrato `BrowserAutomationBackend` desacoplado de Playwright y modelo
  `BrowserSearchResponse` con estados `success`, `partial`, `no_evidence`,
  `blocked`, `captcha`, `rate_limited`, `timeout` y `unavailable`.
- `BrowserSearchProvider` convierte resultados DOM estructurados en la evidencia
  web existente, acepta campos parciales y nunca inventa los ausentes.
- Solo admite URLs HTTPS, limita el texto visible, conserva título, tipo, año,
  snippet, puntuación, consulta, URL y procedencia `browser_search`.
- CAPTCHA y bloqueo se detienen sin evasión; timeout, rate limit, dependencia
  ausente y proveedor deshabilitado generan estados explícitos y sanitizados.
- El orden de la fábrica queda Tavily -> Serper -> Exa -> Browser, con prioridad
  inicial 40. Browser permanece desactivado por defecto.
- La caché web compartida sigue envolviendo toda la cadena, por lo que una
  evidencia de navegador reutilizable evita una nueva apertura mientras conserve
  validez.
- Se incorporaron las opciones `BROWSER_SEARCH_ENABLED`, `BROWSER_HEADLESS`,
  `BROWSER_TIMEOUT`, `BROWSER_MAX_CONCURRENCY`, `BROWSER_DELAY_MIN_MS`,
  `BROWSER_DELAY_MAX_MS`, `BROWSER_MAX_RESULTS`,
  `BROWSER_MAX_PAGE_TEXT_CHARS` y `MCE_BROWSER_PRIORITY`.
- Hasta completar la Fase H, habilitar Browser informa exactamente que
  Playwright y Chromium están pendientes de comprobación.

### VALIDACIÓN DE FASE G

- 58 pruebas aisladas aprobadas: contrato Browser, estados de bloqueo, orden de
  fallback, fábrica, motor web, identificación, IA y procesamiento.
- Ruff limpio y mypy limpio sobre los 168 archivos fuente.
- No se instaló ni ejecutó Playwright/Chromium.
- Sin navegador real, red, PostgreSQL ni sesiones existentes.

### PENDIENTE

- Fase H: comprobar si Playwright y Chromium existen y solicitar permiso antes
  de cualquier instalación o control real del navegador.

## Diagnóstico de Playwright y Chromium - Fase H - 2026-08-14

### COMPROBADO

- El entorno virtual de MCE no contiene el paquete Python `playwright`.
- `python -m playwright --version` confirma `No module named playwright`.
- Por esa ausencia no es posible comprobar de forma fiable el Chromium
  administrado por Playwright, arrancar el navegador, abrir la página local de
  prueba ni validar su cierre.

### NO REALIZADO

- No se instaló ningún paquete ni navegador.
- No se abrió ningún proceso de navegador.
- No hubo acceso a PostgreSQL, sesiones ni servicios externos.

### BLOQUEO Y PERMISO REQUERIDO

- Para continuar se necesita permiso para instalar `playwright` exclusivamente
  en la `.venv` del proyecto y descargar el Chromium gestionado por Playwright.
- Después de la instalación se repetirá la Fase H: versión, ejecutable,
  arranque, página local, cierre y ausencia de procesos huérfanos.

## Validación efectiva de Playwright - Fase H - 2026-08-14

### RESULTADO ACTUALIZADO

- El usuario instaló Playwright 1.62.0 correctamente dentro de la `.venv` de
  MCE y la importación Python quedó disponible.
- La descarga del Chromium administrado por Playwright no pudo completarse:
  `cdn.playwright.dev` respondió 403 por restricción geográfica y el espejo de
  Google agotó el tiempo de espera y luego reinició la conexión.
- No se intentó evadir la restricción ni usar mecanismos no autorizados.
- Se detectó Google Chrome instalado en
  `C:\Program Files\Google\Chrome\Application\chrome.exe` y Microsoft Edge en
  `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`.
- Playwright inició Chrome local 151.0.7922.138 en modo headless, cargó una
  página HTML local, verificó su título y contenido, y cerró correctamente.
- Tras el cierre quedaron cero procesos nuevos de Chrome.
- No se consultó Internet durante la prueba del navegador y no se tocaron
  PostgreSQL, sesiones reales ni datos del catálogo.

### ESTADO DE FASE H

- Playwright está instalado y su control real de un navegador Chromium local
  queda validado.
- El binario administrado por Playwright continúa ausente por bloqueo externo;
  Chrome local es la alternativa operativa comprobada.
- Antes de activar BrowserSearchProvider en producción, su backend concreto debe
  admitir de forma explícita el ejecutable local o un canal instalado y mantener
  el proveedor desactivado si ninguno está disponible.

### SIGUIENTE FASE

- Fase I: crear el extractor de evidencia compatible con Playwright, usando DOM,
  múltiples selectores defensivos, límites y diagnósticos explícitos antes de
  cualquier navegación web real.

## Extractor de evidencia de navegador - Fase I - 2026-08-14

### IMPLEMENTADO

- Nuevo `BrowserEvidenceExtractor`, independiente del paquete Playwright pero
  compatible por protocolo con una página y sus locators reales.
- Extracción estructurada y opcional de título, URL, snippet, año, tipo,
  temporadas, géneros, reparto, valoración, plataformas, títulos alternativos y
  texto visible limitado.
- Resultados orgánicos y panel enriquecido se consultan mediante varios
  selectores candidatos; la ausencia o rotura de uno no invalida toda la página.
- Las evidencias repetidas se deduplican por título y URL, se rechazan enlaces
  no HTTPS y se respetan `BROWSER_MAX_RESULTS` y
  `BROWSER_MAX_PAGE_TEXT_CHARS`.
- CAPTCHA, tráfico inusual, 429, bloqueo, acceso denegado y consentimiento que
  impide el acceso producen estados explícitos sin intentar evasión.
- Los campos no visibles permanecen vacíos. Una ficha incompleta queda marcada
  como extracción parcial en lugar de inventar datos.
- La clasificación preserva `dorama` y `novela` cuando el texto visible aporta
  esas señales específicas, sin reducirlas automáticamente a serie genérica.

### VALIDACIÓN DE FASE I

- 16 pruebas específicas aprobadas para extracción, selectores alternativos,
  panel enriquecido, campos parciales, CAPTCHA, 429, bloqueo, consentimiento,
  URLs inseguras, DOM roto, duplicados y límites.
- Prueba real local aprobada con Playwright y Chrome 151: se extrajeron
  correctamente título `Vincenzo`, año 2021, tipo dorama, una temporada,
  géneros, reparto y valoración 8.4 desde HTML local.
- Chrome cerró correctamente y dejó cero procesos nuevos tras la prueba.
- Regresión web e identificación: 60 pruebas aprobadas.
- Ruff limpio, mypy limpio sobre 169 archivos fuente y compilación completa sin
  errores.
- Dos intentos iniciales de la regresión fueron impedidos por ACL de la carpeta
  temporal del sandbox; la misma suite pasó fuera del sandbox con un temporal
  aislado. No fue un fallo funcional del extractor.
- Sin navegación web externa, PostgreSQL, sesiones reales ni migraciones.

### SIGUIENTE FASE

- Fase J: convertir la extracción estructurada en enriquecimiento parcial con
  procedencia preservada y sin rellenar campos no demostrados.

## Enriquecimiento parcial de navegador - Fase J - 2026-08-14

### IMPLEMENTADO

- Nuevo `BrowserPartialEnrichmentMapper` que reutiliza directamente
  `MetadataField`, `FieldProvenance` y `MetadataConsolidator`; no se creó un
  sistema paralelo de procedencia.
- Cada evidencia de navegador produce un conjunto independiente de campos con
  `source_type=provider`, `source_name=browser_search`, hora UTC y URL externa
  cuando existe.
- Se pueden incorporar únicamente los valores demostrados: título, año, tipo,
  cantidad de temporadas, géneros, reparto, valoración, plataformas, aliases,
  descripción y URL fuente.
- Póster, duración, episodios, director y cualquier otro valor ausente no se
  materializan con `None` ni se completan por inferencia.
- La evidencia de panel enriquecido sin enlace conserva sus campos útiles y
  deja `external_reference` vacío, sin fabricar una URL.
- Los estados sin evidencia, CAPTCHA, bloqueo, 429, timeout o entorno no
  disponible no producen metadatos parciales.
- La completitud se expone solo como porcentaje descriptivo de campos presentes;
  nunca se convierte en confianza de identidad. La confianza por campo queda
  vacía mientras la fuente no aporte una medición demostrable.
- El consolidado existente rellena campos ausentes, respeta bloqueos manuales y
  genera conflictos auditables ante valores distintos. Esta fase no publica ni
  aprueba automáticamente una identidad.

### VALIDACIÓN DE FASE J

- 6 pruebas nuevas verifican campos demostrados, ausencias, procedencia por
  fuente, panel sin URL, estados bloqueados, consolidación, bloqueo manual y
  separación entre completitud y confianza.
- 24 pruebas enfocadas de extractor, enriquecimiento parcial y consolidación
  aprobadas.
- Regresión de metadatos, identificación y enriquecimiento: 75 pruebas
  aprobadas.
- Ruff limpio, mypy limpio sobre 170 archivos fuente y compilación completa sin
  errores.
- La regresión dentro del sandbox volvió a encontrar la ACL temporal conocida;
  la misma suite pasó fuera del sandbox con temporal aislado.
- Sin navegación externa, PostgreSQL, sesiones reales, publicaciones ni
  migraciones.

### SIGUIENTE FASE

- Fase K: integrar Qwen local sobre la evidencia parcial, manteniendo JSON
  estricto, límites de contexto y rechazo de campos o URLs inventados.

## Integración local de Qwen - Fase K - 2026-08-14

### IMPLEMENTADO

- `BrowserQwenEvidenceAdapter` conecta el enriquecimiento parcial de la Fase J
  con el contrato ya existente de evidencia IA, sin crear una segunda ruta de
  metadatos ni perder la procedencia del navegador.
- `EvidenceSource` transporta de forma opcional año, tipo, temporadas, géneros,
  reparto, valoración, plataformas, títulos alternativos y origen, además de
  título, URL y snippet.
- El esquema estricto de Qwen admite `matched`, `partial_match`, `ambiguous` e
  `insufficient_evidence`, así como `accept`, `partial_accept`, `escalate` y
  `human_review`.
- Cada campo analizado conserva valor, confianza y URLs citadas mediante
  `AIFieldEvidence`. El validador y la caché mantienen esa trazabilidad.
- La salida prohíbe propiedades desconocidas y campos fuera de la lista
  autorizada. Las URLs citadas tanto a nivel de resultado como de campo se
  comparan con la evidencia recibida; cualquier URL inventada queda marcada.
- El reintento por JSON o esquema inválido sigue limitado a uno.
- El contexto de entrada siempre es JSON completo. Ante el límite se compactan
  snippets y evidencias de manera determinista; no se corta texto serializado.
- Qwen continúa siendo analizador local y no una fuente. `partial_match` no se
  autoaprueba. Esta fase no cambia aún el fallback hacia Groq.

### VALIDACIÓN DE FASE K

- 19 pruebas focalizadas de Qwen, evidencia parcial y persistencia aprobadas.
- 84 pruebas de regresión de metadatos, navegador, enriquecimiento y revisión IA
  aprobadas fuera del sandbox con temporal aislado. El primer intento terminó
  los casos, pero la ACL temporal conocida impidió a pytest limpiar su carpeta.
- Ruff, mypy y compilación completa aprobaron sin errores.
- Diagnóstico real local aprobado: Ollama conectado, `qwen2.5:3b` instalado e
  inferencia mínima correcta.
- Inferencia estructurada real aprobada en una llamada y sin JSON inválido. La
  respuesta conservadora terminó en revisión humana, citó las dos URLs
  suministradas y no inventó fuentes.
- No se descargaron modelos, no se llamó a Groq y no se conectó ni modificó
  PostgreSQL o sesiones reales.

### SIGUIENTE FASE

- Fase L: validar la ruta completa Qwen -> validador -> Groq fallback y sus
  condiciones de escalamiento, sin atribuir a la IA evidencia inexistente.

## Cadena Qwen -> validador -> Groq - Fase L - 2026-08-14

### IMPLEMENTADO

- El resultado interno conserva `analysis_status` y `recommended_action` de
  Qwen; ambos sobreviven a la caché local junto con la procedencia por campo.
- El validador exige para Qwen `matched` + `accept`, confianza mínima 80,
  puntuación determinista mínima 95, dos dominios públicos independientes,
  título respaldado, tipo compatible, ausencia de contradicciones y ausencia de
  fuentes inventadas.
- Una salida parcial, ambigua, insuficiente, de baja confianza, contradictoria o
  con URL inventada nunca puede convertirse en aprobación solo por su puntaje.
- Todo resultado Qwen no aceptado escala exactamente una vez a Groq. También se
  escala ante Ollama caído, timeout, JSON inválido o esquema inválido. Se eliminó
  el atajo que evitaba Groq cuando había menos de dos dominios porque contradecía
  la regla explícita de escalamiento por evidencia insuficiente.
- Una salida Qwen ya aceptada por MCE termina la cadena y no llama a Groq.
- La salida de Groq ahora pasa obligatoriamente por el mismo validador antes de
  regresar al orquestador. Groq debe proponer aprobación y además superar las
  reglas deterministas; de lo contrario queda en revisión humana.
- Se añadieron contadores separados para fallback aceptado y fallback enviado a
  revisión humana, además de rutas de log explícitas.
- Los 429 y bloqueos recuperables de Groq conservan su comportamiento anterior;
  esta fase no agrega reintentos infinitos ni cambia la política de cuota.

### PROBADO CON DOBLES AISLADOS

- 32 pruebas focalizadas aprobaron: Qwen aceptado sin Groq; baja confianza;
  parcial; ambigüedad; evidencia insuficiente; fallo local; JSON inválido;
  contradicciones; URL inventada por Qwen o Groq; validación positiva y negativa
  del fallback; 429 sin reintentos encadenados y persistencia de procedencia.
- La cadena utiliza las clases reales `OllamaQwenAnalyzer`,
  `GroqStructuredAnalyzer`, `EvidenceValidator` y `ValidatedAnalyzerChain`; solo
  el transporte HTTP de Groq fue simulado.

### PROBADO REALMENTE

- Se ejecutó Qwen local real con `qwen2.5:3b` sobre dos evidencias
  contradictorias. Qwen fue no concluyente, la cadena escaló una vez y el
  sustituto aislado de Groq solo quedó aprobado después del validador con
  puntuación 100.
- Resultado observado: una llamada Qwen, una ruta fallback, cero llamadas reales
  a Groq y ruta final `Groq aceptado por validador`.

### VALIDACIÓN DE FASE L

- Regresión amplia de metadatos, navegador, enriquecimiento, procesamiento y
  revisión IA: 120 pruebas aprobadas.
- Ruff, mypy y compilación completa aprobaron sin errores.
- No se conectó ni modificó PostgreSQL o las sesiones reales.
- No se consumió cuota Groq. La prueba externa real de Groq permanece para la
  Fase N de pruebas reales, de acuerdo con la secuencia autorizada.

### SIGUIENTE FASE

- Fase M: validar reanudación e idempotencia de navegador/Qwen/Groq y reutilizar
  caché sin repetir trabajo completado.

## Reanudación e idempotencia - Fase M - 2026-08-14

### IMPLEMENTADO

- La huella de revisión IA ahora incluye la versión explícita del contrato
  `mce.ai-review.prompt.v4`, además del esquema, proveedor, analizador, modelo,
  título, categoría, año, temporada, episodio y aliases normalizados. Una caché
  producida por reglas anteriores no se confunde con la cadena actual.
- La caché persistente IA incorpora suma SHA-256 y recuperación segura. Una fila
  alterada o ilegible se elimina en vez de detener MCE o devolver evidencia
  corrupta.
- Solo se reutilizan resultados terminales: aprobado, revisión humana o no
  encontrado. Esperas de cuota o proveedor y errores no quedan convertidos en
  resultados definitivos; la obra permanece reintentable.
- La caché web compartida también incorpora suma SHA-256. Conserva compatibilidad
  con filas anteriores, las actualiza al leerlas y elimina entradas corruptas o
  vencidas antes de volver a consultar.
- Las fallas transitorias de un proveedor web no se guardan. Un resultado vacío
  obtenido correctamente sí se conserva, evitando llamadas posteriores
  innecesarias dentro del TTL.
- Se conservó el checkpoint existente por `work_group_id`: una obra terminada se
  persiste inmediatamente y no vuelve a seleccionarse al reanudar. Una obra con
  muchos archivos cuenta como una unidad lógica y hace una sola consulta.
- El control de trabajo en curso agrupa solicitudes concurrentes idénticas: dos
  consumidores de la misma obra reciben el mismo resultado con una sola
  búsqueda y un solo análisis.

### VALIDACIÓN DE FASE M

- 72 pruebas focalizadas aprobaron reanudación tras reinicio, caché web e IA,
  alteración de contenido, estados transitorios, consultas repetidas, checkpoint
  por obra y continuación solo de pendientes.
- Una prueba concurrente adicional confirmó una sola búsqueda y un solo análisis
  para dos solicitudes simultáneas de la misma obra.
- La regresión amplia de metadatos, navegador, enriquecimiento, revisión IA,
  procesamiento y checkpoints aprobó 134 pruebas.
- Ruff aprobó todo `src` y `tests`; mypy aprobó 170 archivos fuente y la
  compilación completa terminó sin errores.
- Todas las pruebas utilizaron memoria, SQLite y directorios temporales
  aislados. No se conectó ni modificó PostgreSQL real, las siete sesiones, el
  catálogo maestro ni proveedores externos.

### SIGUIENTE FASE

- Fase N: ejecutar las pruebas integrales y reales previstas por la
  especificación. Autorizada y documentada a continuación.

## Pruebas integrales y reales - Fase N - 2026-08-14

### IMPLEMENTADO

- El contrato Browser ya no queda conectado a un marcador no disponible. La
  fábrica de producción utiliza `PlaywrightBrowserAutomationBackend` con Chrome
  local, una sola instancia reutilizable, páginas cerradas por consulta, hilo
  dedicado, cola acotada y cierre ordenado.
- El extractor Browser prioriza el enlace del encabezado sobre enlaces
  auxiliares y usa `text_content` como respaldo cuando Chrome headless conserva
  texto en el DOM pero `inner_text` está vacío. Esto cerró el falso
  `no_evidence` observado con resultados reales de Bing.
- El transporte HTTP clasifica 429, 432 y 433 como límites remotos. En 432/433
  marca la cuota del plan como agotada, evita reintentos inútiles y permite
  continuar hacia el siguiente proveedor sin exponer cuerpo, consulta o clave.
- Playwright quedó declarado como dependencia de ejecución. La configuración
  permite seleccionar el canal de Chrome y la plantilla HTTPS del buscador sin
  acoplar el extractor a una sola página.

### VALIDACIÓN REAL

- 12 pruebas reales aprobaron en 86.65 s: cinco proveedores especializados,
  Tavily, Serper, Exa, Ollama/Qwen, Groq, Chrome contra una página local y
  Chrome/Bing público.
- Serper y Exa devolvieron evidencia real. Ollama con `qwen2.5:3b` y Groq
  respondieron con JSON válido y sin URLs inventadas. Chrome inició, navegó,
  extrajo evidencia pública y cerró correctamente.
- Tavily respondió HTTP 432 porque la cuota actual del plan está agotada. La
  prueba confirmó el comportamiento correcto y conservador de MCE ante esa
  condición; una búsqueda Tavily con resultados requiere reponer o ampliar la
  cuota externa.
- Las pruebas focalizadas del extractor y backend Browser aprobaron 12 casos.
  Ruff aprobó `src` y `tests`, mypy aprobó 171 archivos fuente y `compileall`
  terminó sin errores.
- La regresión final se reanudó el 2026-08-20 fuera del ACL temporal del sandbox.
  Una primera ejecución alcanzó 543 pruebas aprobadas y un único timeout Qt bajo
  carga; el caso aislado aprobó y el módulo completo de interfaz aprobó sus 41
  pruebas. La repetición completa definitiva terminó con 544 pruebas aprobadas,
  12 pruebas reales omitidas deliberadamente y cero fallos en 164.01 s.

### AISLAMIENTO

- Se excluyó explícitamente `tests/integration/postgresql` en todas las
  regresiones. No se conectó, migró ni modificó PostgreSQL real, el catálogo
  maestro ni las siete sesiones existentes.
- Las pruebas locales utilizaron dobles, memoria, SQLite, servidor HTTP local y
  directorios temporales. Las pruebas externas fueron consultas de solo lectura.

### SIGUIENTE FASE

- Fase O: benchmarks. No iniciada; requiere autorización separada.

## Benchmarks reales - Fase O - 2026-08-20

### IMPLEMENTADO

- Se añadió un ejecutor reproducible y sanitizado para medir Tavily, Serper,
  Exa, Browser/Bing, Qwen 2.5 3B y Groq con cinco obras conocidas, concurrencia
  uno y un máximo de tres resultados.
- El informe mide latencia media, p50, p95, intentos por minuto, éxito, límites,
  errores, JSON válido, exactitud, falsos positivos, CPU, RAM y VRAM observada.
- Browser incorpora además navegación, extracción, parser, knowledge panel,
  campos útiles y resolución completa, parcial o sin mejora.
- La medición de RAM para Windows fue corregida y cubierta por prueba automática.

### RESULTADOS REALES

- Serper y Exa alcanzaron 5/5 resultados exactos, sin errores ni falsos
  positivos de evidencia.
- Browser devolvió evidencia en 5/5 sin CAPTCHA ni bloqueo, pero solo 1/5 lotes
  contenía una coincidencia inequívoca entre los tres primeros resultados; fue
  mucho más lento que las APIs.
- Qwen produjo 5/5 JSON válidos, 2/5 títulos exactos y cero aprobaciones falsas:
  conservó todos los casos en revisión humana.
- Groq produjo 5/5 JSON válidos y títulos exactos, pero una corrida reproducida
  detectó que aprobó Spirited Away citando una fuente no entregada. Es una señal
  de seguridad intermitente que debe endurecerse en una fase posterior.
- Tavily confirmó nuevamente cuota agotada y detuvo el benchmark tras el primer
  intento, sin reintentos innecesarios.
- El informe completo está en `docs/PHASE_O_BENCHMARK_REPORT.md` y los datos
  sanitizados en `docs/phase_o_benchmark_2026-08-20.json`.

### AISLAMIENTO

- No se conectó ni modificó PostgreSQL real, el catálogo maestro ni las siete
  sesiones. No se persistieron claves, consultas ni credenciales en el informe.

### VALIDACIÓN DE FASE O

- Las cinco pruebas unitarias del instrumento aprobaron.
- Ruff, mypy y `compileall` terminaron sin errores para el ejecutor nuevo.
- El JSON fue leído y validado, contiene los seis proveedores, incluye RAM para
  todos y no contiene claves, credenciales ni consultas.
- La regresión local definitiva, excluyendo `tests/live` y
  `tests/integration/postgresql`, terminó con 549 pruebas aprobadas y cero
  fallos en 157.48 s.
- Una corrida previa incluyó accidentalmente `tests/live`: 560 pruebas
  aprobaron y solo Exa falló por timeout remoto de 10 segundos. Esa corrida no
  se usa como la regresión aislada definitiva.

### SIGUIENTE FASE

- Fase P: optimización guiada exclusivamente por estos resultados. No iniciada;
  requiere autorización separada.

## Optimización por benchmark - Fase P - 2026-08-20

### IMPLEMENTADO

- El orden predeterminado medido ahora es Exa 10, Serper 20, Tavily 30 y Browser
  40. Exa y Serper conservaron configuración y Tavily permanece disponible.
- La interfaz migra una sola vez los antiguos valores predeterminados y conserva
  cualquier prioridad personalizada.
- Qwen y Groq ya no pueden devolver una aprobación directa si citan una fuente
  no suministrada; degradan a revisión humana antes del validador final.
- Browser filtra evidencia no relacionada, exige más coincidencias en consultas
  largas y resuelve enlaces de redirección de Bing a la URL pública real.
- Concurrencia, modelos, límites de salida y umbrales de aprobación permanecen
  sin cambios porque el benchmark no justificó modificarlos de forma segura.

### VALIDACIÓN REAL

- Groq reprodujo la fuente inventada de Spirited Away y la nueva barrera la
  convirtió en revisión humana: 5/5 títulos exactos y cero aprobaciones
  inseguras.
- La comprobación Browser combinada descartó los cuatro lotes ajenos observados
  en Fase O y conservó la coincidencia útil de Dark. Money Heist se reprobó tras
  endurecer el filtro final.
- El informe detallado está en `docs/PHASE_P_OPTIMIZATION_REPORT.md`.

### AISLAMIENTO

- No se conectó ni modificó PostgreSQL real, el catálogo maestro ni las siete
  sesiones. No se cambió la base productiva ni se publicaron resultados.

### VALIDACIÓN DE FASE P

- 51 pruebas focalizadas aprobaron el flujo IA, Browser, fábrica y prioridades.
- Dos pruebas de interfaz aprobaron la migración y la construcción de la ventana.
- Ruff aprobó todo `src`, `tests` y `tools`; mypy aprobó 171 archivos fuente y
  `compileall` terminó sin errores.
- La regresión local definitiva, excluyendo `tests/live` y
  `tests/integration/postgresql`, terminó con 554 pruebas aprobadas y cero
  fallos en 156.69 s.

### SIGUIENTE FASE

- Fase Q: UI. Completada y validada el 2026-08-20.

## UI y configuración - Fase Q - 2026-08-20

### IMPLEMENTADO

- La página Configuración ahora se desplaza y conserva accesibles todos los
  controles en resoluciones menores.
- Web mantiene activación y prioridades para Tavily, Serper y Exa.
- Browser incorpora activación, modo Headless, timeout, concurrencia, esperas,
  máximo de resultados y una prueba local del navegador.
- El estado Browser distingue Playwright, Chrome/Chromium, modo y causa concreta.
- Ollama incorpora timeout y concurrencia; su estado separa servidor, modelo e
  inferencia.
- Las preferencias se aplican al runtime del siguiente lote y nunca almacenan
  claves.

### VALIDACIÓN DE FASE Q

- Las pruebas específicas comprobaron persistencia, aplicación al runtime y
  diagnóstico separado de Playwright/Chrome.
- Ruff aprobó `src`, `tests` y `tools`; mypy aprobó 171 archivos fuente.
- La regresión local, excluyendo `tests/live` y
  `tests/integration/postgresql`, terminó con 559 pruebas aprobadas y cero
  fallos en 230.80 s.
- Informe: `docs/PHASE_Q_UI_REPORT.md`.
- Guía de configuración: `docs/WEB_BROWSER_CONFIGURATION.md`.

### AISLAMIENTO

- No se conectó ni modificó PostgreSQL real, el catálogo maestro ni las siete
  sesiones. No se hicieron llamadas reales a proveedores durante Fase Q.

### SIGUIENTE FASE

- Fase R: release. Completada y validada el 2026-08-20.

## Release - Fase R - 2026-08-20

### IMPLEMENTADO

- Reconstrucción PyInstaller `onedir` de `dist\MCE` y auditoría recursiva del
  contenido.
- Documentación final de instalación, componentes externos, diagnóstico y
  límites de la entrega candidata.
- `.env.example` alineado con el orden web optimizado Exa -> Serper -> Tavily.

### VALIDACIÓN

- Ejecutable real iniciado con datos aislados, sin credenciales, sin red y sin
  PostgreSQL productivo. La ventana compilada y sus cinco etapas fueron
  observables mediante accesibilidad.
- 198 pruebas focalizadas y 559 pruebas de regresión local aprobadas.
- 34 integraciones PostgreSQL aprobadas exclusivamente sobre `mce_test`, después
  de migrarla con comprobación previa desde 0020 hasta 0022.
- Ruff, mypy (171 archivos) y `compileall` sin incidencias.
- SHA-256 del ejecutable:
  `86B85A6BCC18B3D94C3C04B642CDE6E42ABFA0341369D8B3EB0006E70D52D0A0`.
- Informe completo: `docs/PHASE_R_RELEASE_REPORT.md`.

### AISLAMIENTO

- No se conectó, migró ni modificó PostgreSQL `mce`, el catálogo maestro ni las
  siete sesiones. `mce_test` terminó en revisión 0022 y sin filas en las tablas
  operativas comprobadas.
- Chrome/Chromium, Ollama, `qwen2.5:3b` y claves API no se empaquetaron.

### PENDIENTE MANUAL

- Verificar la carpeta distribuida en una PC limpia sin Python y en Windows 11.
- La captura visual automatizada de la página Configuración quedó bloqueada por
  la API de captura de Windows; el arranque compilado sí fue comprobado.

### SIGUIENTE FASE

- Ninguna iniciada. Se detiene aquí hasta una autorización nueva.

## Endurecimiento posterior a la prueba real de Doramas - 2026-08-20

### HALLAZGOS REALES

- Ollama/Qwen podía consumir hasta 120 segundos por obra mientras el servicio local
  no respondía y repetía el fallo tres veces antes de abrir su circuito.
- Fragmentos de una misma obra con igual título, categoría y año podían crear claves
  IA distintas por temporada, episodio o alias local, provocando llamadas Groq
  repetidas.
- Los resultados observados para `2DA` fueron ambiguos, con puntuaciones de 63 a 70;
  conservarlos en revisión humana fue correcto y evita contaminar el catálogo.

### CORREGIDO

- Qwen ejecuta una comprobación local de servidor y modelo con un máximo de tres
  segundos antes de inferir. Si Ollama o `qwen2.5:3b` no están disponibles, abre el
  circuito inmediatamente y permite el fallback sin tres esperas de 120 segundos.
- La caché IA identifica la obra por título limpio, categoría y año; temporada,
  episodio, grupo físico y alias ruidosos ya no multiplican las llamadas externas.
- Se conserva la política existente: Doramas con identidad inequívoca pueden entrar
  al catálogo con metadatos parciales, pero una identidad ambigua permanece en
  revisión humana.

### VALIDACIÓN AISLADA

- 51 pruebas focalizadas aprobaron.
- Ruff y mypy aprobaron los archivos modificados.
- La regresión local completa, excluyendo proveedores reales y PostgreSQL, terminó
  con 561 pruebas aprobadas y cero fallos en 188.81 segundos.
- El ejecutable fue reconstruido en `dist\\MCE\\MCE.exe` y quedó cerrado. Su
  SHA-256 es `CDD5B8DE861CDCC109890E49208F0E90F3B6F58E771AED937DAEC86986896C4F`.
- No se conectó, migró ni modificó PostgreSQL real, el catálogo maestro ni las siete
  sesiones durante estas correcciones.

## Consolidación canónica al revalidar revisión humana - 2026-08-20

### HALLAZGO REAL

- Una fila agrupada visualmente podía contener varios grupos físicos con el mismo
  título. Al pulsar `Revalidar y completar`, la interfaz volvía a expandirla y el
  motor ejecutaba un ciclo por cada grupo, aunque el catálogo solo necesitaba una
  identidad de obra.
- La caché evitaba algunas llamadas externas repetidas, pero no evitaba los ciclos
  internos ni consolidaba todos los archivos bajo la misma obra canónica.

### CORREGIDO

- La selección agrupada permanece como una sola obra lógica durante la
  repreparación.
- Todos sus miembros reciben un `work_group_id` canónico determinista antes del
  enriquecimiento, conservando cada archivo, ruta, fuente y procedencia.
- El motor consulta proveedores e IA una sola vez por esa obra y propaga el
  resultado a todos los archivos asociados.
- Si la identidad sigue siendo ambigua, vuelve una sola obra consolidada a revisión
  en vez de recrear varios registros equivalentes.

### VALIDACIÓN AISLADA

- Prueba directa: dos grupos separados con el mismo título se convierten en una
  obra, realizan una sola llamada al proveedor y conservan sus dos archivos.
- 3 pruebas focales y 77 pruebas de regresión de procesamiento, sesiones e interfaz
  aprobaron; Ruff y mypy aprobaron los archivos modificados.
- No se conectó, migró ni modificó PostgreSQL real ni las sesiones existentes durante
  las pruebas.

## Separación VOB y aceptación útil de metadatos - 2026-08-20

### OBJETIVO AUTORIZADO

- Mantener las siete categorías de contenido y añadir tres colas virtuales:
  `Películas VOB`, `Series VOB` y `Doramas VOB`. Son diez categorías de contenido;
  `Pendientes` continúa como cola especial y no cuenta como categoría del catálogo.
- Evitar que fragmentos físicos como `Part_1_1.vob` de carpetas diferentes se
  agrupen como si fueran una sola película.
- Catalogar una identidad inequívoca sin exigir una ficha enciclopédica. La ficha
  útil registra año, temporadas cuando corresponde, sinopsis, dirección, reparto
  principal y valoración cuando la evidencia los proporciona.

### CORREGIDO

- La categoría canónica del archivo permanece intacta, pero el flujo de preparación
  y enriquecimiento separa automáticamente los `.vob` en las tres colas virtuales.
- El agrupamiento VOB toma el título de la carpeta de la obra y omite contenedores
  técnicos como `VIDEO_TS`, carpetas de disco y temporadas. Dos obras distintas con
  el mismo nombre de fragmento ya no se fusionan.
- La versión de clasificación subió a 6 y la de agrupamiento a 7 para que una nueva
  preparación regenere de forma explícita las identidades lógicas.
- Una coincidencia exacta de título y tipo alcanza el umbral automático; el año y
  otras señales siguen aumentando la certeza. Las alternativas cercanas o
  contradictorias conservan el bloqueo por ambigüedad.
- Wikidata u otro proveedor estructurado puede cerrar una identidad exacta aunque el
  proveedor primario no tenga resultados. Una fuente web pública cuyo título
  coincide, sin contradicciones y validada con al menos 80 puntos puede ser aceptada
  por Qwen sin gastar una llamada Groq.
- Los títulos genéricos o de contenedor (`Part_1_1`, `VIDEO_TS`, `trilogía`,
  `colección`, etc.) no consumen proveedores ni IA: vuelven a preparación local para
  recuperar una identidad de obra antes de buscar.
- El catálogo conserva `temporadas` y `valoración`; la completitud se audita como
  completa o parcial, pero una identidad inequívoca no se devuelve a revisión solo
  porque falte un dato complementario.

### VALIDACIÓN AISLADA

- 116 pruebas focalizadas de preparación, identificación, IA, procesamiento y
  presentación aprobaron.
- La suite unitaria completa terminó con 527 pruebas aprobadas y cero fallos en
  229.09 segundos.
- Ruff y mypy aprobaron; no hubo conexión, migración ni escritura en PostgreSQL real
  ni modificación de las sesiones existentes.
- El ejecutable fue reconstruido en `dist\\MCE\\MCE.exe` (15,005,714 bytes,
  SHA-256 `ADC2CB6309B1AEBE8A6F58D9A2521FF0E7A5EA358A0BD59279BF748E2BFD94D8`).

### CONTINUIDAD OPERATIVA

- Las sesiones ya preparadas no se reinterpretan silenciosamente. Para ver las diez
  categorías y regenerar los grupos VOB se debe ejecutar una nueva preparación
  local con esta versión, conservando originales y procedencia.
- El nuevo ejecutable está construido y cerrado, listo para una prueba visual y un
  lote pequeño observado. La prueba real debe comenzar con una nueva preparación
  local para materializar las colas VOB sin alterar los archivos originales.

## Repreparación local de Revisión humana - 2026-08-20

- Se agregó el acceso interno `F9` para ejecutar `Repreparar todos` cuando la capa
  de accesibilidad de Windows no puede pulsar el botón; usa exactamente el mismo
  flujo local de la interfaz.
- Prueba real completada sobre la revisión existente: 554 referencias evaluadas,
  553 procesadas, 0 modificadas, 553 ya limpias, 0 sin título recuperable y 1
  referencia histórica obsoleta omitida.
- El registro confirmó `external_calls=0`: no se consultaron proveedores ni IA y no
  se publicó contenido en el catálogo maestro. Solo se actualizaron los checkpoints
  de las sesiones correspondientes.
- Ejecutable reconstruido en `dist\\MCE\\MCE.exe`, SHA-256
  `C5CA7FFEA9FA2D1D3F251889EFA9970BE23E0DD8EFD92B9823796FAD10DB2A65`.

## Separación VOB completa y preparación local masiva - 2026-08-20

### CORREGIDO EN CÓDIGO

- Las siete categorías originales conservan su identidad canónica: Películas,
  Series, Novelas, Doramas, Anime, Concursos y Animados.
- Cada categoría tiene ahora una cola operativa VOB independiente. La etapa de
  enriquecimiento muestra 14 categorías de contenido y la cola especial
  `Pendientes`, para un total de 15 filas fijas.
- `Documentales` permanece dentro de Películas, según la taxonomía autorizada; si
  su soporte es VOB se muestra en Películas VOB.
- Los resúmenes usan la categoría operativa después de separar VOB. Una obra que
  pasa a una cola VOB se descuenta de la categoría normal y no se cuenta dos veces.
- La versión de agrupamiento subió a `mce-work-grouping-v8`. Una preparación local
  nueva regenera las identidades lógicas de elementos no consolidados y elimina su
  estado antiguo de revisión/enriquecimiento, conservando identificadores, rutas,
  archivos fuente, JSON originales y obras ya consolidadas.
- La interfaz detecta sesiones preparadas con una versión anterior y ya no las
  presenta incorrectamente como vigentes.
- Se agregó `Preparar todas`: encadena fuera del hilo visual solo las sesiones que
  necesitan v8, sin proveedores, IA ni publicación del catálogo. Al terminar vuelve
  a cargar Revisión humana desde el estado persistido.

### VALIDACIÓN AISLADA

- 58 pruebas focalizadas aprobaron, incluidas las siete variantes VOB, Documentales
  como Películas VOB, los 15 renglones fijos y el reinicio seguro de una obra que
  estaba en revisión.
- Ruff, mypy y la compilación de los cuatro módulos modificados aprobaron.
- Las pruebas no conectaron ni modificaron PostgreSQL real ni las sesiones reales.

### CONTINUIDAD OPERATIVA

- Falta ejecutar `Preparar todas` sobre las sesiones reales para materializar v8 y
  dejar vacía Revisión humana sin borrar JSON ni medios. El arranque gráfico desde
  código fue bloqueado por el límite temporal de aprobaciones de Codex; no se intentó
  eludir el bloqueo y no se realizaron escrituras reales.
- Quedó activa la vigilancia `vigilar-categorias-vob-y-preparacion-mce`, cada dos
  minutos, en modo de solo lectura.
