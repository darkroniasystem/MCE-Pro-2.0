# Rendimiento de la Fase 12

Benchmark ejecutado en Windows con Python 3.12.10. Los nombres se generan de
forma determinista y se procesan en flujo; la memoria es el pico del working set
del proceso Windows. El informe reproducible se genera con
`tools\benchmark_phase12.py`.

| Registros | Limpieza y clasificación | Velocidad | Exportación JSON | Velocidad | Pico |
|---:|---:|---:|---:|---:|---:|
| 10 000 | 1,63 s | 6 154/s | 0,24 s | 41 665/s | 18,8 MiB |
| 100 000 | 14,78 s | 6 765/s | 2,38 s | 42 093/s | 18,8 MiB |
| 500 000 | 72,58 s | 6 889/s | 11,90 s | 42 018/s | 19,0 MiB |
| 1 000 000 | 151,69 s | 6 592/s | 23,78 s | 42 049/s | 19,0 MiB |

El crecimiento es lineal y la memoria permanece constante. No se introdujo
concurrencia: no existe evidencia de que compense la complejidad ni el riesgo de
sobrecargar proveedores. La importación integral real se valida por separado con
el JSON MSL de muestra de 284 041 registros.

## Importación MSL real

La medición inicial de `tools\benchmark_msl_import.py` alcanzó 2.104,82 MiB y
45,73 s porque `json.load` materializaba el inventario completo. La implementación
incremental con `ijson` vuelve a recorrer las matrices sin conservarlas y libera
cada registro temporal después de mapearlo.

El benchmark posterior procesó los mismos 284.041 registros con estado
`completed_with_warnings` en 90,71 s (3.131 registros/s) y **573,93 MiB** de pico.
La memoria disminuyó 72,7 % y queda bajo el objetivo de 1 GiB. Una prueba de
equivalencia compara estado, estadísticas, incidencias, rutas, fuentes, videos,
subtítulos e ignorados entre ambos lectores. No se descarta información.

La prueba del ejecutable empaquetado arrancó desde un CWD ajeno, con Python
ausente de `PATH`, creó sus directorios privados y respondió antes del control de
los ocho segundos. No se observó bloqueo del hilo visual durante el arranque.
