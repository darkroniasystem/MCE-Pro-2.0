# Preparación para un futuro MCE Server

MCE Desktop 1.0 no incluye servidor, API pública, n8n ni acceso multiusuario.
Esta nota evita decisiones que obliguen a reescribir el núcleo posteriormente.

## Restricciones actuales

- El núcleo no depende de PySide6 ni de un proceso global de escritorio.
- Casos de uso reciben DTO serializables y devuelven resultados explícitos.
- Repositorios, almacenamiento, reloj, proveedores y transacciones son puertos.
- Los trabajos tienen identificadores estables y estados persistentes.
- Las operaciones mutables son idempotentes y auditables.
- Configuración y secretos se inyectan desde el entorno de ejecución.
- Los errores tienen códigos estables traducibles a CLI, GUI o HTTP.
- Logging usa contexto de trabajo/importación y no guarda secretos.

## Adaptadores futuros

Desktop, CLI y una eventual API llamarán los mismos casos de uso. La API será un
adaptador de presentación; n8n será un cliente externo. Ninguno reimplementará
validación, procesamiento o sincronización.

## Contrato operativo futuro

Un servidor podrá crear importaciones y trabajos, iniciar procesamiento, obtener
estado, aprobar una simulación y solicitar exportaciones. La autorización,
almacenamiento remoto, colas distribuidas y concurrencia multiusuario se
diseñarán en su propia fase; no se presuponen en Desktop 1.0.

