# Operaciones de la Fase 11

La Fase 11 incorpora exportación, auditoría, reversión, diagnóstico,
respaldo y mantenimiento sin convertir MCE en servidor ni integrar el futuro bot.

## Exportaciones

`ExportService` produce JSON UTF-8 con contrato `mce.export.v1` y CSV UTF-8 con
BOM para Excel. Escribe mediante archivo temporal y reemplazo atómico, admite
iterables grandes y excluye campos cuyo nombre indique contraseñas, tokens,
claves o URL de base de datos. Las celdas que podrían interpretarse como
fórmulas se neutralizan en CSV.

La interfaz permite exportar Catálogo, Bancos, Fuentes, Historial y el reporte
de Diagnóstico. El servicio acepta además conjuntos de disponibilidades,
archivos físicos, duplicados, errores, pendientes e importaciones cuando sus
repositorios los proporcionen.

## Contrato del futuro bot

`BotCatalogRecord` define `mce.bot.catalog.v1`. PostgreSQL publica la vista de
solo lectura `bot_catalog_v1`, con identidad, títulos, tipo, año, banco, alias y
metadatos normalizados. El bot continuará siendo una aplicación separada y en
esta fase no se crea una API pública.

## Auditoría y reversión

La tabla `audit_events` registra fecha UTC, actor, acción, tipo e identidad del
objeto, valores anterior y nuevo, `correlation_id` y relación de reversión. Las
acciones del escritorio se registran en PostgreSQL cuando
`MCE_TEST_DATABASE_URL` apunta exactamente a `mce_test`.

`TransactionalReversalService` aplica el manejador de reversión, crea el evento
inverso y enlaza el evento original dentro de una sola transacción. Un fallo
revierte tanto el cambio como la auditoría parcial.

## Copias de seguridad

`PostgresBackupService` usa exclusivamente `pg_dump` y `pg_restore`, sin `shell`.
La contraseña se transmite por `PGPASSWORD` al proceso hijo y nunca aparece en
argumentos, resultados ni documentación. Las copias usan formato custom `.dump`
y se validan con `pg_restore --list`.

La restauración está restringida por defecto a `mce_test`. El catálogo `mce`
requiere `allow_master=True` después de una confirmación expresa. Crear o validar
una copia no elimina bases de datos.

## Diagnóstico y mantenimiento

El reporte comprueba configuración segura de PostgreSQL, versiones de MCE y
Python, plataforma, espacio disponible, directorios y la integridad básica de
la caché SQLite. Nunca presenta credenciales.

El mantenimiento puede eliminar entradas de caché expiradas, detectar
checkpoints inválidos o interrumpidos y archivar checkpoints terminales. Solo
se archivan estados `completed`, `cancelled` o `failed`; el archivo se mueve a
un directorio controlado y no se toca ningún archivo multimedia.

## Límites deliberados

- No existe todavía una base de producción.
- No se implementa el bot ni una API remota.
- No se ejecutan optimizaciones, empaquetado o logging de producción de Fase 12.
- Restaurar una copia requiere una llamada explícita y permanece limitado a
  `mce_test` durante el desarrollo.
