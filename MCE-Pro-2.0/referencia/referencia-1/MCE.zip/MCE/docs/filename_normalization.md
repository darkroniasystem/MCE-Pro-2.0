# Normalización técnica de nombres

La Fase 4 analiza nombres y rutas importados sin renombrar archivos ni alterar
`original_name` u `original_path`. `FilenameNormalizationPipeline` aplica NFKC,
separa delimitadores y camel case seguro, extrae señales y genera candidatos.

## Componentes

- `TokenDictionary`: vocabulario técnico central e inmutable.
- `FilenameTokenizer`: extensión, Unicode, delimitadores y tokens.
- `NoiseClassifier`: años, resolución, codecs, fuente, audio, idioma, edición,
  HDR, 3D, calidad, región, volumen, parte, episodios y grupos.
- `TitleCandidateBuilder`: candidatos derivados y confianza.
- `NormalizationTrace`: explicación individual de cada token eliminado.

Los años se limitan a 1878–2100 y un nombre compuesto solo por un número,
como `1917`, queda protegido como título. Patrones episódicos generan pistas,
no una clasificación definitiva. Si existe ambigüedad se conserva además un
candidato alternativo de menor confianza.

## Límites

No identifica obras, consulta proveedores, traduce, renombra archivos, crea
relaciones definitivas ni ejecuta el motor de evidencias de la Fase 5.
