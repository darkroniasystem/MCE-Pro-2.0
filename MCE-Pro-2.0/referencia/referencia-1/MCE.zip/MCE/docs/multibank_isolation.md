# Aislamiento multibanco

MCE puede compartir la identidad lógica de una obra, pero nunca sus rutas ni su
disponibilidad. Toda consulta de inventario exige un `bank_id` explícito.

## Garantías PostgreSQL

- `physical_files.bank_id` es obligatorio, referencia `banks.id` y tiene un índice
  compuesto con fuente y ruta normalizada.
- `availabilities.bank_id` es obligatorio y solo admite una fila por
  `(content_id, bank_id)`.
- `BankScopedCatalogRepository` filtra rutas y disponibilidad por banco y rechaza
  consultas sin banco.
- La migración `0015` deriva el banco histórico desde escaneo e instalación para las
  rutas, y desde el dato previo o la obra para la disponibilidad.

Una obra global puede tener disponibilidad en varios bancos. Consultar el banco A
solo devuelve rutas del banco A; la misma consulta para B solo devuelve las de B.
La separación staging/aprobado/publicado permanece fuera de este alcance y se aborda
en las fases siguientes.
