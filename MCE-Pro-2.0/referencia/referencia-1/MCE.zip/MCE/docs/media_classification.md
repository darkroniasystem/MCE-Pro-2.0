# Motor local de evidencias

La Fase 5 convierte el análisis de nombres y carpetas en candidatos explicables. Cada
resultado incluye tipo, confianza, evidencia, alternativas, advertencias y un
conflicto visible cuando dos hipótesis tienen fuerza similar. Si la evidencia no
alcanza el umbral, el resultado es `unknown`.

`PathEvidenceEngine` recorre explícitamente las carpetas desde el padre más
cercano hacia la raíz. Cada coincidencia conserva el segmento, la palabra que
coincidió y su distancia. Las carpetas cercanas tienen prioridad sobre
contenedores genéricos lejanos y todas las palabras respetan límites léxicos para
evitar coincidencias parciales accidentales.

Se reconocen película, serie, temporada, episodio, novela, anime, dorama,
documental, animación occidental, disco DVD, especial y desconocido. Los
patrones episódicos incluyen `S01E01`, `1x01`, `T1 E1`, episodio/capítulo,
rangos y numeración continua.

Los patrones episódicos siguen siendo evidencias estructurales. No crean todavía
relaciones entre obras, temporadas, episodios, archivos y subtítulos. Esa
responsabilidad corresponde a la Fase 6.

Esta fase no identifica obras, consulta proveedores, persiste relaciones
editoriales, agrupa archivos ni decide automáticamente conflictos de baja
confianza.
