# Enriquecimiento, conflictos y revisión

La Fase 8 representa cada campo como `MetadataField`: valor, `FieldProvenance` y
estado de bloqueo. La procedencia conserva proveedor, registro externo, fecha,
confianza y origen automático o manual mediante `FieldSourceType`.

`MetadataConsolidator` aplica la prioridad explícita del dominio. Los valores
distintos siempre crean `MetadataConflict` con opciones y procedencias; una
fuente de mayor prioridad puede quedar como valor actual, pero la discrepancia
no desaparece. Una resolución humana selecciona una opción y genera auditoría.

`ReviewService` implementa listado, detalle, aprobación, rechazo, corrección,
bloqueo, desbloqueo, reversión y resolución. Cada acción conserva actor, fecha,
valor anterior/nuevo, razón y origen. Un bloqueo manual impide toda escritura
automática; un bloqueo de sistema solo admite una corrección manual explícita.

La aprobación o el rechazo de varias filas se ejecuta en un trabajador de fondo.
La selección queda congelada, los botones se deshabilitan durante la operación,
el progreso se informa por porcentaje y las tablas se refrescan una sola vez al
terminar. Las decisiones se guardan mediante la operación masiva del servicio y
los checkpoints se resuelven agrupados por sesión.

El puerto opcional `LanguageModelProvider` no escribe datos ni controla
transacciones. Su proveedor falso valida un esquema cerrado con tarea, valor y
explicación. Las respuestas inválidas o la desconexión son errores visibles.

No se implementan todavía interfaz de revisión, deduplicación final,
consolidación entre obras ni publicación del catálogo.
