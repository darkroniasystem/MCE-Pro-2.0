# Interfaz de escritorio

## Flujo principal

La navegación cotidiana sigue cuatro etapas visibles y numeradas:

1. **Importación**: selección, validación y creación de sesión.
2. **Limpieza y enriquecimiento**: control del pipeline, proveedores y progreso.
3. **Vista previa del catálogo**: revisión y filtros para anime, novelas,
   películas, series, temporadas y episodios.
4. **Finalización**: resumen por categoría y generación de salidas aprobadas.

Revisión humana, duplicados, bancos, fuentes, historial, configuración y
diagnóstico permanecen disponibles como herramientas auxiliares. Los nombres
internos de los casos de uso no cambian y ninguna etapa publica datos de forma
implícita.

Las cuatro etapas se presentan como pestañas superiores; no se duplican en la
barra lateral. El lateral queda reservado para Resumen y herramientas auxiliares,
mientras Configuración se abre desde el botón compacto de engranaje de la cabecera.
Las acciones de Sesiones se agrupan en Procesamiento, Consulta y Sesión para
separar controles normales de operaciones destructivas. Las etiquetas dentro de
tarjetas usan fondo transparente para evitar bloques o sombras detrás del texto.

Al iniciar una sesión aparece un monitor en tiempo real con dos barras: progreso
general y avance de la etapa activa. Sus métricas incluyen registros procesados,
velocidad, tiempo transcurrido, ETA aproximada, encontrados, pendientes y errores.
Los eventos se limitan para no saturar el hilo visual durante inventarios grandes.
Los grupos de acciones aparecen antes de la tabla para permanecer visibles en
ventanas 16:9. Al borrar una sesión inactiva también se retira su monitor anterior.

La Fase 10 incorpora una interfaz local PySide6 para Windows. La ventana principal
organiza Inicio, Importaciones, Sesiones, Pendientes de revisión, Catálogo,
Duplicados, Bancos, Fuentes, Historial, Configuración y Diagnóstico.

## Separación de responsabilidades

- Los widgets presentan información y emiten intenciones del usuario.
- Los presentadores traducen esas intenciones a solicitudes de aplicación.
- Los ViewModels mantienen estados, filtros y paginación sin depender de Qt.
- `TaskRunnable` y `QThreadPool` ejecutan operaciones costosas fuera del hilo visual.
- Los resultados regresan al hilo de interfaz únicamente mediante señales Qt.
- Los widgets no importan SQLAlchemy ni proveedores externos.

La cancelación es cooperativa mediante `CancellationToken`; nunca termina un hilo
por la fuerza. Las acciones destructivas visibles requieren confirmación.

## Flujo de importación

El usuario selecciona o arrastra un JSON de MSL, solicita su validación y recibe un
resumen con estado, versión de esquema, archivos e incidencias. Crear sesión solo se
habilita para paquetes válidos y se delega mediante una señal. Antes de crearla,
el usuario confirma un nombre de banco obligatorio, inicialmente tomado del JSON.

## Tablas y preferencias

Las tablas incluyen búsqueda, selección múltiple controlada, detalle y paginación.
`QSettings` conserva tema y geometría sin almacenar secretos.

La navegación utiliza iconos locales del sistema y una barra superior muestra la
sección activa, el estado de PostgreSQL y la actividad. El inicio distribuye sus
métricas en una cuadrícula; las tablas vacías orientan al usuario y la selección
abre un panel lateral de detalles. La importación presenta cuatro pasos y seis
métricas visuales para revisar el resultado antes de crear una sesión.

## Prueba visual manual

1. Active el entorno y ejecute `mce-desktop`.
2. Compruebe navegación por las once secciones con ratón y teclado.
3. Cambie de tema, cierre y reabra la aplicación.
4. Redimensione la ventana y confirme la restauración de geometría.
5. Arrastre un JSON válido y otro archivo no JSON sobre Importaciones.
6. Valide un JSON grande y confirme que la ventana sigue respondiendo.
7. Solicite cancelar durante el trabajo y compruebe el mensaje visible.
8. Compruebe filtros, paginación, selección múltiple y detalle.
9. Verifique las confirmaciones de acciones destructivas.
10. Revise contraste, foco, nombres accesibles y escalado de Windows.
11. Sin proveedores compatibles, inicie una sesión y confirme `waiting_internet`
    con cero revisiones creadas por el fallo de configuración.
12. Con las claves configuradas, reinicie MCE, confirme `Proveedores · 5/5` y compruebe
    que solo resultados probables, ambiguos o sin coincidencia pasan a revisión.

La automatización usa `QT_QPA_PLATFORM=offscreen`; no sustituye esta revisión visual.

Para una validación manual, use siempre **Seleccionar JSON** y el selector de
archivos del sistema. El archivo puede estar en cualquier carpeta, disco, memoria
USB o ruta accesible por el usuario. MCE no vigila carpetas, no precarga una ruta
de muestras y no depende de datos de desarrollo. El límite predeterminado es
1 GiB para admitir escaneos reales de bancos de copia.

Después de una validación aceptada, `Crear sesión` delega en `SessionService` fuera
del hilo visual. Al finalizar, la aplicación muestra la sesión con estado `ready`,
navega a Sesiones y guarda un checkpoint atómico en `data/session_checkpoints`.
Al reiniciar se recuperan las sesiones válidas.

`Iniciar` ejecuta las fases 5 a 9 fuera del hilo visual. Pausar, reanudar y cancelar
usan un token cooperativo. Los resultados sin identidad segura aparecen en
Pendientes de revisión; aprobarlos los incorpora al catálogo local. Duplicados usa
el detector conservador de la Fase 9 y permite combinar, separar, ignorar o posponer
con auditoría y reversión. Bancos, Fuentes, Historial y Diagnóstico se alimentan del
flujo real, no de datos de demostración.

El runtime persiste contenidos confirmados, IDs, aliases, metadatos y procedencia
en el catálogo maestro PostgreSQL `mce`. Las pruebas de integración utilizan de
forma exclusiva `mce_test`. Diagnóstico muestra por separado TMDb, Fanart.tv,
AniList y TVMaze sin revelar claves. Si falta configuración, Internet o cuota y no
existe respaldo compatible, la sesión queda en `waiting_internet`. Solo una
coincidencia realmente ambigua, probable o inexistente pasa a revisión humana.
Las revisiones repetidas de una misma obra se consolidan en una sola fila con el
número de archivos agrupados.

Vista previa y Finalización permiten exportar un PDF visual con carátulas y
secciones separadas para anime, novelas, películas, series, temporadas y episodios.
La descarga de carátulas rechaza rutas locales, HTTP y direcciones de red privadas.

Los controles principales y las once entradas de navegación incluyen ayudas
emergentes descriptivas al mantener el puntero encima. Las incidencias de importación
se agrupan por código y cantidad para evitar miles de líneas repetidas; la interfaz
muestra como máximo cinco tipos principales y conserva los contadores completos.
