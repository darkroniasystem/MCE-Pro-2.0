# Política de proveedores

1. Consultar primero el proveedor especializado.
2. Consultar Wikidata como complemento para alias e IDs.
3. Ante `success_no_results`, evaluar Wikidata y los demás proveedores.
4. Ante timeout, rate limit o indisponibilidad del principal, conservar el
   resultado complementario como `provider_partial`; nunca confirmar ausencia.
5. Confirmar `not_found` solo cuando todos los proveedores aplicables terminen.
6. La fusión añade alias e IDs y rellena vacíos; no sobrescribe silenciosamente
   los campos protegidos del proveedor principal.
