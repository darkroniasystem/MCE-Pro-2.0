# Pipeline de importación

```text
MSL JSON
   │
   ▼
SafeJsonReader
   │
   ▼
SchemaDetector
   │
   ▼
StructuralValidator
   │
   ▼
SemanticValidator
   │
   ▼
ImportMapper
   │
   ▼
ImportPackage
   │
   ▼
ImportResult
```

## Lector

`SafeJsonReader` comprueba existencia, archivo regular, extensión, tamaño,
UTF-8/BOM, sintaxis, raíz objeto y profundidad. Rechaza enlaces simbólicos y no
abre ninguna ruta multimedia mencionada por el documento.

## Detector de esquema

`SchemaDetector` clasifica versiones como soportadas, ausentes, mal formadas,
futuras, legadas o incompatibles. No interpreta registros.

## Normalizador

`MslNormalizer` aplica exclusivamente alias de campos conocidos para 1.0, 2.2
y legado. Conserva nombres, rutas y valores declarados; solo recorta espacios,
normaliza extensiones y prepara rutas para comparación.

## Validadores

`StructuralValidator` revisa contenedores y campos mínimos. `SemanticValidator`
comprueba referencias, IDs duplicados, fechas, rutas, extensiones, tipos,
alcance y resumen. Ambos producen `ImportIssue`; el modo estricto cambia la
política de aceptación, no duplica las reglas.

## Hash y duplicados

`LocalSha256Calculator` lee el JSON original por bloques. `ImportRegistry` es un
puerto y `InMemoryImportRegistry` su implementación temporal. Un hash repetido
produce `duplicate` antes del mapeo salvo autorización `force_duplicate`.

## Mapper

`ImportMapper` genera UUID internos cuando sea necesario y crea únicamente
`Scan`, `ScanImport`, `ScanScope`, `Source`, `PhysicalFile` y `Subtitle`. No crea
obras, versiones, temporadas, episodios ni disponibilidad.

## Resultado atómico

Un error o advertencia bloqueante en modo estricto devuelve incidencias y
estadísticas, pero nunca un paquete marcado como válido. Solo después del mapeo
completo se registra el hash y se devuelve `completed` o
`completed_with_warnings`.

Las etapas opcionales de progreso son `reading`, `hashing`,
`detecting_schema`, `validating_structure`, `validating_records`, `mapping` y
`completed`. No dependen de PySide6 ni de hilos.
