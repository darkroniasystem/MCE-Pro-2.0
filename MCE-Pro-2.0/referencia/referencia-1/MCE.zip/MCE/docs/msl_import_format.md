# Formato de importación MSL

## Versiones admitidas

MCE admite los esquemas `1.0` conceptual y `2.2` observado en una exportación
real de MSL. La ausencia de `schema_version` se clasifica como legado y solo se
acepta con `allow_legacy=True`. Versiones futuras, incompatibles o mal formadas
se rechazan mediante un `ImportResult` controlado.

## Contrato canónico 1.0

Campos raíz reconocidos:

```text
schema_version  requerido salvo legado permitido
generator       opcional en modo normal
scan            fechas, ID y alcance
bank            opcional en modo normal
installation    opcional en modo normal
sources         lista de fuentes
files           lista de archivos
summary         opcional en modo normal
```

Cada archivo requiere nombre y al menos una ruta relativa o completa. `source_id`,
IDs de archivo, tamaño y hash multimedia son opcionales en modo normal. El modo
estricto rechaza advertencias como IDs ausentes, referencias rotas o resúmenes
inconsistentes.

## Formato real 2.2

La política de alias reconoce explícitamente:

```text
banco            → bank
instalacion      → installation
fuentes          → sources
videos           → files de tipo video
fecha_inicio     → scan.started_at
fecha_fin        → scan.finished_at
alcance_escaneo  → scan.scope
nombre/ruta      → display_name/root_path
ruta_relativa/ruta_completa → rutas de archivo
```

Los IDs como `scan_...`, `src_...` o `med_...` se conservan como valores
declarados. Como no son UUID del dominio, MCE genera IDs internos y registra
`INVALID_EXTERNAL_ID` sin destruir el valor original.

## Formato legado

Los alias controlados incluyen `file_name`, `filename`, `name`, `path`,
`full_path`, `extension`, `ext`, `files`, `archivos`, `sources` y `fuentes`.
No se traducen campos desconocidos arbitrariamente. El uso de legado produce
`SCHEMA_VERSION_MISSING` y `LEGACY_FIELD_ALIAS`.

## Extensiones

Videos: `.mp4`, `.mkv`, `.avi`, `.mov`, `.mpg`, `.mpeg`, `.m4v`, `.wmv`,
`.flv`, `.webm`, `.ts`, `.m2ts`, `.vob`, `.3gp`, `.ogv`.

Subtítulos: `.srt`, `.ass`, `.ssa`, `.vtt`, `.sub`, `.smi`. `.txt` se conserva
como subtítulo probable y genera `AMBIGUOUS_TEXT_FILE`.

DVD: `VIDEO_TS`, `VIDEO_TS.IFO` y `VTS_XX_X.VOB`. La Fase 2 los reconoce, pero
no agrupa un DVD completo como película.

Extensiones desconocidas se conservan en `ignored_files`, generan
`UNKNOWN_EXTENSION` y no impiden una importación normal.

## Ejemplo mínimo

```json
{
  "schema_version": "1.0",
  "scan": {
    "started_at": "2026-07-19T10:00:00Z",
    "finished_at": "2026-07-19T10:01:00Z",
    "scope": {"type": "full"}
  },
  "sources": [{"source_id": "source-1", "root_path": "E:\\"}],
  "files": [{"source_id": "source-1", "name": "Film.mkv", "relative_path": "Film.mkv"}]
}
```

## Errores comunes

- JSON vacío, mal formado o con raíz distinta de objeto.
- Archivo mayor que `ImportLimits.max_file_size_mb`.

El límite predeterminado es `1024 MiB` (1 GiB). La comprobación ocurre antes de
leer el JSON y puede reducirse o ampliarse explícitamente mediante `ImportLimits`.
- Versión futura o incompatible.
- Fechas sin zona horaria o rango invertido.
- `source_id` inexistente o duplicado.
- Nombre/ruta vacíos, caracteres nulos o longitudes excesivas.
- Extensión y tipo multimedia contradictorios.
- Contadores del resumen diferentes a los registros.

El importador carga actualmente el JSON completo en memoria después de validar
su tamaño. El diseño separado permite añadir lectura incremental en una fase
futura sin cambiar DTO ni reglas.

Tras la confirmación de creación de sesión, el archivo validado se conserva sin
alteraciones y se enlaza con su manifiesto de staging según
`original_json_staging.md`.

Los escaneos posteriores reutilizan identidades lógicas sin perder sus
observaciones históricas según `incremental_import.md`.
