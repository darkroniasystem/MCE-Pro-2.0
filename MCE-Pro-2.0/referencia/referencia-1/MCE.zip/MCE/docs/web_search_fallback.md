# Búsqueda web de respaldo (Fase 12)

MCE consulta la web únicamente como evidencia adicional cuando los proveedores
estructurados no encuentran la obra, devuelven candidatos ambiguos, dejan una
confianza de 75 a 94, contradicen el tipo local o carecen de evidencia esencial.
Un resultado web nunca cambia por sí solo el estado a `identified`.

La implementación usa una interfaz `WebSearchProvider` intercambiable. El
adaptador seleccionado consume la API JSON de Tavily y no analiza HTML, resultados
de Google ni paneles de conocimiento. Se habilita explícitamente con:

```text
TAVILY_API_KEY=<credencial>
```

Opciones:

- `MCE_WEB_SEARCH_MAX_CANDIDATES` (mínimo 2, valor inicial 8).
- `MCE_WEB_SEARCH_CACHE_TTL_HOURS` (valor inicial 24).

La consulta combina título limpio, tipo probable, año y temporada. Por cada
candidato se conserva fuente, título, tipo inferido, año, descripción, URL HTTPS,
puntuación posicional, fecha de recolección y consulta. La caché SQLite es
persistente e independiente de las sesiones, pero comparte el archivo físico de
caché de metadatos para simplificar respaldo y mantenimiento.

Tavily usa los mismos límites configurables de timeout, reintentos, solicitudes,
concurrencia, intervalo mínimo y circuit breaker que los proveedores de la Fase 11.
La caché se consulta antes de entrar en esos controles, por lo que una coincidencia
vigente no consume cuota ni crédito.

Sin proveedor o credencial configurados, la función queda desactivada de forma
explícita y el flujo estructurado de la Fase 11 continúa intacto.
