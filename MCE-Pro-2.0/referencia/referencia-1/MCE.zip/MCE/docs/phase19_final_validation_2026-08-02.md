# Fase 19 — Validación final

Fecha: 2026-08-02  
Versión: 0.12.0  
Plataforma de validación: Windows 10 19045, Python 3.12.10, PostgreSQL

## Resultado ejecutivo

La suite, las migraciones aisladas, los siete JSON reales, el clasificador etiquetado,
el rendimiento, la distribución PyInstaller y una importación externa posterior a la
eliminación de `samples` fueron validados correctamente. El propietario declaró que
MCE se utilizará exclusivamente en esta computadora, por lo que la validación en un
segundo equipo queda fuera del alcance operativo final.

## Pruebas automatizadas

- Suite completa final: 400 passed, 5 deselected, 107.56 s.
- Dataset etiquetado: 20 rutas anónimas; siete categorías comerciales; precisión
  mínima exigida 95 %, cero falsos positivos y un caso pendiente esperado.
- Migraciones PostgreSQL en base temporal aislada:
  - base vacía a head: 0017;
  - 43 tablas resultantes;
  - revisión 0016 a head: 0017;
  - base temporal eliminada al terminar.
- Defecto corregido: las migraciones posteriores al esquema inicial ahora reconocen
  de forma segura un esquema actual ya materializado y no recrean columnas/tablas.

## JSON reales de MSL

| Banco | Registros | Duración | Rendimiento | Pico RSS |
|---|---:|---:|---:|---:|
| animado | 9,582 | 1.525 s | 6,283/s | 85.86 MiB |
| combos | 10,991 | 1.953 s | 5,629/s | 131.04 MiB |
| concursos | 14,554 | 2.341 s | 6,216/s | 125.22 MiB |
| doramas | 6,116 | 1.109 s | 5,515/s | 61.09 MiB |
| novelas | 113,542 | 47.004 s | 2,416/s | 240.63 MiB |
| peliculas | 37,579 | 5.813 s | 6,464/s | 271.85 MiB |
| serie | 132,352 | 45.150 s | 2,931/s | 286.84 MiB |

Total: 324,716 registros. La medición fue de lectura, validación y mapeo, sin
persistencia automática ni dependencia productiva hacia la carpeta de muestras.

## Rendimiento adicional

- Pipeline de 10,000 elementos: 5.157 s, 1,938.95/s, 19.031 MiB.
- Pipeline de 100,000 elementos: 49.310 s, 2,027.99/s, 19.031 MiB.
- Exportación de 10,000 elementos: 0.271 s, 36,893/s, 19.277 MiB.
- Exportación de 100,000 elementos: 2.384 s, 41,955/s, 19.539 MiB.

## Distribución

- PyInstaller 6.21.0; compilación reproducible completada en 105.1 s.
- `dist/MCE/MCE.exe`: 10,329,807 bytes.
- Distribución onedir: 867 archivos.
- Auditoría: `secrets_exposed=false`, `samples_dependency=false`.
- Arranque compilado con PostgreSQL: 0.767 s hasta integridad inicial.
- Integridad: modo seguro desactivado, cero errores y cero advertencias.
- Validación visual manual en esta computadora: correcta.
- Configuración `MCE_DATABASE_URL` persistida y validada mediante un arranque normal
  desde Explorer.
- Corrección final: el modo seguro ya no materializa checkpoints locales mayores de
  8 MiB durante el arranque. La prueba de regresión conserva la recuperación de
  checkpoints pequeños. Antes de la corrección, dos instancias llegaron a consumir
  aproximadamente 3.3 GiB; después, el EXE arrancó en 0.744 s y utilizó unos 141 MiB.

## Importación externa posterior a `samples`

- Archivo: `fase19_validacion_externa.json` (1,073 bytes).
- SHA-256: `2a0d888676b01d3ba8097258d331ad274a27a2e5173b345eeb65c773bc9df27b`.
- Schema: 2.2.
- Scan: `scan_fase19_externo_20260802`.
- Banco externo: `bank_fase19_externo`.
- Flujo real: seleccionado, validado y convertido en sesión desde la interfaz.
- Resultado: una sesión, un banco, una fuente, un video, cero subtítulos.
- Persistencia: un insertado, cero actualizados, cero duplicados, una advertencia MSL,
  cero errores y cero cruces de identidad de archivo entre bancos.
- Archivo original archivado como `verified`; tamaño y hash coinciden con el original.
- Alcance parcial: cero ausencias alteradas.
- Memoria del EXE tras importar: aproximadamente 172 MiB; proceso respondiendo.

## Limpieza

- `samples` fue eliminada antes de la importación externa final.
- La distribución final se conserva en `dist/MCE`.
- Las fuentes, pruebas, migraciones, documentación, recursos, configuración pública y
  scripts reproducibles se conservan.

## Cierre

No quedan comprobaciones aplicables pendientes. La prueba en una segunda computadora
se declaró no necesaria porque la instalación de producción estará limitada a este
equipo. Con esa decisión de alcance, la Fase 19 queda completada.
