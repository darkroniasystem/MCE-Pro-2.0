# Enriquecimiento por obra única (Fase 11)

El enriquecimiento recibe exclusivamente obras lógicas agrupadas por
`work_group_id`. Los archivos físicos y subtítulos permanecen vinculados, pero no
incrementan el total ni originan consultas independientes. Las categorías elegidas
congelan el total mostrado por la barra de progreso antes de iniciar el trabajo.

## Estrategia de proveedores

- Película: TMDb y evidencia complementaria de Wikidata.
- Serie, novela, dorama, concurso o reality: TMDb TV, TVMaze y Wikidata.
- Anime: AniList, TMDb y Wikidata.
- Fanart.tv solo completa imágenes cuando existe un identificador compatible.

Cada proveedor tiene caché persistente independiente de la sesión, cuota local,
reintentos exponenciales, ritmo mínimo configurable, límite de concurrencia y
circuit breaker independiente. Un fallo de un proveedor se registra y los demás
continúan. Se distinguen ausencia de resultados, cuota, timeout, autenticación,
respuesta inválida e indisponibilidad.

Los umbrales iniciales son configurables mediante `MatchPolicy`: 95–100 permite
identificación automática si no hay ambigüedad; 75–94 produce candidato probable;
0–74 exige revisión. Nunca se adopta simplemente el primer resultado.

Cada elemento de una obra conserva `providers_completed`, `providers_pending`,
`providers_failed` y `metadata_from_cache`. PostgreSQL deriva `cache_hits` por obra
única, no por archivo físico. Los resultados completados se guardan y checkpointan
al terminar cada obra para que una pausa, cancelación o cierre no repita llamadas.

La búsqueda web de respaldo no forma parte de esta fase.
