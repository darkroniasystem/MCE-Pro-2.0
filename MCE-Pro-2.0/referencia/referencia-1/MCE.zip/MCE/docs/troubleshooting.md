# Solución de problemas

## MCE no inicia

- Confirme que copió toda la carpeta `dist\MCE`, incluida `_internal`.
- Revise `%LOCALAPPDATA%\MCE Desktop\logs\mce-desktop.log`.
- Pruebe renombrar temporalmente `settings.ini` si la configuración está dañada.

## PostgreSQL aparece pendiente

- Compruebe la variable de entorno y reinicie MCE.
- Durante desarrollo, la base debe llamarse exactamente `mce_test`.
- Confirme servicio, host, puerto, usuario y firewall sin publicar la contraseña.
- Ejecute las migraciones hasta `head`.

## Proveedores sin conexión

Revise acceso HTTPS, claves y cuotas. MCE conserva la sesión como
`waiting_internet`; no envía masivamente los archivos a revisión.

## Browser no está disponible

- Abra **Configuración** y use **Probar navegador**.
- Si Playwright está disponible pero Chrome/Chromium no, instale un navegador
  compatible en Windows o configure el canal local soportado. MCE no empaqueta
  un navegador.
- Un CAPTCHA, bloqueo o página inesperada se registra como evidencia no
  disponible; MCE no intenta evadir protecciones.
- Revise el detalle del proveedor y el log antes de reintentar. Evite repetir
  el lote mientras exista un bloqueo o una cuota activa.

## Ollama o Qwen no están disponibles

- Confirme que Ollama esté iniciado y accesible en la URL configurada.
- Confirme que el modelo configurado, por defecto `qwen2.5:3b`, exista en
  Ollama.
- Use **Probar Ollama y Qwen** para distinguir servidor caído, modelo ausente e
  inferencia fallida.
- MCE no incluye Ollama ni descarga modelos automáticamente.

## Cuota o enfriamiento de Groq

El panel muestra el plazo de espera conocido o conservador. No pulse reanudar
repetidamente: MCE conserva el checkpoint y omite llamadas mientras siga activo
el enfriamiento. Si el proveedor no informa una renovación fiable, espere el
plazo mostrado y consulte el log antes de continuar.

## Caché dañada

Cierre MCE, conserve una copia si necesita diagnóstico y retire
`%LOCALAPPDATA%\MCE Desktop\cache\metadata_cache.sqlite3`. MCE creará una caché
nueva. Esto no elimina el catálogo PostgreSQL.

## Sesión interrumpida

Reabra MCE y consulte **Sesiones**. Los checkpoints válidos se restauran. Un
checkpoint corrupto no se ejecuta y queda indicado por Diagnóstico.

## Archivo JSON rechazado

MCE exige archivo regular `.json`, UTF-8, dentro del límite configurado y sin
enlaces simbólicos. Revise el código de incidencia mostrado por el importador.
