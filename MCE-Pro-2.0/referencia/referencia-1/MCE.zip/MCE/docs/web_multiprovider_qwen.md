# Motor web multiproveedor y Qwen local

## Flujo

MCE conserva a los proveedores estructurados como primera autoridad. La búsqueda
web solo se ejecuta cuando esos proveedores no resuelven una obra lógica:

1. caché web compartida;
2. Tavily;
3. Serper, solo si Tavily falla o aporta evidencia insuficiente;
4. Exa, solo si los anteriores no bastan;
5. BrowserSearchProvider, solo si las tres APIs siguen siendo insuficientes;
6. Qwen local mediante Ollama;
7. validador determinista de MCE;
8. Groq únicamente si Qwen falla o no es aceptado;
9. revisión humana cuando ninguna propuesta puede demostrarse.

La búsqueda, el análisis y el progreso se realizan por obra lógica única, no por
archivo o episodio.

La evidencia insuficiente de cada proveedor se conserva y se combina con la del
siguiente. Las URLs normalizadas se deduplican y el límite final prioriza
dominios distintos, evitando perder una segunda fuente útil por haber llenado el
cupo con varios resultados del mismo sitio.

Cada intento registra resultados propios, resultados nuevos, total acumulado,
estado y uso de caché. Cada proveedor controlado expone además una telemetría
común con prioridad, timeout conocido, reintentos, fallos consecutivos,
enfriamiento, circuito, última operación, solicitudes, éxitos, fallos, rate
limits y cuotas locales agotadas.

Serper y Exa descartan filas malformadas y URLs no HTTPS, aceptan respuestas
vacías sin convertirlas en errores y limitan el texto conservado. Ante 429 no
repiten inmediatamente la misma solicitud: registran el límite o cuota y pasan
al proveedor siguiente. La inspección interna de un error nunca expone el cuerpo
remoto, la consulta ni las credenciales.

Tavily también trata 432 (límite del plan) y 433 (límite de pago por uso) como
cuota agotada. Esos estados no se reintentan en cadena: se registran de forma
sanitizada y el gestor continúa con Serper y Exa.

## Configuración

Las credenciales se leen exclusivamente desde variables de entorno:

- TAVILY_API_KEY
- SERPER_API_KEY
- EXA_API_KEY
- GROQ_API_KEY

La interfaz permite activar cada proveedor y cambiar su prioridad. Desde la
Fase P, los valores predeterminados medidos son Exa 10, Serper 20 y Tavily 30.
La migración cambia una sola vez los antiguos valores predeterminados y conserva
cualquier prioridad que el usuario haya personalizado. Browser mantiene 40.

Browser tiene prioridad 40 y permanece desactivado por defecto. Su contrato ya
está integrado. Playwright 1.62.0 y el control de Chrome local fueron validados
en la Fase H; el Chromium administrado por Playwright no pudo descargarse por
una restricción externa de ubicación. Configuración inicial:

    BROWSER_SEARCH_ENABLED=false
    BROWSER_HEADLESS=true
    BROWSER_TIMEOUT=20
    BROWSER_MAX_CONCURRENCY=1
    BROWSER_DELAY_MIN_MS=1000
    BROWSER_DELAY_MAX_MS=2500
    BROWSER_MAX_RESULTS=5
    BROWSER_MAX_PAGE_TEXT_CHARS=12000
    MCE_BROWSER_PRIORITY=40
    MCE_BROWSER_CHANNEL=chrome
    MCE_BROWSER_SEARCH_URL_TEMPLATE=https://www.bing.com/search?q={query}

La Fase N conectó el contrato a un backend Playwright real que reutiliza una
sola instancia de Chrome, crea y cierra una página por consulta y ejecuta todas
las operaciones del navegador en un hilo dedicado. La cola acotada y la
concurrencia máxima de uno aplican contrapresión; no se crean navegadores sin
límite. Si Playwright o Chrome no están disponibles, el diagnóstico queda
visible y MCE continúa por la ruta conservadora sin simular evidencia.

El extractor de la Fase I admite resultados orgánicos y panel enriquecido con
múltiples selectores defensivos. Puede conservar título, enlace, snippet, año,
tipo, temporadas, géneros, reparto, valoración, plataformas, títulos
alternativos y texto visible limitado. Todos los campos son opcionales: si una
página solo demuestra una parte, el resto permanece pendiente.

La Fase J convierte esos valores en `MetadataField` con procedencia
`browser_search` por campo. No se crean campos vacíos para completar una ficha y
la completitud descriptiva no equivale a confianza de identidad. Los bloqueos
manuales y conflictos continúan bajo las reglas generales de consolidación de
MCE; el navegador no publica ni aprueba por sí solo.

Los estados CAPTCHA y bloqueo nunca activan mecanismos de evasión. El proveedor
se detiene, conserva el diagnóstico y permite que MCE continúe hacia IA o
revisión humana.

Ollama es opcional. Valores iniciales:

    OLLAMA_ENABLED=false
    OLLAMA_BASE_URL=http://localhost:11434
    OLLAMA_MODEL=qwen2.5:3b
    OLLAMA_TIMEOUT=120
    LOCAL_LLM_MAX_CONCURRENCY=1
    LOCAL_LLM_MAX_WEB_RESULTS=5
    LOCAL_LLM_MAX_CONTEXT_CHARS=8000
    LOCAL_LLM_MAX_OUTPUT_TOKENS=800
    LOCAL_LLM_CIRCUIT_FAILURE_THRESHOLD=3
    LOCAL_LLM_CIRCUIT_COOLDOWN_SECONDS=60

MCE no instala Ollama ni descarga modelos automáticamente. Después de instalar
Ollama, el modelo se prepara manualmente con:

    ollama pull qwen2.5:3b

La opción Probar Ollama y Qwen comprueba el servicio, la presencia exacta del
modelo y una inferencia mínima.

### Contrato local de Qwen

La Fase K conecta el enriquecimiento parcial del navegador con Qwen mediante
`BrowserQwenEvidenceAdapter`. El contexto conserva título, año, tipo,
temporadas, géneros, reparto, valoración, plataformas, títulos alternativos,
snippet, URL y origen cuando cada valor existe. Qwen analiza esos datos, pero
no cuenta como una fuente independiente.

El contexto se serializa siempre como JSON completo. Si excede el límite, MCE
reduce snippets y luego la cantidad de evidencias; nunca corta una cadena JSON
a mitad. La salida rechaza propiedades desconocidas, nombres de campo fuera de
la lista permitida y URLs que no estuvieran en la evidencia recibida. Cada
metadato analizado puede conservar valor, confianza y URLs de procedencia.

Los estados locales admitidos son `matched`, `partial_match`, `ambiguous` e
`insufficient_evidence`. Una respuesta parcial nunca se autoaprueba y cualquier
URL inventada fuerza revisión. La decisión Qwen-validator-Groq pertenece a la
Fase L.

### Ruta validada Qwen a Groq

La Fase L conserva en el resultado interno el estado y la recomendación de
Qwen. MCE solo acepta directamente una salida local `matched` + `accept`, con
confianza mínima 80, dos dominios públicos independientes, títulos respaldados,
tipo compatible, puntuación determinista mínima 95, cero contradicciones y cero
URLs inventadas.

Todo resultado local no aceptado —incluidos baja confianza, `partial_match`,
`ambiguous`, `insufficient_evidence`, timeout, JSON o esquema inválido,
contradicciones, fuentes inventadas u Ollama no disponible— escala una sola vez
a Groq. Una salida aceptada por Qwen no consume Groq.

Groq tampoco se autoaprueba: su salida vuelve a pasar por validación de fuentes,
confianza y puntuación determinista. Una URL no suministrada o cualquier falta
de evidencia suficiente termina en revisión humana. Los 429 siguen propagando
el estado recuperable existente y no encadenan modelos adicionales.

## Caché y seguridad

La caché web compartida utiliza título normalizado, aliases incluidos en la
consulta, año, categoría y versión de estrategia. Conserva en cada evidencia el
proveedor que produjo el resultado y puede reutilizar entradas Tavily anteriores.

Qwen y Groq reciben fragmentos limitados; no reciben páginas completas ni rutas
privadas. Solo pueden citar URLs suministradas por MCE. Una URL inventada se marca
como hallucinated_source, impide la aprobación automática y provoca escalamiento
o revisión humana.

## Reanudación

Los estados aceptados continúan guardándose mediante los trabajos, elementos y
checkpoints PostgreSQL existentes. La caché SQLite es independiente de las
sesiones. Reiniciar MCE no debe repetir una obra completada ni una búsqueda válida
que siga dentro de su TTL.

La Fase M endurece esa garantía. La versión del contrato IA forma parte de la
huella de cada obra (`mce.ai-review.prompt.v4`), por lo que una respuesta creada
con un prompt anterior no se reutiliza como si hubiera pasado por las reglas
Qwen-validator-Groq actuales. La caché IA solo reutiliza estados terminales:
aprobado, revisión humana o no encontrado. Esperas por cuota o proveedor, errores
y demás estados transitorios se descartan para que el trabajo pendiente pueda
intentarse de nuevo.

Las entradas web y de revisión IA incluyen una suma SHA-256 del contenido. Una
entrada alterada, incompleta o ilegible se elimina y se vuelve a calcular; las
entradas antiguas sin suma siguen siendo compatibles y se actualizan al leerse.
Una falla transitoria del proveedor no se guarda como resultado web válido.

El checkpoint de procesamiento continúa avanzando por `work_group_id`, es decir,
por obra lógica y no por cantidad de archivos. Cada grupo terminado se persiste
antes de continuar; al reiniciar solo se seleccionan grupos pendientes. Las
consultas terminales ya registradas y los resultados aceptados no se repiten.
Solicitudes simultáneas con la misma huella se agrupan en una sola búsqueda y
un solo análisis.

## Estado de validación

Tavily, Serper y Exa fueron comprobados realmente el 2026-08-10 con consultas
aisladas. Ollama y `qwen2.5:3b` fueron comprobados mediante diagnóstico e
inferencia real. El benchmark posterior a la corrección procesó 50 variantes:
0 errores, 0 URLs inventadas, 56 % de título canónico exacto y 0 aprobaciones
incorrectas. La latencia media fue 12.447 ms, p50 12.299 ms y p95 15.514 ms.
Los resultados completos están en `docs/qwen_benchmark_2026-08-10_v2.json`.

El validador exige que dos dominios independientes respalden exactamente el
título canónico antes de aprobar. Qwen funciona como primer filtro conservador;
lo no aceptado escala a Groq o revisión humana.

En la validación real de Fase N del 2026-08-14, Serper, Exa, Qwen local, Groq y
Chrome/Playwright aprobaron sus recorridos. Chrome también extrajo resultados
de una búsqueda pública de Bing después de incorporar el respaldo DOM descrito
arriba. Tavily respondió 432 por cuota de plan agotada: MCE lo clasificó como
cuota, no reintentó y dejó disponible la continuación multiproveedor.
