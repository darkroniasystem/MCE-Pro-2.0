# Proveedores de metadatos

TMDb es la fuente principal para películas y series, AniList para anime y
TVMaze complementa series. Fanart.tv aporta imágenes. Wikidata no sustituye
estas fuentes: aporta etiquetas, alias, sitelinks e identificadores externos.

Solo `success_no_results` significa una consulta válida sin candidatos. Límites,
timeouts, indisponibilidad y respuestas inválidas mantienen estados distintos.
