# Títulos alternativos y búsqueda

MCE conserva por separado el nombre original observado en el banco, el título
limpio local, el título original de la obra y las variantes española e inglesa.
Los títulos alternativos se almacenan en `content_aliases` con forma normalizada,
idioma, país, tipo, procedencia, alcance de banco y confirmación manual.

TMDb aporta títulos alternativos regionales y traducciones; AniList aporta título
nativo, inglés, romanizado y sinónimos. TVMaze aporta el título canónico y
Wikidata etiquetas y alias multilingües. La fusión conserva
los alias de todos los proveedores activos y elimina duplicados normalizados.

La clave de búsqueda elimina diferencias de caja, diacríticos, puntos, guiones y
otros signos. También equipara números romanos básicos del I al XX con sus formas
arábigas. Una búsqueda siempre exige `bank_id`: los alias globales ayudan a
encontrar la obra dentro del banco consultado, pero nunca exponen disponibilidad
de otro banco.
