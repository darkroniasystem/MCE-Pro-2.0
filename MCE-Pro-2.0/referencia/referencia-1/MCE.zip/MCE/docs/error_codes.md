# Códigos de error

## Formato

`MCE-<ÁREA>-<NNN>`, donde el área identifica el subsistema. Todo error
estructurado incluirá `error_code`, `message`, `technical_detail`, `stage`,
`job_id`, `import_id`, `recoverable`, `suggested_action` y `timestamp`.

Los detalles técnicos se registran en logs; la interfaz muestra un mensaje útil
sin credenciales, tokens ni datos personales innecesarios.

## Catálogo inicial

| Código | Significado | Recuperable | Acción sugerida |
|---|---|---:|---|
| `MCE-IMP-001` | JSON inválido o ilegible | Sí | Seleccionar una exportación válida de MSL |
| `MCE-IMP-002` | Versión de esquema incompatible | Sí | Actualizar MCE o exportar con una versión compatible |
| `MCE-IMP-003` | Contrato incompleto | Sí | Revisar los campos indicados |
| `MCE-IMP-004` | Identidad de banco o instalación inválida | Sí | Corregir la identidad en MSL y reexportar |
| `MCE-IMP-005` | Importación ya registrada | Sí | Abrir el trabajo existente o confirmar reprocesamiento |
| `MCE-JOB-001` | Transición de estado inválida | Sí | Actualizar el trabajo y repetir una acción permitida |
| `MCE-SES-001` | Paquete inválido o ya asociado a sesión | Sí | Abrir la sesión existente o importar otro paquete |
| `MCE-SES-002` | Checkpoint dañado o incompatible | Sí | Conservarlo y restaurar un checkpoint compatible |
| `MCE-DB-001` | Conexión a base de datos fallida | Sí | Comprobar servicio y credenciales |
| `MCE-API-001` | Proveedor no disponible | Sí | Reintentar o continuar sin conexión |
| `MCE-SYNC-001` | Sincronización revertida | Sí | Revisar el conflicto y volver a simular |
| `MCE-EXP-001` | Exportación fallida | Sí | Verificar destino, espacio y permisos |
| `MCE-PDF-001` | Generación de PDF fallida | Sí | Revisar recursos y destino |
| `MCE-CFG-001` | Configuración inválida | Sí | Restaurar valores válidos sin exponer secretos |
| `MCE-INT-001` | Error interno no clasificado | No | Conservar el log y reportar el incidente |

Agregar un código exige documentar su semántica y probar su emisión. Un código
existente no se reutiliza con otro significado.
