# Revisión por obra y aprobación masiva

La pantalla **Pendientes de revisión** presenta una fila por `work_group_id`. Una fila
puede representar varios archivos y conserva el total en `archivos agrupados`; las
decisiones nunca se repiten por episodio o archivo.

## Alcance de las acciones

- **Aprobar** y **Rechazar** actúan sobre las filas seleccionadas de la página visible.
- **Aprobar todas** congela todas las obras que coinciden con el filtro actual, incluidas
  las que están en otras páginas.
- Una obra con el mismo identificador solo entra una vez en el lote.
- Corregir y bloquear siguen siendo decisiones individuales.

## Ejecución y progreso

Los lotes se ejecutan mediante `TaskRunnable`, fuera del hilo de Qt. Mientras están
activos se deshabilitan las acciones de revisión, pero la ventana continúa atendiendo
eventos. La selección se congela al comenzar y el porcentaje usa exclusivamente ese
total. El 100 % se emite después de aplicar las decisiones y actualizar las sesiones.

Si el trabajador falla, las acciones vuelven a habilitarse y la interfaz conserva las
filas que no llegaron a confirmarse. La publicación atómica del catálogo pertenece a la
Fase 17 y no forma parte de este contrato.
