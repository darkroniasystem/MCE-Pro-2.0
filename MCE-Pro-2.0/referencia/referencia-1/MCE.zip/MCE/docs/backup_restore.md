# Backup y restauración PostgreSQL

MCE utiliza el formato custom oficial de PostgreSQL. Las operaciones se ejecutan
sin `shell`; la contraseña se entrega al proceso mediante `PGPASSWORD` y no se
incluye en argumentos ni logs.

## Crear y validar

`PostgresBackupService.create()` invoca `pg_dump --format=custom` y reemplaza el
destino solamente cuando se creó una copia no vacía. `validate()` ejecuta
`pg_restore --list`.

## Restaurar

La restauración valida primero la copia y utiliza `--exit-on-error`, `--clean`,
`--if-exists` y `--no-owner`. Se acepta `mce_test` para pruebas. Restaurar el
catálogo maestro `mce` requiere `allow_master=True`; `postgres`, `mce_master` y
cualquier otra base son rechazadas siempre.

Una restauración sustituye objetos de la base seleccionada. Cierre MCE, confirme
que no hay sesiones ejecutándose y conserve una segunda copia antes de restaurar.

Nunca copie contraseñas a nombres de archivo, comandos compartidos o informes.
