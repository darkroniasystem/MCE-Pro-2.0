# Publicación atómica y versionada

`CatalogPublicationService` construye un snapshot completo a partir de las obras
aprobadas y de la versión publicada vigente. Antes de activarlo valida metadatos,
conflictos, disponibilidades, `bank_id`, rutas presentes y duplicados.

Cada intento conserva `catalog_version`, fechas, versión anterior, estado e informe
de validación. Un informe inválido se registra como `failed` sin tocar la versión
activa. Una publicación válida crea todas sus entradas y cambia el puntero activo en
una sola transacción protegida por bloqueo asesor PostgreSQL. Un error en cualquier
punto revierte entradas, estados y puntero.

Solo puede existir una versión `active`. Las anteriores quedan `superseded` y pueden
reactivarse mediante `rollback_to`. Los consumidores futuros leen exclusivamente las
entradas del snapshot activo mediante `active_catalog`, opcionalmente filtradas por
banco; nunca consultan staging ni aprobados directamente.

La acción **Publicar catálogo** de Finalización solicita confirmación y trabaja fuera
del hilo visual. Un rechazo de validación muestra el número de incidencias y declara
explícitamente que la versión anterior permanece intacta.
