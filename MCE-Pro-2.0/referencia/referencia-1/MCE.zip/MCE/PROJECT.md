# Definición de MCE Desktop

## Integración Wikidata y taxonomía local

La preparación offline produce únicamente las categorías publicables
`movie`, `novela`, `dorama`, `series`, `anime` y `western_animation`.
Audio queda como `unsupported_media`; conciertos, cursos y karaoke permanecen
sin clasificar hasta proveedor o revisión humana. Wikidata usa MediaWiki Action
API y complementa, pero no reemplaza, al proveedor especializado.

## Identidad

- Nombre: Media Cleaner & Enrichment (MCE Desktop).
- Objetivo inicial: versión 1.0 para Windows 10 y Windows 11.
- Idioma principal: español.
- Operación inicial: local, en una sola computadora.

## Problema que resuelve

MediaScan Local genera inventarios técnicos en JSON. MCE recibe esos inventarios
y los transforma, mediante etapas trazables y revisables, en un catálogo
multimedia maestro. El JSON original se conserva sin alteraciones.

## Alcance de MCE Desktop 1.0

La versión 1.0 deberá poder importar y validar escaneos; filtrar, normalizar,
clasificar y agrupar registros; identificar y enriquecer contenidos con caché;
gestionar revisión, duplicados y disponibilidad; sincronizar transaccionalmente
con PostgreSQL; reanudar trabajos; revertir importaciones; y exportar JSON, CSV,
Excel y PDF.

## Fuera de alcance

- Escanear discos o analizar el contenido binario de archivos multimedia.
- Mover, renombrar o eliminar archivos físicos.
- Acceso multiusuario, panel web, API pública o administración remota en 1.0.
- Depender de una conexión a Internet o de inteligencia artificial para operar.

## Principios obligatorios

1. El dominio no depende de PySide6, SQLAlchemy ni proveedores externos.
2. La interfaz delega en casos de uso y no contiene lógica de negocio.
3. Servicios y adaptadores reciben sus dependencias explícitamente.
4. Las operaciones son idempotentes y conservan historial.
5. Toda entrada externa se considera no confiable y se valida.
6. Un escaneo parcial nunca declara ausente lo que quedó fuera de su alcance.
7. Las decisiones humanas y los campos bloqueados no se sobrescriben.
8. Los errores son visibles, estructurados y recuperables cuando sea posible.

## Capas

La dirección de dependencias es `presentation → application → domain`. La capa
`infrastructure` implementa puertos definidos hacia el núcleo y depende del
dominio, nunca al contrario. Los detalles están en `docs/architecture.md`.

## Modelo central de dominio

MCE distingue cuatro conceptos que nunca se fusionan:

- `Content`: obra multimedia universal.
- `ContentVersion`: edición editorial o comercial de una obra.
- `PhysicalFile`: archivo observado en una fuente durante un escaneo.
- `Availability`: presencia de un archivo u obra en un banco y ubicación.

También distingue `Scan`, producido por MSL, de `ScanImport`, que registra la
recepción inmutable de ese escaneo en MCE. El detalle completo está en
`docs/domain_model.md`.

## Estados centrales acordados

- Trabajo: `pending`, `running`, `paused`, `completed`, `failed`, `cancelled`,
  `waiting_internet`, `waiting_review`.
- Importación: `received`, `validating`, `valid`, `invalid`, `incompatible`,
  `duplicate`, `processing`, `completed`, `failed`, `reverted`.
- Revisión: `not_required`, `pending`, `approved`, `rejected`, `corrected`.
- Disponibilidad: `available`, `not_available`, `unknown`, `archived`.
- Archivo: `present`, `missing`, `moved`, `unverified`, `excluded`.
- Alcance: `full`, `partial`, `selected_sources`, `selected_paths`.

Las transiciones se validan mediante reglas puras centrales. Un trabajo fallido
solo vuelve a pendiente mediante preparación explícita de reintento; una
disponibilidad archivada requiere restauración explícita.

## Convenciones

## Interfaz de escritorio

La Fase 10 añade una interfaz PySide6 con once secciones, previsualización de
importaciones, tablas filtrables y paginadas, preferencias persistentes y acciones
con confirmación. Los widgets delegan en presentadores y casos de uso. El trabajo
costoso utiliza `QThreadPool`, señales y cancelación cooperativa. El flujo ejecuta
las fases 5 a 9, deriva incertidumbre a revisión humana y conecta la resolución
reversible de duplicados. Las sesiones se recuperan mediante checkpoints locales;
la publicación definitiva del catálogo en PostgreSQL sigue fuera de esta fase.

## Convenciones de implementación

- Código, módulos y campos técnicos: inglés; interfaz y documentación: español.
- Python con type hints y APIs públicas documentadas.
- Fechas persistidas en UTC y formato ISO 8601; presentación en zona local.
- Identificadores internos opacos y estables; no inferidos de títulos mutables.
- Rutas tratadas con semántica de Windows y sin escribir en la fuente escaneada.
- Archivos de texto en UTF-8 y finales de línea administrados por Git.
- Secretos exclusivamente fuera del repositorio y de los logs.

## Versionado

MCE usa versionado semántico (`MAJOR.MINOR.PATCH`) desde 1.0.0. Durante el
desarrollo previo se usa `0.x.y`; el dominio inicial es `0.1.0`. Los
cambios públicos se registran en `CHANGELOG.md` y los contratos incluyen su
propia versión para no confundirla con la versión de la aplicación.

## Desarrollo por fases

Cada fase se implementa y verifica por separado. No se anticipan componentes de
fases futuras y no se avanza mientras existan pruebas relacionadas fallidas.

## Importación MSL en memoria

La Fase 2 añade una capa de aplicación que lee archivos JSON regulares UTF-8,
detecta esquemas, valida estructura y semántica, normaliza alias conocidos y
mapea únicamente `Scan`, `ScanImport`, `ScanScope`, `Source`, `PhysicalFile` y
`Subtitle`. Los esquemas admitidos son 1.0 y el formato real 2.2 de MSL; los
archivos sin versión solo se aceptan mediante la política de legado.

El importador calcula SHA-256 del JSON por bloques, detecta duplicados mediante
un puerto en memoria y produce `ImportResult` e incidencias con códigos estables.
No identifica obras ni escribe en bases de datos.

## Sesiones de procesamiento

La Fase 3 convierte exclusivamente paquetes importados válidos en
`ProcessingSession`. Cada `SessionItem` conserva las identidades de importación,
fuente y archivo, la ruta original y la etapa `imported`. Las sesiones poseen
transiciones explícitas, estadísticas derivadas, cancelación cooperativa,
reintento de fallos y checkpoints JSON versionados. Los repositorios de ejecución
son locales y los checkpoints conservan las sesiones entre reinicios. Las fases
5 a 10 añaden posteriormente el procesamiento semántico sin alterar el contrato
original de la Fase 3.

## Persistencia PostgreSQL

La Fase 4 mantiene modelos SQLAlchemy separados del dominio, migraciones
Alembic y una unidad de trabajo transaccional. Las pruebas reales utilizan
exclusivamente `MCE_TEST_DATABASE_URL` cuando la base exacta es `mce_test`.
Comprueban commit, rollback, restricciones, claves externas, paginación,
aislamiento por banco, duplicados, alcances y reversión. La base `mce` contiene
el catálogo maestro real y se mantiene estrictamente separada de esas pruebas.

## Normalización técnica

La Fase 5 produce `FilenameAnalysis`, candidatos de título, pistas estructuradas
y una traza por cada eliminación. La entrada original permanece inmutable. Las
reglas protegen títulos numéricos y Unicode y no realizan identificación,
traducción, clasificación definitiva ni cambios en archivos físicos.

## Clasificación y estructura preliminar

La Fase 6 combina señales normalizadas en candidatos con confianza, evidencia y
conflictos explícitos. Reconoce estructuras episódicas y DVD, relaciona
subtítulos de forma conservadora y crea agrupaciones provisionales. No crea una
identidad definitiva de contenido ni consulta proveedores externos.

## Identificación de contenido

La Fase 7 consulta proveedores mediante el puerto `MetadataProvider`, puntúa
candidatos con evidencia y conserva resultados ambiguos. Incluye caché con TTL,
modo offline, reintentos limitados, cancelación y límites de solicitudes. Las
pruebas usan proveedores falsos y no requieren internet ni credenciales reales;
la composición de escritorio utiliza TMDb real y nunca el adaptador falso.

## Enriquecimiento y revisión

La Fase 8 consolida metadatos por campo conservando procedencia, conflictos y
prioridad. Las decisiones humanas, correcciones, bloqueos, desbloqueos y
reversiones son auditables. La IA opcional solo produce sugerencias validadas y
nunca sobrescribe campos ni controla persistencia.

## Deduplicación y consolidación

La Fase 9 distingue obra, versión, archivo físico y disponibilidad. Detecta
duplicados y movimientos mediante evidencia, protege bancos y alcances, conserva
historial y permite fusiones reversibles. Nunca elimina archivos multimedia.

## Fase 10

Se implementaron cinco proveedores reales, orquestación por capacidades, fusión
determinista, caché, aliases confirmados y persistencia PostgreSQL normalizada. Los
cinco smoke tests live fueron ejecutados con éxito el 24 de julio de 2026.

## Fase 11

La operación local incluye exportaciones JSON/CSV atómicas y un catálogo PDF
visual por categorías con carátulas HTTPS, contrato estable
`mce.bot.catalog.v1`, vista PostgreSQL de solo lectura, auditoría estructurada,
reversión transaccional, asistencia basada en `pg_dump`/`pg_restore`, reporte de
salud, limpieza de caché, detección de sesiones interrumpidas y archivado de
checkpoints terminales. El bot, la API, el empaquetado y las optimizaciones de
producción permanecen fuera de esta fase.

## Fase 12

La estabilización separa los recursos de solo lectura de los datos mutables del
usuario. Configuración, caché, checkpoints, exportaciones, respaldos y logs viven
en `%LOCALAPPDATA%\MCE Desktop` o en `MCE_DATA_DIR` durante pruebas controladas.
Los logs rotan, incluyen identificadores de correlación y ocultan credenciales.

La distribución primaria es PyInstaller `onedir`, generada en `dist\MCE`. La
candidatura 0.12.0 no se declarará comercialmente estable hasta verificar ese
directorio completo en una PC limpia sin Python y completar la cobertura en
Windows 11. La importación grande ya cumple el objetivo local de memoria mediante
lectura incremental con equivalencia verificada.

## Refactorización del flujo posterior a la Fase 11

La importación, clasificación y limpieza son etapas locales independientes del
enriquecimiento. La migración `0005` añade estados persistentes y sesiones de
clasificación, limpieza y enriquecimiento. Está creada y verificada sobre
`mce_test`; su aplicación al catálogo maestro `mce` queda pendiente de aprobar
el dry-run. No se han importado datos ni creado sesiones nuevas.
