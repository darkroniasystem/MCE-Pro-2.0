"""Crea y valida un backup real de producción sin restaurarlo."""

from datetime import UTC, datetime

from mce.infrastructure.database.diagnostics import runtime_database_url
from mce.infrastructure.operations import PostgresBackupService
from mce.infrastructure.runtime import RuntimePaths


def main() -> None:
    raw = runtime_database_url()
    if raw is None:
        raise SystemExit("PostgreSQL no configurado")
    paths = RuntimePaths.discover()
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    target = paths.backups / f"mce-phase18-{stamp}.dump"
    service = PostgresBackupService()
    created = service.create(raw, target)
    print(f"created={str(created.success).lower()}")
    print(f"database={created.database}")
    print(f"path={created.path}")
    print(f"bytes={created.path.stat().st_size if created.path.exists() else 0}")
    if not created.success:
        raise SystemExit(created.message)
    validated = service.validate(created.path)
    print(f"validated={str(validated.success).lower()}")
    if not validated.success:
        raise SystemExit(validated.message)


if __name__ == "__main__":
    main()
