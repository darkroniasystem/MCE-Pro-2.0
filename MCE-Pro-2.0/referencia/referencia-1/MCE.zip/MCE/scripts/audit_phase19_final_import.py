"""Audita la importación externa final de la Fase 19 sin modificar datos."""

from sqlalchemy import create_engine, text

from mce.infrastructure.database.diagnostics import runtime_database_url

SCAN_ID = "scan_fase19_externo_20260802"
EXTERNAL_BANK_ID = "bank_fase19_externo"


def main() -> None:
    engine = create_engine(runtime_database_url(), pool_pre_ping=True)
    queries = {
        "session": """
            SELECT status, schema_version, total_expected, processed_count,
                   inserted_count, updated_count, duplicate_count,
                   warning_count, error_count, package_hash, external_bank_id
              FROM processing_sessions
             WHERE external_bank_id=:external_bank_id
               AND original_filename='fase19_validacion_externa.json'
        """,
        "bank": """
            SELECT id, external_bank_id, name
              FROM banks WHERE external_bank_id=:external_bank_id
        """,
        "sources": """
            SELECT count(*) FROM sources source
              JOIN installations installation ON installation.id=source.installation_id
              JOIN banks bank ON bank.id=installation.bank_id
             WHERE bank.external_bank_id=:external_bank_id
        """,
        "files": """
            SELECT count(*) FROM physical_files file
              JOIN banks bank ON bank.id=file.bank_id
             WHERE bank.external_bank_id=:external_bank_id
        """,
        "subtitles": """
            SELECT count(*) FROM subtitles subtitle
              JOIN physical_files file ON file.id=subtitle.physical_file_id
              JOIN banks bank ON bank.id=file.bank_id
             WHERE bank.external_bank_id=:external_bank_id
        """,
        "imports": """
            SELECT count(*), bool_or(import.is_duplicate), min(import.status)
              FROM scan_imports import
              JOIN processing_sessions session ON session.import_id=import.id
             WHERE session.external_bank_id=:external_bank_id
               AND session.original_filename='fase19_validacion_externa.json'
        """,
        "original": """
            SELECT original_filename, size_bytes, schema_version, status
              FROM original_jsons
             WHERE file_hash=(SELECT package_hash FROM processing_sessions
                               WHERE external_bank_id=:external_bank_id
                                 AND original_filename='fase19_validacion_externa.json')
        """,
        "cross_bank_files": """
            SELECT count(*) FROM physical_files file
              JOIN banks bank ON bank.id=file.bank_id
             WHERE file.catalog_file_id IN (
                   SELECT catalog_file_id FROM physical_files expected
                     JOIN banks expected_bank ON expected_bank.id=expected.bank_id
                    WHERE expected_bank.external_bank_id=:external_bank_id
             ) AND bank.external_bank_id<>:external_bank_id
        """,
    }
    parameters = {"scan_id": SCAN_ID, "external_bank_id": EXTERNAL_BANK_ID}
    try:
        with engine.connect() as connection:
            for name, sql in queries.items():
                rows = connection.execute(text(sql), parameters).all()
                print(f"{name}={rows}")
    finally:
        engine.dispose()


if __name__ == "__main__":
    main()
