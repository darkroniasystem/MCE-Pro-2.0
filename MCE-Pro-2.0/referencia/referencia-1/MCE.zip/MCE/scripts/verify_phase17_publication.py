"""Resume versiones publicadas sin exponer metadatos del catálogo."""

import os

from sqlalchemy import create_engine, text


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    with engine.connect() as connection:
        revision = connection.execute(text("SELECT version_num FROM alembic_version")).scalar_one()
        versions = tuple(
            connection.execute(
                text(
                    """
                    SELECT catalog_version, status, previous_version_id IS NOT NULL AS has_previous,
                           validation_report ->> 'valid' AS valid,
                           jsonb_array_length(
                               COALESCE(
                                   validation_report::jsonb -> 'errors',
                                   '[]'::jsonb
                               )
                           ) AS errors
                    FROM catalog_publications
                    ORDER BY catalog_version
                    """
                )
            ).mappings()
        )
        entries = connection.execute(
            text("SELECT count(*) FROM catalog_publication_entries")
        ).scalar_one()
        active_entries = connection.execute(
            text(
                """
                SELECT count(*)
                FROM catalog_publication_entries AS entry
                JOIN catalog_publications AS publication
                  ON publication.id = entry.publication_id
                WHERE publication.status = 'active'
                """
            )
        ).scalar_one()
        active_banks = connection.execute(
            text(
                """
                SELECT count(DISTINCT entry.bank_id)
                FROM catalog_publication_entries AS entry
                JOIN catalog_publications AS publication
                  ON publication.id = entry.publication_id
                WHERE publication.status = 'active'
                """
            )
        ).scalar_one()
        duplicate_pairs = connection.execute(
            text(
                """
                SELECT count(*) FROM (
                    SELECT entry.content_id, entry.bank_id
                    FROM catalog_publication_entries AS entry
                    JOIN catalog_publications AS publication
                      ON publication.id = entry.publication_id
                    WHERE publication.status = 'active'
                    GROUP BY entry.content_id, entry.bank_id
                    HAVING count(*) > 1
                ) AS duplicates
                """
            )
        ).scalar_one()
        quarantined = connection.execute(
            text(
                """
                SELECT count(*) FROM contents
                WHERE catalog_stage = 'staging'
                  AND publication_status = 'publication_blocked'
                  AND publication_block_reason LIKE 'failed_publication:%'
                """
            )
        ).scalar_one()
        quarantine_audits = connection.execute(
            text(
                """
                SELECT count(*) FROM audit_events
                WHERE action = 'quarantine_invalid_publication'
                  AND reversed_by IS NULL
                """
            )
        ).scalar_one()
        active = sum(row["status"] == "active" for row in versions)
    print(f"revision={revision}")
    for row in versions:
        print(dict(row))
    print(f"versions={len(versions)}")
    print(f"active_versions={active}")
    print(f"entries={entries}")
    print(f"active_entries={active_entries}")
    print(f"active_banks={active_banks}")
    print(f"duplicate_pairs={duplicate_pairs}")
    print(f"quarantined={quarantined}")
    print(f"quarantine_audits={quarantine_audits}")


if __name__ == "__main__":
    main()
