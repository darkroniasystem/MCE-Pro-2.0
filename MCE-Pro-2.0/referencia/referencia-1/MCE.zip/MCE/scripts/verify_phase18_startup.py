"""Ejecuta el preflight real de Fase 18 sin modificar PostgreSQL."""

from mce.infrastructure.operations import PostgresBackupService, StartupIntegrityService
from mce.infrastructure.runtime import RuntimePaths, resource_path


def main() -> None:
    paths = RuntimePaths.discover()
    report = StartupIntegrityService().inspect(resource_path("alembic.ini").parent, paths)
    for check in report.checks:
        print(f"{check.name}={check.status}:{check.message}")
    print(f"safe_mode={str(report.safe_mode).lower()}")
    print(f"healthy={str(report.healthy).lower()}")
    print(f"pg_dump={PostgresBackupService._tool('pg_dump')}")
    print(f"pg_restore={PostgresBackupService._tool('pg_restore')}")


if __name__ == "__main__":
    main()
