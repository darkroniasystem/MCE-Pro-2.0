"""Comprueba que la distribución no dependa de muestras ni contenga secretos."""

import os
from pathlib import Path


def main() -> None:
    root = Path("dist/MCE").resolve()
    if not (root / "MCE.exe").is_file():
        raise SystemExit("MCE.exe ausente")
    forbidden_names = {"samples", "tests", ".env", "identity.json", "media_scan.json"}
    bad_names = [path for path in root.rglob("*") if path.name.casefold() in forbidden_names]
    if bad_names:
        raise SystemExit("la distribución contiene nombres prohibidos")
    secret_names = ("api_key", "apikey", "password", "passwd", "secret", "token")
    secrets = {
        value.encode()
        for name, value in os.environ.items()
        if value and any(fragment in name.casefold() for fragment in secret_names)
    }
    forbidden_fragments = (
        b"samples\\msl",
        b"samples/msl",
        b"replace_with_your_tavily_api_key",
    )
    exposed: list[str] = []
    dependencies: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        data = path.read_bytes()
        if any(secret in data for secret in secrets):
            exposed.append(str(path.relative_to(root)))
        if any(fragment in data for fragment in forbidden_fragments):
            dependencies.append(str(path.relative_to(root)))
    if exposed:
        raise SystemExit("se detectaron secretos del entorno en la distribución")
    if dependencies:
        raise SystemExit("se detectaron dependencias de prueba o samples")
    print(f"files={sum(path.is_file() for path in root.rglob('*'))}")
    print("secrets_exposed=false")
    print("samples_dependency=false")


if __name__ == "__main__":
    main()
