"""Resume impedimentos de publicación sin modificar PostgreSQL."""

import os

from sqlalchemy import create_engine, text


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    checks = {
        "eligible_contents": """
            SELECT count(*) FROM contents
            WHERE catalog_stage IN ('approved', 'published')
              AND review_status IN ('approved', 'corrected')
              AND status = 'active'
        """,
        "missing_availability": """
            SELECT count(*) FROM contents AS content
            WHERE content.catalog_stage IN ('approved', 'published')
              AND content.review_status IN ('approved', 'corrected')
              AND content.status = 'active'
              AND NOT EXISTS (
                  SELECT 1 FROM availabilities AS availability
                  WHERE availability.content_id = content.id
              )
        """,
        "invalid_availability": """
            SELECT count(*) FROM availabilities AS availability
            JOIN contents AS content ON content.id = availability.content_id
            WHERE content.catalog_stage IN ('approved', 'published')
              AND availability.payload ->> 'status' != 'available'
        """,
        "availability_without_present_path": """
            SELECT count(*) FROM availabilities AS availability
            JOIN contents AS content ON content.id = availability.content_id
            WHERE content.catalog_stage IN ('approved', 'published')
              AND NOT EXISTS (
                  SELECT 1 FROM physical_files AS file
                  WHERE file.content_id = content.id
                    AND file.bank_id = availability.bank_id
                    AND file.status = 'present'
                    AND length(trim(file.original_path)) > 0
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM jsonb_array_elements_text(
                      COALESCE(
                          availability.payload::jsonb -> 'physical_file_ids',
                          '[]'::jsonb
                      )
                  ) AS referenced(file_id)
                  JOIN physical_files AS file ON file.id = referenced.file_id
                  WHERE file.bank_id = availability.bank_id
                    AND file.status = 'present'
                    AND length(trim(file.original_path)) > 0
              )
        """,
        "availability_with_referenced_ids": """
            SELECT count(*) FROM availabilities AS availability
            JOIN contents AS content ON content.id = availability.content_id
            WHERE content.catalog_stage IN ('approved', 'published')
              AND jsonb_array_length(
                  COALESCE(
                      availability.payload::jsonb -> 'physical_file_ids',
                      '[]'::jsonb
                  )
              ) > 0
        """,
        "referenced_files_matching_bank": """
            SELECT count(DISTINCT availability.id)
            FROM availabilities AS availability
            JOIN contents AS content ON content.id = availability.content_id
            JOIN LATERAL jsonb_array_elements_text(
                COALESCE(
                    availability.payload::jsonb -> 'physical_file_ids',
                    '[]'::jsonb
                )
            ) AS referenced(file_id) ON true
            JOIN physical_files AS file
              ON file.id = referenced.file_id
             AND file.bank_id = availability.bank_id
            WHERE content.catalog_stage IN ('approved', 'published')
        """,
    }
    with engine.connect() as connection:
        for name, statement in checks.items():
            print(f"{name}={connection.execute(text(statement)).scalar_one()}")


if __name__ == "__main__":
    main()
