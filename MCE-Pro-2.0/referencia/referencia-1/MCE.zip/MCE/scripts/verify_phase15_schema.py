"""Verifica el contrato estructural multibanco sin mostrar datos sensibles."""

import os

from sqlalchemy import create_engine, text


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    checks = {
        "physical_without_bank": "SELECT count(*) FROM physical_files WHERE bank_id IS NULL",
        "availability_without_bank": "SELECT count(*) FROM availabilities WHERE bank_id IS NULL",
        "physical_bank_index": """
            SELECT count(*) FROM pg_indexes
            WHERE tablename = 'physical_files'
              AND indexname = 'ix_physical_files_bank_source_path'
        """,
        "availability_bank_unique": """
            SELECT count(*) FROM pg_constraint
            WHERE conname = 'uq_availabilities_content_bank'
        """,
        "bank_foreign_keys": """
            SELECT count(*) FROM pg_constraint
            WHERE conname IN (
                'fk_physical_files_bank_id_banks',
                'fk_availabilities_bank_id_banks'
            )
        """,
    }
    with engine.connect() as connection:
        revision = connection.execute(text("SELECT version_num FROM alembic_version")).scalar_one()
        print(f"revision={revision}")
        for name, statement in checks.items():
            print(f"{name}={connection.execute(text(statement)).scalar_one()}")


if __name__ == "__main__":
    main()
