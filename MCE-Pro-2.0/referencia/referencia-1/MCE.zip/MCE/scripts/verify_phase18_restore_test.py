"""Valida el ciclo protegido de restauración solo contra mce_test."""

import os
from datetime import UTC, datetime

from sqlalchemy.engine import make_url

from mce.infrastructure.operations import PostgresBackupService
from mce.infrastructure.runtime import RuntimePaths


def main() -> None:
    raw = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
    if not raw or make_url(raw).database != "mce_test":
        raise SystemExit("MCE_TEST_DATABASE_URL debe apuntar exactamente a mce_test")
    paths = RuntimePaths.discover()
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    source = paths.backups / f"mce-test-phase18-source-{stamp}.dump"
    safety = paths.backups / f"mce-test-phase18-before-restore-{stamp}.dump"
    service = PostgresBackupService()
    created = service.create(raw, source)
    if not created.success:
        raise SystemExit(created.message)
    restored = service.restore_safely(raw, source, safety)
    print(f"source_valid={str(service.validate(source).success).lower()}")
    print(f"restore_point_valid={str(service.validate(safety).success).lower()}")
    print(f"restored={str(restored.success).lower()}")
    print(f"database={restored.database}")
    if not restored.success:
        raise SystemExit(restored.message)


if __name__ == "__main__":
    main()
