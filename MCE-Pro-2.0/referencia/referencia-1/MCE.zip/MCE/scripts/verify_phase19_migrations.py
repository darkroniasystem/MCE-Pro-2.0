"""Prueba Alembic desde vacío y desde 0016 en una base temporal aislada."""

import os
import subprocess
import sys

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import make_url

DATABASE = "mce_phase19_migration"


def run_alembic(environment: dict[str, str], *arguments: str) -> None:
    result = subprocess.run(
        [sys.executable, "-m", "alembic", *arguments],
        check=False,
        env=environment,
        capture_output=True,
        text=True,
    )
    if result.returncode:
        raw = environment["MCE_DATABASE_URL"]
        raise RuntimeError((result.stderr or result.stdout).replace(raw, "<database-url>"))


def main() -> None:
    raw = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
    source = make_url(raw)
    if source.get_backend_name() != "postgresql" or source.database != "mce_test":
        raise SystemExit("se requiere MCE_TEST_DATABASE_URL exacta para derivar la base temporal")
    admin_url = source.set(database="postgres")
    target_url = source.set(database=DATABASE)
    admin = create_engine(admin_url, isolation_level="AUTOCOMMIT")
    def reset_database(*, create: bool) -> None:
        with admin.connect() as connection:
            connection.execute(
                text(
                    "SELECT pg_terminate_backend(pid) "
                    "FROM pg_stat_activity WHERE datname=:name"
                ),
                {"name": DATABASE},
            )
            connection.execute(text(f'DROP DATABASE IF EXISTS "{DATABASE}"'))
            if create:
                connection.execute(text(f'CREATE DATABASE "{DATABASE}"'))

    reset_database(create=True)
    environment = os.environ.copy()
    environment["MCE_DATABASE_URL"] = target_url.render_as_string(hide_password=False)
    target = create_engine(target_url)
    try:
        run_alembic(environment, "upgrade", "head")
        with target.connect() as connection:
            empty_head = connection.execute(
                text("SELECT version_num FROM alembic_version")
            ).scalar_one()
            table_count = len(inspect(connection).get_table_names())
        target.dispose()
        reset_database(create=True)
        run_alembic(environment, "upgrade", "0016")
        run_alembic(environment, "upgrade", "head")
        with target.connect() as connection:
            previous_head = connection.execute(
                text("SELECT version_num FROM alembic_version")
            ).scalar_one()
        print(f"empty_to_head={empty_head}")
        print(f"tables={table_count}")
        print(f"previous_to_head={previous_head}")
    finally:
        target.dispose()
        reset_database(create=False)
        admin.dispose()


if __name__ == "__main__":
    main()
