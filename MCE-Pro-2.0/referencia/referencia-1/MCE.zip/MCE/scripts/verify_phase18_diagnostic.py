"""Verifica estructura y redacción del paquete diagnóstico real."""

import json
import os
import re
import zipfile
from pathlib import Path


def main() -> None:
    target = Path(os.environ.get("MCE_DIAGNOSTIC_PATH", "")).expanduser()
    if not target.is_file():
        raise SystemExit("paquete no encontrado")
    with zipfile.ZipFile(target) as archive:
        names = set(archive.namelist())
        if names != {"diagnostic.json", "logs/latest.log"}:
            raise SystemExit(f"estructura inesperada: {sorted(names)}")
        raw_json = archive.read("diagnostic.json").decode("utf-8")
        raw_logs = archive.read("logs/latest.log").decode("utf-8")
    payload = json.loads(raw_json)
    rendered = raw_json + raw_logs
    if payload.get("contract_version") != "mce.diagnostic.v1":
        raise SystemExit("contrato incorrecto")
    if payload.get("context", {}).get("active_stage") != "Diagnóstico":
        raise SystemExit("etapa activa incorrecta")
    exposed_url = re.search(r"postgresql(?:\+\w+)?://[^:\s/]+:(?!\*\*\*)[^@\s]+@", rendered, re.I)
    if exposed_url:
        raise SystemExit("URL PostgreSQL con credenciales expuestas")
    sensitive_fragments = ("api_key", "apikey", "password", "passwd", "secret", "token")
    exposed_environment = [
        name
        for name, value in os.environ.items()
        if value
        and any(fragment in name.casefold() for fragment in sensitive_fragments)
        and value in rendered
    ]
    if exposed_environment:
        raise SystemExit("se detectaron valores sensibles del entorno")
    bank = payload.get("context", {}).get("bank_id")
    if bank is not None and not str(bank).startswith("bank-"):
        raise SystemExit("bank_id no anonimizado")
    print("zip_valid=true")
    print("contract=mce.diagnostic.v1")
    print(f"active_stage={payload['context']['active_stage']}")
    print(f"health_checks={len(payload.get('health_checks', []))}")
    print(f"log_chars={len(raw_logs)}")
    print("secrets_exposed=false")


if __name__ == "__main__":
    main()
