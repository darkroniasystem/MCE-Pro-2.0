"""Aparta de forma reversible los contenidos inválidos de una publicación fallida."""

from __future__ import annotations

import argparse

from sqlalchemy import select

from mce.infrastructure.database.models import CatalogPublicationModel
from mce.infrastructure.database.publication import CatalogPublicationService


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--actor", default="phase17-maintenance")
    args = parser.parse_args()

    service = CatalogPublicationService.from_runtime_environment()
    if service is None:
        raise SystemExit("MCE_DATABASE_URL no está configurada.")
    with service.factory() as database:
        publication = database.scalar(
            select(CatalogPublicationModel)
            .where(CatalogPublicationModel.status == "failed")
            .order_by(CatalogPublicationModel.catalog_version.desc())
            .limit(1)
        )
        if publication is None:
            raise SystemExit("No existe una publicación fallida para procesar.")
        errors = tuple((publication.validation_report or {}).get("errors", ()))
        affected = {
            str(error["content_id"])
            for error in errors
            if error.get("code")
            in {
                "MISSING_AVAILABILITY",
                "INVALID_AVAILABILITY",
                "INVALID_PATHS",
                "INVALID_METADATA",
            }
            and error.get("content_id")
        }
        publication_id = publication.id
        version = publication.catalog_version

    print(f"publication_id={publication_id}")
    print(f"catalog_version={version}")
    print(f"candidates={len(affected)}")
    if not args.apply:
        print("result=preview_only")
        return
    changed = service.quarantine_invalid(publication_id, actor=args.actor)
    print(f"changed={changed}")
    print("result=applied")


if __name__ == "__main__":
    main()
