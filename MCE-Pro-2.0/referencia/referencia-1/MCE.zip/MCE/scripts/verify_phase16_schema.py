"""Verifica la separación persistente de capas del catálogo."""

import os

from sqlalchemy import create_engine, text


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    with engine.connect() as connection:
        revision = connection.execute(text("SELECT version_num FROM alembic_version")).scalar_one()
        rows = connection.execute(
            text(
                """
                SELECT catalog_stage, count(*) AS records
                FROM contents
                GROUP BY catalog_stage
                ORDER BY catalog_stage
                """
            )
        ).mappings()
        invalid = connection.execute(
            text(
                """
                SELECT count(*) FROM contents
                WHERE catalog_stage NOT IN ('staging', 'approved', 'published')
                   OR catalog_stage IS NULL
                """
            )
        ).scalar_one()
        constraint = connection.execute(
            text(
                """
                SELECT count(*) FROM pg_constraint
                WHERE conname = 'ck_contents_catalog_stage'
                """
            )
        ).scalar_one()
        index = connection.execute(
            text(
                """
                SELECT count(*) FROM pg_indexes
                WHERE tablename = 'contents'
                  AND indexname = 'ix_contents_catalog_stage'
                """
            )
        ).scalar_one()
        phase16_staging = connection.execute(
            text(
                """
                SELECT count(*)
                FROM import_staging_documents AS staging
                WHERE staging.header ->> 'scan_id' = 'scan_fase16_capas_20260802'
                """
            )
        ).scalar_one()
        published = connection.execute(
            text("SELECT count(*) FROM contents WHERE catalog_stage = 'published'")
        ).scalar_one()
        print(f"revision={revision}")
        for row in rows:
            print(dict(row))
        print(f"invalid_or_null={invalid}")
        print(f"stage_constraint={constraint}")
        print(f"stage_index={index}")
        print(f"phase16_staging_imports={phase16_staging}")
        print(f"published_records={published}")


if __name__ == "__main__":
    main()
