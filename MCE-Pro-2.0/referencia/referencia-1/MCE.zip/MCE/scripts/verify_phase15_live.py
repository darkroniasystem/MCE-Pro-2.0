"""Audita los dos escaneos sintéticos de aislamiento multibanco."""

import os

from sqlalchemy import bindparam, create_engine, text

BANKS = ("bank_fase15_aislamiento_a", "bank_fase15_aislamiento_b")


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    statement = text(
        """
        SELECT banks.external_bank_id,
               physical_files.bank_id,
               physical_files.original_path
        FROM banks
        JOIN installations ON installations.bank_id = banks.id
        JOIN scans ON scans.installation_id = installations.id
        JOIN physical_files ON physical_files.scan_id = scans.id
        WHERE banks.external_bank_id IN :bank_ids
        ORDER BY banks.external_bank_id, physical_files.normalized_path
        """
    ).bindparams(bindparam("bank_ids", expanding=True))
    availability_statement = text(
        """
        SELECT banks.external_bank_id, availabilities.bank_id,
               availabilities.payload ->> 'status' AS status
        FROM availabilities
        JOIN banks ON banks.id = availabilities.bank_id
        WHERE banks.external_bank_id IN :bank_ids
        ORDER BY banks.external_bank_id
        """
    ).bindparams(bindparam("bank_ids", expanding=True))
    with engine.connect() as connection:
        rows = tuple(connection.execute(statement, {"bank_ids": BANKS}).mappings())
        availability_rows = tuple(
            connection.execute(
                availability_statement, {"bank_ids": BANKS}
            ).mappings()
        )
    for row in rows:
        print(dict(row))
    print(f"rows={len(rows)}")
    print(f"banks={len({row['bank_id'] for row in rows})}")
    print(f"paths={len({row['original_path'] for row in rows})}")
    for row in availability_rows:
        print(f"availability={dict(row)}")
    print(f"availabilities={len(availability_rows)}")


if __name__ == "__main__":
    main()
