"""Muestra actividad segura de PostgreSQL sin revelar consultas ni credenciales."""

import os

from sqlalchemy import create_engine, text


def main() -> None:
    engine = create_engine(os.environ["MCE_DATABASE_URL"], pool_pre_ping=True)
    statement = text(
        """
        SELECT pid, application_name, state, wait_event_type, wait_event
        FROM pg_stat_activity
        WHERE datname = current_database() AND pid != pg_backend_pid()
        ORDER BY pid
        """
    )
    with engine.connect() as connection:
        for row in connection.execute(statement).mappings():
            print(dict(row))


if __name__ == "__main__":
    main()
