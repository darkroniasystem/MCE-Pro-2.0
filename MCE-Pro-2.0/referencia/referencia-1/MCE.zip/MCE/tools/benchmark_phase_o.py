"""Benchmark real, limitado y reproducible de la pila web/IA de MCE.

No usa PostgreSQL ni sesiones. Las claves se leen del entorno y nunca se
serializan. El informe guarda métricas agregadas y resultados sanitizados.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import platform
import re
import statistics
import subprocess
import time
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import quote_plus

from mce.application.ai_review import AIReviewDecision, AIReviewInput, EvidenceSource
from mce.application.ai_review.models import AIRateLimitDeferred
from mce.application.identification.service import (
    ProviderOfflineError,
    ProviderRateLimitError,
    ProviderTimeoutError,
)
from mce.infrastructure.ai_review import GroqStructuredAnalyzer, create_groq_client
from mce.infrastructure.local_ai import OllamaQwenAnalyzer, UrllibOllamaTransport
from mce.infrastructure.metadata.browser_extractor import BrowserEvidenceExtractor
from mce.infrastructure.metadata.browser_search import BrowserSearchSettings, BrowserSearchStatus
from mce.infrastructure.metadata.http_transport import UrllibJsonTransport
from mce.infrastructure.metadata.web_search import (
    ExaWebSearchProvider,
    SerperWebSearchProvider,
    TavilyWebSearchProvider,
)


@dataclass(frozen=True, slots=True)
class BenchmarkCase:
    canonical: str
    category: str
    year: int
    aliases: tuple[str, ...]
    query: str
    summary: str


CASES = (
    BenchmarkCase(
        "Vincenzo",
        "dorama",
        2021,
        ("Binsenjo",),
        "Vincenzo Korean drama 2021 cast director",
        "South Korean television drama released in 2021.",
    ),
    BenchmarkCase(
        "Parasite",
        "movie",
        2019,
        ("Gisaengchung", "Parásitos"),
        "Parasite Korean film 2019 director cast",
        "South Korean film directed by Bong Joon Ho and released in 2019.",
    ),
    BenchmarkCase(
        "Spirited Away",
        "anime",
        2001,
        ("Sen to Chihiro no Kamikakushi", "El viaje de Chihiro"),
        "Spirited Away anime film 2001 director cast",
        "Japanese animated film directed by Hayao Miyazaki and released in 2001.",
    ),
    BenchmarkCase(
        "Dark",
        "series",
        2017,
        ("Dark Netflix",),
        "Dark Netflix series 2017 cast creators",
        "German science fiction television series that premiered in 2017.",
    ),
    BenchmarkCase(
        "Money Heist",
        "series",
        2017,
        ("La casa de papel", "Casa de Papel"),
        "La casa de papel Money Heist series 2017 cast creator",
        "Spanish television series released internationally as Money Heist.",
    ),
)


class SearchProvider(Protocol):
    def search(self, query: str, *, limit: int) -> tuple[Any, ...]: ...


def normalized(value: str) -> str:
    folded = unicodedata.normalize("NFKD", value.casefold())
    without_marks = "".join(char for char in folded if not unicodedata.combining(char))
    return " ".join(re.findall(r"[a-z0-9]+", without_marks))


def matches_case(case: BenchmarkCase, *values: str) -> bool:
    haystack = normalized(" ".join(values))
    return any(
        normalized(candidate) in haystack
        for candidate in (case.canonical, *case.aliases)
        if normalized(candidate)
    )


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = min(len(ordered) - 1, round((len(ordered) - 1) * fraction))
    return round(ordered[index], 2)


def _working_set_mib() -> tuple[float | None, float | None]:
    if os.name != "nt":
        return None, None

    class ProcessMemoryCounters(ctypes.Structure):
        _fields_ = [
            ("cb", ctypes.c_ulong),
            ("PageFaultCount", ctypes.c_ulong),
            ("PeakWorkingSetSize", ctypes.c_size_t),
            ("WorkingSetSize", ctypes.c_size_t),
            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPagedPoolUsage", ctypes.c_size_t),
            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
            ("PagefileUsage", ctypes.c_size_t),
            ("PeakPagefileUsage", ctypes.c_size_t),
        ]

    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    psapi.GetProcessMemoryInfo.argtypes = (
        ctypes.c_void_p,
        ctypes.POINTER(ProcessMemoryCounters),
        ctypes.c_ulong,
    )
    psapi.GetProcessMemoryInfo.restype = ctypes.c_int

    counters = ProcessMemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    handle = kernel32.GetCurrentProcess()
    if not psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
        return None, None
    divisor = 1024 * 1024
    return counters.WorkingSetSize / divisor, counters.PeakWorkingSetSize / divisor


def _system_vram_used_mib() -> float | None:
    try:
        completed = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=memory.used",
                "--format=csv,noheader,nounits",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=5,
        )
        values = [float(line.strip()) for line in completed.stdout.splitlines() if line.strip()]
        return sum(values) if values else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


@dataclass(slots=True)
class ResourceWindow:
    wall_started: float
    cpu_started: float
    rss_started_mib: float | None
    vram_started_mib: float | None

    @classmethod
    def start(cls) -> ResourceWindow:
        rss, _peak = _working_set_mib()
        vram = _system_vram_used_mib()
        return cls(time.perf_counter(), time.process_time(), rss, vram)

    def finish(self) -> dict[str, float | None]:
        elapsed = max(0.000001, time.perf_counter() - self.wall_started)
        cpu_seconds = max(0.0, time.process_time() - self.cpu_started)
        rss_after, peak_rss = _working_set_mib()
        vram_after = _system_vram_used_mib()
        logical_cpus = max(1, os.cpu_count() or 1)
        return {
            "elapsed_ms": round(elapsed * 1_000, 2),
            "cpu_seconds": round(cpu_seconds, 4),
            "cpu_percent_system_capacity": round(
                100 * cpu_seconds / elapsed / logical_cpus, 2
            ),
            "rss_before_mib": _rounded(self.rss_started_mib),
            "rss_after_mib": _rounded(rss_after),
            "process_peak_rss_mib": _rounded(peak_rss),
            "system_vram_before_mib": _rounded(self.vram_started_mib),
            "system_vram_after_mib": _rounded(vram_after),
        }


def _rounded(value: float | None) -> float | None:
    return round(value, 2) if value is not None else None


def summarize(name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    latencies = [float(row["elapsed_ms"]) for row in rows if "elapsed_ms" in row]
    successes = sum(row.get("outcome") == "success" for row in rows)
    exact = sum(bool(row.get("exact")) for row in rows)
    false_positives = sum(bool(row.get("false_positive")) for row in rows)
    elapsed_seconds = sum(latencies) / 1_000
    return {
        "provider": name,
        "attempted": len(rows),
        "successes": successes,
        "failures": sum(row.get("outcome") == "failure" for row in rows),
        "no_evidence": sum(row.get("outcome") == "no_evidence" for row in rows),
        "blocked": sum(row.get("outcome") == "blocked" for row in rows),
        "captcha": sum(row.get("outcome") == "captcha" for row in rows),
        "timeouts": sum(row.get("outcome") == "timeout" for row in rows),
        "rate_limits": sum(row.get("outcome") == "rate_limited" for row in rows),
        "json_valid": sum(bool(row.get("json_valid")) for row in rows),
        "exact": exact,
        "false_positives": false_positives,
        "success_percent": round(100 * successes / len(rows), 2) if rows else 0.0,
        "accuracy_percent": round(100 * exact / successes, 2) if successes else 0.0,
        "latency_ms": {
            "mean": round(statistics.mean(latencies), 2) if latencies else None,
            "p50": percentile(latencies, 0.50),
            "p95": percentile(latencies, 0.95),
        },
        "throughput_works_per_minute": (
            round(60 * len(rows) / elapsed_seconds, 3) if elapsed_seconds else None
        ),
        "resources": {
            "process_peak_rss_mib": max(
                (
                    float(row["process_peak_rss_mib"])
                    for row in rows
                    if row.get("process_peak_rss_mib") is not None
                ),
                default=None,
            ),
            "mean_cpu_percent_system_capacity": round(
                statistics.mean(
                    float(row.get("cpu_percent_system_capacity") or 0.0) for row in rows
                ),
                2,
            )
            if rows
            else None,
            "system_vram_observation_only": True,
            "system_vram_peak_observed_mib": max(
                (
                    float(row["system_vram_after_mib"])
                    for row in rows
                    if row.get("system_vram_after_mib") is not None
                ),
                default=None,
            ),
        },
        "rows": rows,
    }


def benchmark_search_provider(
    name: str,
    provider: SearchProvider,
    cases: tuple[BenchmarkCase, ...],
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for case in cases:
        resources = ResourceWindow.start()
        row: dict[str, Any] = {"work": case.canonical}
        stop_after = False
        try:
            results = provider.search(case.query, limit=3)
            texts = tuple(
                f"{getattr(item, 'title', '')} {getattr(item, 'description', '')}"
                for item in results
            )
            exact = bool(results) and matches_case(case, *texts)
            row.update(
                outcome="success" if results else "no_evidence",
                result_count=len(results),
                exact=exact,
                false_positive=bool(results) and not exact,
            )
        except ProviderRateLimitError as exc:
            row.update(
                outcome="rate_limited",
                quota_exhausted=bool(getattr(exc, "quota_exhausted", False)),
                error_type=type(exc).__name__,
            )
            stop_after = bool(getattr(exc, "quota_exhausted", False))
        except ProviderTimeoutError as exc:
            row.update(outcome="timeout", error_type=type(exc).__name__)
        except ProviderOfflineError as exc:
            row.update(outcome="blocked", error_type=type(exc).__name__)
        except Exception as exc:
            row.update(outcome="failure", error_type=type(exc).__name__)
        row.update(resources.finish())
        rows.append(row)
        print(f"{name}: {len(rows)}/{len(cases)} {row['outcome']}", flush=True)
        if stop_after:
            break
    return summarize(name, rows)


def benchmark_browser(cases: tuple[BenchmarkCase, ...]) -> dict[str, Any]:
    from playwright.sync_api import sync_playwright

    settings = BrowserSearchSettings(
        enabled=True,
        headless=True,
        timeout_seconds=30,
        max_concurrency=1,
        delay_min_ms=0,
        delay_max_ms=0,
        max_results=3,
        max_page_text_chars=12_000,
    )
    rows: list[dict[str, Any]] = []
    manager = sync_playwright().start()
    browser = manager.chromium.launch(channel="chrome", headless=True)
    try:
        for case in cases:
            resources = ResourceWindow.start()
            row: dict[str, Any] = {"work": case.canonical}
            page = browser.new_page()
            try:
                opened = time.perf_counter()
                page.goto(
                    f"https://www.bing.com/search?q={quote_plus(case.query)}",
                    wait_until="domcontentloaded",
                    timeout=30_000,
                )
                navigation_ms = round((time.perf_counter() - opened) * 1_000, 2)
                extraction_started = time.perf_counter()
                extraction = BrowserEvidenceExtractor().extract(
                    page, settings=settings, limit=3
                )
                extraction_ms = round(
                    (time.perf_counter() - extraction_started) * 1_000, 2
                )
                texts = tuple(
                    f"{item.title} {item.snippet} {item.visible_text}"
                    for item in extraction.evidence
                )
                exact = bool(extraction.evidence) and matches_case(case, *texts)
                useful = sum(_useful_browser_fields(item) for item in extraction.evidence)
                outcome = _browser_outcome(extraction.status)
                row.update(
                    outcome=outcome,
                    browser_status=extraction.status.value,
                    result_count=len(extraction.evidence),
                    navigation_ms=navigation_ms,
                    extraction_ms=extraction_ms,
                    parser_success=bool(extraction.evidence),
                    knowledge_panel=any(
                        item.origin == "knowledge_panel" for item in extraction.evidence
                    ),
                    useful_fields=useful,
                    exact=exact,
                    false_positive=bool(extraction.evidence) and not exact,
                    resolution=(
                        "complete"
                        if exact
                        and any(
                            item.year is not None and item.media_type is not None
                            for item in extraction.evidence
                        )
                        else "partial"
                        if extraction.evidence
                        else "no_improvement"
                    ),
                )
            except Exception as exc:
                outcome = "timeout" if "timeout" in type(exc).__name__.casefold() else "failure"
                row.update(outcome=outcome, error_type=type(exc).__name__)
            finally:
                page.close()
            row.update(resources.finish())
            rows.append(row)
            print(f"browser: {len(rows)}/{len(cases)} {row['outcome']}", flush=True)
    finally:
        browser.close()
        manager.stop()

    report = summarize("browser", rows)
    report["browser"] = {
        "mean_navigation_ms": _mean_field(rows, "navigation_ms"),
        "mean_extraction_ms": _mean_field(rows, "extraction_ms"),
        "parser_success_percent": _percent(rows, "parser_success"),
        "knowledge_panel_percent": _percent(rows, "knowledge_panel"),
        "useful_fields_percent": round(
            100 * sum((row.get("useful_fields") or 0) > 0 for row in rows) / len(rows), 2
        )
        if rows
        else 0.0,
        "complete": sum(row.get("resolution") == "complete" for row in rows),
        "partial": sum(row.get("resolution") == "partial" for row in rows),
        "no_improvement": sum(row.get("resolution") == "no_improvement" for row in rows),
    }
    return report


def _useful_browser_fields(item: Any) -> int:
    return sum(
        bool(value)
        for value in (
            item.year,
            item.media_type,
            item.seasons,
            item.genres,
            item.cast,
            item.rating,
            item.platforms,
            item.alternate_titles,
        )
    )


def _browser_outcome(status: BrowserSearchStatus) -> str:
    if status in {BrowserSearchStatus.SUCCESS, BrowserSearchStatus.PARTIAL}:
        return "success"
    if status is BrowserSearchStatus.CAPTCHA:
        return "captcha"
    if status is BrowserSearchStatus.BLOCKED:
        return "blocked"
    if status is BrowserSearchStatus.TIMEOUT:
        return "timeout"
    if status is BrowserSearchStatus.RATE_LIMITED:
        return "rate_limited"
    if status is BrowserSearchStatus.NO_EVIDENCE:
        return "no_evidence"
    return "failure"


def _mean_field(rows: list[dict[str, Any]], field: str) -> float | None:
    values = [float(row[field]) for row in rows if row.get(field) is not None]
    return round(statistics.mean(values), 2) if values else None


def _percent(rows: list[dict[str, Any]], field: str) -> float:
    return round(100 * sum(bool(row.get(field)) for row in rows) / len(rows), 2) if rows else 0.0


def _ai_evidence(case: BenchmarkCase) -> tuple[EvidenceSource, ...]:
    slug = normalized(case.canonical).replace(" ", "-")
    return (
        EvidenceSource(
            f"https://authority-one.example/{slug}",
            case.canonical,
            case.summary,
            "benchmark",
            case.year,
            case.category,
        ),
        EvidenceSource(
            f"https://authority-two.example/{slug}",
            case.canonical,
            case.summary,
            "benchmark",
            case.year,
            case.category,
        ),
    )


def benchmark_analyzer(
    name: str,
    analyzer: Any,
    cases: tuple[BenchmarkCase, ...],
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for index, case in enumerate(cases):
        resources = ResourceWindow.start()
        row: dict[str, Any] = {"work": case.canonical}
        sources = _ai_evidence(case)
        try:
            result = analyzer.analyze(
                AIReviewInput(
                    f"phase-o-{name}-{index}",
                    case.aliases[0] if case.aliases else case.canonical,
                    case.category,
                    case.year,
                    alternative_titles=(case.canonical, *case.aliases),
                ),
                sources,
            )
            exact = matches_case(case, result.canonical_title or "")
            false_positive = (
                result.decision is AIReviewDecision.APPROVE
                and (not exact or result.hallucinated_source)
            )
            row.update(
                outcome="success",
                json_valid=True,
                exact=exact,
                false_positive=false_positive,
                decision=result.decision.value,
                analysis_status=result.analysis_status,
                hallucinated_source=result.hallucinated_source,
                model=result.model,
                provider=result.provider,
                analyzer_latency_ms=result.latency_ms,
            )
        except AIRateLimitDeferred as exc:
            row.update(
                outcome="rate_limited",
                error_type=type(exc).__name__,
                retry_after_seconds=round(exc.retry_after_seconds, 2),
            )
        except Exception as exc:
            message = str(exc).casefold()
            outcome = "timeout" if "timeout" in message else "failure"
            row.update(
                outcome=outcome,
                json_valid=False,
                error_type=type(exc).__name__,
            )
        row.update(resources.finish())
        rows.append(row)
        print(f"{name}: {len(rows)}/{len(cases)} {row['outcome']}", flush=True)
        if row["outcome"] == "rate_limited":
            break
    return summarize(name, rows)


def _credential(name: str) -> str | None:
    value = os.environ.get(name, "").strip()
    return value or None


def _unavailable(name: str, reason: str) -> dict[str, Any]:
    report = summarize(name, [])
    report["availability"] = "unavailable"
    report["reason"] = reason
    return report


def run_benchmark(case_limit: int) -> dict[str, Any]:
    cases = CASES[: max(1, min(len(CASES), case_limit))]
    reports: dict[str, Any] = {}
    web_factories: dict[str, tuple[str, Callable[[str], SearchProvider]]] = {
        "tavily": (
            "TAVILY_API_KEY",
            lambda key: TavilyWebSearchProvider(
                key, UrllibJsonTransport("https://api.tavily.com", provider_name="Tavily")
            ),
        ),
        "serper": (
            "SERPER_API_KEY",
            lambda key: SerperWebSearchProvider(
                key, UrllibJsonTransport("https://google.serper.dev", provider_name="Serper")
            ),
        ),
        "exa": (
            "EXA_API_KEY",
            lambda key: ExaWebSearchProvider(
                key, UrllibJsonTransport("https://api.exa.ai", provider_name="Exa")
            ),
        ),
    }
    for name, (credential_name, factory) in web_factories.items():
        key = _credential(credential_name)
        reports[name] = (
            benchmark_search_provider(name, factory(key), cases)
            if key
            else _unavailable(name, f"{credential_name} no configurada")
        )

    try:
        reports["browser"] = benchmark_browser(cases)
    except Exception as exc:
        reports["browser"] = _unavailable("browser", type(exc).__name__)

    qwen = OllamaQwenAnalyzer(UrllibOllamaTransport(), model="qwen2.5:3b", timeout=120)
    reports["qwen"] = benchmark_analyzer("qwen", qwen, cases)

    groq_key = _credential("GROQ_API_KEY")
    reports["groq"] = (
        benchmark_analyzer(
            "groq",
            GroqStructuredAnalyzer(
                create_groq_client(groq_key, timeout=45),
                min_interval_seconds=2.1,
                rate_limit_retries=0,
            ),
            cases,
        )
        if groq_key
        else _unavailable("groq", "GROQ_API_KEY no configurada")
    )

    return {
        "schema": "mce.phase-o.benchmark.v1",
        "created_at": datetime.now(UTC).isoformat(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "case_count": len(cases),
        "limits": {
            "concurrency": 1,
            "results_per_search": 3,
            "browser_headless": True,
            "external_calls_stop_on_confirmed_quota": True,
        },
        "resource_notes": {
            "cpu": "CPU del proceso Python como porcentaje de capacidad lógica total",
            "ram": "working set del proceso Python; el navegador hijo no se atribuye",
            "vram": "observación total del sistema NVIDIA, no atribuible a un proveedor",
        },
        "metric_definitions": {
            "web_exact": (
                "al menos uno de los tres primeros resultados contiene el título "
                "canónico o un alias esperado"
            ),
            "web_false_positive": (
                "el proveedor devolvió evidencia, pero ninguna de las tres primeras "
                "entradas coincidió con el título o sus aliases; no implica publicación"
            ),
            "ai_false_positive": (
                "el analizador aprobó un título incorrecto o citó una fuente inventada"
            ),
            "throughput": "intentos terminados por minuto, incluidos límites y fallos",
        },
        "providers": reports,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--cases", type=int, default=5, choices=range(1, 6))
    arguments = parser.parse_args()
    report = run_benchmark(arguments.cases)
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                name: {
                    key: value
                    for key, value in provider.items()
                    if key not in {"rows", "resources"}
                }
                for name, provider in report["providers"].items()
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
