"""Benchmark reproducible y acotado para la Fase 12."""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import time
from ctypes import wintypes
from pathlib import Path
from typing import Any

from mce.application.classification import MediaClassifier
from mce.application.normalization import FilenameNormalizationPipeline
from mce.application.operations import ExportFormat, ExportRequest, ExportService


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def peak_working_set_mib() -> float:
    counters = ProcessMemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    get_process = ctypes.windll.kernel32.GetCurrentProcess
    get_process.restype = wintypes.HANDLE
    get_memory = ctypes.windll.psapi.GetProcessMemoryInfo
    get_memory.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(ProcessMemoryCounters),
        wintypes.DWORD,
    ]
    get_memory.restype = wintypes.BOOL
    handle = get_process()
    if not get_memory(
        handle, ctypes.byref(counters), counters.cb
    ):
        raise OSError("GetProcessMemoryInfo failed")
    return round(counters.PeakWorkingSetSize / 1024 / 1024, 3)


def generated_name(index: int) -> str:
    season = index % 20 + 1
    episode = index % 250 + 1
    year = 1980 + index % 47
    return f"Serie Unicode ñ {index % 1000} S{season:02d}E{episode:03d} {year} 1080p.mkv"


def benchmark_pipeline(count: int) -> dict[str, Any]:
    normalizer = FilenameNormalizationPipeline()
    classifier = MediaClassifier()
    checksum = 0
    started = time.perf_counter()
    for index in range(count):
        analysis = normalizer.analyze(
            generated_name(index), original_path=rf"\\server\bank\Series\{index % 500}"
        )
        classified = classifier.classify(analysis)
        checksum += len(classified.alternatives) + len(classified.evidence)
    elapsed = time.perf_counter() - started
    return {
        "records": count,
        "seconds": round(elapsed, 6),
        "records_per_second": round(count / elapsed, 2),
        "process_peak_mib": peak_working_set_mib(),
        "checksum": checksum,
    }


def benchmark_export(count: int, directory: Path) -> dict[str, Any]:
    destination = directory / f"export-{count}.json"
    rows = ({"id": index, "title": generated_name(index)} for index in range(count))
    started = time.perf_counter()
    result = ExportService().export(
        ExportRequest("benchmark", destination, ExportFormat.JSON, rows)
    )
    elapsed = time.perf_counter() - started
    byte_count = result.byte_count
    destination.unlink()
    return {
        "records": count,
        "seconds": round(elapsed, 6),
        "records_per_second": round(count / elapsed, 2),
        "process_peak_mib": peak_working_set_mib(),
        "bytes": byte_count,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--sizes", nargs="+", type=int, default=[10_000, 100_000, 500_000, 1_000_000]
    )
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    output = arguments.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.parent / "generated"
    temporary.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "python": os.sys.version.split()[0],
        "memory_metric": "Windows process peak working set",
        "pipeline": [],
        "json_export": [],
    }
    for size in arguments.sizes:
        report["pipeline"].append(benchmark_pipeline(size))
        output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    for size in arguments.sizes:
        report["json_export"].append(benchmark_export(size, temporary))
        output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
