"""Retira el lote Anime actual y lo reagrupa desde sus rutas sin perder archivos."""

from __future__ import annotations

import argparse
import os
import shutil
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from sqlalchemy import create_engine, func, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from mce.application.dto import ProcessingStage, SessionStatus
from mce.application.dto.session_models import SessionItemStatus
from mce.application.processing import LocalPreparationService
from mce.infrastructure.checkpoints import JsonCheckpointStore
from mce.infrastructure.database.models import (
    AuditEventModel,
    ContentModel,
    PhysicalFileModel,
)

EXPECTED_FILES = 75
EXPECTED_OLD_GROUPS = 5
EXPECTED_NEW_GROUPS = 11


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    raw = os.environ.get("MCE_DATABASE_URL", "")
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        raise SystemExit("RECHAZADO: el destino no es exactamente PostgreSQL/mce")
    directory = Path(os.environ["LOCALAPPDATA"]) / "MCE Desktop" / "checkpoints"
    checkpoint = max(directory.glob("*.json"), key=lambda path: path.stat().st_mtime)
    store = JsonCheckpointStore(directory)
    processing = store.load(checkpoint.stem)
    anime = tuple(item for item in processing.items if item.detected_category == "anime")
    old_groups = {item.work_group_id for item in anime}
    if len(anime) != EXPECTED_FILES or len(old_groups) != EXPECTED_OLD_GROUPS:
        raise SystemExit(
            f"RECHAZADO: se esperaban 75 archivos/5 grupos y hay "
            f"{len(anime)}/{len(old_groups)}"
        )
    engine = create_engine(raw, pool_pre_ping=True)
    factory = sessionmaker(engine, expire_on_commit=False)
    with factory() as database:
        contents = tuple(
            database.scalars(
                select(ContentModel).where(ContentModel.content_type == "anime")
            )
        )
        content_ids = tuple(item.id for item in contents)
        linked = database.scalar(
            select(func.count())
            .select_from(PhysicalFileModel)
            .where(PhysicalFileModel.content_id.in_(content_ids))
        )
    print(f"modo={'apply' if args.apply else 'dry-run'}")
    print(f"anime_contenidos={len(contents)}")
    print(f"anime_archivos_vinculados={linked}")
    print(f"checkpoint_archivos={len(anime)}")
    print(f"grupos_antes={len(old_groups)}")
    if len(contents) != 5 or linked != EXPECTED_FILES:
        raise SystemExit("RECHAZADO: PostgreSQL no coincide con el lote Anime esperado")
    reset_ids = {item.item_id for item in anime}
    reset_items = tuple(
        replace(
            item,
            stage=ProcessingStage.CLEANED,
            status=SessionItemStatus.PENDING,
            warning=None,
            parent_content_id=None,
            work_group_id=None,
            work_title=None,
            grouping_confidence=None,
            grouping_reason=None,
            grouping_version=None,
            grouping_status="grouping_pending",
            enrichment_status="pending_enrichment",
            identification_confidence=None,
            metadata_confidence=None,
            final_confidence=None,
            review_reason=None,
        )
        if item.item_id in reset_ids
        else item
        for item in processing.items
    )
    reset = replace(
        processing,
        items=reset_items,
        status=SessionStatus.READY,
        failure_reason=None,
        updated_at=datetime.now(UTC),
    )
    anime_reset = replace(
        reset,
        items=tuple(item for item in reset.items if item.item_id in reset_ids),
    )
    anime_grouped, _ = LocalPreparationService().group(anime_reset)
    grouped_by_id = {item.item_id: item for item in anime_grouped.items}
    regrouped = replace(
        reset,
        items=tuple(grouped_by_id.get(item.item_id, item) for item in reset.items),
    )
    new_anime = tuple(item for item in regrouped.items if item.detected_category == "anime")
    new_groups = {item.work_group_id for item in new_anime}
    print(f"grupos_despues={len(new_groups)}")
    print(
        "obras="
        + " | ".join(
            sorted({item.work_title or "(sin título)" for item in new_anime})
        )
    )
    if len(new_groups) != EXPECTED_NEW_GROUPS:
        raise SystemExit(
            f"RECHAZADO: se esperaban 11 grupos corregidos y hay {len(new_groups)}"
        )
    if not args.apply:
        engine.dispose()
        return 0
    original_bytes = checkpoint.stat().st_size
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    backup = checkpoint.with_suffix(f".before-anime-regroup-{stamp}.json")
    shutil.copy2(checkpoint, backup)
    with factory.begin() as database:
        database.add(
            AuditEventModel(
                id=str(uuid4()),
                occurred_at=datetime.now(UTC),
                actor="codex-repair",
                action="revert_and_regroup_anime_batch",
                object_type="content_batch",
                object_id="anime-container-regroup",
                previous_value={
                    "content_ids": list(content_ids),
                    "works": 5,
                    "files": 75,
                },
                new_value={"status": "ready_for_enrichment", "works": 11, "files": 75},
                correlation_id=str(uuid4()),
                reversible=False,
                reversed_by=None,
            )
        )
        for content in contents:
            database.delete(content)
    store.save(regrouped)
    engine.dispose()
    print(f"checkpoint_bytes_antes={original_bytes}")
    print(f"checkpoint_bytes_despues={checkpoint.stat().st_size}")
    print(f"backup={backup}")
    print("resultado=REAGRUPACION_COMPLETADA")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
