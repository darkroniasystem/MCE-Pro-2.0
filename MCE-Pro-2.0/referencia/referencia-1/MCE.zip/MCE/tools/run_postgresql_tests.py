"""Ejecuta la integración real usando exclusivamente PostgreSQL mce_test."""

from __future__ import annotations

import os
import subprocess
import sys

from sqlalchemy.engine import make_url


def main() -> int:
    raw_test = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
    if raw_test:
        test_url = make_url(raw_test)
    else:
        master_url = make_url(os.environ.get("MCE_DATABASE_URL", ""))
        if master_url.get_backend_name() != "postgresql" or master_url.database != "mce":
            print("BLOQUEADO: falta una conexión autorizada para derivar mce_test")
            return 2
        test_url = master_url.set(database="mce_test")
    if test_url.get_backend_name() != "postgresql" or test_url.database != "mce_test":
        print("BLOQUEADO: las pruebas exigen la base exacta mce_test")
        return 2
    environment = os.environ.copy()
    environment["MCE_TEST_DATABASE_URL"] = test_url.render_as_string(hide_password=False)
    cache = os.path.join(os.environ.get("TEMP", ".test-runtime"), "mce-pytest-pg-cache")
    return subprocess.call(
        [
            sys.executable,
            "-m",
            "pytest",
            "tests/integration/postgresql",
            "-q",
            "-o",
            f"cache_dir={cache}",
        ],
        env=environment,
    )


if __name__ == "__main__":
    raise SystemExit(main())
