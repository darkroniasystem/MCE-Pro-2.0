"""Estima consultas por obra de un JSON MSL grande sin cargarlo completo."""

from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path, PureWindowsPath

import ijson

SEASON = re.compile(r"^(?:season|temporada|s)\s*[._ -]*\d{1,3}$", re.IGNORECASE)
GENERIC = {
    "anime",
    "animes",
    "backup",
    "banco",
    "catalogo",
    "catálogo",
    "copia",
    "copias",
    "media",
    "movies",
    "peliculas",
    "películas",
    "series",
    "tv",
    "videos",
}


def records(path: Path):
    with path.open("rb") as stream:
        yield from ijson.items(stream, "videos.item")


def main() -> int:
    if len(sys.argv) != 2:
        print("Uso: analyze_processing_groups.py <media_scan.json>")
        return 2
    source = Path(sys.argv[1]).resolve()
    parents: Counter[str] = Counter()
    videos = 0
    subtitles = 0
    for record in records(source):
        path = PureWindowsPath(str(record.get("ruta_completa") or record.get("full_path") or ""))
        parents[str(path.parent).casefold()] += 1
        videos += 1
        embedded = record.get("subtitulos")
        subtitles += len(embedded) if isinstance(embedded, list) else 0
    groups: set[str] = set()
    for record in records(source):
        raw = str(record.get("ruta_completa") or record.get("full_path") or "")
        path = PureWindowsPath(raw)
        parent = path.parent
        season_parent = bool(SEASON.fullmatch(parent.name.strip()))
        folder = parent.parent if season_parent else parent
        use_folder = season_parent or parents[str(parent).casefold()] > 1
        if use_folder and folder.name.strip().casefold() not in GENERIC:
            key = f"{record.get('source_id')}|folder|{str(folder).casefold()}"
        else:
            key = f"{record.get('source_id')}|file|{path.stem.casefold()}"
        groups.add(key)
    saved = videos - len(groups)
    reduction = saved * 100 / videos if videos else 0.0
    print(f"videos: {videos}")
    print(f"subtitulos_locales: {subtitles}")
    print(f"grupos_consultables_estimados: {len(groups)}")
    print(f"consultas_reutilizadas_estimadas: {saved}")
    print(f"reduccion_estimada: {reduction:.1f} %")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
