"""Mide una importación MSL real sin persistir ni alterar el archivo."""

from __future__ import annotations

import argparse
import ctypes
import time
from ctypes import wintypes
from pathlib import Path

from mce.application.dto import ImportRequest
from mce.application.importers import ImportService


class ProcessMemoryCounters(ctypes.Structure):
    _fields_ = [
        ("cb", ctypes.c_ulong),
        ("PageFaultCount", ctypes.c_ulong),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


def peak_mib() -> float:
    counters = ProcessMemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    get_process = ctypes.windll.kernel32.GetCurrentProcess
    get_process.restype = wintypes.HANDLE
    get_memory = ctypes.windll.psapi.GetProcessMemoryInfo
    get_memory.argtypes = [
        wintypes.HANDLE,
        ctypes.POINTER(ProcessMemoryCounters),
        wintypes.DWORD,
    ]
    get_memory.restype = wintypes.BOOL
    if not get_memory(get_process(), ctypes.byref(counters), counters.cb):
        raise OSError("GetProcessMemoryInfo failed")
    return round(counters.PeakWorkingSetSize / 1024 / 1024, 2)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    result = ImportService().import_file(ImportRequest(args.path))
    elapsed = time.perf_counter() - started
    records = result.statistics.total_records
    print(f"estado: {result.status.value}")
    print(f"registros: {records}")
    print(f"segundos: {elapsed:.3f}")
    print(f"registros_por_segundo: {records / elapsed:.2f}")
    print(f"memoria_pico_mib: {peak_mib():.2f}")
    return 0 if result.success else 1


if __name__ == "__main__":
    raise SystemExit(main())
