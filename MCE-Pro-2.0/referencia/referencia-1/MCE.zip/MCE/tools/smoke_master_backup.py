"""Crea y valida una copia real del catálogo maestro sin restaurarla."""

from __future__ import annotations

import os
from pathlib import Path

from sqlalchemy.engine import make_url

from mce.infrastructure.operations import PostgresBackupService


def main() -> int:
    raw = os.environ.get("MCE_DATABASE_URL", "").strip()
    if not raw:
        print("BLOQUEADO: MCE_DATABASE_URL no disponible")
        return 2
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        print("BLOQUEADO: el destino no es PostgreSQL mce")
        return 3
    destination = Path(".test-runtime/master-backup/mce.dump")
    service = PostgresBackupService()
    created = service.create(raw, destination)
    if not created.success:
        print("backup: falló")
        return 4
    validated = service.validate(destination)
    print("base: mce")
    print(f"backup: {'creado' if created.success else 'falló'}")
    print(f"validación: {'correcta' if validated.success else 'falló'}")
    print(f"tamaño_bytes: {destination.stat().st_size}")
    print("credenciales: ocultas")
    return 0 if validated.success else 5


if __name__ == "__main__":
    raise SystemExit(main())
