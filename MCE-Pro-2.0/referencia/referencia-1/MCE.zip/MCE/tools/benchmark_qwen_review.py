"""Benchmark aislado de Qwen con 50 variantes difíciles y evidencia fija."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from dataclasses import dataclass
from pathlib import Path

from mce.application.ai_review import AIReviewDecision, AIReviewInput, EvidenceSource
from mce.application.ai_review.validator import EvidenceValidator
from mce.infrastructure.local_ai import OllamaQwenAnalyzer, UrllibOllamaTransport


@dataclass(frozen=True, slots=True)
class Work:
    canonical: str
    category: str
    year: int
    aliases: tuple[str, ...]
    domains: tuple[str, str]
    summary: str


WORKS = (
    Work(
        "Parasite",
        "movie",
        2019,
        ("Gisaengchung", "Parásitos"),
        ("festival-cannes.com", "imdb.com"),
        "South Korean film directed by Bong Joon Ho, released in 2019.",
    ),
    Work(
        "Vagabond",
        "dorama",
        2019,
        ("Baegabondeu", "Vagabond K-drama"),
        ("sbs.co.kr", "mydramalist.com"),
        "South Korean television series first broadcast in 2019.",
    ),
    Work(
        "Spirited Away",
        "anime",
        2001,
        ("Sen to Chihiro no Kamikakushi", "El viaje de Chihiro"),
        ("ghibli.jp", "imdb.com"),
        "Japanese animated fantasy film directed by Hayao Miyazaki, released in 2001.",
    ),
    Work(
        "Dark",
        "series",
        2017,
        ("Dark Netflix", "Dark 2017"),
        ("netflix.com", "imdb.com"),
        "German science fiction thriller television series that premiered in 2017.",
    ),
    Work(
        "Money Heist",
        "series",
        2017,
        ("La casa de papel", "Casa de Papel"),
        ("netflix.com", "imdb.com"),
        "Spanish television crime drama series released internationally as Money Heist.",
    ),
    Work(
        "The Glory",
        "dorama",
        2022,
        ("Deo Geullori", "La gloria"),
        ("netflix.com", "mydramalist.com"),
        "South Korean television series starring Song Hye-kyo, released in 2022.",
    ),
    Work(
        "Attack on Titan",
        "anime",
        2013,
        ("Shingeki no Kyojin", "Ataque a los titanes"),
        ("crunchyroll.com", "anilist.co"),
        "Japanese anime television series that premiered in 2013.",
    ),
    Work(
        "The Office",
        "series",
        2005,
        ("The Office US", "La oficina"),
        ("nbc.com", "imdb.com"),
        "American workplace comedy television series that premiered in 2005.",
    ),
    Work(
        "Oldboy",
        "movie",
        2003,
        ("Oldeuboi", "Old Boy Korean"),
        ("festival-cannes.com", "imdb.com"),
        "South Korean neo-noir action thriller film directed by Park Chan-wook, released in 2003.",
    ),
    Work(
        "Crash Landing on You",
        "dorama",
        2019,
        ("Sarangui Bulsichak", "Aterrizaje de emergencia en tu corazón"),
        ("netflix.com", "mydramalist.com"),
        "South Korean television series that premiered in 2019.",
    ),
)


def variants(work: Work) -> tuple[str, ...]:
    return (
        work.canonical,
        work.aliases[0],
        f"0012 - {work.canonical} WEB-DL 1080p",
        f"{work.canonical} ({work.year}) LAT",
        f"S01 {work.aliases[1]} COMPLETE",
    )


def evidence(work: Work) -> tuple[EvidenceSource, ...]:
    return tuple(
        EvidenceSource(
            f"https://{domain}/title/{work.canonical.casefold().replace(' ', '-')}",
            work.canonical,
            work.summary,
            "benchmark",
        )
        for domain in work.domains
    )


def percentile(values: list[int], fraction: float) -> int:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, round((len(ordered) - 1) * fraction))]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", default="qwen2.5:3b")
    parser.add_argument("--max-context-chars", type=int, default=8_000)
    parser.add_argument("--max-output-tokens", type=int, default=800)
    arguments = parser.parse_args()
    analyzer = OllamaQwenAnalyzer(
        UrllibOllamaTransport(),
        model=arguments.model,
        max_context_chars=arguments.max_context_chars,
        max_output_tokens=arguments.max_output_tokens,
    )
    validator = EvidenceValidator()
    rows: list[dict[str, object]] = []
    started = time.perf_counter()
    for work in WORKS:
        sources = evidence(work)
        for title in variants(work):
            item = AIReviewInput(
                f"benchmark-{len(rows):02d}",
                title,
                work.category,
                work.year,
                alternative_titles=work.aliases,
            )
            try:
                result = validator.validate(item, analyzer.analyze(item, sources))
                canonical_ok = (
                    result.canonical_title or ""
                ).casefold() == work.canonical.casefold()
                rows.append(
                    {
                        "input": title,
                        "expected": work.canonical,
                        "proposed": result.canonical_title,
                        "decision": result.decision.value,
                        "score": result.deterministic_score,
                        "canonical_ok": canonical_ok,
                        "hallucinated_source": result.hallucinated_source,
                        "latency_ms": result.latency_ms,
                    }
                )
            except Exception as exc:
                rows.append(
                    {"input": title, "expected": work.canonical, "error": type(exc).__name__}
                )
            print(f"progress={len(rows)}/50", flush=True)
    latencies: list[int] = []
    for row in rows:
        latency = row.get("latency_ms")
        if isinstance(latency, int):
            latencies.append(latency)
    report = {
        "model": arguments.model,
        "cases": len(rows),
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "canonical_accuracy_percent": round(
            100 * sum(bool(row.get("canonical_ok")) for row in rows) / len(rows), 2
        ),
        "auto_approved_percent": round(
            100
            * sum(row.get("decision") == AIReviewDecision.APPROVE.value for row in rows)
            / len(rows),
            2,
        ),
        "hallucinated_source_count": sum(bool(row.get("hallucinated_source")) for row in rows),
        "error_count": sum("error" in row for row in rows),
        "latency_ms": {
            "mean": round(statistics.mean(latencies), 2) if latencies else None,
            "p50": percentile(latencies, 0.50) if latencies else None,
            "p95": percentile(latencies, 0.95) if latencies else None,
        },
        "rows": rows,
        "limits": {
            "concurrency": 1,
            "web_results": 2,
            "max_context_chars": arguments.max_context_chars,
            "max_output_tokens": arguments.max_output_tokens,
        },
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "rows"}, ensure_ascii=False
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
