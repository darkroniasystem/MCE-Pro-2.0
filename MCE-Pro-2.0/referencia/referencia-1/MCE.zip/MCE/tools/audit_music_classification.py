"""Auditoría de solo lectura para la categoría local `music`."""

from __future__ import annotations

import json
import os
import re
from collections import Counter
from pathlib import Path, PureWindowsPath
from typing import Any

import ijson

AUDIO_EXTENSIONS = {".aac", ".flac", ".m4a", ".mp3", ".ogg", ".wav"}
VIDEO_EXTENSIONS = {
    ".3gp",
    ".avi",
    ".m2ts",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".mts",
    ".ts",
    ".vob",
    ".webm",
    ".wmv",
}


def _checkpoint() -> Path:
    directory = Path(os.environ["LOCALAPPDATA"]) / "MCE Desktop" / "checkpoints"
    candidates = sorted(directory.glob("*.json"), key=lambda path: path.stat().st_mtime)
    if not candidates:
        raise RuntimeError("no se encontró ningún checkpoint de MCE")
    return candidates[-1]


def analyze(path: Path) -> dict[str, Any]:
    extensions: Counter[str] = Counter()
    folders: Counter[str] = Counter()
    rules: Counter[str] = Counter()
    reasons: Counter[str] = Counter()
    banks: Counter[str] = Counter()
    examples: list[dict[str, Any]] = []
    suspicious: list[dict[str, Any]] = []
    proposed: Counter[str] = Counter()
    examples_by_proposal: dict[str, list[dict[str, Any]]] = {}
    totals = Counter()
    with path.open("rb") as stream:
        for item in ijson.items(stream, "session.items.item"):
            if item.get("detected_category") != "music":
                continue
            original_path = str(item.get("original_path") or "")
            name = str(item.get("original_name") or PureWindowsPath(original_path).name)
            suffix = PureWindowsPath(name).suffix.casefold() or "(sin extensión)"
            parent = str(PureWindowsPath(original_path).parent)
            matched = tuple(str(value) for value in item.get("matched_rules") or ())
            reason = str(item.get("classification_reason") or "sin motivo")
            raw_confidence = item.get("category_confidence")
            confidence = float(raw_confidence) if raw_confidence is not None else None
            bank_id = str(item.get("bank_id") or "(sin bank_id)")
            extensions[suffix] += 1
            folders[parent] += 1
            reasons[reason] += 1
            banks[bank_id] += 1
            for rule in matched or ("(sin regla registrada)",):
                rules[rule] += 1
            if suffix in AUDIO_EXTENSIONS:
                media_type = "audio"
                totals["audio"] += 1
            elif suffix in VIDEO_EXTENSIONS:
                media_type = "video"
                totals["video"] += 1
            else:
                media_type = "unknown"
                totals["unknown"] += 1
            record = {
                "extension": suffix,
                "path": original_path,
                "name": name,
                "imported_record_type": "session_item",
                "inferred_media_type": media_type,
                "rules": matched,
                "reason": reason,
                "confidence": confidence,
                "bank_id": bank_id,
            }
            if len(examples) < 30:
                examples.append(record)
            text = f"{name} {original_path}".casefold()
            if media_type == "audio":
                proposed_category = "unsupported_media"
            elif suffix in {".srt", ".ass", ".ssa", ".sub", ".vtt"}:
                proposed_category = "subtitle"
            elif "karaoke" in text:
                proposed_category = "karaoke"
            elif "concert" in text or "concierto" in text:
                proposed_category = "concert"
            elif "\\series" in text or re.search(
                r"(?:s\d{1,3}e\d{1,4}|\d{1,3}x\d{1,4}|cap(?:itulo)?\s*\d+)",
                text,
            ):
                proposed_category = "series_or_episode"
            elif any(
                signal in text for signal in ("music video", "video musical", "videoclip")
            ):
                proposed_category = "needs_provider_review"
            elif any(
                signal in text
                for signal in ("\\pelis\\", "\\peliculas\\", "\\filmes", "\\sagas de filmes\\")
            ):
                proposed_category = "movie"
            else:
                proposed_category = "needs_review"
            proposed[proposed_category] += 1
            record["proposed_category"] = proposed_category
            category_examples = examples_by_proposal.setdefault(proposed_category, [])
            if len(category_examples) < 5:
                category_examples.append(record)
            if proposed_category not in {"concert", "karaoke"}:
                if len(suspicious) < 100:
                    suspicious.append(record)
                totals["possibly_misclassified"] += 1
            totals["music"] += 1
    return {
        "mode": "read-only checkpoint audit",
        "checkpoint": str(path),
        "checkpoint_bytes": path.stat().st_size,
        "music_records": totals["music"],
        "video_files": totals["video"],
        "audio_files": totals["audio"],
        "unknown_media_files": totals["unknown"],
        "possibly_misclassified": totals["possibly_misclassified"],
        "extension_distribution": dict(extensions.most_common()),
        "top_source_folders": dict(folders.most_common(30)),
        "classification_rules": dict(rules.most_common()),
        "classification_reasons": dict(reasons.most_common()),
        "proposed_reclassification": dict(proposed.most_common()),
        "bank_id_distribution": dict(banks.most_common()),
        "representative_examples": examples,
        "suspicious_examples": suspicious,
        "examples_by_proposed_category": examples_by_proposal,
    }


def main() -> int:
    report = analyze(_checkpoint())
    output = Path(".test-runtime/audits/music-classification.json").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {
        key: value for key, value in report.items() if not key.endswith("examples")
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"reporte={output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
