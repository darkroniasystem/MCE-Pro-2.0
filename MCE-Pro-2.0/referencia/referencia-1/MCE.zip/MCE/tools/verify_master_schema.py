"""Verifica el esquema maestro sin dejar datos ficticios."""

from __future__ import annotations

import os

from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import make_url

from mce.infrastructure.database.models import Base


def main() -> int:
    raw = os.environ.get("MCE_DATABASE_URL", "").strip()
    if not raw:
        print("BLOQUEADO: MCE_DATABASE_URL no disponible")
        return 2
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        print("BLOQUEADO: el destino no es PostgreSQL mce")
        return 3
    engine = create_engine(raw, pool_pre_ping=True)
    try:
        inspector = inspect(engine)
        actual = set(inspector.get_table_names())
        expected = set(Base.metadata.tables)
        missing = expected - actual
        views = set(inspector.get_view_names())
        foreign_keys = sum(len(inspector.get_foreign_keys(table)) for table in expected & actual)
        unique_constraints = sum(
            len(inspector.get_unique_constraints(table)) for table in expected & actual
        )
        indexes = sum(len(inspector.get_indexes(table)) for table in expected & actual)
        with engine.connect() as connection:
            current = connection.execute(
                text("SELECT version_num FROM alembic_version")
            ).scalar_one()
            transaction = connection.begin_nested()
            connection.execute(text("SELECT 1"))
            transaction.rollback()
        head = ScriptDirectory.from_config(Config("alembic.ini")).get_current_head()
    finally:
        engine.dispose()
    print("base: mce")
    print(f"tablas_modeladas: {len(expected)}")
    print(f"tablas_encontradas: {len(actual)}")
    print(f"indices: {indexes}")
    print(f"claves_foraneas: {foreign_keys}")
    print(f"restricciones_unicas: {unique_constraints}")
    print(f"vista_bot_catalog_v1: {'correcta' if 'bot_catalog_v1' in views else 'faltante'}")
    print(f"alembic: {current} / head {head}")
    if missing or current != head or "bot_catalog_v1" not in views:
        print(f"ERROR: faltan {len(missing)} tablas o componentes requeridos")
        return 4
    print("resultado: esquema maestro verificado; no se conservaron datos de prueba")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
