"""Renderiza vistas principales de MCE para inspección visual local."""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from mce.application.processing import ProcessingProgress
from mce.presentation.main_window import MainWindow


def main() -> int:
    output = Path(".test-runtime/ui-preview")
    output.mkdir(parents=True, exist_ok=True)
    app = QApplication.instance() or QApplication([])
    window = MainWindow(
        QSettings(str(output / "settings.ini"), QSettings.Format.IniFormat)
    )
    window.resize(1600, 900)
    window.show()
    window.navigate_to("Catálogo")
    app.processEvents()
    window.grab().save(str(output / "catalog.png"))
    window.navigate_to("Sesiones")
    window.session_progress_panel.begin(284_018)
    window.session_progress_panel.update_progress(
        ProcessingProgress(
            "enriching",
            "Buscando y enriqueciendo metadatos por obra",
            12_840,
            284_018,
            4.5,
            70,
            1_204,
            82,
            0,
        )
    )
    app.processEvents()
    window.grab().save(str(output / "sessions.png"))
    window.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
