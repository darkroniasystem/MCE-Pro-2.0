"""Dry-run conservador de reclasificación del catálogo maestro MCE.

Este comando solo ejecuta SELECT dentro de una transacción PostgreSQL READ ONLY.
No crea tablas, no altera estados y no aplica la migración propuesta.
"""

from __future__ import annotations

import json
import os
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import make_url

VALID_CATEGORIES = {
    "anime",
    "documentary",
    "dorama",
    "episode",
    "movie",
    "novela",
    "novel",
    "season",
    "series",
    "special",
    "western_animation",
}
APPROVED = {"approved", "auto_approved"}
REVIEW_TERMINAL = {"approved", "rejected", "blocked"}
TRANSIENT_PROVIDER = {
    "pending",
    "pending_enrichment",
    "provider_partial",
    "provider_unavailable",
    "rate_limited",
    "timeout",
    "waiting_rate_limit",
    "waiting_retry",
}


@dataclass(frozen=True, slots=True)
class Proposal:
    entity: str
    identifier: str
    action: str
    reason: str


def _database_url() -> str:
    raw = os.environ.get("MCE_DATABASE_URL", "").strip()
    if not raw:
        print("BLOQUEADO: MCE_DATABASE_URL no está disponible", file=sys.stderr)
        raise SystemExit(2)
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        print("BLOQUEADO: el dry-run exige PostgreSQL mce exacta", file=sys.stderr)
        raise SystemExit(2)
    return raw


def _rows(connection: Any, statement: str) -> list[dict[str, Any]]:
    return [dict(row) for row in connection.execute(text(statement)).mappings()]


def _count_by(rows: list[dict[str, Any]], field: str, fallback: str) -> Counter[str]:
    return Counter(str(row.get(field) or fallback) for row in rows)


def _sorted(counter: Counter[str]) -> dict[str, int]:
    return dict(sorted(counter.items(), key=lambda item: item[0].casefold()))


def analyze() -> dict[str, Any]:
    engine = create_engine(_database_url(), pool_pre_ping=True)
    with engine.connect() as connection:
        transaction = connection.begin()
        try:
            connection.execute(text("SET TRANSACTION READ ONLY"))
            database = connection.execute(text("select current_database()")).scalar_one()
            if database != "mce":
                raise RuntimeError("la conexión efectiva no apunta a mce")
            schema = inspect(connection)
            required = {
                "alembic_version",
                "banks",
                "contents",
                "external_identifiers",
                "normalized_metadata",
                "physical_files",
                "provider_queries",
                "scan_imports",
                "scans",
            }
            missing = sorted(required - set(schema.get_table_names()))
            if missing:
                raise RuntimeError(f"faltan tablas requeridas: {', '.join(missing)}")

            revision = connection.execute(
                text("select version_num from alembic_version")
            ).scalar_one()
            contents = _rows(
                connection,
                """
                SELECT c.id, c.bank_id, c.content_type, c.status,
                       c.identification_status, c.review_status,
                       COALESCE(MAX(nm.confidence), NULL) AS confidence,
                       COUNT(DISTINCT ei.id) AS external_ids,
                       COUNT(DISTINCT nm.id) AS metadata_fields,
                       COUNT(DISTINCT mc.id) AS conflicts
                  FROM contents c
             LEFT JOIN external_identifiers ei ON ei.content_id = c.id
             LEFT JOIN normalized_metadata nm ON nm.content_id = c.id
             LEFT JOIN metadata_conflicts mc ON mc.content_id = c.id
              GROUP BY c.id
                """,
            )
            files = _rows(
                connection,
                """
                SELECT pf.id, pf.content_id, pf.status,
                       COALESCE(si.bank_id, c.bank_id) AS bank_id,
                       c.content_type, c.bank_id AS content_bank_id,
                       si.bank_id AS scan_bank_id
                  FROM physical_files pf
                  JOIN scans s ON s.id = pf.scan_id
             LEFT JOIN scan_imports si ON si.scan_id = s.id
             LEFT JOIN contents c ON c.id = pf.content_id
                """,
            )
            provider_rows = _rows(
                connection,
                """
                SELECT content_id, status, provider
                  FROM provider_queries
                 WHERE content_id IS NOT NULL
                """,
            )
            banks = _rows(
                connection,
                """
                SELECT b.id, b.name,
                       COUNT(DISTINCT c.id) AS contents,
                       COUNT(DISTINCT pf.id) AS files
                  FROM banks b
             LEFT JOIN contents c ON c.bank_id = b.id
             LEFT JOIN scan_imports si ON si.bank_id = b.id
             LEFT JOIN scans s ON s.id = si.scan_id
             LEFT JOIN physical_files pf ON pf.scan_id = s.id
              GROUP BY b.id, b.name
              ORDER BY b.name, b.id
                """,
            )
        finally:
            transaction.rollback()
    engine.dispose()

    provider_by_content: dict[str, list[str]] = defaultdict(list)
    for row in provider_rows:
        provider_by_content[str(row["content_id"])].append(str(row["status"]).casefold())

    proposals: list[Proposal] = []
    inconsistencies: list[dict[str, str]] = []
    enriched_untouched: set[str] = set()
    ready_for_enrichment: set[str] = set()
    needs_reclassification: set[tuple[str, str]] = set()

    for row in files:
        file_id = str(row["id"])
        content_id = str(row["content_id"]) if row["content_id"] else ""
        category = str(row["content_type"] or "").casefold()
        if not content_id or category not in VALID_CATEGORIES:
            needs_reclassification.add(("physical_file", file_id))
            proposals.append(
                Proposal(
                    "physical_file",
                    file_id,
                    "reclassify",
                    "sin contenido enlazado o categoría local válida",
                )
            )
        scan_bank = row.get("scan_bank_id")
        content_bank = row.get("content_bank_id")
        if content_id and scan_bank and content_bank and scan_bank != content_bank:
            inconsistencies.append(
                {
                    "entity": "physical_file",
                    "id": file_id,
                    "reason": "bank_id del escaneo y del contenido no coinciden",
                }
            )

    for row in contents:
        content_id = str(row["id"])
        category = str(row["content_type"] or "").casefold()
        identification = str(row["identification_status"] or "").casefold()
        review = str(row["review_status"] or "").casefold()
        status = str(row["status"] or "").casefold()
        external_ids = int(row["external_ids"] or 0)
        metadata_fields = int(row["metadata_fields"] or 0)
        conflicts = int(row["conflicts"] or 0)
        confidence = row["confidence"]
        provider_states = provider_by_content.get(content_id, [])
        has_enrichment = external_ids > 0 or metadata_fields > 0

        if has_enrichment:
            enriched_untouched.add(content_id)
        elif category in VALID_CATEGORIES and review not in REVIEW_TERMINAL:
            ready_for_enrichment.add(content_id)
            proposals.append(
                Proposal(
                    "content",
                    content_id,
                    "mark_ready_for_enrichment",
                    "categoría válida sin evidencia enriquecida",
                )
            )
        else:
            needs_reclassification.add(("content", content_id))
            proposals.append(
                Proposal(
                    "content",
                    content_id,
                    "reclassify",
                    "categoría ausente o no normalizada",
                )
            )

        if identification == "identified" and external_ids == 0:
            inconsistencies.append(
                {
                    "entity": "content",
                    "id": content_id,
                    "reason": "identified sin identificador externo",
                }
            )
        if review in APPROVED and external_ids == 0:
            inconsistencies.append(
                {
                    "entity": "content",
                    "id": content_id,
                    "reason": "approved sin identificador externo",
                }
            )
        if identification == "identified" and confidence is None:
            inconsistencies.append(
                {
                    "entity": "content",
                    "id": content_id,
                    "reason": "identified sin confianza persistida",
                }
            )

        active_review = review not in REVIEW_TERMINAL | {"", "none", "not_required"}
        transient = not provider_states or any(
            state in TRANSIENT_PROVIDER for state in provider_states
        )
        if active_review and transient:
            proposals.append(
                Proposal(
                    "content",
                    content_id,
                    "withdraw_from_active_review",
                    "enriquecimiento sin completar o proveedor transitorio",
                )
            )

        strong = (
            active_review
            and identification == "identified"
            and external_ids > 0
            and confidence is not None
            and float(confidence) >= 90
            and conflicts == 0
        )
        if strong:
            proposals.append(
                Proposal(
                    "content",
                    content_id,
                    "auto_approve",
                    "identificación fuerte, ID externo y sin conflictos",
                )
            )

        # Deliberadamente no se infiere not_found_confirmed: el esquema actual
        # no persiste la lista de proveedores aplicables y pendientes.
        if status in {"rejected", "blocked"} and review in APPROVED:
            inconsistencies.append(
                {
                    "entity": "content",
                    "id": content_id,
                    "reason": "estado de contenido incompatible con revisión aprobada",
                }
            )

    action_counts = Counter(proposal.action for proposal in proposals)
    modified_rows = {(proposal.entity, proposal.identifier) for proposal in proposals}
    category_distribution = _count_by(contents, "content_type", "sin_clasificar")
    category_distribution["sin_contenido_enlazado"] += sum(
        1 for row in files if not row["content_id"]
    )
    bank_distribution = {
        str(row["id"]): {
            "name": str(row["name"]),
            "contents": int(row["contents"] or 0),
            "physical_files": int(row["files"] or 0),
        }
        for row in banks
    }
    return {
        "mode": "dry-run",
        "database": "mce",
        "alembic_revision": revision,
        "target_alembic_revision": "0008",
        "schema_migration_pending": revision != "0008",
        "read_only_transaction": True,
        "current_distribution_by_category": _sorted(category_distribution),
        "current_content_statuses": _sorted(_count_by(contents, "status", "sin_estado")),
        "current_identification_statuses": _sorted(
            _count_by(contents, "identification_status", "sin_estado")
        ),
        "current_review_statuses": _sorted(
            _count_by(contents, "review_status", "sin_estado")
        ),
        "records_needing_reclassification": len(needs_reclassification),
        "records_ready_for_enrichment": len(ready_for_enrichment),
        "already_enriched_untouched": len(enriched_untouched),
        "inconsistent_records": len(
            {(row["entity"], row["id"], row["reason"]) for row in inconsistencies}
        ),
        "distribution_by_bank_id": bank_distribution,
        "proposed_actions": _sorted(action_counts),
        "would_auto_approve": action_counts["auto_approve"],
        "would_withdraw_from_active_review": action_counts[
            "withdraw_from_active_review"
        ],
        "would_mark_not_found_confirmed": 0,
        "exact_rows_modified_by_apply": len(modified_rows),
        "safety_notes": [
            "No se ejecutó DDL, INSERT, UPDATE, DELETE ni migración Alembic.",
            "La revisión 0008 ya está aplicada; el dry-run no ejecuta migraciones.",
            "not_found_confirmed permanece en cero porque el esquema actual no demuestra "
            "que todos los proveedores aplicables hayan terminado sin resultados.",
            "Los registros aprobados o enriquecidos no se proponen para reprocesamiento.",
        ],
        "inconsistency_sample": inconsistencies[:20],
    }


def main() -> int:
    report = analyze()
    output = Path(".test-runtime/dry-run/pipeline-reclassification.json").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print(f"reporte: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
