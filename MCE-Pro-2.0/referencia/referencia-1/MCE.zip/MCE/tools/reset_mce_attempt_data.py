"""Elimina datos de intentos de MCE conservando esquema y migraciones."""

from __future__ import annotations

import argparse
import os
from datetime import datetime
from pathlib import Path

from sqlalchemy import create_engine, inspect, text
from sqlalchemy.engine import make_url

from mce.infrastructure.operations import PostgresBackupService


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    arguments = parser.parse_args()
    if not arguments.apply:
        print("BLOQUEADO: use --apply para confirmar la limpieza")
        return 2
    raw = os.environ.get("MCE_DATABASE_URL", "").strip()
    if not raw:
        print("BLOQUEADO: MCE_DATABASE_URL no disponible")
        return 2
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        print("BLOQUEADO: el destino debe ser PostgreSQL mce exacta")
        return 3

    backup_root = Path(os.environ["LOCALAPPDATA"]) / "MCE Desktop" / "backups"
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = backup_root / f"mce-before-attempt-cleanup-{timestamp}.dump"
    backup_service = PostgresBackupService()
    created = backup_service.create(raw, backup)
    if not created.success:
        print("BLOQUEADO: no se pudo crear el respaldo")
        return 4
    validated = backup_service.validate(backup)
    if not validated.success:
        print("BLOQUEADO: el respaldo no superó la validación")
        return 5

    engine = create_engine(raw, pool_pre_ping=True)
    with engine.begin() as connection:
        if connection.execute(text("select current_database()")).scalar_one() != "mce":
            raise RuntimeError("la conexión efectiva no apunta a mce")
        tables = sorted(
            table
            for table in inspect(connection).get_table_names()
            if table != "alembic_version"
        )
        before = {
            table: connection.execute(
                text(f'SELECT COUNT(*) FROM "{table}"')
            ).scalar_one()
            for table in tables
        }
        quoted = ", ".join(f'"{table}"' for table in tables)
        if quoted:
            connection.execute(text(f"TRUNCATE TABLE {quoted} RESTART IDENTITY CASCADE"))
    with engine.connect() as connection:
        remaining = sum(
            connection.execute(
                text(f'SELECT COUNT(*) FROM "{table}"')
            ).scalar_one()
            for table in tables
        )
        revision = connection.execute(
            text("SELECT version_num FROM alembic_version")
        ).scalar_one()
    engine.dispose()

    print("base: mce")
    print(f"filas_eliminadas: {sum(before.values())}")
    print(f"tablas_limpiadas: {len(tables)}")
    print(f"filas_restantes: {remaining}")
    print(f"alembic: {revision}")
    print(f"respaldo: {backup}")
    print(f"respaldo_bytes: {backup.stat().st_size}")
    print("credenciales: ocultas")
    return 0 if remaining == 0 and revision == "0004" else 6


if __name__ == "__main__":
    raise SystemExit(main())
