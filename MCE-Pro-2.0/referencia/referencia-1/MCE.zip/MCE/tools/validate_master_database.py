"""Valida de forma segura el destino maestro antes de migraciones."""

from __future__ import annotations

import os

from sqlalchemy.engine import make_url


def main() -> int:
    raw = os.environ.get("MCE_DATABASE_URL", "").strip()
    if not raw:
        print("MCE_DATABASE_URL: no disponible")
        return 2
    url = make_url(raw)
    safe = url.get_backend_name() == "postgresql" and url.database == "mce"
    print(f"motor: {'PostgreSQL' if url.get_backend_name() == 'postgresql' else 'NO PERMITIDO'}")
    print(f"host: {url.host or '(local)'}")
    print(f"puerto: {url.port or 5432}")
    print(f"base: {url.database or '(vacía)'}")
    print("contraseña: oculta")
    if not safe:
        print("BLOQUEADO: el destino maestro no es PostgreSQL mce")
        return 3
    print("protección: catálogo maestro autorizado")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
