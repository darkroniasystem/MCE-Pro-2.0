"""Barrera de seguridad antes de operaciones destructivas sobre PostgreSQL."""

from __future__ import annotations

import os

from sqlalchemy.engine import make_url


def main() -> int:
    raw = os.getenv("MCE_TEST_DATABASE_URL", "")
    if not raw:
        print("MCE_TEST_DATABASE_URL: no disponible")
        return 2
    url = make_url(raw)
    is_postgresql = url.drivername.startswith("postgresql")
    print(f"motor: {'PostgreSQL' if is_postgresql else 'NO PERMITIDO'}")
    print(f"host: {url.host or '(local)'}")
    print(f"puerto: {url.port or 5432}")
    print(f"base: {url.database or '(vacía)'}")
    print("contraseña: oculta")
    if not is_postgresql or url.database != "mce_test":
        print("BLOQUEADO: el destino no es PostgreSQL mce_test")
        return 3
    print("protección: destino de pruebas autorizado")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
