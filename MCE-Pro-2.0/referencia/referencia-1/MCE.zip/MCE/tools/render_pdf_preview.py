"""Genera un catálogo PDF controlado para inspección visual."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QColor, QImage
from PySide6.QtWidgets import QApplication

from mce.presentation.pdf_catalog import PdfCatalogExporter


def main() -> int:
    QApplication.instance() or QApplication([])
    cover = QImage(240, 360, QImage.Format.Format_RGB32)
    cover.fill(QColor("#2563eb"))
    rows = [
        {
            "título": "Akira",
            "título original": "AKIRA",
            "tipo": "anime",
            "año": 1988,
            "géneros": "Animación, ciencia ficción",
            "director": "Katsuhiro Otomo",
            "reparto": "Mitsuo Iwata, Nozomu Sasaki",
            "banco": "Catálogo maestro",
            "sinopsis": (
                "Una historia de ciencia ficción ambientada en Neo-Tokyo, incluida para "
                "comprobar el ajuste de texto y la representación de caracteres Unicode."
            ),
            "carátula": "https://example.test/akira.jpg",
        },
        {
            "título": "Amélie",
            "tipo": "movie",
            "año": 2001,
            "géneros": "Comedia, romance",
            "director": "Jean-Pierre Jeunet",
            "banco": "Catálogo maestro",
            "sinopsis": "Película utilizada para validar la sección de películas.",
        },
        {
            "título": "Serie de demostración",
            "tipo": "series",
            "año": 2025,
            "géneros": "Drama",
            "banco": "Catálogo maestro",
        },
        {"título": "Temporada 1", "tipo": "season", "banco": "Catálogo maestro"},
        {"título": "Episodio 1", "tipo": "episode", "banco": "Catálogo maestro"},
    ]
    destination = Path("output/pdf/catalogo_mce_muestra.pdf")
    destination.parent.mkdir(parents=True, exist_ok=True)
    PdfCatalogExporter(lambda url: cover if url else None).export(rows, destination)
    print(destination.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
