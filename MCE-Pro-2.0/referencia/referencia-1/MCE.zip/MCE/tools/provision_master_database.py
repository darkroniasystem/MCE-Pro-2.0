"""Crea de forma no destructiva el catálogo maestro PostgreSQL `mce`."""

from __future__ import annotations

import os
import winreg

import psycopg
from psycopg import sql
from sqlalchemy.engine import make_url


def main() -> int:
    raw = os.environ.get("MCE_TEST_DATABASE_URL", "").strip()
    if not raw:
        print("BLOQUEADO: MCE_TEST_DATABASE_URL no está configurada")
        return 2
    test_url = make_url(raw)
    if test_url.get_backend_name() != "postgresql" or test_url.database != "mce_test":
        print("BLOQUEADO: la conexión de origen no es PostgreSQL mce_test")
        return 3
    admin_url = test_url.set(database="postgres")
    target_url = test_url.set(database="mce")
    admin_dsn = admin_url.render_as_string(hide_password=False).replace(
        "postgresql+psycopg://", "postgresql://", 1
    )
    target_dsn = target_url.render_as_string(hide_password=False).replace(
        "postgresql+psycopg://", "postgresql://", 1
    )
    with psycopg.connect(admin_dsn, autocommit=True) as connection:
        exists = connection.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s", ("mce",)
        ).fetchone()
        if exists is None:
            connection.execute(
                sql.SQL("CREATE DATABASE {} ENCODING 'UTF8' TEMPLATE template0").format(
                    sql.Identifier("mce")
                )
            )
            outcome = "creada"
        else:
            outcome = "ya existente"
    with psycopg.connect(target_dsn) as connection:
        database = connection.execute("SELECT current_database()").fetchone()
        if database is None or database[0] != "mce":
            print("BLOQUEADO: no se pudo verificar el catálogo maestro")
            return 4
    persisted = target_url.render_as_string(hide_password=False)
    with winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        "Environment",
        0,
        winreg.KEY_SET_VALUE,
    ) as key:
        winreg.SetValueEx(key, "MCE_DATABASE_URL", 0, winreg.REG_SZ, persisted)
    print("motor: PostgreSQL")
    print(f"host: {target_url.host or 'localhost'}")
    print(f"puerto: {target_url.port or 5432}")
    print("base: mce")
    print("contraseña: oculta")
    print(f"resultado: base {outcome}; variable de usuario configurada")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
