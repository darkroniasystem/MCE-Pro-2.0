"""Repara exclusivamente el primer lote Anime aprobado de forma incompleta."""

from __future__ import annotations

import argparse
import os
import shutil
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from uuid import uuid4

from sqlalchemy import create_engine, func, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import sessionmaker

from mce.application.dto import ProcessingStage, SessionStatus
from mce.application.dto.session_models import SessionItemStatus
from mce.infrastructure.checkpoints import JsonCheckpointStore
from mce.infrastructure.database.models import (
    AuditEventModel,
    ContentModel,
    PhysicalFileModel,
)

EXPECTED_CONTENTS = {
    "456ad848-968f-5296-86aa-27321ca8cfe2": "DamePri Anime Caravan",
    "fc0dcfb6-cb51-5c9a-bf8b-6bad0adb4044": "Rick and Morty: The Anime",
    "69460705-13a6-55e8-8e47-7260a21b2000": (
        "Sword Art Online: FULLDIVE - Opening Eizou"
    ),
}
EXPECTED_GROUPS = 5
EXPECTED_FILES = 75


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    raw = os.environ.get("MCE_DATABASE_URL", "")
    url = make_url(raw)
    if url.get_backend_name() != "postgresql" or url.database != "mce":
        raise SystemExit("RECHAZADO: MCE_DATABASE_URL no apunta exactamente a PostgreSQL/mce")
    checkpoint_dir = Path(os.environ["LOCALAPPDATA"]) / "MCE Desktop" / "checkpoints"
    candidates = sorted(checkpoint_dir.glob("*.json"), key=lambda path: path.stat().st_mtime)
    if not candidates:
        raise SystemExit("RECHAZADO: no existe checkpoint")
    checkpoint = candidates[-1]
    store = JsonCheckpointStore(checkpoint_dir)
    processing = store.load(checkpoint.stem)
    anime = tuple(item for item in processing.items if item.detected_category == "anime")
    groups = {item.work_group_id for item in anime}
    if len(anime) != EXPECTED_FILES or len(groups) != EXPECTED_GROUPS:
        raise SystemExit(
            f"RECHAZADO: se esperaban 75 archivos/5 grupos y hay {len(anime)}/{len(groups)}"
        )
    engine = create_engine(raw, pool_pre_ping=True)
    factory = sessionmaker(engine, expire_on_commit=False)
    with factory() as database:
        rows = tuple(
            database.scalars(
                select(ContentModel).where(ContentModel.id.in_(EXPECTED_CONTENTS))
            )
        )
        actual = {row.id: row.main_title for row in rows}
        linked = database.scalar(
            select(func.count())
            .select_from(PhysicalFileModel)
            .where(PhysicalFileModel.content_id.in_(EXPECTED_CONTENTS))
        )
    print(f"modo={'apply' if args.apply else 'dry-run'}")
    print(f"checkpoint={checkpoint.name}")
    print(f"anime_archivos={len(anime)}")
    print(f"anime_grupos={len(groups)}")
    print(f"contenidos_incompletos={actual}")
    print(f"archivos_vinculados={linked}")
    if actual != EXPECTED_CONTENTS or linked != 0:
        raise SystemExit("RECHAZADO: los contenidos ya no coinciden con la auditoría aprobada")
    if not args.apply:
        engine.dispose()
        return 0
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    backup = checkpoint.with_suffix(f".before-anime-repair-{stamp}.json")
    shutil.copy2(checkpoint, backup)
    with factory.begin() as database:
        database.add(
            AuditEventModel(
                id=str(uuid4()),
                occurred_at=datetime.now(UTC),
                actor="codex-repair",
                action="revert_incomplete_anime_approval",
                object_type="content_batch",
                object_id="first-anime-approval",
                previous_value={
                    "content_ids": list(EXPECTED_CONTENTS),
                    "titles": list(EXPECTED_CONTENTS.values()),
                },
                new_value={"status": "returned_to_review", "groups": 5, "files": 75},
                correlation_id=str(uuid4()),
                reversible=False,
                reversed_by=None,
            )
        )
        for content_id in EXPECTED_CONTENTS:
            row = database.get(ContentModel, content_id)
            if row is None:
                raise RuntimeError(f"contenido desapareció durante reparación: {content_id}")
            database.delete(row)
    reset_ids = {item.item_id for item in anime}
    repaired_items = tuple(
        replace(
            item,
            stage=ProcessingStage.READY_FOR_ENRICHMENT,
            status=SessionItemStatus.PENDING,
            warning=None,
            parent_content_id=None,
            enrichment_status="pending_enrichment",
            identification_confidence=None,
            metadata_confidence=None,
            final_confidence=None,
            review_reason=None,
        )
        if item.item_id in reset_ids
        else item
        for item in processing.items
    )
    repaired = replace(
        processing,
        items=repaired_items,
        status=SessionStatus.READY,
        failure_reason=None,
        updated_at=datetime.now(UTC),
    )
    store.save(repaired)
    engine.dispose()
    print(f"backup={backup}")
    print("resultado=REPARACION_COMPLETADA")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
