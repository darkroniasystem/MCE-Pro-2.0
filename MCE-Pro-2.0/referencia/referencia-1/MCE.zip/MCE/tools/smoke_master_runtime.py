"""Comprueba el runtime gráfico contra el catálogo maestro sin escribir datos."""

from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from mce.infrastructure.runtime import RuntimePaths, resource_path
from mce.presentation.main_window import MainWindow


def main() -> int:
    if not os.environ.get("MCE_DATABASE_URL"):
        print("BLOQUEADO: MCE_DATABASE_URL no disponible")
        return 2
    app = QApplication.instance() or QApplication([])
    paths = RuntimePaths.discover()
    window = MainWindow(
        QSettings(str(paths.configuration / "smoke-master.ini"), QSettings.Format.IniFormat),
        runtime_paths=paths,
    )
    report = window.health_service.inspect(resource_path("alembic.ini").parent, paths.cache)
    checks = {item.name: item.status for item in report.checks}
    badge_ok = "catálogo maestro" in window.database_badge.text()
    persistence_ok = (
        window.metadata_persistence is not None and window.audit_persistence is not None
    )
    database_ok = checks.get("postgresql") == "ok" and checks.get("migrations") == "ok"
    window.close()
    app.processEvents()
    print(f"badge_catalogo_maestro: {'correcto' if badge_ok else 'incorrecto'}")
    print(f"persistencia_runtime: {'activa' if persistence_ok else 'inactiva'}")
    print(f"postgresql: {checks.get('postgresql', 'faltante')}")
    print(f"migraciones: {checks.get('migrations', 'faltante')}")
    print("credenciales: ocultas")
    return 0 if badge_ok and persistence_ok and database_ok else 4


if __name__ == "__main__":
    raise SystemExit(main())
