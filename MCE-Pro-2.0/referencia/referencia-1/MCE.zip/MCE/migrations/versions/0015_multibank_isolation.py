"""Aislamiento obligatorio de rutas y disponibilidad por banco.

Revision ID: 0015
Revises: 0014
"""

import sqlalchemy as sa
from alembic import op

revision = "0015"
down_revision = "0014"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.add_column("physical_files", sa.Column("bank_id", sa.String(36), nullable=True))
    op.execute(
        """
        UPDATE physical_files AS pf
        SET bank_id = installations.bank_id
        FROM scans
        JOIN installations ON installations.id = scans.installation_id
        WHERE scans.id = pf.scan_id
        """
    )
    op.alter_column("physical_files", "bank_id", nullable=False)
    op.create_foreign_key(
        "fk_physical_files_bank_id_banks",
        "physical_files",
        "banks",
        ["bank_id"],
        ["id"],
        ondelete="RESTRICT",
    )
    op.create_index("ix_physical_files_bank_id", "physical_files", ["bank_id"])
    op.create_index(
        "ix_physical_files_bank_source_path",
        "physical_files",
        ["bank_id", "source_id", "normalized_path"],
    )

    op.add_column("availabilities", sa.Column("bank_id", sa.String(36), nullable=True))
    op.execute(
        """
        UPDATE availabilities AS availability
        SET bank_id = COALESCE(
            NULLIF(availability.payload ->> 'bank_id', ''),
            contents.bank_id
        )
        FROM contents
        WHERE contents.id = availability.content_id
        """
    )
    op.alter_column("availabilities", "bank_id", nullable=False)
    op.create_foreign_key(
        "fk_availabilities_bank_id_banks",
        "availabilities",
        "banks",
        ["bank_id"],
        ["id"],
        ondelete="RESTRICT",
    )
    op.create_index("ix_availabilities_bank_id", "availabilities", ["bank_id"])
    op.create_unique_constraint(
        "uq_availabilities_content_bank",
        "availabilities",
        ["content_id", "bank_id"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_availabilities_content_bank", "availabilities", type_="unique"
    )
    op.drop_index("ix_availabilities_bank_id", table_name="availabilities")
    op.drop_constraint(
        "fk_availabilities_bank_id_banks", "availabilities", type_="foreignkey"
    )
    op.drop_column("availabilities", "bank_id")
    op.drop_index("ix_physical_files_bank_source_path", table_name="physical_files")
    op.drop_index("ix_physical_files_bank_id", table_name="physical_files")
    op.drop_constraint(
        "fk_physical_files_bank_id_banks", "physical_files", type_="foreignkey"
    )
    op.drop_column("physical_files", "bank_id")
