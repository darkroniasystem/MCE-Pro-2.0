"""Versiones completas y activación atómica del catálogo.

Revision ID: 0017
Revises: 0016
"""

import sqlalchemy as sa
from alembic import op

revision = "0017"
down_revision = "0016"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.create_table(
        "catalog_publications",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("catalog_version", sa.Integer(), nullable=False),
        sa.Column(
            "previous_version_id",
            sa.String(36),
            sa.ForeignKey("catalog_publications.id", ondelete="RESTRICT"),
        ),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("validation_report", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("published_at", sa.DateTime(timezone=True)),
        sa.CheckConstraint(
            "status IN ('failed','active','superseded')",
            name="ck_catalog_publications_status",
        ),
        sa.UniqueConstraint("catalog_version"),
    )
    op.create_index(
        "ix_catalog_publications_catalog_version",
        "catalog_publications",
        ["catalog_version"],
    )
    op.create_index(
        "ix_catalog_publications_status", "catalog_publications", ["status"]
    )
    op.create_index(
        "uq_catalog_publications_single_active",
        "catalog_publications",
        ["status"],
        unique=True,
        postgresql_where=sa.text("status = 'active'"),
    )
    op.create_table(
        "catalog_publication_entries",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "publication_id",
            sa.String(36),
            sa.ForeignKey("catalog_publications.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "content_id",
            sa.String(36),
            sa.ForeignKey("contents.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "bank_id",
            sa.String(36),
            sa.ForeignKey("banks.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(
            "publication_id",
            "content_id",
            "bank_id",
            name="uq_publication_content_bank",
        ),
    )
    op.create_index(
        "ix_catalog_publication_entries_publication_id",
        "catalog_publication_entries",
        ["publication_id"],
    )
    op.create_index(
        "ix_catalog_publication_entries_content_id",
        "catalog_publication_entries",
        ["content_id"],
    )
    op.create_index(
        "ix_catalog_publication_entries_bank_id",
        "catalog_publication_entries",
        ["bank_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_catalog_publication_entries_bank_id",
        table_name="catalog_publication_entries",
    )
    op.drop_index(
        "ix_catalog_publication_entries_content_id",
        table_name="catalog_publication_entries",
    )
    op.drop_index(
        "ix_catalog_publication_entries_publication_id",
        table_name="catalog_publication_entries",
    )
    op.drop_table("catalog_publication_entries")
    op.drop_index(
        "uq_catalog_publications_single_active", table_name="catalog_publications"
    )
    op.drop_index("ix_catalog_publications_status", table_name="catalog_publications")
    op.drop_index(
        "ix_catalog_publications_catalog_version", table_name="catalog_publications"
    )
    op.drop_table("catalog_publications")
