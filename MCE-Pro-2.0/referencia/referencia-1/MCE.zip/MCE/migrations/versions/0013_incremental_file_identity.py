"""Identidad lógica estable para importación incremental.

Revision ID: 0013
Revises: 0012
"""

import sqlalchemy as sa
from alembic import op

revision = "0013"
down_revision = "0012"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.create_table(
        "catalog_file_identities",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "bank_id",
            sa.String(36),
            sa.ForeignKey("banks.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "source_id",
            sa.String(36),
            sa.ForeignKey("sources.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("normalized_path", sa.Text(), nullable=False),
        sa.Column(
            "first_seen_scan_id",
            sa.String(36),
            sa.ForeignKey("scans.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column(
            "last_seen_scan_id",
            sa.String(36),
            sa.ForeignKey("scans.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("first_seen_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, server_default="present"),
        sa.UniqueConstraint("bank_id", "source_id", "normalized_path"),
    )
    op.create_index("ix_catalog_file_identities_bank_id", "catalog_file_identities", ["bank_id"])
    op.create_index(
        "ix_catalog_file_identities_source_id", "catalog_file_identities", ["source_id"]
    )
    op.create_index(
        "ix_catalog_file_identities_last_seen_scan_id",
        "catalog_file_identities",
        ["last_seen_scan_id"],
    )
    op.add_column(
        "physical_files",
        sa.Column(
            "catalog_file_id",
            sa.String(36),
            sa.ForeignKey("catalog_file_identities.id", ondelete="RESTRICT"),
            nullable=True,
        ),
    )
    op.create_index("ix_physical_files_catalog_file_id", "physical_files", ["catalog_file_id"])


def downgrade() -> None:
    op.drop_index("ix_physical_files_catalog_file_id", table_name="physical_files")
    op.drop_column("physical_files", "catalog_file_id")
    op.drop_index(
        "ix_catalog_file_identities_last_seen_scan_id",
        table_name="catalog_file_identities",
    )
    op.drop_index("ix_catalog_file_identities_source_id", table_name="catalog_file_identities")
    op.drop_index("ix_catalog_file_identities_bank_id", table_name="catalog_file_identities")
    op.drop_table("catalog_file_identities")
