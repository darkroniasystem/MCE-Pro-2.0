"""Ledger durable de sesiones y auditoría de consolidación.

Revision ID: 0010
Revises: 0009
"""

import sqlalchemy as sa
from alembic import op

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None


SESSION_COLUMNS = (
    sa.Column("scan_id", sa.String(36)),
    sa.Column("bank_id", sa.String(36)),
    sa.Column("external_bank_id", sa.String(255)),
    sa.Column("schema_version", sa.String(32)),
    sa.Column("msl_app_version", sa.String(32)),
    sa.Column("original_filename", sa.String(255)),
    sa.Column("original_size", sa.BigInteger()),
    sa.Column("original_reference", sa.Text()),
    sa.Column("completed_at", sa.DateTime(timezone=True)),
    sa.Column("interrupted_at", sa.DateTime(timezone=True)),
    sa.Column("recoverable", sa.Boolean(), nullable=False, server_default=sa.false()),
    sa.Column("current_stage", sa.String(32)),
    sa.Column("total_expected", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("processed_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("inserted_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("updated_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("duplicate_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("skipped_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("warning_count", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("error_count", sa.Integer(), nullable=False, server_default="0"),
)

JOB_COLUMNS = (
    sa.Column("job_type", sa.String(32), nullable=False, server_default="import"),
    sa.Column("total", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("processed", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("succeeded", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("failed", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("skipped", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("cache_hits", sa.Integer(), nullable=False, server_default="0"),
    sa.Column("current_checkpoint", sa.String(36)),
    sa.Column("worker_owner", sa.String(255)),
    sa.Column("started_at", sa.DateTime(timezone=True)),
    sa.Column(
        "updated_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()
    ),
    sa.Column("completed_at", sa.DateTime(timezone=True)),
    sa.Column("error_summary", sa.Text()),
)


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    for column in SESSION_COLUMNS:
        op.add_column("processing_sessions", column)
    op.create_foreign_key(
        "fk_processing_sessions_bank_id", "processing_sessions", "banks", ["bank_id"], ["id"]
    )
    op.create_index("ix_processing_sessions_scan_id", "processing_sessions", ["scan_id"])
    op.create_index("ix_processing_sessions_bank_id", "processing_sessions", ["bank_id"])
    op.create_index(
        "ix_processing_sessions_external_bank_id",
        "processing_sessions",
        ["external_bank_id"],
    )
    for column in JOB_COLUMNS:
        op.add_column("processing_jobs", column)
    op.create_table(
        "processing_checkpoints",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "job_id",
            sa.String(36),
            sa.ForeignKey("processing_jobs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("stage", sa.String(32), nullable=False),
        sa.Column("batch_number", sa.Integer(), nullable=False),
        sa.Column("last_completed_item", sa.String(36)),
        sa.Column("processed_count", sa.Integer(), nullable=False),
        sa.Column("resume_data", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("checksum", sa.String(64), nullable=False),
        sa.UniqueConstraint("job_id", "stage", "batch_number"),
    )
    op.create_index("ix_processing_checkpoints_job_id", "processing_checkpoints", ["job_id"])
    op.create_table(
        "bank_consolidations",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("external_bank_id", sa.String(255), nullable=False),
        sa.Column("canonical_bank_id", sa.String(36), nullable=False),
        sa.Column("merged_bank_ids", sa.JSON(), nullable=False),
        sa.Column("affected_tables", sa.JSON(), nullable=False),
        sa.Column("moved_records", sa.Integer(), nullable=False),
        sa.Column("conflicts", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("result", sa.String(32), nullable=False),
        sa.Column("rollback_reference", sa.Text()),
    )
    op.create_index(
        "ix_bank_consolidations_external_bank_id", "bank_consolidations", ["external_bank_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_bank_consolidations_external_bank_id", table_name="bank_consolidations")
    op.drop_table("bank_consolidations")
    op.drop_index("ix_processing_checkpoints_job_id", table_name="processing_checkpoints")
    op.drop_table("processing_checkpoints")
    for column in reversed(JOB_COLUMNS):
        op.drop_column("processing_jobs", column.name)
    op.drop_index("ix_processing_sessions_external_bank_id", table_name="processing_sessions")
    op.drop_index("ix_processing_sessions_bank_id", table_name="processing_sessions")
    op.drop_index("ix_processing_sessions_scan_id", table_name="processing_sessions")
    op.drop_constraint("fk_processing_sessions_bank_id", "processing_sessions", type_="foreignkey")
    for column in reversed(SESSION_COLUMNS):
        op.drop_column("processing_sessions", column.name)
