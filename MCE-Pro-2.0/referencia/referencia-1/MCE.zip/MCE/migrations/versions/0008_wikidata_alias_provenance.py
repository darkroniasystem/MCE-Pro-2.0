"""Wikidata, título preferido y procedencia completa de alias.

Revision ID: 0008
Revises: 0007
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    if "catalog_publications" in inspect(bind).get_table_names():
        return
    contents_columns = {
        column["name"] for column in inspect(bind).get_columns("contents")
    }
    if "preferred_display_title" not in contents_columns:
        op.add_column(
            "contents", sa.Column("preferred_display_title", sa.String(500))
        )
    alias_columns = {
        column["name"] for column in inspect(bind).get_columns("content_aliases")
    }
    for column in (
        sa.Column("provider", sa.String(32)),
        sa.Column("provider_entity_id", sa.String(64)),
        sa.Column(
            "is_manual",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
        sa.Column("confidence", sa.Float()),
    ):
        if column.name not in alias_columns:
            op.add_column("content_aliases", column)
    op.execute("UPDATE content_aliases SET provider = source WHERE provider IS NULL")
    inspector = inspect(bind)
    unique_constraints = {
        item["name"] for item in inspector.get_unique_constraints("content_aliases")
    }
    if "uq_bank_normalized_alias" in unique_constraints:
        op.drop_constraint(
            "uq_bank_normalized_alias", "content_aliases", type_="unique"
        )
    if "uq_content_bank_normalized_alias" not in unique_constraints:
        op.create_unique_constraint(
            "uq_content_bank_normalized_alias",
            "content_aliases",
            ["content_id", "bank_id", "normalized_alias"],
        )
    indexes = {
        item["name"] for item in inspect(bind).get_indexes("content_aliases")
    }
    for name, columns in (
        ("ix_content_aliases_provider", ["provider"]),
        ("ix_content_aliases_provider_entity_id", ["provider_entity_id"]),
        ("ix_content_aliases_language", ["language"]),
        ("ix_content_aliases_normalized", ["normalized_alias"]),
    ):
        if name not in indexes:
            op.create_index(name, "content_aliases", columns)


def downgrade() -> None:
    op.drop_index("ix_content_aliases_normalized", table_name="content_aliases")
    op.drop_index("ix_content_aliases_language", table_name="content_aliases")
    op.drop_index("ix_content_aliases_provider_entity_id", table_name="content_aliases")
    op.drop_index("ix_content_aliases_provider", table_name="content_aliases")
    op.drop_constraint(
        "uq_content_bank_normalized_alias", "content_aliases", type_="unique"
    )
    op.create_unique_constraint(
        "uq_bank_normalized_alias",
        "content_aliases",
        ["bank_id", "normalized_alias"],
    )
    op.drop_column("content_aliases", "confidence")
    op.drop_column("content_aliases", "is_manual")
    op.drop_column("content_aliases", "provider_entity_id")
    op.drop_column("content_aliases", "provider")
    op.drop_column("contents", "preferred_display_title")
