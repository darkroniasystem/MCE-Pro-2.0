"""Resumen persistido para la vista de enriquecimiento.

Revision ID: 0020
Revises: 0019
"""

import sqlalchemy as sa
from alembic import op

revision = "0020"
down_revision = "0019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    columns = {
        column["name"]
        for column in sa.inspect(op.get_bind()).get_columns("processing_sessions")
    }
    if "enrichment_summary" not in columns:
        op.add_column(
            "processing_sessions",
            sa.Column(
                "enrichment_summary",
                sa.JSON(),
                nullable=False,
                server_default=sa.text("'{}'::json"),
            ),
        )
        op.execute(
            sa.text(
                """
                UPDATE processing_sessions AS session
                   SET enrichment_summary = summary.payload
                  FROM (
                        SELECT session_id,
                               json_object_agg(category, category_payload) AS payload
                          FROM (
                                SELECT session_id,
                                       coalesce(
                                           state->>'detected_category', 'unclassified'
                                       ) AS category,
                                       json_build_object(
                                           'total', count(*),
                                           'works', count(DISTINCT coalesce(
                                               state->>'work_group_id', id
                                           )),
                                           'ready', count(*) FILTER (
                                               WHERE state->>'stage' = 'ready_for_enrichment'
                                           ),
                                           'uncertain', count(*) FILTER (
                                               WHERE state->>'classification_status' IN (
                                                   'classification_uncertain', 'unclassified'
                                               )
                                           ),
                                           'completed', count(*) FILTER (
                                               WHERE state->>'enrichment_status'
                                                     = 'enrichment_complete'
                                           ),
                                           'rejected', count(*) FILTER (
                                               WHERE state->>'enrichment_status'
                                                     = 'review_rejected'
                                           ),
                                           'reviews', count(*) FILTER (
                                               WHERE state->>'enrichment_status'
                                                     = 'needs_human_review'
                                           )
                                       ) AS category_payload
                                  FROM processing_session_items
                                 GROUP BY session_id, category
                               ) AS categories
                         GROUP BY session_id
                       ) AS summary
                 WHERE summary.session_id = session.id
                """
            )
        )


def downgrade() -> None:
    columns = {
        column["name"]
        for column in sa.inspect(op.get_bind()).get_columns("processing_sessions")
    }
    if "enrichment_summary" in columns:
        op.drop_column("processing_sessions", "enrichment_summary")
