"""Agrupación de obras, publicación controlada y lotes reversibles."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None


def _add_missing(table: str, columns: tuple[sa.Column, ...]) -> None:
    existing = {
        column["name"] for column in inspect(op.get_bind()).get_columns(table)
    }
    for column in columns:
        if column.name not in existing:
            op.add_column(table, column)


def upgrade() -> None:
    _add_missing(
        "contents",
        (
            sa.Column(
                "parent_content_id",
                sa.String(36),
                sa.ForeignKey("contents.id", ondelete="SET NULL"),
                nullable=True,
            ),
            sa.Column("work_group_id", sa.String(36), nullable=True),
            sa.Column(
                "publication_status",
                sa.String(32),
                nullable=False,
                server_default="publication_blocked",
            ),
            sa.Column("publication_block_reason", sa.Text(), nullable=True),
            sa.Column("identification_confidence", sa.Float(), nullable=True),
            sa.Column("metadata_confidence", sa.Float(), nullable=True),
            sa.Column("matching_version", sa.String(64), nullable=True),
            sa.Column("metadata_merge_version", sa.String(64), nullable=True),
            sa.Column("publication_policy_version", sa.String(64), nullable=True),
        ),
    )
    _add_missing(
        "physical_files",
        (
            sa.Column("work_group_id", sa.String(36), nullable=True),
            sa.Column("grouping_confidence", sa.Float(), nullable=True),
            sa.Column("grouping_reason", sa.Text(), nullable=True),
            sa.Column("grouping_version", sa.String(64), nullable=True),
            sa.Column(
                "grouping_status",
                sa.String(32),
                nullable=False,
                server_default="grouping_pending",
            ),
        ),
    )
    inspector = inspect(op.get_bind())
    tables = set(inspector.get_table_names())
    for table in ("operation_batches", "correction_rules"):
        if table not in tables:
            op.create_table(
                table,
                sa.Column("id", sa.String(36), primary_key=True),
                sa.Column("payload", sa.JSON(), nullable=False, server_default="{}"),
                sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
            )
    indexes = {index["name"] for index in inspector.get_indexes("contents")}
    if "ix_contents_work_group_id" not in indexes:
        op.create_index("ix_contents_work_group_id", "contents", ["work_group_id"])
    if "ix_contents_publication_status" not in indexes:
        op.create_index(
            "ix_contents_publication_status", "contents", ["publication_status"]
        )
    file_indexes = {
        index["name"] for index in inspector.get_indexes("physical_files")
    }
    if "ix_physical_files_work_group_id" not in file_indexes:
        op.create_index(
            "ix_physical_files_work_group_id", "physical_files", ["work_group_id"]
        )
    if "ix_physical_files_grouping_status" not in file_indexes:
        op.create_index(
            "ix_physical_files_grouping_status",
            "physical_files",
            ["grouping_status"],
        )


def downgrade() -> None:
    op.drop_index("ix_physical_files_grouping_status", table_name="physical_files")
    op.drop_index("ix_physical_files_work_group_id", table_name="physical_files")
    op.drop_index("ix_contents_publication_status", table_name="contents")
    op.drop_index("ix_contents_work_group_id", table_name="contents")
    op.drop_table("correction_rules")
    op.drop_table("operation_batches")
    for column in (
        "grouping_status",
        "grouping_version",
        "grouping_reason",
        "grouping_confidence",
        "work_group_id",
    ):
        op.drop_column("physical_files", column)
    for column in (
        "publication_policy_version",
        "metadata_merge_version",
        "matching_version",
        "metadata_confidence",
        "identification_confidence",
        "publication_block_reason",
        "publication_status",
        "work_group_id",
        "parent_content_id",
    ):
        op.drop_column("contents", column)
