"""Separa preparación local, enriquecimiento online y revisión terminal."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = inspect(bind)
    provider_columns = {
        column["name"] for column in inspector.get_columns("provider_queries")
    }
    if "result_count" not in provider_columns:
        op.add_column(
            "provider_queries", sa.Column("result_count", sa.Integer(), nullable=True)
        )
    if "next_retry_at" not in provider_columns:
        op.add_column(
            "provider_queries",
            sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True),
        )
    columns = (
        sa.Column("detected_category", sa.String(64), nullable=True),
        sa.Column("category_confidence", sa.Float(), nullable=True),
        sa.Column(
            "classification_status",
            sa.String(32),
            nullable=False,
            server_default="classification_pending",
        ),
        sa.Column("clean_title", sa.String(500), nullable=True),
        sa.Column("detected_year", sa.Integer(), nullable=True),
        sa.Column("season_number", sa.Integer(), nullable=True),
        sa.Column("episode_number", sa.Integer(), nullable=True),
        sa.Column(
            "cleaning_status",
            sa.String(32),
            nullable=False,
            server_default="cleaning_pending",
        ),
        sa.Column(
            "enrichment_status",
            sa.String(32),
            nullable=False,
            server_default="pending_enrichment",
        ),
        sa.Column("final_confidence", sa.Float(), nullable=True),
        sa.Column("review_reason", sa.Text(), nullable=True),
        sa.Column("next_retry_at", sa.DateTime(timezone=True), nullable=True),
    )
    physical_columns = {
        column["name"] for column in inspector.get_columns("physical_files")
    }
    for column in columns:
        if column.name not in physical_columns:
            op.add_column("physical_files", column)
    indexes = {index["name"] for index in inspector.get_indexes("physical_files")}
    for name, column in (
        ("ix_physical_files_detected_category", "detected_category"),
        ("ix_physical_files_classification_status", "classification_status"),
        ("ix_physical_files_cleaning_status", "cleaning_status"),
        ("ix_physical_files_enrichment_status", "enrichment_status"),
    ):
        if name not in indexes:
            op.create_index(name, "physical_files", [column])
    tables = set(inspector.get_table_names())
    for table in ("classification_sessions", "cleaning_sessions", "enrichment_sessions"):
        if table not in tables:
            op.create_table(
                table,
                sa.Column("id", sa.String(36), primary_key=True),
                sa.Column("payload", sa.JSON(), nullable=False, server_default="{}"),
                sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
            )


def downgrade() -> None:
    for table in ("enrichment_sessions", "cleaning_sessions", "classification_sessions"):
        op.drop_table(table)
    for name in (
        "ix_physical_files_enrichment_status",
        "ix_physical_files_cleaning_status",
        "ix_physical_files_classification_status",
        "ix_physical_files_detected_category",
    ):
        op.drop_index(name, table_name="physical_files")
    for column in (
        "next_retry_at",
        "review_reason",
        "final_confidence",
        "enrichment_status",
        "cleaning_status",
        "episode_number",
        "season_number",
        "detected_year",
        "clean_title",
        "classification_status",
        "category_confidence",
        "detected_category",
    ):
        op.drop_column("physical_files", column)
    op.drop_column("provider_queries", "next_retry_at")
    op.drop_column("provider_queries", "result_count")
