"""Persistencia normalizada de proveedores para la Fase 10."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

from mce.infrastructure.database.models import (
    ContentAliasModel,
    ExternalIdentifierModel,
    NormalizedMetadataModel,
    ProviderQueryModel,
)

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = inspect(bind)
    columns = {item["name"] for item in inspector.get_columns("contents")}
    if "bank_id" not in columns:
        op.add_column("contents", sa.Column("bank_id", sa.String(36)))
        op.create_foreign_key(
            "fk_contents_bank_id_banks",
            "contents",
            "banks",
            ["bank_id"],
            ["id"],
            ondelete="RESTRICT",
        )
        op.create_index("ix_contents_bank_id", "contents", ["bank_id"])
    existing = set(inspector.get_table_names())
    for table in (
        ExternalIdentifierModel.__table__,
        ContentAliasModel.__table__,
        NormalizedMetadataModel.__table__,
        ProviderQueryModel.__table__,
    ):
        if table.name not in existing:
            table.create(bind)


def downgrade() -> None:
    bind = op.get_bind()
    existing = set(inspect(bind).get_table_names())
    for table in (
        ProviderQueryModel.__table__,
        NormalizedMetadataModel.__table__,
        ContentAliasModel.__table__,
        ExternalIdentifierModel.__table__,
    ):
        if table.name in existing:
            table.drop(bind)
    columns = {item["name"] for item in inspect(bind).get_columns("contents")}
    if "bank_id" in columns:
        inspector = inspect(bind)
        indexes = {item.get("name") for item in inspector.get_indexes("contents")}
        if "ix_contents_bank_id" in indexes:
            op.drop_index("ix_contents_bank_id", table_name="contents")
        foreign_keys = {
            item.get("name")
            for item in inspector.get_foreign_keys("contents")
            if item.get("constrained_columns") == ["bank_id"]
        }
        for name in foreign_keys:
            if name:
                op.drop_constraint(name, "contents", type_="foreignkey")
        op.drop_column("contents", "bank_id")
