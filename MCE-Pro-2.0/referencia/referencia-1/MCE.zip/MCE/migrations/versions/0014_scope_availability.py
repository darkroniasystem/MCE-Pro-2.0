"""Disponibilidad reconciliada según alcance de escaneo.

Revision ID: 0014
Revises: 0013
"""

import sqlalchemy as sa
from alembic import op

revision = "0014"
down_revision = "0013"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.add_column(
        "catalog_file_identities",
        sa.Column(
            "missing_since_scan_id",
            sa.String(36),
            sa.ForeignKey("scans.id", ondelete="RESTRICT"),
            nullable=True,
        ),
    )
    op.add_column(
        "catalog_file_identities",
        sa.Column("availability_checked_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_table(
        "availability_events",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "catalog_file_id",
            sa.String(36),
            sa.ForeignKey("catalog_file_identities.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "scan_id",
            sa.String(36),
            sa.ForeignKey("scans.id", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("previous_status", sa.String(32), nullable=False),
        sa.Column("new_status", sa.String(32), nullable=False),
        sa.Column("reason", sa.String(64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index(
        "ix_availability_events_catalog_file_id",
        "availability_events",
        ["catalog_file_id"],
    )
    op.create_index("ix_availability_events_scan_id", "availability_events", ["scan_id"])


def downgrade() -> None:
    op.drop_index("ix_availability_events_scan_id", table_name="availability_events")
    op.drop_index(
        "ix_availability_events_catalog_file_id",
        table_name="availability_events",
    )
    op.drop_table("availability_events")
    op.drop_column("catalog_file_identities", "availability_checked_at")
    op.drop_column("catalog_file_identities", "missing_since_scan_id")
