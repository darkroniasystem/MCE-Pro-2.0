"""Identidad externa estable para bancos MSL.

Revision ID: 0009
Revises: 0008
"""

import sqlalchemy as sa
from alembic import op

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.add_column("banks", sa.Column("external_bank_id", sa.String(255)))
    op.create_index(
        "ix_banks_external_bank_id",
        "banks",
        ["external_bank_id"],
        unique=True,
    )


def downgrade() -> None:
    op.drop_index("ix_banks_external_bank_id", table_name="banks")
    op.drop_column("banks", "external_bank_id")
