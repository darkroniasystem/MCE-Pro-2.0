"""Títulos multilingües, alias trazables y búsqueda normalizada."""

import sqlalchemy as sa
from alembic import op
from sqlalchemy import inspect

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def _add_missing(table: str, columns: tuple[sa.Column, ...]) -> None:
    existing = {
        column["name"] for column in inspect(op.get_bind()).get_columns(table)
    }
    for column in columns:
        if column.name not in existing:
            op.add_column(table, column)


def upgrade() -> None:
    _add_missing(
        "contents",
        (
            sa.Column("raw_bank_title", sa.String(500), nullable=True),
            sa.Column("clean_bank_title", sa.String(500), nullable=True),
            sa.Column("spanish_title", sa.String(500), nullable=True),
            sa.Column("english_title", sa.String(500), nullable=True),
            sa.Column("normalized_search_text", sa.Text(), nullable=True),
        ),
    )
    _add_missing(
        "content_aliases",
        (
            sa.Column("language", sa.String(32), nullable=True),
            sa.Column("country", sa.String(8), nullable=True),
            sa.Column(
                "alias_type",
                sa.String(32),
                nullable=False,
                server_default="alternative",
            ),
            sa.Column("provenance", sa.String(255), nullable=True),
        ),
    )
    inspector = inspect(op.get_bind())
    indexes = {index["name"] for index in inspector.get_indexes("content_aliases")}
    if "ix_content_aliases_normalized_alias" not in indexes:
        op.create_index(
            "ix_content_aliases_normalized_alias",
            "content_aliases",
            ["normalized_alias"],
        )
    content_indexes = {index["name"] for index in inspector.get_indexes("contents")}
    if "ix_contents_normalized_search_text" not in content_indexes:
        op.create_index(
            "ix_contents_normalized_search_text",
            "contents",
            ["normalized_search_text"],
        )
    if op.get_bind().dialect.name == "postgresql":
        op.execute("DROP VIEW IF EXISTS bot_catalog_v1")
        op.execute(
            """
            CREATE OR REPLACE VIEW bot_catalog_v1 AS
            SELECT
                c.id AS content_id,
                c.main_title AS title,
                c.original_title,
                c.spanish_title,
                c.english_title,
                c.raw_bank_title,
                c.clean_bank_title,
                c.content_type,
                c.release_year AS year,
                c.bank_id,
                COALESCE(
                    (SELECT jsonb_agg(a.alias ORDER BY a.alias)
                       FROM content_aliases a
                      WHERE a.content_id = c.id
                        AND (a.bank_id IS NULL OR a.bank_id = c.bank_id)),
                    '[]'::jsonb
                ) AS aliases,
                c.normalized_search_text,
                COALESCE(
                    (SELECT jsonb_object_agg(m.field_name, m.value)
                       FROM normalized_metadata m WHERE m.content_id = c.id),
                    '{}'::jsonb
                ) AS metadata,
                'mce.bot.catalog.v1'::text AS contract_version
            FROM contents c
            WHERE c.status = 'active'
            """
        )


def downgrade() -> None:
    if op.get_bind().dialect.name == "postgresql":
        op.execute("DROP VIEW IF EXISTS bot_catalog_v1")
    op.drop_index("ix_contents_normalized_search_text", table_name="contents")
    op.drop_index("ix_content_aliases_normalized_alias", table_name="content_aliases")
    for column in ("provenance", "alias_type", "country", "language"):
        op.drop_column("content_aliases", column)
    for column in (
        "normalized_search_text",
        "english_title",
        "spanish_title",
        "clean_bank_title",
        "raw_bank_title",
    ):
        op.drop_column("contents", column)
