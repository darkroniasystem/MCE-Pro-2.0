"""Auditoria persistente y aislada de la revision mediante IA.

Revision ID: 0022
Revises: 0021
"""

import sqlalchemy as sa
from alembic import op

revision = "0022"
down_revision = "0021"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    if "ai_review_runs" in set(sa.inspect(bind).get_table_names()):
        return
    op.create_table(
        "ai_review_runs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "session_id",
            sa.String(36),
            sa.ForeignKey("processing_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "bank_id",
            sa.String(36),
            sa.ForeignKey("banks.id", ondelete="RESTRICT"),
            nullable=True,
        ),
        sa.Column("work_group_id", sa.String(255), nullable=False),
        sa.Column("query_fingerprint", sa.String(64), nullable=False),
        sa.Column("search_provider", sa.String(32), nullable=False),
        sa.Column("ai_provider", sa.String(32), nullable=False),
        sa.Column("ai_model", sa.String(128), nullable=True),
        sa.Column("prompt_version", sa.String(64), nullable=False),
        sa.Column("schema_version", sa.String(64), nullable=False),
        sa.Column("sanitized_query", sa.JSON(), nullable=False),
        sa.Column("sources", sa.JSON(), nullable=False),
        sa.Column("contradictions", sa.JSON(), nullable=False),
        sa.Column("structured_response", sa.JSON(), nullable=False),
        sa.Column("model_confidence", sa.Float(), nullable=True),
        sa.Column("mce_score", sa.Float(), nullable=True),
        sa.Column("state", sa.String(32), nullable=False),
        sa.Column("decision", sa.String(32), nullable=False),
        sa.Column("cached", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("attempt_count", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("latency_ms", sa.Integer(), nullable=True),
        sa.Column("input_tokens", sa.Integer(), nullable=True),
        sa.Column("output_tokens", sa.Integer(), nullable=True),
        sa.Column("error", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(
            "session_id",
            "work_group_id",
            "query_fingerprint",
            name="uq_ai_review_session_work_fingerprint",
        ),
    )
    op.create_index("ix_ai_review_runs_session_id", "ai_review_runs", ["session_id"])
    op.create_index("ix_ai_review_runs_bank_id", "ai_review_runs", ["bank_id"])
    op.create_index(
        "ix_ai_review_runs_work_group_id", "ai_review_runs", ["work_group_id"]
    )
    op.create_index(
        "ix_ai_review_runs_query_fingerprint",
        "ai_review_runs",
        ["query_fingerprint"],
    )


def downgrade() -> None:
    op.drop_table("ai_review_runs")
