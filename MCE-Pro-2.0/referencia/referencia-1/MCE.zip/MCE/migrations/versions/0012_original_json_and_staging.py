"""Archivo inmutable del JSON original y manifiesto de staging.

Revision ID: 0012
Revises: 0011
"""

import sqlalchemy as sa
from alembic import op

revision = "0012"
down_revision = "0011"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.create_table(
        "original_jsons",
        sa.Column("file_hash", sa.String(64), primary_key=True),
        sa.Column("storage_reference", sa.Text(), nullable=False, unique=True),
        sa.Column("original_filename", sa.String(255), nullable=False),
        sa.Column("size_bytes", sa.BigInteger(), nullable=False),
        sa.Column("schema_version", sa.String(32)),
        sa.Column("status", sa.String(32), nullable=False, server_default="verified"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("length(file_hash)=64"),
        sa.CheckConstraint("size_bytes>=0"),
    )
    op.create_table(
        "import_staging_documents",
        sa.Column(
            "import_id",
            sa.String(36),
            sa.ForeignKey("scan_imports.id", ondelete="CASCADE"),
            primary_key=True,
        ),
        sa.Column(
            "original_hash",
            sa.String(64),
            sa.ForeignKey("original_jsons.file_hash", ondelete="RESTRICT"),
            nullable=False,
        ),
        sa.Column("header", sa.JSON(), nullable=False),
        sa.Column("source_count", sa.Integer(), nullable=False),
        sa.Column("video_count", sa.Integer(), nullable=False),
        sa.Column("subtitle_count", sa.Integer(), nullable=False),
        sa.Column("warning_count", sa.Integer(), nullable=False),
        sa.Column("error_count", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(32), nullable=False, server_default="validated"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index(
        "ix_import_staging_documents_original_hash",
        "import_staging_documents",
        ["original_hash"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_import_staging_documents_original_hash",
        table_name="import_staging_documents",
    )
    op.drop_table("import_staging_documents")
    op.drop_table("original_jsons")
