"""Ruta original seleccionada y contador de inciertos por sesión.

Revision ID: 0018
Revises: 0017
"""

import sqlalchemy as sa
from alembic import op

revision = "0018"
down_revision = "0017"
branch_labels = None
depends_on = None


def upgrade() -> None:
    columns = {
        column["name"]
        for column in sa.inspect(op.get_bind()).get_columns("processing_sessions")
    }
    if "source_path" not in columns:
        op.add_column("processing_sessions", sa.Column("source_path", sa.Text()))
    if "uncertain_count" not in columns:
        op.add_column(
            "processing_sessions",
            sa.Column("uncertain_count", sa.Integer(), nullable=False, server_default="0"),
        )
        op.execute(
            sa.text(
                """
                UPDATE processing_sessions AS session
                   SET uncertain_count = counts.total
                  FROM (
                        SELECT session_id, count(*) AS total
                          FROM processing_session_items
                         WHERE state->>'classification_status'
                               IN ('classification_uncertain', 'unclassified')
                         GROUP BY session_id
                       ) AS counts
                 WHERE counts.session_id = session.id
                """
            )
        )


def downgrade() -> None:
    columns = {
        column["name"]
        for column in sa.inspect(op.get_bind()).get_columns("processing_sessions")
    }
    if "uncertain_count" in columns:
        op.drop_column("processing_sessions", "uncertain_count")
    if "source_path" in columns:
        op.drop_column("processing_sessions", "source_path")