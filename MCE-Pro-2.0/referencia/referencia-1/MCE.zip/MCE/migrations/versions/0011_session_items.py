"""Elementos de sesión normalizados para carga bajo demanda.

Revision ID: 0011
Revises: 0010
"""

import sqlalchemy as sa
from alembic import op

revision = "0011"
down_revision = "0010"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.create_table(
        "processing_session_items",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column(
            "session_id",
            sa.String(36),
            sa.ForeignKey("processing_sessions.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "physical_file_id",
            sa.String(36),
            sa.ForeignKey("physical_files.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
        ),
        sa.Column("ordinal", sa.Integer(), nullable=False),
        sa.Column("state", sa.JSON(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("session_id", "ordinal"),
    )
    op.create_index(
        "ix_processing_session_items_session_id",
        "processing_session_items",
        ["session_id"],
    )


def downgrade() -> None:
    op.drop_index(
        "ix_processing_session_items_session_id",
        table_name="processing_session_items",
    )
    op.drop_table("processing_session_items")
