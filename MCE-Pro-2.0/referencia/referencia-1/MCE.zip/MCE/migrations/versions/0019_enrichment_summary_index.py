"""Indice agregado para la vista de enriquecimiento.

Revision ID: 0019
Revises: 0018
"""

from alembic import op

revision = "0019"
down_revision = "0018"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE INDEX IF NOT EXISTS ix_session_items_enrichment_summary
            ON processing_session_items (
                session_id,
                (state->>'detected_category'),
                (state->>'work_group_id'),
                (state->>'stage'),
                (state->>'classification_status'),
                (state->>'enrichment_status')
            ) INCLUDE (id)
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_session_items_enrichment_summary")
