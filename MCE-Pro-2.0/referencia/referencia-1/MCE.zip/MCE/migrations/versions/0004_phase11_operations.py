"""Auditoría y contrato de consulta de la Fase 11."""

from alembic import op
from sqlalchemy import inspect

from mce.infrastructure.database.models import AuditEventModel

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    if "audit_events" not in inspect(bind).get_table_names():
        AuditEventModel.__table__.create(bind)
    if bind.dialect.name == "postgresql":
        op.execute(
            """
            CREATE OR REPLACE VIEW bot_catalog_v1 AS
            SELECT
                c.id AS content_id,
                c.main_title AS title,
                c.original_title,
                c.content_type,
                c.release_year AS year,
                c.bank_id,
                COALESCE(
                    (SELECT jsonb_agg(a.alias ORDER BY a.alias)
                     FROM content_aliases a WHERE a.content_id = c.id), '[]'::jsonb
                ) AS aliases,
                COALESCE(
                    (SELECT jsonb_object_agg(m.field_name, m.value)
                     FROM normalized_metadata m WHERE m.content_id = c.id), '{}'::jsonb
                ) AS metadata,
                'mce.bot.catalog.v1'::text AS contract_version
            FROM contents c
            WHERE c.status = 'active'
            """
        )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.execute("DROP VIEW IF EXISTS bot_catalog_v1")
    if "audit_events" in inspect(bind).get_table_names():
        AuditEventModel.__table__.drop(bind)
