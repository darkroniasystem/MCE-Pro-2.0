"""Capa canonica y trazabilidad del motor de obra logica.

Revision ID: 0021
Revises: 0020
"""

import sqlalchemy as sa
from alembic import op

revision = "0021"
down_revision = "0020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = set(inspector.get_table_names())
    if "canonical_works" not in tables:
        op.create_table(
            "canonical_works",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("provider", sa.String(32), nullable=False),
            sa.Column("content_type", sa.String(32), nullable=False),
            sa.Column("external_id", sa.String(255), nullable=False),
            sa.Column("official_title", sa.String(500), nullable=False),
            sa.Column("release_year", sa.Integer(), nullable=True),
            sa.Column("metadata", sa.JSON(), nullable=False, server_default=sa.text("'{}'::json")),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.UniqueConstraint(
                "provider", "content_type", "external_id", name="uq_canonical_work_identity"
            ),
        )
    content_columns = {column["name"] for column in sa.inspect(bind).get_columns("contents")}
    if "canonical_work_id" not in content_columns:
        op.add_column("contents", sa.Column("canonical_work_id", sa.String(36), nullable=True))
        op.create_foreign_key(
            "fk_contents_canonical_work_id",
            "contents",
            "canonical_works",
            ["canonical_work_id"],
            ["id"],
            ondelete="RESTRICT",
        )
        op.create_index("ix_contents_canonical_work_id", "contents", ["canonical_work_id"])
    if bind.dialect.name == "postgresql":
        op.execute(
            """
            WITH ranked AS (
                SELECT ei.content_id, ei.provider, ei.external_id, c.content_type,
                       c.main_title, c.release_year,
                       row_number() OVER (
                           PARTITION BY ei.content_id
                           ORDER BY CASE WHEN ei.identifier_type = ei.provider THEN 0 ELSE 1 END,
                                    ei.created_at, ei.id
                       ) AS position
                FROM external_identifiers ei
                JOIN contents c ON c.id = ei.content_id
            ), chosen AS (
                SELECT *,
                       md5(provider || ':' || content_type || ':' || external_id) AS digest
                FROM ranked WHERE position = 1
            )
            INSERT INTO canonical_works(
                id, provider, content_type, external_id, official_title,
                release_year, metadata, created_at, updated_at
            )
            SELECT substr(digest,1,8) || '-' || substr(digest,9,4) || '-' ||
                   substr(digest,13,4) || '-' || substr(digest,17,4) || '-' ||
                   substr(digest,21,12),
                   provider, content_type, external_id, main_title,
                   release_year, '{}'::json, now(), now()
            FROM chosen
            ON CONFLICT (provider, content_type, external_id) DO NOTHING
            """
        )
        op.execute(
            """
            WITH ranked AS (
                SELECT ei.content_id, ei.provider, ei.external_id, c.content_type,
                       row_number() OVER (
                           PARTITION BY ei.content_id
                           ORDER BY CASE WHEN ei.identifier_type = ei.provider THEN 0 ELSE 1 END,
                                    ei.created_at, ei.id
                       ) AS position
                FROM external_identifiers ei
                JOIN contents c ON c.id = ei.content_id
            )
            UPDATE contents c
            SET canonical_work_id = cw.id
            FROM ranked r
            JOIN canonical_works cw
              ON cw.provider = r.provider
             AND cw.content_type = r.content_type
             AND cw.external_id = r.external_id
            WHERE r.position = 1 AND c.id = r.content_id
            """
        )
    physical_columns = {
        column["name"] for column in sa.inspect(bind).get_columns("physical_files")
    }
    additions = (
        ("original_group_title", sa.Column("original_group_title", sa.String(500))),
        ("order_prefix", sa.Column("order_prefix", sa.String(32))),
        ("technical_tags", sa.Column("technical_tags", sa.JSON())),
        ("language_hints", sa.Column("language_hints", sa.JSON())),
        ("normalization_trace", sa.Column("normalization_trace", sa.JSON())),
        ("normalization_version", sa.Column("normalization_version", sa.String(64))),
        (
            "possible_extra",
            sa.Column(
                "possible_extra", sa.Boolean(), nullable=False, server_default=sa.false()
            ),
        ),
    )
    for name, column in additions:
        if name not in physical_columns:
            op.add_column("physical_files", column)


def downgrade() -> None:
    bind = op.get_bind()
    physical_columns = {
        column["name"] for column in sa.inspect(bind).get_columns("physical_files")
    }
    for name in (
        "possible_extra",
        "normalization_version",
        "normalization_trace",
        "language_hints",
        "technical_tags",
        "order_prefix",
        "original_group_title",
    ):
        if name in physical_columns:
            op.drop_column("physical_files", name)
    content_columns = {column["name"] for column in sa.inspect(bind).get_columns("contents")}
    if "canonical_work_id" in content_columns:
        op.drop_index("ix_contents_canonical_work_id", table_name="contents")
        op.drop_constraint(
            "fk_contents_canonical_work_id", "contents", type_="foreignkey"
        )
        op.drop_column("contents", "canonical_work_id")
    if "canonical_works" in set(sa.inspect(bind).get_table_names()):
        op.drop_table("canonical_works")
