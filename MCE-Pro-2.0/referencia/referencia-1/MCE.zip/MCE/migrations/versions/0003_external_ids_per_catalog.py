"""Permite que bancos distintos referencien la misma identidad externa."""

from alembic import op
from sqlalchemy import inspect

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    names = {
        item.get("name")
        for item in inspect(op.get_bind()).get_unique_constraints("external_identifiers")
    }
    if "uq_external_identity" in names:
        op.drop_constraint("uq_external_identity", "external_identifiers", type_="unique")


def downgrade() -> None:
    op.create_unique_constraint(
        "uq_external_identity",
        "external_identifiers",
        ["provider", "identifier_type", "external_id"],
    )
