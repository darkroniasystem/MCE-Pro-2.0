"""Separa staging, catálogo aprobado y catálogo publicado.

Revision ID: 0016
Revises: 0015
"""

import sqlalchemy as sa
from alembic import op

revision = "0016"
down_revision = "0015"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if "catalog_publications" in sa.inspect(op.get_bind()).get_table_names():
        return
    op.add_column(
        "contents",
        sa.Column("catalog_stage", sa.String(16), nullable=True, server_default="staging"),
    )
    op.execute(
        """
        UPDATE contents
        SET catalog_stage = CASE
            WHEN publication_status = 'published' THEN 'published'
            WHEN review_status IN ('approved', 'corrected') THEN 'approved'
            ELSE 'staging'
        END
        """
    )
    op.alter_column("contents", "catalog_stage", nullable=False)
    op.create_check_constraint(
        "ck_contents_catalog_stage",
        "contents",
        "catalog_stage IN ('staging','approved','published')",
    )
    op.create_index("ix_contents_catalog_stage", "contents", ["catalog_stage"])


def downgrade() -> None:
    op.drop_index("ix_contents_catalog_stage", table_name="contents")
    op.drop_constraint("ck_contents_catalog_stage", "contents", type_="check")
    op.drop_column("contents", "catalog_stage")
